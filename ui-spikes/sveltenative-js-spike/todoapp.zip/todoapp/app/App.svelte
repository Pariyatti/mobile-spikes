<page>
    <actionBar title="My Tasks" />

    <tabs tabPostion="bottom">
        <tabStrip>
            <tabStripItem title="To Do" class="tab-text" />
            <tabStripItem title="Completed" class="tab-text" />
        </tabStrip>
        <!-- To Do Tab -->
        <tabContentItem>
            <gridLayout columns="*,120" rows="70,*">
                <textField col="0" row="0"
                           bind:text="{textFieldValue}"
                           hint="Type new task..."
                           editable="true"
                           on:returnPress="{onButtonTap}" />
                <button col="1" row="0" text="Add task" on:tap="{onButtonTap}" class="-primary -outline-lg"/>

                <listView items="{todos}" on:itemTap="{onItemTap}" row="1" colSpan="2">
                    <Template let:item>
                        <label text="{item.name}" textWrap="true"/>
                    </Template>
                </listView>

            </gridLayout>
        </tabContentItem>
        <!-- Completed Tab -->
        <tabContentItem>
            <listView items="{dones}" on:itemTap="{onDoneTap}">
                <Template let:item>
                        <label text="{item.name}" textWrap="true" class="todo-item-completed" />
                </Template>
            </listView>
        </tabContentItem>
    </tabs>
</page>

<script>
    import { Template } from 'svelte-native/components'

    let todos = [];
    let textFieldValue = "";
    let dones = [];

    const removeFromList = (list, item) => list.filter(t => t !== item);
    const addToList = (list, item) => [item, ...list];

    async function onItemTap(args) {
      let result = await action("What do you want to do with this task?", "Cancel", [
          "Mark completed",
          "Delete forever"
      ]);
      console.log(result); // for debugging

      let item = todos[args.index];
      switch (result) {
        case "Mark completed":
          dones = addToList(dones, item); // Adds item to top of completed tasks
          todos = removeFromList(todos, item); // Removes tapped item
          break;
        case "Delete forever":
          todos = removeFromList(todos, item); // Removes tapped item
          break;
        case "Cancel" || undefined: // Dismisses dialog box
          break;
      }
    }

    function onButtonTap() {
        if (textFieldValue === "") return;
        console.log(`New task added: ${textFieldValue}.`);
        todos = [{ name: textFieldValue }, ...todos];
        textFieldValue = "";
    }

    async function onDoneTap(args) {
        let result = await action("What do you want to do with this task?", "Cancel", [
			"Mark To Do",
			"Delete forever"
	    ]);
        console.log(`Completed: ${result}`); // for debugging

        let item = dones[args.index];
        switch (result) {
            case "Mark To Do":
              todos = addToList(todos, item); // Adds tapped item to top of completed tasks
              dones = removeFromList(dones, item); // Removes tapped item
              break;
            case "Delete forever":
              dones = removeFromList(dones, item); // Removes tapped item
              break;
            case "Cancel" || undefined:
              break;
        }

    }
</script>

<style>
    textField {
        font-size: 25;
	}

    .todo-item-completed {
        color: #393939;
        text-decoration: line-through;
    }
</style>
