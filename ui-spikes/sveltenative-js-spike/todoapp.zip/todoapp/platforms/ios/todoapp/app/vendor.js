(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["vendor"],{

/***/ "../node_modules/nativescript-dev-webpack/hmr/hmr-update.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const hot = __webpack_require__("../node_modules/nativescript-dev-webpack/hot.js");
const file_system_1 = __webpack_require__("tns-core-modules/file-system");
function hmrUpdate() {
    const currentAppFolder = file_system_1.knownFolders.currentApp();
    const latestHash = __webpack_require__["h"]();
    return hot(latestHash, filename => {
        const fullFilePath = file_system_1.path.join(currentAppFolder.path, filename);
        return file_system_1.File.exists(fullFilePath) ? currentAppFolder.getFile(filename) : null;
    });
}
exports.hmrUpdate = hmrUpdate;
//# sourceMappingURL=hmr-update.js.map

/***/ }),

/***/ "../node_modules/nativescript-dev-webpack/hmr/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var hmr_update_1 = __webpack_require__("../node_modules/nativescript-dev-webpack/hmr/hmr-update.js");
exports.hmrUpdate = hmr_update_1.hmrUpdate;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "../node_modules/nativescript-dev-webpack/hot.js":
/***/ (function(module, exports, __webpack_require__) {

const hmrPrefix = 'HMR:';
const log = {
    info: (message) => console.info(`${hmrPrefix} ${message}`),
    warn: (message) => console.warn(`${hmrPrefix} ${message}`),
    error: (message) => console.error(`${hmrPrefix} ${message}`),
};
const refresh = 'Application needs to be restarted in order to apply the changes.';
const hotOptions = {
    ignoreUnaccepted: false,
    ignoreDeclined: false,
    ignoreErrored: false,
    onUnaccepted(data) {
        const chain = [].concat(data.chain);
        const last = chain[chain.length - 1];

        if (last === 0) {
            chain.pop();
        }

        log.warn(`Ignored an update to unaccepted module: `);
        chain.forEach(mod => log.warn(`         ➭ ${mod}`));
    },
    onDeclined(data) {
        log.warn(`Ignored an update to declined module:`);
        data.chain.forEach(mod => log.warn(`         ➭ ${mod}`));
    },
    onErrored(data) {
        log.warn(
            `Ignored an error while updating module ${data.moduleId} <${data.type}>`
        );
        log.warn(data.error);
    },
};

let nextHash;
let currentHash;

function upToDate() {
    return nextHash.indexOf(__webpack_require__.h()) >= 0;
}

function result(modules, appliedModules) {
    const unaccepted = modules.filter(
        (moduleId) => appliedModules && appliedModules.indexOf(moduleId) < 0
    );

    if (unaccepted.length > 0) {
        log.warn('The following modules could not be updated:');

        for (const moduleId of unaccepted) {
            log.warn(`          ⦻ ${moduleId}`);
        }
    }

    if (!(appliedModules || []).length) {
        log.info('No Modules Updated.');
    } else {
        log.info('The following modules were updated:');

        for (const moduleId of appliedModules) {
            log.info(`         ↻ ${moduleId}`);
        }

        const numberIds = appliedModules.every(
            (moduleId) => typeof moduleId === 'number'
        );
        if (numberIds) {
            log.info(
                'Please consider using the NamedModulesPlugin for module names.'
            );
        }
    }
}

function check(options) {
    return module.hot
        .check()
        .then((modules) => {
            if (!modules) {
                log.warn(
                    `Cannot find update. ${refresh}`
                );
                return null;
            }

            return module.hot
                .apply(hotOptions)
                .then((appliedModules) => {
                    let nextCheck;
                    if (!upToDate()) {
                        nextCheck = check(options);
                    }

                    result(modules, appliedModules);

                    if (upToDate()) {
                        // Do not modify message - CLI depends on this exact content to determine hmr operation status.
                        log.info(`Successfully applied update with hmr hash ${currentHash}. App is up to date.`);
                    }

                    return nextCheck || null;
                })
                .catch((err) => {
                    const status = module.hot.status();
                    if (['abort', 'fail'].indexOf(status) >= 0) {
                        // Do not modify message - CLI depends on this exact content to determine hmr operation status.
                        log.error(`Cannot apply update with hmr hash ${currentHash}.`);
                        log.error(err.message || err.stack);
                    } else {
                        log.error(`Update failed: ${err.message || err.stack}`);
                    }
                });
        })
        .catch((err) => {
            const status = module.hot.status();
            if (['abort', 'fail'].indexOf(status) >= 0) {
                log.error(`Cannot check for update. ${refresh}`);
                log.error(err.message || err.stack);
            } else {
                log.error(`Update check failed: ${err.message || err.stack}`);
            }
        });
}

if (true) {
    log.info('Hot Module Replacement Enabled. Waiting for signal.');
} else {}

function update(latestHash, options) {
    nextHash = latestHash;
    if (!upToDate()) {
        const status = module.hot.status();

        if (status === 'idle') {
            //Do not modify message - CLI depends on this exact content to determine hmr operation status.
            log.info(`Checking for updates to the bundle with hmr hash ${currentHash}.`);
            return check(options);
        } else if (['abort', 'fail'].indexOf(status) >= 0) {
            log.warn(
                `Cannot apply update. A previous update ${status}ed. ${refresh}`
            );
        }
    }
};

function getNextHash(hash, getFileContent) {
    const file = getFileContent(`${hash}.hot-update.json`);
    if (!file) {
        return Promise.resolve(hash);
    }

    return file.readText().then(hotUpdateContent => {
        if (hotUpdateContent) {
            const manifest = JSON.parse(hotUpdateContent);
            const newHash = manifest.h;
            return getNextHash(newHash, getFileContent);
        } else {
            return Promise.resolve(hash);
        }
    }).catch(error => Promise.reject(error));
}

module.exports = function checkState(initialHash, getFileContent) {
    currentHash = initialHash;
    return getNextHash(initialHash, getFileContent).then(nextHash => {
        if (nextHash != initialHash) {
            return update(nextHash, {});
        }
    })
}


/***/ }),

/***/ "../node_modules/nativescript-dev-webpack/load-application-css-regular.js":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {const loadCss = __webpack_require__("../node_modules/nativescript-dev-webpack/load-application-css.js");

module.exports = function() {
    loadCss(function() {
        const appCssContext = __webpack_require__("./ sync ^\\.\\/app\\.(css|scss|less|sass)$");
        global.registerWebpackModules(appCssContext);
    });
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../node_modules/nativescript-dev-webpack/load-application-css.js":
/***/ (function(module, exports, __webpack_require__) {

module.exports = function (loadModuleFn) {
    const application = __webpack_require__("tns-core-modules/application");
    __webpack_require__("tns-core-modules/ui/styling/style-scope");

    loadModuleFn();

    application.loadAppCss();
}


/***/ }),

/***/ "../node_modules/nativescript-theme-core/css/blue.css":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {module.exports = {"type":"stylesheet","stylesheet":{"rules":[{"type":"comment","comment":"!\n * NativeScript Theme v2.0.24 (https://nativescript.org)\n * Copyright 2016-2016 The Theme Authors\n * Copyright 2016-2019 Progress Software\n * Licensed under Apache 2.0 (https://github.com/NativeScript/theme/blob/master/LICENSE)\n "},{"type":"rule","selectors":["Button",".nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"color","value":"#004363"}]},{"type":"rule","selectors":[".ns-dark Button",".ns-dark .nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"color","value":"#fcfeff"}]},{"type":"rule","selectors":["Button:active","Button.-active",".nt-button:active",".nt-button.-active"],"declarations":[{"type":"declaration","property":"color","value":"#004363"}]},{"type":"rule","selectors":[".ns-dark Button:active",".ns-dark Button.-active",".ns-dark .nt-button:active",".ns-dark .nt-button.-active"],"declarations":[{"type":"declaration","property":"color","value":"#fcfeff"}]},{"type":"rule","selectors":["Button.-outline",".nt-button.-outline"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"border-color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark Button.-outline",".ns-dark .nt-button.-outline"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"keyframes","name":"-hightlight-light","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#f2f2f2"}]}]},{"type":"keyframes","name":"-hightlight-dark","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#232323"}]}]},{"type":"rule","selectors":["Button.-outline:active","Button.-outline.-active",".nt-button.-outline:active",".nt-button.-outline.-active"],"declarations":[{"type":"declaration","property":"animation","value":"-hightlight-light .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#f2f2f2"}]},{"type":"rule","selectors":[".ns-dark Button.-outline:active",".ns-dark Button.-outline.-active",".ns-dark .nt-button.-outline:active",".ns-dark .nt-button.-outline.-active"],"declarations":[{"type":"declaration","property":"animation","value":"-hightlight-dark .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#232323"}]},{"type":"rule","selectors":["Button.-primary",".nt-button.-primary"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"border-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark Button.-primary",".ns-dark .nt-button.-primary"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"border-color","value":"#30bcff"}]},{"type":"keyframes","name":"accent-hightlight-light","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#00aafc"}]}]},{"type":"keyframes","name":"accent-hightlight-dark","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#00aafc"}]}]},{"type":"rule","selectors":["Button.-primary:active","Button.-primary.-active",".nt-button.-primary:active",".nt-button.-primary.-active"],"declarations":[{"type":"declaration","property":"animation","value":"accent-hightlight-light .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#00aafc"}]},{"type":"rule","selectors":[".ns-dark Button.-primary:active",".ns-dark Button.-primary.-active",".ns-dark .nt-button.-primary:active",".ns-dark .nt-button.-primary.-active"],"declarations":[{"type":"declaration","property":"animation","value":"accent-hightlight-dark .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#00aafc"}]},{"type":"rule","selectors":["ActivityIndicator",".nt-activity-indicator"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark ActivityIndicator",".ns-dark .nt-activity-indicator"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["SegmentedBar",".nt-segmented-bar"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"selected-background-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark SegmentedBar",".ns-dark .nt-segmented-bar"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"selected-background-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-ios SegmentedBar",".ns-ios .nt-segmented-bar"],"declarations":[{"type":"declaration","property":"margin","value":"0 15"},{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark.ns-ios SegmentedBar",".ns-dark.ns-ios .nt-segmented-bar"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["Progress",".nt-progress"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.1)"}]},{"type":"rule","selectors":[".ns-dark Progress",".ns-dark .nt-progress"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.1)"}]},{"type":"rule","selectors":["Slider",".nt-slider"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark Slider",".ns-dark .nt-slider"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"rule","selectors":["Slider[isEnabled=false]",".ns-android Slider[isEnabled=false]",".nt-slider[isEnabled=false]",".ns-android .nt-slider[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e0e0e0"},{"type":"declaration","property":"background-color","value":"#e0e0e0"}]},{"type":"rule","selectors":["SearchBar",".nt-search-bar"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"text-field-hint-color","value":"#737373"},{"type":"declaration","property":"text-field-background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-dark SearchBar",".ns-dark .nt-search-bar"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"text-field-hint-color","value":"#b3b3b3"},{"type":"declaration","property":"text-field-background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-android Switch",".ns-android .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#ccc"},{"type":"declaration","property":"background-color","value":"#ccc"}]},{"type":"rule","selectors":[".ns-dark.ns-android Switch",".ns-dark.ns-android .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#636363"},{"type":"declaration","property":"background-color","value":"#636363"}]},{"type":"rule","selectors":[".ns-android Switch[checked=true]",".ns-android .nt-switch[checked=true]"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark.ns-android Switch[checked=true]",".ns-dark.ns-android .nt-switch[checked=true]"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-android Switch[isEnabled=false]",".ns-android .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e6e6e6"}]},{"type":"rule","selectors":[".ns-dark.ns-android Switch[isEnabled=false]",".ns-dark.ns-android .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#4a4a4a"}]},{"type":"rule","selectors":[".ns-ios Switch",".ns-ios .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"off-background-color","value":"#e6e6e6"}]},{"type":"rule","selectors":[".ns-dark.ns-ios Switch",".ns-dark.ns-ios .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#303030"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"off-background-color","value":"#4a4a4a"}]},{"type":"rule","selectors":[".ns-ios Switch[isEnabled=false]",".ns-ios .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":[".ns-dark.ns-ios Switch[isEnabled=false]",".ns-dark.ns-ios .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":["TabView",".nt-tab-view"],"declarations":[{"type":"declaration","property":"selected-tab-text-color","value":"#30bcff"},{"type":"declaration","property":"tab-background-color","value":"#fff"},{"type":"declaration","property":"tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"android-selected-tab-highlight-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark TabView",".ns-dark .nt-tab-view"],"declarations":[{"type":"declaration","property":"selected-tab-text-color","value":"#30bcff"},{"type":"declaration","property":"tab-background-color","value":"#303030"},{"type":"declaration","property":"tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"android-selected-tab-highlight-color","value":"#30bcff"}]},{"type":"rule","selectors":["TabView.ns-dark",".nt-tab-view.ns-dark"],"declarations":[{"type":"declaration","property":"selected-tab-text-color","value":"#30bcff"},{"type":"declaration","property":"tab-background-color","value":"#303030"},{"type":"declaration","property":"tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"android-selected-tab-highlight-color","value":"#30bcff"}]},{"type":"rule","selectors":["TabStrip",".nt-tab-strip"],"declarations":[{"type":"declaration","property":"highlight-color","value":"#30bcff"},{"type":"declaration","property":"background","value":"#f2f2f2"}]},{"type":"rule","selectors":[".ns-dark TabStrip",".ns-dark .nt-tab-strip"],"declarations":[{"type":"declaration","property":"highlight-color","value":"#30bcff"},{"type":"declaration","property":"background","value":"#3a3a3a"}]},{"type":"rule","selectors":["TabStripItem",".nt-tab-strip__item"],"declarations":[{"type":"declaration","property":"color","value":"#262626"}]},{"type":"rule","selectors":[".ns-dark TabStripItem",".ns-dark .nt-tab-strip__item"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":["TabStripItem:active","TabStripItem:active Label",".nt-tab-strip__item:active",".nt-tab-strip__item:active Label"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark TabStripItem:active",".ns-dark TabStripItem:active Label",".ns-dark .nt-tab-strip__item:active",".ns-dark .nt-tab-strip__item:active Label"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["TabContentItem",".nt-tab-content__item"],"declarations":[{"type":"declaration","property":"background","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark TabContentItem",".ns-dark .nt-tab-content__item"],"declarations":[{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":["ListView","RadListView",".nt-list-view"],"declarations":[{"type":"declaration","property":"item-selected-background-color","value":"rgba(48,188,255,.15)"},{"type":"declaration","property":"separator-color","value":"#ccc"}]},{"type":"rule","selectors":[".ns-dark ListView",".ns-dark RadListView",".ns-dark .nt-list-view"],"declarations":[{"type":"declaration","property":"item-selected-background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":["ListView>*.active","ListView>*:highlighted","RadListView>*.active","RadListView>*:highlighted",".nt-list-view>*.active",".nt-list-view>*:highlighted"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":[".ns-dark ListView>*.active",".ns-dark ListView>*:highlighted",".ns-dark RadListView>*.active",".ns-dark RadListView>*:highlighted",".ns-dark .nt-list-view>*.active",".ns-dark .nt-list-view>*:highlighted"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":["ListView .-separator","RadListView .-separator",".nt-list-view .-separator"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"#ccc"}]},{"type":"rule","selectors":[".ns-dark ListView .-separator",".ns-dark RadListView .-separator",".ns-dark .nt-list-view .-separator"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"#636363"}]},{"type":"rule","selectors":[".ns-dark ListView",".ns-dark RadListView",".ns-dark .nt-list-view"],"declarations":[{"type":"declaration","property":"separator-color","value":"#636363"}]},{"type":"rule","selectors":["ListView .nt-list-view__delete","RadListView .nt-list-view__delete",".nt-list-view .nt-list-view__delete"],"declarations":[{"type":"declaration","property":"background-color","value":"#d50000"}]},{"type":"rule","selectors":["ListView .nt-list-view__delete>Label","RadListView .nt-list-view__delete>Label",".nt-list-view .nt-list-view__delete>Label"],"declarations":[{"type":"declaration","property":"color","value":"#262626"}]},{"type":"rule","selectors":[".ns-dark ListView .nt-list-view__delete>Label",".ns-dark RadListView .nt-list-view__delete>Label",".ns-dark .nt-list-view .nt-list-view__delete>Label"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":["ListView NTIcon","ListView .nt-icon","RadListView NTIcon","RadListView .nt-icon",".nt-list-view NTIcon",".nt-list-view .nt-icon"],"declarations":[{"type":"declaration","property":"color","value":"#006698"}]},{"type":"rule","selectors":[".ns-dark ListView NTIcon",".ns-dark ListView .nt-icon",".ns-dark RadListView NTIcon",".ns-dark RadListView .nt-icon",".ns-dark .nt-list-view NTIcon",".ns-dark .nt-list-view .nt-icon"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header",".nt-drawer .nt-drawer__header"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#2444fe"}]},{"type":"rule","selectors":["RadSideDrawer>*","RadSideDrawer .nt-drawer__content",".nt-drawer>*",".nt-drawer .nt-drawer__content"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__list-item.-selected",".nt-drawer .nt-drawer__list-item.-selected"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__list-item.-selected Label",".nt-drawer .nt-drawer__list-item.-selected Label"],"declarations":[{"type":"declaration","property":"color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer .nt-drawer__header","RadSideDrawer.ns-dark .nt-drawer__header",".ns-dark .nt-drawer .nt-drawer__header",".nt-drawer.ns-dark .nt-drawer__header"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303c84"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer>*",".ns-dark RadSideDrawer .nt-drawer__content","RadSideDrawer.ns-dark>*","RadSideDrawer.ns-dark .nt-drawer__content",".ns-dark .nt-drawer>*",".ns-dark .nt-drawer .nt-drawer__content",".nt-drawer.ns-dark>*",".nt-drawer.ns-dark .nt-drawer__content"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer .nt-drawer__list-item.-selected","RadSideDrawer.ns-dark .nt-drawer__list-item.-selected",".ns-dark .nt-drawer .nt-drawer__list-item.-selected",".nt-drawer.ns-dark .nt-drawer__list-item.-selected"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer .nt-drawer__list-item.-selected Label","RadSideDrawer.ns-dark .nt-drawer__list-item.-selected Label",".ns-dark .nt-drawer .nt-drawer__list-item.-selected Label",".nt-drawer.ns-dark .nt-drawer__list-item.-selected Label"],"declarations":[{"type":"declaration","property":"color","value":"#96ddff"}]},{"type":"rule","selectors":["TextView","TextField","PickerField","DatePickerField","TimePickerField","DateTimePickerFields","DataFormEditorCore","RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"},{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"placeholder-color","value":"#737373"},{"type":"declaration","property":"border-color","value":"#c7c7c7"}]},{"type":"rule","selectors":[".ns-dark TextView",".ns-dark TextField",".ns-dark PickerField",".ns-dark DatePickerField",".ns-dark TimePickerField",".ns-dark DateTimePickerFields",".ns-dark DataFormEditorCore",".ns-dark RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"placeholder-color","value":"#b3b3b3"},{"type":"declaration","property":"border-color","value":"#fafafa"}]},{"type":"rule","selectors":["TextView:focus","TextField:focus","PickerField:focus","DatePickerField:focus","TimePickerField:focus","DateTimePickerFields:focus","DataFormEditorCore:focus","RadAutoCompleteTextView:focus"],"declarations":[{"type":"declaration","property":"border-color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark TextView:focus",".ns-dark TextField:focus",".ns-dark PickerField:focus",".ns-dark DatePickerField:focus",".ns-dark TimePickerField:focus",".ns-dark DateTimePickerFields:focus",".ns-dark DataFormEditorCore:focus",".ns-dark RadAutoCompleteTextView:focus"],"declarations":[{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"rule","selectors":["TextView[isEnabled=false]","TextField[isEnabled=false]","PickerField[isEnabled=false]","DatePickerField[isEnabled=false]","TimePickerField[isEnabled=false]","DateTimePickerFields[isEnabled=false]","DataFormEditorCore[isEnabled=false]","RadAutoCompleteTextView[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e0e0e0"},{"type":"declaration","property":"background-color","value":"#f2f2f2"}]},{"type":"rule","selectors":[".ns-dark TextView[isEnabled=false]",".ns-dark TextField[isEnabled=false]",".ns-dark PickerField[isEnabled=false]",".ns-dark DatePickerField[isEnabled=false]",".ns-dark TimePickerField[isEnabled=false]",".ns-dark DateTimePickerFields[isEnabled=false]",".ns-dark DataFormEditorCore[isEnabled=false]",".ns-dark RadAutoCompleteTextView[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e0e0e0"},{"type":"declaration","property":"background-color","value":"#3d3d3d"}]},{"type":"rule","selectors":["PropertyEditor:focus DataFormEditorCore"],"declarations":[{"type":"declaration","property":"border-color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark PropertyEditor:focus DataFormEditorCore"],"declarations":[{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"rule","selectors":["RadAutoCompleteTextView Token"],"declarations":[{"type":"declaration","property":"background-color","value":"#96ddff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView Token"],"declarations":[{"type":"declaration","property":"background-color","value":"#0088c9"}]},{"type":"rule","selectors":["RadAutoCompleteTextView Token:selected"],"declarations":[{"type":"declaration","property":"background-color","value":"#63cdff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView Token:selected"],"declarations":[{"type":"declaration","property":"background-color","value":"#00aafc"}]},{"type":"rule","selectors":["RadAutoCompleteTextView ClearButton"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView ClearButton"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["RadAutoCompleteTextView SuggestionView"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView SuggestionView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":["RadDataForm"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"placeholder-color","value":"#737373"}]},{"type":"rule","selectors":[".ns-dark RadDataForm"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"placeholder-color","value":"#b3b3b3"}]},{"type":"rule","selectors":["RadDataForm PropertyEditor"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark RadDataForm PropertyEditor"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":["PickerPage ListView"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark PickerPage ListView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":["PickerPage ListView>*"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":[".ns-dark PickerPage ListView>*"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":["PickerPage.ns-dark ListView",".ns-dark SuggestionView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":[".date-time-picker"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background","value":"#fff"}]},{"type":"rule","selectors":[".date-time-picker.ns-dark"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":[".date-time-picker-buttons"],"declarations":[{"type":"declaration","property":"color","value":"#004363"}]},{"type":"rule","selectors":[".date-time-picker-buttons.ns-dark"],"declarations":[{"type":"declaration","property":"color","value":"#fcfeff"}]},{"type":"rule","selectors":[".ns-dark.date-time-picker-button-cancel"],"declarations":[{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":[".date-time-picker-spinners"],"declarations":[{"type":"declaration","property":"color","value":"#006596"}]},{"type":"rule","selectors":[".date-time-picker-spinners.ns-dark"],"declarations":[{"type":"declaration","property":"color","value":"#c9eeff"}]},{"type":"rule","selectors":["DataFormEditorLabel","NTInput>Label",".nt-input>Label"],"declarations":[{"type":"declaration","property":"color","value":"#006596"}]},{"type":"rule","selectors":[".ns-dark DataFormEditorLabel",".ns-dark NTInput>Label",".ns-dark .nt-input>Label"],"declarations":[{"type":"declaration","property":"color","value":"#c9eeff"}]},{"type":"rule","selectors":["ActionBar","NTActionBar",".nt-action-bar"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#3d5afe"}]},{"type":"rule","selectors":[".ns-dark ActionBar",".ns-dark NTActionBar",".ns-dark .nt-action-bar"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#374597"}]},{"type":"rule","selectors":["ActionBar NTIcon","ActionBar Label","ActionBar Button","ActionBar .nt-action-bar__item","NTActionBar NTIcon","NTActionBar Label","NTActionBar Button","NTActionBar .nt-action-bar__item",".nt-action-bar NTIcon",".nt-action-bar Label",".nt-action-bar Button",".nt-action-bar .nt-action-bar__item"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark ActionBar NTIcon",".ns-dark ActionBar Label",".ns-dark ActionBar Button",".ns-dark ActionBar .nt-action-bar__item",".ns-dark NTActionBar NTIcon",".ns-dark NTActionBar Label",".ns-dark NTActionBar Button",".ns-dark NTActionBar .nt-action-bar__item",".ns-dark .nt-action-bar NTIcon",".ns-dark .nt-action-bar Label",".ns-dark .nt-action-bar Button",".ns-dark .nt-action-bar .nt-action-bar__item"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":["ActionBar NTIcon:active","ActionBar NTIcon.-active","ActionBar Label:active","ActionBar Label.-active","ActionBar Button:active","ActionBar Button.-active","ActionBar .nt-action-bar__item:active","ActionBar .nt-action-bar__item.-active","NTActionBar NTIcon:active","NTActionBar NTIcon.-active","NTActionBar Label:active","NTActionBar Label.-active","NTActionBar Button:active","NTActionBar Button.-active","NTActionBar .nt-action-bar__item:active","NTActionBar .nt-action-bar__item.-active",".nt-action-bar NTIcon:active",".nt-action-bar NTIcon.-active",".nt-action-bar Label:active",".nt-action-bar Label.-active",".nt-action-bar Button:active",".nt-action-bar Button.-active",".nt-action-bar .nt-action-bar__item:active",".nt-action-bar .nt-action-bar__item.-active"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark ActionBar NTIcon:active",".ns-dark ActionBar NTIcon.-active",".ns-dark ActionBar Label:active",".ns-dark ActionBar Label.-active",".ns-dark ActionBar Button:active",".ns-dark ActionBar Button.-active",".ns-dark ActionBar .nt-action-bar__item:active",".ns-dark ActionBar .nt-action-bar__item.-active",".ns-dark NTActionBar NTIcon:active",".ns-dark NTActionBar NTIcon.-active",".ns-dark NTActionBar Label:active",".ns-dark NTActionBar Label.-active",".ns-dark NTActionBar Button:active",".ns-dark NTActionBar Button.-active",".ns-dark NTActionBar .nt-action-bar__item:active",".ns-dark NTActionBar .nt-action-bar__item.-active",".ns-dark .nt-action-bar NTIcon:active",".ns-dark .nt-action-bar NTIcon.-active",".ns-dark .nt-action-bar Label:active",".ns-dark .nt-action-bar Label.-active",".ns-dark .nt-action-bar Button:active",".ns-dark .nt-action-bar Button.-active",".ns-dark .nt-action-bar .nt-action-bar__item:active",".ns-dark .nt-action-bar .nt-action-bar__item.-active"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-ios ActionBar NTIcon",".ns-ios ActionBar NTIcon:active",".ns-ios ActionBar Label",".ns-ios ActionBar Label:active",".ns-ios ActionBar Button",".ns-ios ActionBar Button:active",".ns-ios ActionBar .nt-action-bar__item",".ns-ios ActionBar .nt-action-bar__item:active",".ns-ios NTActionBar NTIcon",".ns-ios NTActionBar NTIcon:active",".ns-ios NTActionBar Label",".ns-ios NTActionBar Label:active",".ns-ios NTActionBar Button",".ns-ios NTActionBar Button:active",".ns-ios NTActionBar .nt-action-bar__item",".ns-ios NTActionBar .nt-action-bar__item:active",".ns-ios .nt-action-bar NTIcon",".ns-ios .nt-action-bar NTIcon:active",".ns-ios .nt-action-bar Label",".ns-ios .nt-action-bar Label:active",".ns-ios .nt-action-bar Button",".ns-ios .nt-action-bar Button:active",".ns-ios .nt-action-bar .nt-action-bar__item",".ns-ios .nt-action-bar .nt-action-bar__item:active"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-dark.ns-ios ActionBar NTIcon",".ns-dark.ns-ios ActionBar NTIcon:active",".ns-dark.ns-ios ActionBar Label",".ns-dark.ns-ios ActionBar Label:active",".ns-dark.ns-ios ActionBar Button",".ns-dark.ns-ios ActionBar Button:active",".ns-dark.ns-ios ActionBar .nt-action-bar__item",".ns-dark.ns-ios ActionBar .nt-action-bar__item:active",".ns-dark.ns-ios NTActionBar NTIcon",".ns-dark.ns-ios NTActionBar NTIcon:active",".ns-dark.ns-ios NTActionBar Label",".ns-dark.ns-ios NTActionBar Label:active",".ns-dark.ns-ios NTActionBar Button",".ns-dark.ns-ios NTActionBar Button:active",".ns-dark.ns-ios NTActionBar .nt-action-bar__item",".ns-dark.ns-ios NTActionBar .nt-action-bar__item:active",".ns-dark.ns-ios .nt-action-bar NTIcon",".ns-dark.ns-ios .nt-action-bar NTIcon:active",".ns-dark.ns-ios .nt-action-bar Label",".ns-dark.ns-ios .nt-action-bar Label:active",".ns-dark.ns-ios .nt-action-bar Button",".ns-dark.ns-ios .nt-action-bar Button:active",".ns-dark.ns-ios .nt-action-bar .nt-action-bar__item",".ns-dark.ns-ios .nt-action-bar .nt-action-bar__item:active"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-android ActionBar Button",".ns-android ActionBar .nt-button",".ns-android NTActionBar Button",".ns-android NTActionBar .nt-button",".ns-android .nt-action-bar Button",".ns-android .nt-action-bar .nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#3d5afe"}]},{"type":"rule","selectors":[".ns-dark.ns-android ActionBar Button",".ns-dark.ns-android ActionBar .nt-button",".ns-dark.ns-android NTActionBar Button",".ns-dark.ns-android NTActionBar .nt-button",".ns-dark.ns-android .nt-action-bar Button",".ns-dark.ns-android .nt-action-bar .nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#374597"}]},{"type":"rule","selectors":[".hr"],"declarations":[{"type":"declaration","property":"border-color","value":"#d9d9d9"}]},{"type":"rule","selectors":[".ns-dark .hr"],"declarations":[{"type":"declaration","property":"border-color","value":"#4d4d4d"}]},{"type":"rule","selectors":[".hr-light"],"declarations":[{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"rule","selectors":[".ns-dark .hr-light"],"declarations":[{"type":"declaration","property":"border-color","value":"#fcfeff"}]},{"type":"rule","selectors":[".hr-dark"],"declarations":[{"type":"declaration","property":"border-color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark .hr-dark"],"declarations":[{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"rule","selectors":[".ns-root",".ns-modal"],"declarations":[{"type":"declaration","property":"--color-black","value":"#000"},{"type":"declaration","property":"--color-white","value":"#fff"},{"type":"declaration","property":"--color-grey","value":"#e0e0e0"},{"type":"declaration","property":"--color-grey-light","value":"#bababa"},{"type":"declaration","property":"--color-charcoal","value":"#303030"},{"type":"declaration","property":"--color-transparent","value":"transparent"},{"type":"declaration","property":"--color-aqua","value":"#00caab"},{"type":"declaration","property":"--color-blue","value":"#3d5afe"},{"type":"declaration","property":"--color-brown","value":"#795548"},{"type":"declaration","property":"--color-forest","value":"#006968"},{"type":"declaration","property":"--color-grey-dark","value":"#5c687c"},{"type":"declaration","property":"--color-purple","value":"#8130ff"},{"type":"declaration","property":"--color-lemon","value":"#ffea00"},{"type":"declaration","property":"--color-lime","value":"#aee406"},{"type":"declaration","property":"--color-orange","value":"#f57c00"},{"type":"declaration","property":"--color-ruby","value":"#ff1744"},{"type":"declaration","property":"--color-sky","value":"#30bcff"},{"type":"declaration","property":"--color-error","value":"#d50000"},{"type":"declaration","property":"--const-font-size","value":"16"},{"type":"declaration","property":"--const-background-alt-10","value":"#c0ebff"},{"type":"declaration","property":"--const-btn-color-secondary","value":"#01a0ec"},{"type":"declaration","property":"--const-btn-color-disabled","value":"#a4a4a4"},{"type":"declaration","property":"--const-btn-font-size","value":"18"},{"type":"declaration","property":"--const-btn-min-width","value":"64"},{"type":"declaration","property":"--const-btn-height","value":"52"},{"type":"declaration","property":"--const-btn-padding-x","value":"0"},{"type":"declaration","property":"--const-btn-padding-y","value":"0"},{"type":"declaration","property":"--const-btn-margin-x","value":"16"},{"type":"declaration","property":"--const-btn-margin-y","value":"8"},{"type":"declaration","property":"--const-btn-radius","value":"0"},{"type":"declaration","property":"--const-headings-margin-bottom","value":"4"},{"type":"declaration","property":"--const-headings-font-weight","value":"normal"},{"type":"declaration","property":"--const-border-width","value":"1"},{"type":"declaration","property":"--const-border-radius","value":""},{"type":"declaration","property":"--const-border-radius-sm","value":"4"},{"type":"declaration","property":"--const-border-radius-lg","value":"50%"},{"type":"declaration","property":"--const-border-radius-rounded","value":"5"},{"type":"declaration","property":"--const-icon-font-size","value":"16"},{"type":"declaration","property":"--const-icon-font-size-lg","value":"20"},{"type":"declaration","property":"--const-disabled-opacity","value":"0.5"},{"type":"declaration","property":"--light-primary","value":"#262626"},{"type":"declaration","property":"--light-background","value":"#fff"},{"type":"declaration","property":"--light-accent","value":"#30bcff"},{"type":"declaration","property":"--light-ab-color","value":"#fff"},{"type":"declaration","property":"--light-ab-background","value":"#3d5afe"},{"type":"declaration","property":"--light-btn-color","value":"#262626"},{"type":"declaration","property":"--light-border-color","value":"#30bcff"},{"type":"declaration","property":"--light-background-alt-5","value":"#f2f2f2"},{"type":"declaration","property":"--light-background-alt-10","value":"#e6e6e6"},{"type":"declaration","property":"--light-background-alt-20","value":"#cccccc"},{"type":"declaration","property":"--light-secondary","value":"#737373"},{"type":"declaration","property":"--light-disabled","value":"#ace4ff"},{"type":"declaration","property":"--light-text-color","value":"#262626"},{"type":"declaration","property":"--light-headings-color","value":"#262626"},{"type":"declaration","property":"--light-tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"--light-accent-dark","value":"#0088c9"},{"type":"declaration","property":"--light-accent-light","value":"#96ddff"},{"type":"declaration","property":"--light-accent-transparent","value":"rgba(48, 188, 255, 0.8)"},{"type":"declaration","property":"--light-primary-accent","value":"rgba(48, 188, 255, 0.4)"},{"type":"declaration","property":"--light-background-accent","value":"rgba(48, 188, 255, 0.1)"},{"type":"declaration","property":"--light-background-dark-accent","value":"rgba(48, 188, 255, 0.15)"},{"type":"declaration","property":"--light-item-active-color","value":"#676767"},{"type":"declaration","property":"--light-item-active-background","value":"rgba(48, 188, 255, 0.15)"},{"type":"declaration","property":"--light-ab-background-dark","value":"#2444fe"},{"type":"declaration","property":"--light-item-active-icon-color","value":"#676767"},{"type":"declaration","property":"--light-btn-color-inverse","value":"white"},{"type":"declaration","property":"--light-btn-color-secondary","value":"#0d0d0d"},{"type":"declaration","property":"--dark-primary","value":"#fff"},{"type":"declaration","property":"--dark-background","value":"#303030"},{"type":"declaration","property":"--dark-accent","value":"#30bcff"},{"type":"declaration","property":"--dark-border-color","value":"#30bcff"},{"type":"declaration","property":"--dark-btn-color","value":"#fff"},{"type":"declaration","property":"--dark-background-alt-5","value":"#3d3d3d"},{"type":"declaration","property":"--dark-background-alt-10","value":"#4a4a4a"},{"type":"declaration","property":"--dark-background-alt-20","value":"#636363"},{"type":"declaration","property":"--dark-secondary","value":"#b3b3b3"},{"type":"declaration","property":"--dark-disabled","value":"#306883"},{"type":"declaration","property":"--dark-ab-color","value":"white"},{"type":"declaration","property":"--dark-ab-background","value":"#374597"},{"type":"declaration","property":"--dark-text-color","value":"#fff"},{"type":"declaration","property":"--dark-headings-color","value":"#fff"},{"type":"declaration","property":"--dark-tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"--dark-accent-dark","value":"#96ddff"},{"type":"declaration","property":"--dark-accent-light","value":"#fcfeff"},{"type":"declaration","property":"--dark-accent-transparent","value":"rgba(48, 188, 255, 0.8)"},{"type":"declaration","property":"--dark-primary-accent","value":"rgba(48, 188, 255, 0.4)"},{"type":"declaration","property":"--dark-background-accent","value":"rgba(48, 188, 255, 0.1)"},{"type":"declaration","property":"--dark-background-dark-accent","value":"rgba(48, 188, 255, 0.15)"},{"type":"declaration","property":"--dark-item-active-color","value":"#c1c1c1"},{"type":"declaration","property":"--dark-item-active-background","value":"rgba(48, 188, 255, 0.15)"},{"type":"declaration","property":"--dark-ab-background-dark","value":"#303c84"},{"type":"declaration","property":"--dark-item-active-icon-color","value":"#c1c1c1"},{"type":"declaration","property":"--dark-btn-color-inverse","value":"white"},{"type":"declaration","property":"--dark-btn-color-secondary","value":"#e6e6e6"}]}],"parsingErrors":[]}};; 
if ( true && global._isModuleLoadedForUI && global._isModuleLoadedForUI("/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/nativescript-theme-core/css/blue.css") ) {
    
    module.hot.accept();
    module.hot.dispose(() => {
        global.hmrRefresh({ type: "style", path: "/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/nativescript-theme-core/css/blue.css" });
    });
} 
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../node_modules/nativescript-theme-core/css/core.css":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {module.exports = {"type":"stylesheet","stylesheet":{"rules":[{"type":"comment","comment":"!\n * NativeScript Theme v2.0.24 (https://nativescript.org)\n * Copyright 2016-2016 The Theme Authors\n * Copyright 2016-2019 Progress Software\n * Licensed under Apache 2.0 (https://github.com/NativeScript/theme/blob/master/LICENSE)\n "},{"type":"rule","selectors":[".c-black"],"declarations":[{"type":"declaration","property":"color","value":"#000"}]},{"type":"rule","selectors":[".c-bg-black"],"declarations":[{"type":"declaration","property":"background-color","value":"#000"}]},{"type":"rule","selectors":[".c-white"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".c-bg-white"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".c-grey"],"declarations":[{"type":"declaration","property":"color","value":"#e0e0e0"}]},{"type":"rule","selectors":[".c-bg-grey"],"declarations":[{"type":"declaration","property":"background-color","value":"#e0e0e0"}]},{"type":"rule","selectors":[".c-grey-light"],"declarations":[{"type":"declaration","property":"color","value":"#bababa"}]},{"type":"rule","selectors":[".c-bg-grey-light"],"declarations":[{"type":"declaration","property":"background-color","value":"#bababa"}]},{"type":"rule","selectors":[".c-charcoal"],"declarations":[{"type":"declaration","property":"color","value":"#303030"}]},{"type":"rule","selectors":[".c-bg-charcoal"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":[".c-transparent"],"declarations":[{"type":"declaration","property":"color","value":"transparent"}]},{"type":"rule","selectors":[".c-bg-transparent"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":[".c-aqua"],"declarations":[{"type":"declaration","property":"color","value":"#00caab"}]},{"type":"rule","selectors":[".c-bg-aqua"],"declarations":[{"type":"declaration","property":"background-color","value":"#00caab"}]},{"type":"rule","selectors":[".c-blue"],"declarations":[{"type":"declaration","property":"color","value":"#3d5afe"}]},{"type":"rule","selectors":[".c-bg-blue"],"declarations":[{"type":"declaration","property":"background-color","value":"#3d5afe"}]},{"type":"rule","selectors":[".c-brown"],"declarations":[{"type":"declaration","property":"color","value":"#795548"}]},{"type":"rule","selectors":[".c-bg-brown"],"declarations":[{"type":"declaration","property":"background-color","value":"#795548"}]},{"type":"rule","selectors":[".c-forest"],"declarations":[{"type":"declaration","property":"color","value":"#006968"}]},{"type":"rule","selectors":[".c-bg-forest"],"declarations":[{"type":"declaration","property":"background-color","value":"#006968"}]},{"type":"rule","selectors":[".c-grey-dark"],"declarations":[{"type":"declaration","property":"color","value":"#5c687c"}]},{"type":"rule","selectors":[".c-bg-grey-dark"],"declarations":[{"type":"declaration","property":"background-color","value":"#5c687c"}]},{"type":"rule","selectors":[".c-purple"],"declarations":[{"type":"declaration","property":"color","value":"#8130ff"}]},{"type":"rule","selectors":[".c-bg-purple"],"declarations":[{"type":"declaration","property":"background-color","value":"#8130ff"}]},{"type":"rule","selectors":[".c-lemon"],"declarations":[{"type":"declaration","property":"color","value":"#ffea00"}]},{"type":"rule","selectors":[".c-bg-lemon"],"declarations":[{"type":"declaration","property":"background-color","value":"#ffea00"}]},{"type":"rule","selectors":[".c-lime"],"declarations":[{"type":"declaration","property":"color","value":"#aee406"}]},{"type":"rule","selectors":[".c-bg-lime"],"declarations":[{"type":"declaration","property":"background-color","value":"#aee406"}]},{"type":"rule","selectors":[".c-orange"],"declarations":[{"type":"declaration","property":"color","value":"#f57c00"}]},{"type":"rule","selectors":[".c-bg-orange"],"declarations":[{"type":"declaration","property":"background-color","value":"#f57c00"}]},{"type":"rule","selectors":[".c-ruby"],"declarations":[{"type":"declaration","property":"color","value":"#ff1744"}]},{"type":"rule","selectors":[".c-bg-ruby"],"declarations":[{"type":"declaration","property":"background-color","value":"#ff1744"}]},{"type":"rule","selectors":[".c-sky"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".c-bg-sky"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"rule","selectors":[".c-error"],"declarations":[{"type":"declaration","property":"color","value":"#d50000"}]},{"type":"rule","selectors":[".c-bg-error"],"declarations":[{"type":"declaration","property":"background-color","value":"#d50000"}]},{"type":"rule","selectors":[".w-full"],"declarations":[{"type":"declaration","property":"width","value":"100%"}]},{"type":"rule","selectors":[".w-100"],"declarations":[{"type":"declaration","property":"width","value":"100"}]},{"type":"rule","selectors":[".h-full"],"declarations":[{"type":"declaration","property":"height","value":"100%"}]},{"type":"rule","selectors":[".h-100"],"declarations":[{"type":"declaration","property":"height","value":"100"}]},{"type":"rule","selectors":[".m-0"],"declarations":[{"type":"declaration","property":"margin","value":"0"}]},{"type":"rule","selectors":[".m-t-0"],"declarations":[{"type":"declaration","property":"margin-top","value":"0"}]},{"type":"rule","selectors":[".m-r-0"],"declarations":[{"type":"declaration","property":"margin-right","value":"0"}]},{"type":"rule","selectors":[".m-b-0"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"0"}]},{"type":"rule","selectors":[".m-l-0"],"declarations":[{"type":"declaration","property":"margin-left","value":"0"}]},{"type":"rule","selectors":[".m-x-0"],"declarations":[{"type":"declaration","property":"margin-right","value":"0"},{"type":"declaration","property":"margin-left","value":"0"}]},{"type":"rule","selectors":[".m-y-0"],"declarations":[{"type":"declaration","property":"margin-top","value":"0"},{"type":"declaration","property":"margin-bottom","value":"0"}]},{"type":"rule","selectors":[".m-2"],"declarations":[{"type":"declaration","property":"margin","value":"2"}]},{"type":"rule","selectors":[".m-t-2"],"declarations":[{"type":"declaration","property":"margin-top","value":"2"}]},{"type":"rule","selectors":[".m-r-2"],"declarations":[{"type":"declaration","property":"margin-right","value":"2"}]},{"type":"rule","selectors":[".m-b-2"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"2"}]},{"type":"rule","selectors":[".m-l-2"],"declarations":[{"type":"declaration","property":"margin-left","value":"2"}]},{"type":"rule","selectors":[".m-x-2"],"declarations":[{"type":"declaration","property":"margin-right","value":"2"},{"type":"declaration","property":"margin-left","value":"2"}]},{"type":"rule","selectors":[".m-y-2"],"declarations":[{"type":"declaration","property":"margin-top","value":"2"},{"type":"declaration","property":"margin-bottom","value":"2"}]},{"type":"rule","selectors":[".m-4"],"declarations":[{"type":"declaration","property":"margin","value":"4"}]},{"type":"rule","selectors":[".m-t-4"],"declarations":[{"type":"declaration","property":"margin-top","value":"4"}]},{"type":"rule","selectors":[".m-r-4"],"declarations":[{"type":"declaration","property":"margin-right","value":"4"}]},{"type":"rule","selectors":[".m-b-4"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"4"}]},{"type":"rule","selectors":[".m-l-4"],"declarations":[{"type":"declaration","property":"margin-left","value":"4"}]},{"type":"rule","selectors":[".m-x-4"],"declarations":[{"type":"declaration","property":"margin-right","value":"4"},{"type":"declaration","property":"margin-left","value":"4"}]},{"type":"rule","selectors":[".m-y-4"],"declarations":[{"type":"declaration","property":"margin-top","value":"4"},{"type":"declaration","property":"margin-bottom","value":"4"}]},{"type":"rule","selectors":[".m-5"],"declarations":[{"type":"declaration","property":"margin","value":"5"}]},{"type":"rule","selectors":[".m-t-5"],"declarations":[{"type":"declaration","property":"margin-top","value":"5"}]},{"type":"rule","selectors":[".m-r-5"],"declarations":[{"type":"declaration","property":"margin-right","value":"5"}]},{"type":"rule","selectors":[".m-b-5"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"5"}]},{"type":"rule","selectors":[".m-l-5"],"declarations":[{"type":"declaration","property":"margin-left","value":"5"}]},{"type":"rule","selectors":[".m-x-5"],"declarations":[{"type":"declaration","property":"margin-right","value":"5"},{"type":"declaration","property":"margin-left","value":"5"}]},{"type":"rule","selectors":[".m-y-5"],"declarations":[{"type":"declaration","property":"margin-top","value":"5"},{"type":"declaration","property":"margin-bottom","value":"5"}]},{"type":"rule","selectors":[".m-8"],"declarations":[{"type":"declaration","property":"margin","value":"8"}]},{"type":"rule","selectors":[".m-t-8"],"declarations":[{"type":"declaration","property":"margin-top","value":"8"}]},{"type":"rule","selectors":[".m-r-8"],"declarations":[{"type":"declaration","property":"margin-right","value":"8"}]},{"type":"rule","selectors":[".m-b-8"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"8"}]},{"type":"rule","selectors":[".m-l-8"],"declarations":[{"type":"declaration","property":"margin-left","value":"8"}]},{"type":"rule","selectors":[".m-x-8"],"declarations":[{"type":"declaration","property":"margin-right","value":"8"},{"type":"declaration","property":"margin-left","value":"8"}]},{"type":"rule","selectors":[".m-y-8"],"declarations":[{"type":"declaration","property":"margin-top","value":"8"},{"type":"declaration","property":"margin-bottom","value":"8"}]},{"type":"rule","selectors":[".m-10"],"declarations":[{"type":"declaration","property":"margin","value":"10"}]},{"type":"rule","selectors":[".m-t-10"],"declarations":[{"type":"declaration","property":"margin-top","value":"10"}]},{"type":"rule","selectors":[".m-r-10"],"declarations":[{"type":"declaration","property":"margin-right","value":"10"}]},{"type":"rule","selectors":[".m-b-10"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"10"}]},{"type":"rule","selectors":[".m-l-10"],"declarations":[{"type":"declaration","property":"margin-left","value":"10"}]},{"type":"rule","selectors":[".m-x-10"],"declarations":[{"type":"declaration","property":"margin-right","value":"10"},{"type":"declaration","property":"margin-left","value":"10"}]},{"type":"rule","selectors":[".m-y-10"],"declarations":[{"type":"declaration","property":"margin-top","value":"10"},{"type":"declaration","property":"margin-bottom","value":"10"}]},{"type":"rule","selectors":[".m-12"],"declarations":[{"type":"declaration","property":"margin","value":"12"}]},{"type":"rule","selectors":[".m-t-12"],"declarations":[{"type":"declaration","property":"margin-top","value":"12"}]},{"type":"rule","selectors":[".m-r-12"],"declarations":[{"type":"declaration","property":"margin-right","value":"12"}]},{"type":"rule","selectors":[".m-b-12"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"12"}]},{"type":"rule","selectors":[".m-l-12"],"declarations":[{"type":"declaration","property":"margin-left","value":"12"}]},{"type":"rule","selectors":[".m-x-12"],"declarations":[{"type":"declaration","property":"margin-right","value":"12"},{"type":"declaration","property":"margin-left","value":"12"}]},{"type":"rule","selectors":[".m-y-12"],"declarations":[{"type":"declaration","property":"margin-top","value":"12"},{"type":"declaration","property":"margin-bottom","value":"12"}]},{"type":"rule","selectors":[".m-15"],"declarations":[{"type":"declaration","property":"margin","value":"15"}]},{"type":"rule","selectors":[".m-t-15"],"declarations":[{"type":"declaration","property":"margin-top","value":"15"}]},{"type":"rule","selectors":[".m-r-15"],"declarations":[{"type":"declaration","property":"margin-right","value":"15"}]},{"type":"rule","selectors":[".m-b-15"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"15"}]},{"type":"rule","selectors":[".m-l-15"],"declarations":[{"type":"declaration","property":"margin-left","value":"15"}]},{"type":"rule","selectors":[".m-x-15"],"declarations":[{"type":"declaration","property":"margin-right","value":"15"},{"type":"declaration","property":"margin-left","value":"15"}]},{"type":"rule","selectors":[".m-y-15"],"declarations":[{"type":"declaration","property":"margin-top","value":"15"},{"type":"declaration","property":"margin-bottom","value":"15"}]},{"type":"rule","selectors":[".m-16"],"declarations":[{"type":"declaration","property":"margin","value":"16"}]},{"type":"rule","selectors":[".m-t-16"],"declarations":[{"type":"declaration","property":"margin-top","value":"16"}]},{"type":"rule","selectors":[".m-r-16"],"declarations":[{"type":"declaration","property":"margin-right","value":"16"}]},{"type":"rule","selectors":[".m-b-16"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"16"}]},{"type":"rule","selectors":[".m-l-16"],"declarations":[{"type":"declaration","property":"margin-left","value":"16"}]},{"type":"rule","selectors":[".m-x-16"],"declarations":[{"type":"declaration","property":"margin-right","value":"16"},{"type":"declaration","property":"margin-left","value":"16"}]},{"type":"rule","selectors":[".m-y-16"],"declarations":[{"type":"declaration","property":"margin-top","value":"16"},{"type":"declaration","property":"margin-bottom","value":"16"}]},{"type":"rule","selectors":[".m-20"],"declarations":[{"type":"declaration","property":"margin","value":"20"}]},{"type":"rule","selectors":[".m-t-20"],"declarations":[{"type":"declaration","property":"margin-top","value":"20"}]},{"type":"rule","selectors":[".m-r-20"],"declarations":[{"type":"declaration","property":"margin-right","value":"20"}]},{"type":"rule","selectors":[".m-b-20"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"20"}]},{"type":"rule","selectors":[".m-l-20"],"declarations":[{"type":"declaration","property":"margin-left","value":"20"}]},{"type":"rule","selectors":[".m-x-20"],"declarations":[{"type":"declaration","property":"margin-right","value":"20"},{"type":"declaration","property":"margin-left","value":"20"}]},{"type":"rule","selectors":[".m-y-20"],"declarations":[{"type":"declaration","property":"margin-top","value":"20"},{"type":"declaration","property":"margin-bottom","value":"20"}]},{"type":"rule","selectors":[".m-24"],"declarations":[{"type":"declaration","property":"margin","value":"24"}]},{"type":"rule","selectors":[".m-t-24"],"declarations":[{"type":"declaration","property":"margin-top","value":"24"}]},{"type":"rule","selectors":[".m-r-24"],"declarations":[{"type":"declaration","property":"margin-right","value":"24"}]},{"type":"rule","selectors":[".m-b-24"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"24"}]},{"type":"rule","selectors":[".m-l-24"],"declarations":[{"type":"declaration","property":"margin-left","value":"24"}]},{"type":"rule","selectors":[".m-x-24"],"declarations":[{"type":"declaration","property":"margin-right","value":"24"},{"type":"declaration","property":"margin-left","value":"24"}]},{"type":"rule","selectors":[".m-y-24"],"declarations":[{"type":"declaration","property":"margin-top","value":"24"},{"type":"declaration","property":"margin-bottom","value":"24"}]},{"type":"rule","selectors":[".m-25"],"declarations":[{"type":"declaration","property":"margin","value":"25"}]},{"type":"rule","selectors":[".m-t-25"],"declarations":[{"type":"declaration","property":"margin-top","value":"25"}]},{"type":"rule","selectors":[".m-r-25"],"declarations":[{"type":"declaration","property":"margin-right","value":"25"}]},{"type":"rule","selectors":[".m-b-25"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"25"}]},{"type":"rule","selectors":[".m-l-25"],"declarations":[{"type":"declaration","property":"margin-left","value":"25"}]},{"type":"rule","selectors":[".m-x-25"],"declarations":[{"type":"declaration","property":"margin-right","value":"25"},{"type":"declaration","property":"margin-left","value":"25"}]},{"type":"rule","selectors":[".m-y-25"],"declarations":[{"type":"declaration","property":"margin-top","value":"25"},{"type":"declaration","property":"margin-bottom","value":"25"}]},{"type":"rule","selectors":[".m-28"],"declarations":[{"type":"declaration","property":"margin","value":"28"}]},{"type":"rule","selectors":[".m-t-28"],"declarations":[{"type":"declaration","property":"margin-top","value":"28"}]},{"type":"rule","selectors":[".m-r-28"],"declarations":[{"type":"declaration","property":"margin-right","value":"28"}]},{"type":"rule","selectors":[".m-b-28"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"28"}]},{"type":"rule","selectors":[".m-l-28"],"declarations":[{"type":"declaration","property":"margin-left","value":"28"}]},{"type":"rule","selectors":[".m-x-28"],"declarations":[{"type":"declaration","property":"margin-right","value":"28"},{"type":"declaration","property":"margin-left","value":"28"}]},{"type":"rule","selectors":[".m-y-28"],"declarations":[{"type":"declaration","property":"margin-top","value":"28"},{"type":"declaration","property":"margin-bottom","value":"28"}]},{"type":"rule","selectors":[".m-30"],"declarations":[{"type":"declaration","property":"margin","value":"30"}]},{"type":"rule","selectors":[".m-t-30"],"declarations":[{"type":"declaration","property":"margin-top","value":"30"}]},{"type":"rule","selectors":[".m-r-30"],"declarations":[{"type":"declaration","property":"margin-right","value":"30"}]},{"type":"rule","selectors":[".m-b-30"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"30"}]},{"type":"rule","selectors":[".m-l-30"],"declarations":[{"type":"declaration","property":"margin-left","value":"30"}]},{"type":"rule","selectors":[".m-x-30"],"declarations":[{"type":"declaration","property":"margin-right","value":"30"},{"type":"declaration","property":"margin-left","value":"30"}]},{"type":"rule","selectors":[".m-y-30"],"declarations":[{"type":"declaration","property":"margin-top","value":"30"},{"type":"declaration","property":"margin-bottom","value":"30"}]},{"type":"rule","selectors":[".p-0"],"declarations":[{"type":"declaration","property":"padding","value":"0"}]},{"type":"rule","selectors":[".p-t-0"],"declarations":[{"type":"declaration","property":"padding-top","value":"0"}]},{"type":"rule","selectors":[".p-r-0"],"declarations":[{"type":"declaration","property":"padding-right","value":"0"}]},{"type":"rule","selectors":[".p-b-0"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"0"}]},{"type":"rule","selectors":[".p-l-0"],"declarations":[{"type":"declaration","property":"padding-left","value":"0"}]},{"type":"rule","selectors":[".p-x-0"],"declarations":[{"type":"declaration","property":"padding-right","value":"0"},{"type":"declaration","property":"padding-left","value":"0"}]},{"type":"rule","selectors":[".p-y-0"],"declarations":[{"type":"declaration","property":"padding-top","value":"0"},{"type":"declaration","property":"padding-bottom","value":"0"}]},{"type":"rule","selectors":[".p-2"],"declarations":[{"type":"declaration","property":"padding","value":"2"}]},{"type":"rule","selectors":[".p-t-2"],"declarations":[{"type":"declaration","property":"padding-top","value":"2"}]},{"type":"rule","selectors":[".p-r-2"],"declarations":[{"type":"declaration","property":"padding-right","value":"2"}]},{"type":"rule","selectors":[".p-b-2"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"2"}]},{"type":"rule","selectors":[".p-l-2"],"declarations":[{"type":"declaration","property":"padding-left","value":"2"}]},{"type":"rule","selectors":[".p-x-2"],"declarations":[{"type":"declaration","property":"padding-right","value":"2"},{"type":"declaration","property":"padding-left","value":"2"}]},{"type":"rule","selectors":[".p-y-2"],"declarations":[{"type":"declaration","property":"padding-top","value":"2"},{"type":"declaration","property":"padding-bottom","value":"2"}]},{"type":"rule","selectors":[".p-4"],"declarations":[{"type":"declaration","property":"padding","value":"4"}]},{"type":"rule","selectors":[".p-t-4"],"declarations":[{"type":"declaration","property":"padding-top","value":"4"}]},{"type":"rule","selectors":[".p-r-4"],"declarations":[{"type":"declaration","property":"padding-right","value":"4"}]},{"type":"rule","selectors":[".p-b-4"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"4"}]},{"type":"rule","selectors":[".p-l-4"],"declarations":[{"type":"declaration","property":"padding-left","value":"4"}]},{"type":"rule","selectors":[".p-x-4"],"declarations":[{"type":"declaration","property":"padding-right","value":"4"},{"type":"declaration","property":"padding-left","value":"4"}]},{"type":"rule","selectors":[".p-y-4"],"declarations":[{"type":"declaration","property":"padding-top","value":"4"},{"type":"declaration","property":"padding-bottom","value":"4"}]},{"type":"rule","selectors":[".p-5"],"declarations":[{"type":"declaration","property":"padding","value":"5"}]},{"type":"rule","selectors":[".p-t-5"],"declarations":[{"type":"declaration","property":"padding-top","value":"5"}]},{"type":"rule","selectors":[".p-r-5"],"declarations":[{"type":"declaration","property":"padding-right","value":"5"}]},{"type":"rule","selectors":[".p-b-5"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"5"}]},{"type":"rule","selectors":[".p-l-5"],"declarations":[{"type":"declaration","property":"padding-left","value":"5"}]},{"type":"rule","selectors":[".p-x-5"],"declarations":[{"type":"declaration","property":"padding-right","value":"5"},{"type":"declaration","property":"padding-left","value":"5"}]},{"type":"rule","selectors":[".p-y-5"],"declarations":[{"type":"declaration","property":"padding-top","value":"5"},{"type":"declaration","property":"padding-bottom","value":"5"}]},{"type":"rule","selectors":[".p-8"],"declarations":[{"type":"declaration","property":"padding","value":"8"}]},{"type":"rule","selectors":[".p-t-8"],"declarations":[{"type":"declaration","property":"padding-top","value":"8"}]},{"type":"rule","selectors":[".p-r-8"],"declarations":[{"type":"declaration","property":"padding-right","value":"8"}]},{"type":"rule","selectors":[".p-b-8"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"8"}]},{"type":"rule","selectors":[".p-l-8"],"declarations":[{"type":"declaration","property":"padding-left","value":"8"}]},{"type":"rule","selectors":[".p-x-8"],"declarations":[{"type":"declaration","property":"padding-right","value":"8"},{"type":"declaration","property":"padding-left","value":"8"}]},{"type":"rule","selectors":[".p-y-8"],"declarations":[{"type":"declaration","property":"padding-top","value":"8"},{"type":"declaration","property":"padding-bottom","value":"8"}]},{"type":"rule","selectors":[".p-10"],"declarations":[{"type":"declaration","property":"padding","value":"10"}]},{"type":"rule","selectors":[".p-t-10"],"declarations":[{"type":"declaration","property":"padding-top","value":"10"}]},{"type":"rule","selectors":[".p-r-10"],"declarations":[{"type":"declaration","property":"padding-right","value":"10"}]},{"type":"rule","selectors":[".p-b-10"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"10"}]},{"type":"rule","selectors":[".p-l-10"],"declarations":[{"type":"declaration","property":"padding-left","value":"10"}]},{"type":"rule","selectors":[".p-x-10"],"declarations":[{"type":"declaration","property":"padding-right","value":"10"},{"type":"declaration","property":"padding-left","value":"10"}]},{"type":"rule","selectors":[".p-y-10"],"declarations":[{"type":"declaration","property":"padding-top","value":"10"},{"type":"declaration","property":"padding-bottom","value":"10"}]},{"type":"rule","selectors":[".p-12"],"declarations":[{"type":"declaration","property":"padding","value":"12"}]},{"type":"rule","selectors":[".p-t-12"],"declarations":[{"type":"declaration","property":"padding-top","value":"12"}]},{"type":"rule","selectors":[".p-r-12"],"declarations":[{"type":"declaration","property":"padding-right","value":"12"}]},{"type":"rule","selectors":[".p-b-12"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"12"}]},{"type":"rule","selectors":[".p-l-12"],"declarations":[{"type":"declaration","property":"padding-left","value":"12"}]},{"type":"rule","selectors":[".p-x-12"],"declarations":[{"type":"declaration","property":"padding-right","value":"12"},{"type":"declaration","property":"padding-left","value":"12"}]},{"type":"rule","selectors":[".p-y-12"],"declarations":[{"type":"declaration","property":"padding-top","value":"12"},{"type":"declaration","property":"padding-bottom","value":"12"}]},{"type":"rule","selectors":[".p-15"],"declarations":[{"type":"declaration","property":"padding","value":"15"}]},{"type":"rule","selectors":[".p-t-15"],"declarations":[{"type":"declaration","property":"padding-top","value":"15"}]},{"type":"rule","selectors":[".p-r-15"],"declarations":[{"type":"declaration","property":"padding-right","value":"15"}]},{"type":"rule","selectors":[".p-b-15"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"15"}]},{"type":"rule","selectors":[".p-l-15"],"declarations":[{"type":"declaration","property":"padding-left","value":"15"}]},{"type":"rule","selectors":[".p-x-15"],"declarations":[{"type":"declaration","property":"padding-right","value":"15"},{"type":"declaration","property":"padding-left","value":"15"}]},{"type":"rule","selectors":[".p-y-15"],"declarations":[{"type":"declaration","property":"padding-top","value":"15"},{"type":"declaration","property":"padding-bottom","value":"15"}]},{"type":"rule","selectors":[".p-16"],"declarations":[{"type":"declaration","property":"padding","value":"16"}]},{"type":"rule","selectors":[".p-t-16"],"declarations":[{"type":"declaration","property":"padding-top","value":"16"}]},{"type":"rule","selectors":[".p-r-16"],"declarations":[{"type":"declaration","property":"padding-right","value":"16"}]},{"type":"rule","selectors":[".p-b-16"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"16"}]},{"type":"rule","selectors":[".p-l-16"],"declarations":[{"type":"declaration","property":"padding-left","value":"16"}]},{"type":"rule","selectors":[".p-x-16"],"declarations":[{"type":"declaration","property":"padding-right","value":"16"},{"type":"declaration","property":"padding-left","value":"16"}]},{"type":"rule","selectors":[".p-y-16"],"declarations":[{"type":"declaration","property":"padding-top","value":"16"},{"type":"declaration","property":"padding-bottom","value":"16"}]},{"type":"rule","selectors":[".p-20"],"declarations":[{"type":"declaration","property":"padding","value":"20"}]},{"type":"rule","selectors":[".p-t-20"],"declarations":[{"type":"declaration","property":"padding-top","value":"20"}]},{"type":"rule","selectors":[".p-r-20"],"declarations":[{"type":"declaration","property":"padding-right","value":"20"}]},{"type":"rule","selectors":[".p-b-20"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"20"}]},{"type":"rule","selectors":[".p-l-20"],"declarations":[{"type":"declaration","property":"padding-left","value":"20"}]},{"type":"rule","selectors":[".p-x-20"],"declarations":[{"type":"declaration","property":"padding-right","value":"20"},{"type":"declaration","property":"padding-left","value":"20"}]},{"type":"rule","selectors":[".p-y-20"],"declarations":[{"type":"declaration","property":"padding-top","value":"20"},{"type":"declaration","property":"padding-bottom","value":"20"}]},{"type":"rule","selectors":[".p-24"],"declarations":[{"type":"declaration","property":"padding","value":"24"}]},{"type":"rule","selectors":[".p-t-24"],"declarations":[{"type":"declaration","property":"padding-top","value":"24"}]},{"type":"rule","selectors":[".p-r-24"],"declarations":[{"type":"declaration","property":"padding-right","value":"24"}]},{"type":"rule","selectors":[".p-b-24"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"24"}]},{"type":"rule","selectors":[".p-l-24"],"declarations":[{"type":"declaration","property":"padding-left","value":"24"}]},{"type":"rule","selectors":[".p-x-24"],"declarations":[{"type":"declaration","property":"padding-right","value":"24"},{"type":"declaration","property":"padding-left","value":"24"}]},{"type":"rule","selectors":[".p-y-24"],"declarations":[{"type":"declaration","property":"padding-top","value":"24"},{"type":"declaration","property":"padding-bottom","value":"24"}]},{"type":"rule","selectors":[".p-25"],"declarations":[{"type":"declaration","property":"padding","value":"25"}]},{"type":"rule","selectors":[".p-t-25"],"declarations":[{"type":"declaration","property":"padding-top","value":"25"}]},{"type":"rule","selectors":[".p-r-25"],"declarations":[{"type":"declaration","property":"padding-right","value":"25"}]},{"type":"rule","selectors":[".p-b-25"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"25"}]},{"type":"rule","selectors":[".p-l-25"],"declarations":[{"type":"declaration","property":"padding-left","value":"25"}]},{"type":"rule","selectors":[".p-x-25"],"declarations":[{"type":"declaration","property":"padding-right","value":"25"},{"type":"declaration","property":"padding-left","value":"25"}]},{"type":"rule","selectors":[".p-y-25"],"declarations":[{"type":"declaration","property":"padding-top","value":"25"},{"type":"declaration","property":"padding-bottom","value":"25"}]},{"type":"rule","selectors":[".p-28"],"declarations":[{"type":"declaration","property":"padding","value":"28"}]},{"type":"rule","selectors":[".p-t-28"],"declarations":[{"type":"declaration","property":"padding-top","value":"28"}]},{"type":"rule","selectors":[".p-r-28"],"declarations":[{"type":"declaration","property":"padding-right","value":"28"}]},{"type":"rule","selectors":[".p-b-28"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"28"}]},{"type":"rule","selectors":[".p-l-28"],"declarations":[{"type":"declaration","property":"padding-left","value":"28"}]},{"type":"rule","selectors":[".p-x-28"],"declarations":[{"type":"declaration","property":"padding-right","value":"28"},{"type":"declaration","property":"padding-left","value":"28"}]},{"type":"rule","selectors":[".p-y-28"],"declarations":[{"type":"declaration","property":"padding-top","value":"28"},{"type":"declaration","property":"padding-bottom","value":"28"}]},{"type":"rule","selectors":[".p-30"],"declarations":[{"type":"declaration","property":"padding","value":"30"}]},{"type":"rule","selectors":[".p-t-30"],"declarations":[{"type":"declaration","property":"padding-top","value":"30"}]},{"type":"rule","selectors":[".p-r-30"],"declarations":[{"type":"declaration","property":"padding-right","value":"30"}]},{"type":"rule","selectors":[".p-b-30"],"declarations":[{"type":"declaration","property":"padding-bottom","value":"30"}]},{"type":"rule","selectors":[".p-l-30"],"declarations":[{"type":"declaration","property":"padding-left","value":"30"}]},{"type":"rule","selectors":[".p-x-30"],"declarations":[{"type":"declaration","property":"padding-right","value":"30"},{"type":"declaration","property":"padding-left","value":"30"}]},{"type":"rule","selectors":[".p-y-30"],"declarations":[{"type":"declaration","property":"padding-top","value":"30"},{"type":"declaration","property":"padding-bottom","value":"30"}]},{"type":"rule","selectors":[".text-left"],"declarations":[{"type":"declaration","property":"text-align","value":"left"}]},{"type":"rule","selectors":[".text-right"],"declarations":[{"type":"declaration","property":"text-align","value":"right"}]},{"type":"rule","selectors":[".text-center"],"declarations":[{"type":"declaration","property":"text-align","value":"center"}]},{"type":"rule","selectors":[".text-lowercase"],"declarations":[{"type":"declaration","property":"text-transform","value":"lowercase"}]},{"type":"rule","selectors":[".text-uppercase"],"declarations":[{"type":"declaration","property":"text-transform","value":"uppercase"}]},{"type":"rule","selectors":[".text-capitalize"],"declarations":[{"type":"declaration","property":"text-transform","value":"capitalize"}]},{"type":"rule","selectors":[".font-weight-normal"],"declarations":[{"type":"declaration","property":"font-weight","value":"normal"}]},{"type":"rule","selectors":[".font-weight-bold"],"declarations":[{"type":"declaration","property":"font-weight","value":"bold"}]},{"type":"rule","selectors":[".font-italic"],"declarations":[{"type":"declaration","property":"font-style","value":"italic"}]},{"type":"rule","selectors":[".t-10"],"declarations":[{"type":"declaration","property":"font-size","value":"16"}]},{"type":"rule","selectors":[".t-12"],"declarations":[{"type":"declaration","property":"font-size","value":"18"}]},{"type":"rule","selectors":[".t-14"],"declarations":[{"type":"declaration","property":"font-size","value":"20"}]},{"type":"rule","selectors":[".t-15"],"declarations":[{"type":"declaration","property":"font-size","value":"21"}]},{"type":"rule","selectors":[".t-16"],"declarations":[{"type":"declaration","property":"font-size","value":"22"}]},{"type":"rule","selectors":[".t-17"],"declarations":[{"type":"declaration","property":"font-size","value":"23"}]},{"type":"rule","selectors":[".t-18"],"declarations":[{"type":"declaration","property":"font-size","value":"24"}]},{"type":"rule","selectors":[".t-19"],"declarations":[{"type":"declaration","property":"font-size","value":"25"}]},{"type":"rule","selectors":[".t-20"],"declarations":[{"type":"declaration","property":"font-size","value":"26"}]},{"type":"rule","selectors":[".t-25"],"declarations":[{"type":"declaration","property":"font-size","value":"31"}]},{"type":"rule","selectors":[".t-30"],"declarations":[{"type":"declaration","property":"font-size","value":"36"}]},{"type":"rule","selectors":[".t-36"],"declarations":[{"type":"declaration","property":"font-size","value":"42"}]},{"type":"rule","selectors":[".h1",".h2",".h3",".h4",".h5",".h6"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"4"},{"type":"declaration","property":"font-weight","value":"normal"},{"type":"declaration","property":"color","value":"#262626"}]},{"type":"rule","selectors":[".ns-dark .h1",".ns-dark .h2",".ns-dark .h3",".ns-dark .h4",".ns-dark .h5",".ns-dark .h6"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".body",".body2",".footnote"],"declarations":[{"type":"declaration","property":"color","value":"#737373"},{"type":"declaration","property":"font-weight","value":"normal"}]},{"type":"rule","selectors":[".ns-dark .body",".ns-dark .body2",".ns-dark .footnote"],"declarations":[{"type":"declaration","property":"color","value":"#b3b3b3"}]},{"type":"rule","selectors":[".h1"],"declarations":[{"type":"declaration","property":"font-size","value":"32"}]},{"type":"rule","selectors":[".h2"],"declarations":[{"type":"declaration","property":"font-size","value":"22"}]},{"type":"rule","selectors":[".h3"],"declarations":[{"type":"declaration","property":"font-size","value":"15"}]},{"type":"rule","selectors":[".h4"],"declarations":[{"type":"declaration","property":"font-size","value":"12"}]},{"type":"rule","selectors":[".h5"],"declarations":[{"type":"declaration","property":"font-size","value":"11"}]},{"type":"rule","selectors":[".h6"],"declarations":[{"type":"declaration","property":"font-size","value":"10"}]},{"type":"rule","selectors":[".body"],"declarations":[{"type":"declaration","property":"font-size","value":"14"}]},{"type":"rule","selectors":[".body2"],"declarations":[{"type":"declaration","property":"font-size","value":"17"}]},{"type":"rule","selectors":[".footnote"],"declarations":[{"type":"declaration","property":"font-size","value":"13"}]},{"type":"rule","selectors":[".ns-android .h1"],"declarations":[{"type":"declaration","property":"font-size","value":"34"}]},{"type":"rule","selectors":[".ns-android .h2"],"declarations":[{"type":"declaration","property":"font-size","value":"24"}]},{"type":"rule","selectors":[".ns-android .h3"],"declarations":[{"type":"declaration","property":"font-size","value":"16"}]},{"type":"rule","selectors":[".ns-android .h5"],"declarations":[{"type":"declaration","property":"font-size","value":"11"},{"type":"declaration","property":"font-weight","value":"bold"}]},{"type":"rule","selectors":[".ns-android .body2"],"declarations":[{"type":"declaration","property":"font-size","value":"14"},{"type":"declaration","property":"font-weight","value":"500"}]},{"type":"rule","selectors":[".img-rounded"],"declarations":[{"type":"declaration","property":"border-radius","value":"5"}]},{"type":"rule","selectors":[".img-circle"],"declarations":[{"type":"declaration","property":"border-radius","value":"50%"}]},{"type":"rule","selectors":[".img-thumbnail"],"declarations":[{"type":"declaration","property":"border-radius","value":"0"}]},{"type":"rule","selectors":[".invisible"],"declarations":[{"type":"declaration","property":"visibility","value":"collapse"}]},{"type":"rule","selectors":[".pull-left"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"left"}]},{"type":"rule","selectors":[".pull-right"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"right"}]},{"type":"rule","selectors":[".m-x-auto"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"center"}]},{"type":"rule","selectors":[".m-y-auto"],"declarations":[{"type":"declaration","property":"vertical-align","value":"center"}]},{"type":"rule","selectors":[".text-primary"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".text-danger"],"declarations":[{"type":"declaration","property":"color","value":"#d50000"}]},{"type":"rule","selectors":[".bg-primary"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".bg-danger"],"declarations":[{"type":"declaration","property":"background-color","value":"#d50000"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".fa"],"declarations":[{"type":"declaration","property":"font-family","value":"FontAwesome,fontawesome-webfont"}]},{"type":"rule","selectors":[".ns-root"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"font-family","value":"sans-serif"},{"type":"declaration","property":"font-weight","value":"normal"},{"type":"declaration","property":"font-size","value":"16"}]},{"type":"rule","selectors":[".ns-dark.ns-root"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".-hidden",".hidden"],"declarations":[{"type":"declaration","property":"visibility","value":"collapsed"}]},{"type":"rule","selectors":[".-rounded",".rounded"],"declarations":[{"type":"declaration","property":"border-radius","value":"5"}]},{"type":"rule","selectors":[".hr"],"declarations":[{"type":"declaration","property":"height","value":"1"},{"type":"declaration","property":"width","value":"100%"},{"type":"declaration","property":"margin","value":"9 0 10"},{"type":"declaration","property":"border-width","value":"0 0 1"},{"type":"declaration","property":"border-style","value":"solid"}]},{"type":"rule","selectors":[".text-muted"],"declarations":[{"type":"declaration","property":"color","value":"#ace4ff"}]},{"type":"rule","selectors":[".ns-dark .text-muted"],"declarations":[{"type":"declaration","property":"color","value":"#306883"}]},{"type":"rule","selectors":["Label>*","Label>*>*","Button>*","Button>*>*","TextField>*","TextField>*>*","TextView>*","TextView>*>*"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":["Image","ListView","RadListView"],"declarations":[{"type":"declaration","property":"min-height","value":"100"}]},{"type":"rule","selectors":["NTIcon",".nt-icon"],"declarations":[{"type":"declaration","property":"font-size","value":"18"}]},{"type":"rule","selectors":["Button",".nt-button"],"declarations":[{"type":"declaration","property":"text-transform","value":"none"},{"type":"declaration","property":"border-color","value":"transparent"},{"type":"declaration","property":"min-width","value":"64"},{"type":"declaration","property":"height","value":"52"},{"type":"declaration","property":"padding","value":"0 0 0 0"},{"type":"declaration","property":"font-size","value":"18"},{"type":"declaration","property":"margin","value":"8 16 8 16"}]},{"type":"rule","selectors":[".ns-ios Button",".ns-ios .nt-button"],"declarations":[{"type":"declaration","property":"height","value":"40"},{"type":"declaration","property":"border-width","value":"0"}]},{"type":"rule","selectors":[".ns-android Button",".ns-android .nt-button"],"declarations":[{"type":"declaration","property":"margin","value":"4 12"}]},{"type":"rule","selectors":["Button.-outline",".nt-button.-outline"],"declarations":[{"type":"declaration","property":"height","value":"40"},{"type":"declaration","property":"border-width","value":"1"}]},{"type":"rule","selectors":[".ns-android Button.-outline",".ns-android .nt-button.-outline"],"declarations":[{"type":"declaration","property":"margin","value":"8 16"}]},{"type":"rule","selectors":["Button.-rounded-sm","Button.-rounded-lg",".nt-button.-rounded-sm",".nt-button.-rounded-lg"],"declarations":[{"type":"declaration","property":"height","value":"40"},{"type":"declaration","property":"border-radius","value":"4"}]},{"type":"rule","selectors":[".ns-android Button.-rounded-sm",".ns-android Button.-rounded-lg",".ns-android .nt-button.-rounded-sm",".ns-android .nt-button.-rounded-lg"],"declarations":[{"type":"declaration","property":"margin","value":"8 16"}]},{"type":"rule","selectors":["Button.-rounded-lg",".nt-button.-rounded-lg"],"declarations":[{"type":"declaration","property":"border-radius","value":"50%"}]},{"type":"rule","selectors":["Button[isEnabled=false]",".nt-button[isEnabled=false]"],"declarations":[{"type":"declaration","property":"opacity","value":".5"}]},{"type":"rule","selectors":["Button.-simple",".nt-button.-simple"],"declarations":[{"type":"declaration","property":"android-elevation","value":"0"},{"type":"declaration","property":"android-dynamic-elevation-offset","value":"0"}]},{"type":"rule","selectors":[".ns-root Button.-aqua",".ns-root .nt-button.-aqua"],"declarations":[{"type":"declaration","property":"background-color","value":"#00caab"},{"type":"declaration","property":"border-color","value":"#00caab"},{"type":"declaration","property":"color","value":"#fdffff"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-aqua",".ns-dark.ns-root .nt-button.-aqua"],"declarations":[{"type":"declaration","property":"background-color","value":"#00caab"},{"type":"declaration","property":"border-color","value":"#00caab"},{"type":"declaration","property":"color","value":"#fdffff"}]},{"type":"rule","selectors":[".ns-root Button.-blue",".ns-root .nt-button.-blue"],"declarations":[{"type":"declaration","property":"background-color","value":"#3d5afe"},{"type":"declaration","property":"border-color","value":"#3d5afe"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-blue",".ns-dark.ns-root .nt-button.-blue"],"declarations":[{"type":"declaration","property":"background-color","value":"#3d5afe"},{"type":"declaration","property":"border-color","value":"#3d5afe"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-root Button.-brown",".ns-root .nt-button.-brown"],"declarations":[{"type":"declaration","property":"background-color","value":"#795548"},{"type":"declaration","property":"border-color","value":"#795548"},{"type":"declaration","property":"color","value":"#fbf9f8"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-brown",".ns-dark.ns-root .nt-button.-brown"],"declarations":[{"type":"declaration","property":"background-color","value":"#795548"},{"type":"declaration","property":"border-color","value":"#795548"},{"type":"declaration","property":"color","value":"#fbf9f8"}]},{"type":"rule","selectors":[".ns-root Button.-forest",".ns-root .nt-button.-forest"],"declarations":[{"type":"declaration","property":"color","value":"#9cfffe"},{"type":"declaration","property":"background-color","value":"#006968"},{"type":"declaration","property":"border-color","value":"#006968"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-forest",".ns-dark.ns-root .nt-button.-forest"],"declarations":[{"type":"declaration","property":"color","value":"#9cfffe"},{"type":"declaration","property":"background-color","value":"#006968"},{"type":"declaration","property":"border-color","value":"#006968"}]},{"type":"rule","selectors":[".ns-root Button.-grey",".ns-root .nt-button.-grey"],"declarations":[{"type":"declaration","property":"background-color","value":"#5c687c"},{"type":"declaration","property":"border-color","value":"#5c687c"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-grey",".ns-dark.ns-root .nt-button.-grey"],"declarations":[{"type":"declaration","property":"background-color","value":"#5c687c"},{"type":"declaration","property":"border-color","value":"#5c687c"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-root Button.-lemon",".ns-root .nt-button.-lemon"],"declarations":[{"type":"declaration","property":"background-color","value":"#ffea00"},{"type":"declaration","property":"border-color","value":"#ffea00"},{"type":"declaration","property":"color","value":"#000"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-lemon",".ns-dark.ns-root .nt-button.-lemon"],"declarations":[{"type":"declaration","property":"background-color","value":"#ffea00"},{"type":"declaration","property":"border-color","value":"#ffea00"},{"type":"declaration","property":"color","value":"#000"}]},{"type":"rule","selectors":[".ns-root Button.-lime",".ns-root .nt-button.-lime"],"declarations":[{"type":"declaration","property":"background-color","value":"#aee406"},{"type":"declaration","property":"border-color","value":"#aee406"},{"type":"declaration","property":"color","value":"#000"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-lime",".ns-dark.ns-root .nt-button.-lime"],"declarations":[{"type":"declaration","property":"background-color","value":"#aee406"},{"type":"declaration","property":"border-color","value":"#aee406"},{"type":"declaration","property":"color","value":"#000"}]},{"type":"rule","selectors":[".ns-root Button.-orange",".ns-root .nt-button.-orange"],"declarations":[{"type":"declaration","property":"background-color","value":"#f57c00"},{"type":"declaration","property":"border-color","value":"#f57c00"},{"type":"declaration","property":"color","value":"#000"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-orange",".ns-dark.ns-root .nt-button.-orange"],"declarations":[{"type":"declaration","property":"background-color","value":"#f57c00"},{"type":"declaration","property":"border-color","value":"#f57c00"},{"type":"declaration","property":"color","value":"#000"}]},{"type":"rule","selectors":[".ns-root Button.-purple",".ns-root .nt-button.-purple"],"declarations":[{"type":"declaration","property":"background-color","value":"#8130ff"},{"type":"declaration","property":"border-color","value":"#8130ff"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-purple",".ns-dark.ns-root .nt-button.-purple"],"declarations":[{"type":"declaration","property":"background-color","value":"#8130ff"},{"type":"declaration","property":"border-color","value":"#8130ff"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-root Button.-ruby",".ns-root .nt-button.-ruby"],"declarations":[{"type":"declaration","property":"background-color","value":"#ff1744"},{"type":"declaration","property":"border-color","value":"#ff1744"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-ruby",".ns-dark.ns-root .nt-button.-ruby"],"declarations":[{"type":"declaration","property":"background-color","value":"#ff1744"},{"type":"declaration","property":"border-color","value":"#ff1744"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-root Button.-sky",".ns-root .nt-button.-sky"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"border-color","value":"#30bcff"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark.ns-root Button.-sky",".ns-dark.ns-root .nt-button.-sky"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"border-color","value":"#30bcff"},{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":["Page",".nt-page"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark Page",".ns-dark .nt-page"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":["ActivityIndicator",".nt-activity-indicator"],"declarations":[{"type":"declaration","property":"width","value":"30"},{"type":"declaration","property":"height","value":"30"}]},{"type":"rule","selectors":["Slider",".nt-slider"],"declarations":[{"type":"declaration","property":"margin","value":"20 16"}]},{"type":"rule","selectors":[".ns-ios Slider",".ns-ios .nt-slider"],"declarations":[{"type":"declaration","property":"margin","value":"10 15"}]},{"type":"rule","selectors":["Slider[isEnabled=false]",".nt-slider[isEnabled=false]"],"declarations":[{"type":"declaration","property":"background-color","value":"#e0e0e0"},{"type":"declaration","property":"color","value":"#e0e0e0"}]},{"type":"rule","selectors":[".ns-android Switch",".ns-android .nt-switch"],"declarations":[{"type":"declaration","property":"margin","value":"14 16"}]},{"type":"rule","selectors":[".ns-android Switch[isEnabled=false]",".ns-android .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e6e6e6"}]},{"type":"rule","selectors":[".ns-dark.ns-android Switch[isEnabled=false]",".ns-dark.ns-android .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#4a4a4a"}]},{"type":"rule","selectors":[".ns-ios Switch",".ns-ios .nt-switch"],"declarations":[{"type":"declaration","property":"margin","value":"8 15"}]},{"type":"rule","selectors":[".ns-ios Switch[isEnabled=false]",".ns-ios .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":[".ns-dark.ns-ios Switch[isEnabled=false]",".ns-dark.ns-ios .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":["TabView",".nt-tab-view"],"declarations":[{"type":"declaration","property":"tab-text-font-size","value":"18"},{"type":"declaration","property":"text-transform","value":"capitalize"}]},{"type":"rule","selectors":["BottomNavigation",".nt-bottom-navigation"],"declarations":[{"type":"declaration","property":"font-size","value":"14"}]},{"type":"rule","selectors":["ListView","RadListView",".nt-list-view"],"declarations":[{"type":"declaration","property":"min-height","value":"100"},{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":["ListView StackLayout","RadListView StackLayout",".nt-list-view StackLayout"],"declarations":[{"type":"declaration","property":"padding","value":"8"}]},{"type":"rule","selectors":["ListView>*","RadListView>*",".nt-list-view>*"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"},{"type":"declaration","property":"padding","value":"8"},{"type":"declaration","property":"margin","value":"0"}]},{"type":"rule","selectors":["ListView>* Label","RadListView>* Label",".nt-list-view>* Label"],"declarations":[{"type":"declaration","property":"padding","value":"5"},{"type":"declaration","property":"vertical-align","value":"center"}]},{"type":"rule","selectors":["ListView>* Image","RadListView>* Image",".nt-list-view>* Image"],"declarations":[{"type":"declaration","property":"stretch","value":"aspectFit"}]},{"type":"rule","selectors":["ListView.-single-col-cards Image","RadListView.-single-col-cards Image",".nt-list-view.-single-col-cards Image"],"declarations":[{"type":"declaration","property":"width","value":"100%"},{"type":"declaration","property":"height","value":"200"}]},{"type":"rule","selectors":["ListView.-two-col-cards Image","RadListView.-two-col-cards Image",".nt-list-view.-two-col-cards Image"],"declarations":[{"type":"declaration","property":"height","value":"100"}]},{"type":"rule","selectors":[".ns-ios ListView.-two-col-cards>StackLayout",".ns-ios RadListView.-two-col-cards>StackLayout",".ns-ios .nt-list-view.-two-col-cards>StackLayout"],"declarations":[{"type":"declaration","property":"width","value":"50%"}]},{"type":"rule","selectors":[".ns-ios ListView.-two-col-cards>StackLayout Image",".ns-ios RadListView.-two-col-cards>StackLayout Image",".ns-ios .nt-list-view.-two-col-cards>StackLayout Image"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"left"},{"type":"declaration","property":"width","value":"100%"}]},{"type":"rule","selectors":["ListView.-two-lines-image Image","ListView.-single-line-image Image","RadListView.-two-lines-image Image","RadListView.-single-line-image Image",".nt-list-view.-two-lines-image Image",".nt-list-view.-single-line-image Image"],"declarations":[{"type":"declaration","property":"width","value":"60"},{"type":"declaration","property":"height","value":"60"},{"type":"declaration","property":"margin-right","value":"10"},{"type":"declaration","property":"margin-bottom","value":"0"}]},{"type":"rule","selectors":["ListView .-separator","RadListView .-separator",".nt-list-view .-separator"],"declarations":[{"type":"declaration","property":"border-bottom-width","value":"1"}]},{"type":"rule","selectors":["ListView .nt-list-view__delete","RadListView .nt-list-view__delete",".nt-list-view .nt-list-view__delete"],"declarations":[{"type":"declaration","property":"padding","value":"0 10"}]},{"type":"rule","selectors":[".ns-ios ListView .nt-list-view__delete",".ns-ios RadListView .nt-list-view__delete",".ns-ios .nt-list-view .nt-list-view__delete"],"declarations":[{"type":"declaration","property":"padding","value":"0 10 0 25"}]},{"type":"rule","selectors":["ListView .nt-list-view__delete>Label","RadListView .nt-list-view__delete>Label",".nt-list-view .nt-list-view__delete>Label"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"center"},{"type":"declaration","property":"vertical-align","value":"center"},{"type":"declaration","property":"text-transform","value":"capitalize"}]},{"type":"rule","selectors":["ListView NTIcon","ListView .nt-icon","RadListView NTIcon","RadListView .nt-icon",".nt-list-view NTIcon",".nt-list-view .nt-icon"],"declarations":[{"type":"declaration","property":"font-size","value":"20"},{"type":"declaration","property":"width","value":"56"},{"type":"declaration","property":"height","value":"100%"},{"type":"declaration","property":"text-align","value":"center"}]},{"type":"rule","selectors":["RadListView>StackLayout"],"declarations":[{"type":"declaration","property":"padding","value":"0"}]},{"type":"rule","selectors":["RadListView>*>*"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header",".nt-drawer .nt-drawer__header"],"declarations":[{"type":"declaration","property":"height","value":"148"},{"type":"declaration","property":"width","value":"100%"},{"type":"declaration","property":"vertical-align","value":"center"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header Label",".nt-drawer .nt-drawer__header Label"],"declarations":[{"type":"declaration","property":"padding","value":"0"},{"type":"declaration","property":"vertical-align","value":"center"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header>Label",".nt-drawer .nt-drawer__header>Label"],"declarations":[{"type":"declaration","property":"font-size","value":"18"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header-image",".nt-drawer .nt-drawer__header-image"],"declarations":[{"type":"declaration","property":"height","value":"74"},{"type":"declaration","property":"width","value":"74"},{"type":"declaration","property":"border-radius","value":"50%"},{"type":"declaration","property":"vertical-align","value":"center"},{"type":"declaration","property":"margin-bottom","value":"0"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header-footnote",".nt-drawer .nt-drawer__header-footnote"],"declarations":[{"type":"declaration","property":"opacity","value":".5"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header>Label","RadSideDrawer .nt-drawer__header-image",".nt-drawer .nt-drawer__header>Label",".nt-drawer .nt-drawer__header-image"],"declarations":[{"type":"declaration","property":"margin-left","value":"15"},{"type":"declaration","property":"margin-right","value":"15"},{"type":"declaration","property":"horizontal-align","value":"center"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header.-left>Label","RadSideDrawer .nt-drawer__header.-left .nt-drawer__header-image",".nt-drawer .nt-drawer__header.-left>Label",".nt-drawer .nt-drawer__header.-left .nt-drawer__header-image"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"left"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__list-item",".nt-drawer .nt-drawer__list-item"],"declarations":[{"type":"declaration","property":"padding-left","value":"15"},{"type":"declaration","property":"height","value":"48"},{"type":"declaration","property":"horizontal-align","value":"left"},{"type":"declaration","property":"width","value":"100%"},{"type":"declaration","property":"orientation","value":"horizontal"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__list-item Label",".nt-drawer .nt-drawer__list-item Label"],"declarations":[{"type":"declaration","property":"vertical-align","value":"center"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__list-item NTIcon","RadSideDrawer .nt-drawer__list-item .nt-icon",".nt-drawer .nt-drawer__list-item NTIcon",".nt-drawer .nt-drawer__list-item .nt-icon"],"declarations":[{"type":"declaration","property":"font-size","value":"16"},{"type":"declaration","property":"width","value":"30"}]},{"type":"rule","selectors":["RadSideDrawer.ns-dark .nt-drawer__header",".nt-drawer.ns-dark .nt-drawer__header"],"declarations":[{"type":"declaration","property":"background-color","value":"#232323"}]},{"type":"rule","selectors":["RadSideDrawer.ns-dark .nt-drawer__header Label",".nt-drawer.ns-dark .nt-drawer__header Label"],"declarations":[{"type":"declaration","property":"color","value":"#d4d4d4"}]},{"type":"rule","selectors":["Form",".nt-form"],"declarations":[{"type":"declaration","property":"font-family","value":"\"Roboto Regular\""},{"type":"declaration","property":"padding","value":"16 0 10"}]},{"type":"rule","selectors":[".ns-ios Form",".ns-ios .nt-form"],"declarations":[{"type":"declaration","property":"font-family","value":"\"SF UI Text Regular\",system"}]},{"type":"rule","selectors":["Form .-center",".nt-form .-center"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"center"}]},{"type":"rule","selectors":["Form .nt-form__or-separator",".nt-form .nt-form__or-separator"],"declarations":[{"type":"declaration","property":"margin","value":"20 0"}]},{"type":"rule","selectors":["Form .nt-form__link",".nt-form .nt-form__link"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark Form .nt-form__link",".ns-dark .nt-form .nt-form__link"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["Form .nt-form__title",".nt-form .nt-form__title"],"declarations":[{"type":"declaration","property":"font-size","value":"18"}]},{"type":"rule","selectors":["Form .nt-form__logo",".nt-form .nt-form__logo"],"declarations":[{"type":"declaration","property":"margin","value":"20 0"},{"type":"declaration","property":"width","value":"50%"}]},{"type":"rule","selectors":["Form .nt-form__validation-message",".nt-form .nt-form__validation-message"],"declarations":[{"type":"declaration","property":"color","value":"#d50000"},{"type":"declaration","property":"margin","value":"1 0 0"},{"type":"declaration","property":"padding","value":"0"},{"type":"declaration","property":"height","value":"19"}]},{"type":"rule","selectors":["Form .nt-form__footer",".nt-form .nt-form__footer"],"declarations":[{"type":"declaration","property":"padding","value":"0"},{"type":"declaration","property":"horizontal-align","value":"center"}]},{"type":"rule","selectors":["Form .nt-form__footer Button",".nt-form .nt-form__footer Button"],"declarations":[{"type":"declaration","property":"width","value":"50%"},{"type":"declaration","property":"margin","value":"5"}]},{"type":"rule","selectors":["Form[isEnabled=false] *",".nt-form[isEnabled=false] *"],"declarations":[{"type":"declaration","property":"opacity","value":".5"}]},{"type":"rule","selectors":["TextView.ng-valid","TextField.ng-valid","PickerField.ng-valid","DatePickerField.ng-valid","TimePickerField.ng-valid","RadAutoCompleteTextView.ng-valid"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"20"}]},{"type":"rule","selectors":["TextView.ng-invalid.ng-dirty","TextField.ng-invalid.ng-dirty","PickerField.ng-invalid.ng-dirty","DatePickerField.ng-invalid.ng-dirty","TimePickerField.ng-invalid.ng-dirty","RadAutoCompleteTextView.ng-invalid.ng-dirty"],"declarations":[{"type":"declaration","property":"margin-bottom","value":"0"},{"type":"declaration","property":"border-color","value":"#d50000"}]},{"type":"rule","selectors":["TextView","TextField","PickerField","DatePickerField","TimePickerField","DateTimePickerFields","DataFormEditorCore","RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"border-width","value":"0 0 1"},{"type":"declaration","property":"border-radius","value":"0"},{"type":"declaration","property":"background-color","value":"transparent"},{"type":"declaration","property":"font-size","value":"16"},{"type":"declaration","property":"padding","value":"8 0 4"},{"type":"declaration","property":"margin","value":"5 16"}]},{"type":"rule","selectors":["TextView.-rounded","TextView.-border","TextField.-rounded","TextField.-border","PickerField.-rounded","PickerField.-border","DatePickerField.-rounded","DatePickerField.-border","TimePickerField.-rounded","TimePickerField.-border","DateTimePickerFields.-rounded","DateTimePickerFields.-border","DataFormEditorCore.-rounded","DataFormEditorCore.-border","RadAutoCompleteTextView.-rounded","RadAutoCompleteTextView.-border"],"declarations":[{"type":"declaration","property":"border-width","value":"1"},{"type":"declaration","property":"border-radius","value":"5"},{"type":"declaration","property":"padding","value":"12 14"}]},{"type":"rule","selectors":["TextView.-rounded","TextField.-rounded","PickerField.-rounded","DatePickerField.-rounded","TimePickerField.-rounded","DateTimePickerFields.-rounded","DataFormEditorCore.-rounded","RadAutoCompleteTextView.-rounded"],"declarations":[{"type":"declaration","property":"border-radius","value":"50%"}]},{"type":"rule","selectors":["TextView[isEnabled=false]","TextField[isEnabled=false]","PickerField[isEnabled=false]","DatePickerField[isEnabled=false]","TimePickerField[isEnabled=false]","DateTimePickerFields[isEnabled=false]","DataFormEditorCore[isEnabled=false]","RadAutoCompleteTextView[isEnabled=false]"],"declarations":[{"type":"declaration","property":"opacity","value":".5"}]},{"type":"rule","selectors":["Label","DataFormEditorLabel"],"declarations":[{"type":"declaration","property":"padding","value":"2 0"}]},{"type":"rule","selectors":["TextView"],"declarations":[{"type":"declaration","property":"min-height","value":"100"}]},{"type":"rule","selectors":["RadAutoCompleteTextView[displayMode=Tokens]"],"declarations":[{"type":"declaration","property":"padding","value":"4 0 8"}]},{"type":"rule","selectors":["RadAutoCompleteTextView Token"],"declarations":[{"type":"declaration","property":"border-radius","value":"50%"}]},{"type":"rule","selectors":[".ns-android TokenClearButton"],"declarations":[{"type":"declaration","property":"width","value":"18"},{"type":"declaration","property":"height","value":"18"},{"type":"declaration","property":"border-radius","value":"50%"},{"type":"declaration","property":"opacity","value":".6"}]},{"type":"rule","selectors":["PickerField","DatePickerField","TimePickerField","DateTimePickerFields","DataFormEditorCore","RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"background-repeat","value":"no-repeat"},{"type":"declaration","property":"background-position","value":"right center"}]},{"type":"rule","selectors":[".ns-ios PickerField",".ns-ios DatePickerField",".ns-ios TimePickerField",".ns-ios DateTimePickerFields",".ns-ios DataFormEditorCore",".ns-ios RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"background-size","value":"28 16"}]},{"type":"rule","selectors":["PropertyEditor[type=Date] DataFormEditorCore","DatePickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAAAwBAMAAAB9IEC+AAAAD1BMVEVHcEwAAAAAAAAAAAAAAADTrAj/AAAABHRSTlMAwBAgU5DCQwAAAFdJREFUSMdjYCAVuLi4oDHop5RJxAUDOCpgVcroggUIYFXKgk2pMw6lChhudXHAoZSBVkrRw26EKcUC6Kt0NAoGkVIWaFSNKh25Sgd7QURCZURCFUcLAAC2I2hEECBYPgAAAABJRU5ErkJggg==\")"}]},{"type":"rule","selectors":["PropertyEditor[type=Time] DataFormEditorCore","TimePickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAAAwBAMAAAB9IEC+AAAALVBMVEVHcEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACttl6nAAAADnRSTlMAYOBAwCAQ0FCAcPCwoEZwdhsAAAE2SURBVEjHY2AYLIB1Td27d89PBRBWyQhUCALPBQiq1HsHBY8IqGX1e/fuyWRjY0sQjd8N3e/eKSaAGGxC797twGs9UCWMDVSLzwly794mwNhs9949xK2SA8UgoBUNOJVGo5oj924rTqV+EEP53sGMfYLbU28ZkJUy3MPpMaZ3aqhKk94p4PS/AKpSRpxhUPeIAVUpg95zHJEKMwOhVO4d9sjlevcMXWneuwVYlfK8c0BXyvLuAI4AmICulPNdAValfO8M0JVyvHtArFJmqiqFACopbSBWKTsssBAAV2DBowABcEUBPGIRAFfEsmImOVzJBZ4IEQBXIoQnbaQc9JBAhoED3BkGlg3hAHc2hGVuhNYn1CgySCiISCjeSCk0SSiKIQX8DGPjTsIFPAnVBimVESlV3IABAKDkz5jHIcToAAAAAElFTkSuQmCC\")"}]},{"type":"rule","selectors":["DateTimePickerFields"],"declarations":[{"type":"declaration","property":"padding","value":"0"},{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAAAwBAMAAAB3UCypAAAALVBMVEVHcEwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACttl6nAAAADnRSTlMAQGDgwBAg0FCAcPCwoM9Ie+kAAAGcSURBVEjH5Ze/TsMwEMZD2pQWVRUZu0VijxASa8UTVJXYUXYWniDqilhgY+QBmBEjMw9RtTQlU79nICRyrDjxxYkdqYhviYe7X87/7s6WlQqAMDCgPwF15igpWhAOg9cQiD8DCtpHha7k9naYmcQeAZ1UQb/lzBmz2XoUdFFaU2ykc08WK3py3envNyCgVgPoA3CRLrhzBrybgdoJk40TqkdCxRMmg/rY5wfDWeHLBHRYCC4Je2kAeluMzcebAeg8C5S52Ij0oTb2RZeVbKsaQHu4LLpc47zBjdpI9t4rQm3Z/jeAhltxcrNYFzpgcXGoj0BzTU+wE11u8KIJHbOMyF36+NCE9vAouowk268OneBUdBlibR56dPDQTAcMXbaBZtZrCfSYHSmuEe40oeNyO6By+Glofk25VK4pDR2UE51KQqGheerjkqc+ZagvVg8iSStDWTnJRZQTZSgrfLmUCl8NlJVo/hOVEl0HbdVM1EFbtT110E4atG5ayUZNrzI0bc+fXfe+rj2v0E7zIdHJk6eTx5nluCUF1j/RDxQQPw3i9N+zAAAAAElFTkSuQmCC\")"}]},{"type":"rule","selectors":[".ns-ios DateTimePickerFields"],"declarations":[{"type":"declaration","property":"background-size","value":"56 16"}]},{"type":"rule","selectors":["DateTimePickerFields .input","DateTimePickerFields DatePickerField","DateTimePickerFields TimePickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"none"},{"type":"declaration","property":"border-width","value":"0"},{"type":"declaration","property":"margin","value":"0"}]},{"type":"rule","selectors":[".ns-dark DateTimePickerFields .input",".ns-dark DateTimePickerFields DatePickerField",".ns-dark DateTimePickerFields TimePickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"none"},{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":["DateTimePickerFields TimePickerField"],"declarations":[{"type":"declaration","property":"margin-left","value":"-30"}]},{"type":"rule","selectors":["PickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAAAwBAMAAAB9IEC+AAAAGFBMVEVHcEwAAAAAAAAAAAAAAAAAAAAAAAAAAABoAtTLAAAAB3RSTlMAoPAw0BAgCEJU4wAAAEpJREFUSMdjYBgFgwUwChCtVLyQaEPLy4k1Nqm8nFhjmdWJN9Zo1NghZiwJSol3wKihA2ooCZk7hPj0x+pOdEHEEEJ88TYKBgoAAAC5JRg49rIWAAAAAElFTkSuQmCC\")"}]},{"type":"rule","selectors":["PickerPage.input"],"declarations":[{"type":"declaration","property":"padding","value":"0"},{"type":"declaration","property":"margin","value":"0"}]},{"type":"rule","selectors":["PickerPage ListView"],"declarations":[{"type":"declaration","property":"separator-color","value":"transparent"}]},{"type":"rule","selectors":["PickerPage ListView>*"],"declarations":[{"type":"declaration","property":"height","value":"48"},{"type":"declaration","property":"margin-top","value":"0"},{"type":"declaration","property":"padding","value":"10 12"},{"type":"declaration","property":"border-bottom-width","value":"1px"}]},{"type":"rule","selectors":[".ns-dark PickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAAAwBAMAAAB9IEC+AAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAYUExURUdwTP///////////////////////////x1LVb4AAAAHdFJOUwCg8DDQECAIQlTjAAAASklEQVRIx2NgGAWDBTAKEK1UvJBoQ8vLiTU2qbycWGOZ1Yk31mjU2CFmLAlKiXfAqKEDaigJmTuE+PTH6k50QcQQQnzxNgoGCgAAALklGDj2shYAAAAASUVORK5CYII=\")"}]},{"type":"rule","selectors":[".ns-dark DatePickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAAAwBAMAAAB9IEC+AAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAPUExURUdwTP///////////////xPgMRoAAAAEdFJOUwDAECBTkMJDAAAAV0lEQVRIx2NgIBW4uLigMeinlEnEBQM4KmBVyuiCBQhgVcqCTakzDqUKGG51ccChlIFWStHDboQpxQLoq3Q0CgaRUhZoVI0qHblKB3tBREJlREIVRwsAALYjaEQQIFg+AAAAAElFTkSuQmCC\")"}]},{"type":"rule","selectors":[".ns-dark TimePickerField"],"declarations":[{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFQAAAAwBAMAAAB9IEC+AAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAtUExURUdwTP///////////////////////////////////////////////////////81e3QIAAAAOdFJOUwBg4EDAIBDQUHDwsKCA4isvJAAAATZJREFUSMdjYBgsgHV23bt3z3cGEFbJCFQIAs8FCKrUewcFjwioZfV79+7JZWNjWxCN3w1d794pJoAYbELv3q3Aaz1QJYwNVIvPCXLv3iTA2Gzn3j3ErZIDxSCgFQ04lUahmiP3bilOpX4QQ/newYx9gttTbxiQlTKcw+kxpndqqEqT3ing9L8AqlJGnGFQ94gBVSmD3nMckQozA6FU7h32yOV89wxdad67CViVcr9zQFfK8m4DjgC4gK6U910BVqV87wzQlXK8e0CsUmaqKoUAKiltIFYpOyywEABXYMGjAAFwRQE8YhEAV8SyYiY5XMkFnggRAFcihCdtpBz0kECGgQPcGQaWDeEAdzaEZW6E1ifUKDJIKIhIKN5IKTRJKIohBfwNY+NewgU8CdUGKZURKVXcgAEAq1LPmF1qDewAAAAASUVORK5CYII=\")"}]},{"type":"rule","selectors":[".ns-dark DateTimePickerFields"],"declarations":[{"type":"declaration","property":"background-image","value":"url(\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKgAAAAwBAMAAAB3UCypAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAtUExURUdwTP///////////////////////////////////////////////////////81e3QIAAAAOdFJOUwBAYODAECDQUHDwsKCAaxMi1gAAAZxJREFUSMfll89Kw0AQxmPa1EppMQ9QCHgPIngtPkEpeJecPfkEoWdB8O5dPHr1JYrePLY2NZfyPYMxYbNkk51sshuo+F2yh5lfZv/NzFpWKgDCwID+BNSZo6RoQTgMnkIgfgsoaB8VupLb22FmEnsEdFIF/ZYzZ8xm61HQRWlNsZHOPVms6MN1p7/fgIBaDaD3wEW64M4Z8GIGaidMNk6oHgkVT5gM6mOfHwxnhS8T0GEhuCTspQHobTE2H88GoPMsUOZiI9KH2tgXXVayrWoA7eGy6HKN8wY3aiPZe68ItWX73wAabsXJzWJd6IDFxaE+As01PcFOdLnBoyZ0xDIid+njVRPaw7voMpZsvzp0glPRZYi1eejRwUMzHTB02QaaWa8l0GN2pLjGuNOEjsrtgMrhp6H5NeVSuaY0dFBOdCoJhYbmqY9LnvqUob5YPYgkrQxl5SQXUU6Uoazw5VIqfDVQVqL5T1RKdB20VTNRB23V9tRBO2nQumklGzW9ytC0Pf903Ye69rxCO82HRCdPnk4eZ5bjlhRY/0Q/Hn4/DfXSncYAAAAASUVORK5CYII=\")"}]},{"type":"rule","selectors":[".ns-dark DatePickerField",".ns-dark TimePickerField",".ns-dark DateTimePickerFields",".ns-dark RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"class","value":"ns-dark"}]},{"type":"rule","selectors":["RadDataForm PropertyEditor"],"declarations":[{"type":"declaration","property":"padding","value":"5 0 0"}]},{"type":"rule","selectors":["NTInput",".nt-input"],"declarations":[{"type":"declaration","property":"margin","value":"10 0"}]},{"type":"rule","selectors":["DataFormEditorLabel","NTInput>Label",".nt-input>Label"],"declarations":[{"type":"declaration","property":"font-size","value":"16"},{"type":"declaration","property":"color","value":"#bababa"}]},{"type":"rule","selectors":["DataFormEditorLabel","NTInput>Label","NTInput>TextView",">TextField",">PickerField",">DatePickerField",">TimePickerField",">DateTimePickerFields",">RadAutoCompleteTextView",".nt-input>Label",".nt-input>TextView"],"declarations":[{"type":"declaration","property":"margin","value":"0 16"}]},{"type":"rule","selectors":["NTInput.-sides",".nt-input.-sides"],"declarations":[{"type":"declaration","property":"margin","value":"0 0 10"}]},{"type":"rule","selectors":["NTInput.-sides>Label",".nt-input.-sides>Label"],"declarations":[{"type":"declaration","property":"margin","value":"5 16"}]},{"type":"rule","selectors":["NTInput>NTIcon","NTInput>.nt-icon",".nt-input>NTIcon",".nt-input>.nt-icon"],"declarations":[{"type":"declaration","property":"font-size","value":"20"},{"type":"declaration","property":"vertical-align","value":"center"},{"type":"declaration","property":"horizontal-align","value":"right"},{"type":"declaration","property":"margin","value":"-15 10 0 0"}]},{"type":"rule","selectors":["ActionBar","NTActionBar",".nt-action-bar"],"declarations":[{"type":"declaration","property":"font-size","value":"18"}]},{"type":"rule","selectors":["ActionBar NTIcon","ActionBar Label","ActionBar Button","ActionBar .nt-action-bar__item","NTActionBar NTIcon","NTActionBar Label","NTActionBar Button","NTActionBar .nt-action-bar__item",".nt-action-bar NTIcon",".nt-action-bar Label",".nt-action-bar Button",".nt-action-bar .nt-action-bar__item"],"declarations":[{"type":"declaration","property":"android-elevation","value":"0"},{"type":"declaration","property":"font-size","value":"16"},{"type":"declaration","property":"padding","value":"12 3"},{"type":"declaration","property":"margin","value":"0"},{"type":"declaration","property":"min-width","value":"0"},{"type":"declaration","property":"width","value":"auto"},{"type":"declaration","property":"border-width","value":"0"},{"type":"declaration","property":"text-transform","value":"none"},{"type":"declaration","property":"font-weight","value":"normal"}]},{"type":"rule","selectors":["ActionBar NTIcon:active","ActionBar Label:active","ActionBar Button:active","ActionBar .nt-action-bar__item:active","NTActionBar NTIcon:active","NTActionBar Label:active","NTActionBar Button:active","NTActionBar .nt-action-bar__item:active",".nt-action-bar NTIcon:active",".nt-action-bar Label:active",".nt-action-bar Button:active",".nt-action-bar .nt-action-bar__item:active"],"declarations":[{"type":"declaration","property":"opacity","value":".7"}]},{"type":"rule","selectors":["ActionBar>Label","NTActionBar>Label",".nt-action-bar>Label"],"declarations":[{"type":"declaration","property":"font-weight","value":"bold"},{"type":"declaration","property":"font-size","value":"18"}]},{"type":"rule","selectors":[".ns-statusbar-transparent Page>ActionBar",".ns-statusbar-transparent Page>NTActionBar",".ns-statusbar-transparent Page>.nt-action-bar"],"declarations":[{"type":"declaration","property":"padding-top","value":"24"}]},{"type":"rule","selectors":[".ns-android__19.ns-statusbar-transparent Page>ActionBar",".ns-modal.ns-statusbar-transparent Page>ActionBar",".ns-android__19.ns-statusbar-transparent Page>NTActionBar",".ns-modal.ns-statusbar-transparent Page>NTActionBar",".ns-android__19.ns-statusbar-transparent Page>.nt-action-bar",".ns-modal.ns-statusbar-transparent Page>.nt-action-bar"],"declarations":[{"type":"declaration","property":"padding-top","value":"0"}]},{"type":"rule","selectors":[".ns-android ActionBar Button",".ns-android ActionBar .nt-button",".ns-android NTActionBar Button",".ns-android NTActionBar .nt-button",".ns-android .nt-action-bar Button",".ns-android .nt-action-bar .nt-button"],"declarations":[{"type":"declaration","property":"padding","value":"0 6"}]},{"type":"rule","selectors":["ActionBar>Label","NTActionBar>Label",".nt-action-bar>Label"],"declarations":[{"type":"declaration","property":"width","value":"100%"}]},{"type":"rule","selectors":["ActionBar>Label","ActionBar>GridLayout Label","NTActionBar>Label","NTActionBar>GridLayout Label",".nt-action-bar>Label",".nt-action-bar>GridLayout Label"],"declarations":[{"type":"declaration","property":"font-size","value":"18"},{"type":"declaration","property":"vertical-align","value":"center"},{"type":"declaration","property":"text-align","value":"center"}]},{"type":"rule","selectors":["ActionBar>GridLayout","NTActionBar>GridLayout",".nt-action-bar>GridLayout"],"declarations":[{"type":"declaration","property":"padding","value":"0 4"},{"type":"declaration","property":"width","value":"100%"}]},{"type":"rule","selectors":["ActionBar>GridLayout>StackLayout","NTActionBar>GridLayout>StackLayout",".nt-action-bar>GridLayout>StackLayout"],"declarations":[{"type":"declaration","property":"padding","value":"0"},{"type":"declaration","property":"horizontal-align","value":"left"}]},{"type":"rule","selectors":["ActionBar>GridLayout Button","NTActionBar>GridLayout Button",".nt-action-bar>GridLayout Button"],"declarations":[{"type":"declaration","property":"padding","value":"12 10"},{"type":"declaration","property":"horizontal-align","value":"left"}]},{"type":"rule","selectors":["ActionBar>GridLayout [col=\"2\"]","NTActionBar>GridLayout [col=\"2\"]",".nt-action-bar>GridLayout [col=\"2\"]"],"declarations":[{"type":"declaration","property":"horizontal-align","value":"right"}]},{"type":"rule","selectors":[".ns-android ActionBar>GridLayout Button",".ns-android NTActionBar>GridLayout Button",".ns-android .nt-action-bar>GridLayout Button"],"declarations":[{"type":"declaration","property":"padding","value":"12 16"},{"type":"declaration","property":"margin","value":"0"}]},{"type":"rule","selectors":["Button",".nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"color","value":"#004363"}]},{"type":"rule","selectors":[".ns-dark Button",".ns-dark .nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"color","value":"#fcfeff"}]},{"type":"rule","selectors":["Button:active","Button.-active",".nt-button:active",".nt-button.-active"],"declarations":[{"type":"declaration","property":"color","value":"#004363"}]},{"type":"rule","selectors":[".ns-dark Button:active",".ns-dark Button.-active",".ns-dark .nt-button:active",".ns-dark .nt-button.-active"],"declarations":[{"type":"declaration","property":"color","value":"#fcfeff"}]},{"type":"rule","selectors":["Button.-outline",".nt-button.-outline"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"border-color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark Button.-outline",".ns-dark .nt-button.-outline"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"keyframes","name":"-hightlight-light","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#f2f2f2"}]}]},{"type":"keyframes","name":"-hightlight-dark","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#232323"}]}]},{"type":"rule","selectors":["Button.-outline:active","Button.-outline.-active",".nt-button.-outline:active",".nt-button.-outline.-active"],"declarations":[{"type":"declaration","property":"animation","value":"-hightlight-light .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#f2f2f2"}]},{"type":"rule","selectors":[".ns-dark Button.-outline:active",".ns-dark Button.-outline.-active",".ns-dark .nt-button.-outline:active",".ns-dark .nt-button.-outline.-active"],"declarations":[{"type":"declaration","property":"animation","value":"-hightlight-dark .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#232323"}]},{"type":"rule","selectors":["Button.-primary",".nt-button.-primary"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"border-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark Button.-primary",".ns-dark .nt-button.-primary"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"border-color","value":"#30bcff"}]},{"type":"keyframes","name":"accent-hightlight-light","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#00aafc"}]}]},{"type":"keyframes","name":"accent-hightlight-dark","keyframes":[{"type":"keyframe","values":["0%"],"declarations":[{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"keyframe","values":["100%"],"declarations":[{"type":"declaration","property":"background-color","value":"#00aafc"}]}]},{"type":"rule","selectors":["Button.-primary:active","Button.-primary.-active",".nt-button.-primary:active",".nt-button.-primary.-active"],"declarations":[{"type":"declaration","property":"animation","value":"accent-hightlight-light .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#00aafc"}]},{"type":"rule","selectors":[".ns-dark Button.-primary:active",".ns-dark Button.-primary.-active",".ns-dark .nt-button.-primary:active",".ns-dark .nt-button.-primary.-active"],"declarations":[{"type":"declaration","property":"animation","value":"accent-hightlight-dark .3s ease-out forwards"},{"type":"declaration","property":"background-color","value":"#00aafc"}]},{"type":"rule","selectors":["ActivityIndicator",".nt-activity-indicator"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark ActivityIndicator",".ns-dark .nt-activity-indicator"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["SegmentedBar",".nt-segmented-bar"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"selected-background-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark SegmentedBar",".ns-dark .nt-segmented-bar"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"selected-background-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-ios SegmentedBar",".ns-ios .nt-segmented-bar"],"declarations":[{"type":"declaration","property":"margin","value":"0 15"},{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark.ns-ios SegmentedBar",".ns-dark.ns-ios .nt-segmented-bar"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["Progress",".nt-progress"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.1)"}]},{"type":"rule","selectors":[".ns-dark Progress",".ns-dark .nt-progress"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.1)"}]},{"type":"rule","selectors":["Slider",".nt-slider"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark Slider",".ns-dark .nt-slider"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"},{"type":"declaration","property":"background-color","value":"#30bcff"}]},{"type":"rule","selectors":["Slider[isEnabled=false]",".ns-android Slider[isEnabled=false]",".nt-slider[isEnabled=false]",".ns-android .nt-slider[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e0e0e0"},{"type":"declaration","property":"background-color","value":"#e0e0e0"}]},{"type":"rule","selectors":["SearchBar",".nt-search-bar"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"},{"type":"declaration","property":"text-field-hint-color","value":"#737373"},{"type":"declaration","property":"text-field-background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-dark SearchBar",".ns-dark .nt-search-bar"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"},{"type":"declaration","property":"text-field-hint-color","value":"#b3b3b3"},{"type":"declaration","property":"text-field-background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-android Switch",".ns-android .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#ccc"},{"type":"declaration","property":"background-color","value":"#ccc"}]},{"type":"rule","selectors":[".ns-dark.ns-android Switch",".ns-dark.ns-android .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#636363"},{"type":"declaration","property":"background-color","value":"#636363"}]},{"type":"rule","selectors":[".ns-android Switch[checked=true]",".ns-android .nt-switch[checked=true]"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark.ns-android Switch[checked=true]",".ns-dark.ns-android .nt-switch[checked=true]"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-android Switch[isEnabled=false]",".ns-android .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e6e6e6"}]},{"type":"rule","selectors":[".ns-dark.ns-android Switch[isEnabled=false]",".ns-dark.ns-android .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#4a4a4a"}]},{"type":"rule","selectors":[".ns-ios Switch",".ns-ios .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"off-background-color","value":"#e6e6e6"}]},{"type":"rule","selectors":[".ns-dark.ns-ios Switch",".ns-dark.ns-ios .nt-switch"],"declarations":[{"type":"declaration","property":"color","value":"#303030"},{"type":"declaration","property":"background-color","value":"#30bcff"},{"type":"declaration","property":"off-background-color","value":"#4a4a4a"}]},{"type":"rule","selectors":[".ns-ios Switch[isEnabled=false]",".ns-ios .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":[".ns-dark.ns-ios Switch[isEnabled=false]",".ns-dark.ns-ios .nt-switch[isEnabled=false]"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":["TabView",".nt-tab-view"],"declarations":[{"type":"declaration","property":"selected-tab-text-color","value":"#30bcff"},{"type":"declaration","property":"tab-background-color","value":"#fff"},{"type":"declaration","property":"tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"android-selected-tab-highlight-color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark TabView",".ns-dark .nt-tab-view"],"declarations":[{"type":"declaration","property":"selected-tab-text-color","value":"#30bcff"},{"type":"declaration","property":"tab-background-color","value":"#303030"},{"type":"declaration","property":"tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"android-selected-tab-highlight-color","value":"#30bcff"}]},{"type":"rule","selectors":["TabView.ns-dark",".nt-tab-view.ns-dark"],"declarations":[{"type":"declaration","property":"selected-tab-text-color","value":"#30bcff"},{"type":"declaration","property":"tab-background-color","value":"#303030"},{"type":"declaration","property":"tab-text-color","value":"#abd5e9"},{"type":"declaration","property":"android-selected-tab-highlight-color","value":"#30bcff"}]},{"type":"rule","selectors":["TabStrip",".nt-tab-strip"],"declarations":[{"type":"declaration","property":"highlight-color","value":"#30bcff"},{"type":"declaration","property":"background","value":"#f2f2f2"}]},{"type":"rule","selectors":[".ns-dark TabStrip",".ns-dark .nt-tab-strip"],"declarations":[{"type":"declaration","property":"highlight-color","value":"#30bcff"},{"type":"declaration","property":"background","value":"#3a3a3a"}]},{"type":"rule","selectors":["TabStripItem",".nt-tab-strip__item"],"declarations":[{"type":"declaration","property":"color","value":"#262626"}]},{"type":"rule","selectors":[".ns-dark TabStripItem",".ns-dark .nt-tab-strip__item"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":["TabStripItem:active","TabStripItem:active Label",".nt-tab-strip__item:active",".nt-tab-strip__item:active Label"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark TabStripItem:active",".ns-dark TabStripItem:active Label",".ns-dark .nt-tab-strip__item:active",".ns-dark .nt-tab-strip__item:active Label"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["TabContentItem",".nt-tab-content__item"],"declarations":[{"type":"declaration","property":"background","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark TabContentItem",".ns-dark .nt-tab-content__item"],"declarations":[{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":["ListView","RadListView",".nt-list-view"],"declarations":[{"type":"declaration","property":"item-selected-background-color","value":"rgba(48,188,255,.15)"},{"type":"declaration","property":"separator-color","value":"#ccc"}]},{"type":"rule","selectors":[".ns-dark ListView",".ns-dark RadListView",".ns-dark .nt-list-view"],"declarations":[{"type":"declaration","property":"item-selected-background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":["ListView>*.active","ListView>*:highlighted","RadListView>*.active","RadListView>*:highlighted",".nt-list-view>*.active",".nt-list-view>*:highlighted"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":[".ns-dark ListView>*.active",".ns-dark ListView>*:highlighted",".ns-dark RadListView>*.active",".ns-dark RadListView>*:highlighted",".ns-dark .nt-list-view>*.active",".ns-dark .nt-list-view>*:highlighted"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":["ListView .-separator","RadListView .-separator",".nt-list-view .-separator"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"#ccc"}]},{"type":"rule","selectors":[".ns-dark ListView .-separator",".ns-dark RadListView .-separator",".ns-dark .nt-list-view .-separator"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"#636363"}]},{"type":"rule","selectors":[".ns-dark ListView",".ns-dark RadListView",".ns-dark .nt-list-view"],"declarations":[{"type":"declaration","property":"separator-color","value":"#636363"}]},{"type":"rule","selectors":["ListView .nt-list-view__delete","RadListView .nt-list-view__delete",".nt-list-view .nt-list-view__delete"],"declarations":[{"type":"declaration","property":"background-color","value":"#d50000"}]},{"type":"rule","selectors":["ListView .nt-list-view__delete>Label","RadListView .nt-list-view__delete>Label",".nt-list-view .nt-list-view__delete>Label"],"declarations":[{"type":"declaration","property":"color","value":"#262626"}]},{"type":"rule","selectors":[".ns-dark ListView .nt-list-view__delete>Label",".ns-dark RadListView .nt-list-view__delete>Label",".ns-dark .nt-list-view .nt-list-view__delete>Label"],"declarations":[{"type":"declaration","property":"color","value":"#fff"}]},{"type":"rule","selectors":["ListView NTIcon","ListView .nt-icon","RadListView NTIcon","RadListView .nt-icon",".nt-list-view NTIcon",".nt-list-view .nt-icon"],"declarations":[{"type":"declaration","property":"color","value":"#006698"}]},{"type":"rule","selectors":[".ns-dark ListView NTIcon",".ns-dark ListView .nt-icon",".ns-dark RadListView NTIcon",".ns-dark RadListView .nt-icon",".ns-dark .nt-list-view NTIcon",".ns-dark .nt-list-view .nt-icon"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__header",".nt-drawer .nt-drawer__header"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#f2f2f2"}]},{"type":"rule","selectors":["RadSideDrawer>*","RadSideDrawer .nt-drawer__content",".nt-drawer>*",".nt-drawer .nt-drawer__content"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__list-item.-selected",".nt-drawer .nt-drawer__list-item.-selected"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":["RadSideDrawer .nt-drawer__list-item.-selected Label",".nt-drawer .nt-drawer__list-item.-selected Label"],"declarations":[{"type":"declaration","property":"color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer .nt-drawer__header","RadSideDrawer.ns-dark .nt-drawer__header",".ns-dark .nt-drawer .nt-drawer__header",".nt-drawer.ns-dark .nt-drawer__header"],"declarations":[{"type":"declaration","property":"color","value":"#d4d4d4"},{"type":"declaration","property":"background-color","value":"#232323"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer>*",".ns-dark RadSideDrawer .nt-drawer__content","RadSideDrawer.ns-dark>*","RadSideDrawer.ns-dark .nt-drawer__content",".ns-dark .nt-drawer>*",".ns-dark .nt-drawer .nt-drawer__content",".nt-drawer.ns-dark>*",".nt-drawer.ns-dark .nt-drawer__content"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer .nt-drawer__list-item.-selected","RadSideDrawer.ns-dark .nt-drawer__list-item.-selected",".ns-dark .nt-drawer .nt-drawer__list-item.-selected",".nt-drawer.ns-dark .nt-drawer__list-item.-selected"],"declarations":[{"type":"declaration","property":"background-color","value":"rgba(48,188,255,.15)"}]},{"type":"rule","selectors":[".ns-dark RadSideDrawer .nt-drawer__list-item.-selected Label","RadSideDrawer.ns-dark .nt-drawer__list-item.-selected Label",".ns-dark .nt-drawer .nt-drawer__list-item.-selected Label",".nt-drawer.ns-dark .nt-drawer__list-item.-selected Label"],"declarations":[{"type":"declaration","property":"color","value":"#96ddff"}]},{"type":"rule","selectors":["TextView","TextField","PickerField","DatePickerField","TimePickerField","DateTimePickerFields","DataFormEditorCore","RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"},{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"placeholder-color","value":"#737373"},{"type":"declaration","property":"border-color","value":"#c7c7c7"}]},{"type":"rule","selectors":[".ns-dark TextView",".ns-dark TextField",".ns-dark PickerField",".ns-dark DatePickerField",".ns-dark TimePickerField",".ns-dark DateTimePickerFields",".ns-dark DataFormEditorCore",".ns-dark RadAutoCompleteTextView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"placeholder-color","value":"#b3b3b3"},{"type":"declaration","property":"border-color","value":"#fafafa"}]},{"type":"rule","selectors":["TextView:focus","TextField:focus","PickerField:focus","DatePickerField:focus","TimePickerField:focus","DateTimePickerFields:focus","DataFormEditorCore:focus","RadAutoCompleteTextView:focus"],"declarations":[{"type":"declaration","property":"border-color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark TextView:focus",".ns-dark TextField:focus",".ns-dark PickerField:focus",".ns-dark DatePickerField:focus",".ns-dark TimePickerField:focus",".ns-dark DateTimePickerFields:focus",".ns-dark DataFormEditorCore:focus",".ns-dark RadAutoCompleteTextView:focus"],"declarations":[{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"rule","selectors":["TextView[isEnabled=false]","TextField[isEnabled=false]","PickerField[isEnabled=false]","DatePickerField[isEnabled=false]","TimePickerField[isEnabled=false]","DateTimePickerFields[isEnabled=false]","DataFormEditorCore[isEnabled=false]","RadAutoCompleteTextView[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e0e0e0"},{"type":"declaration","property":"background-color","value":"#f2f2f2"}]},{"type":"rule","selectors":[".ns-dark TextView[isEnabled=false]",".ns-dark TextField[isEnabled=false]",".ns-dark PickerField[isEnabled=false]",".ns-dark DatePickerField[isEnabled=false]",".ns-dark TimePickerField[isEnabled=false]",".ns-dark DateTimePickerFields[isEnabled=false]",".ns-dark DataFormEditorCore[isEnabled=false]",".ns-dark RadAutoCompleteTextView[isEnabled=false]"],"declarations":[{"type":"declaration","property":"color","value":"#e0e0e0"},{"type":"declaration","property":"background-color","value":"#3d3d3d"}]},{"type":"rule","selectors":["PropertyEditor:focus DataFormEditorCore"],"declarations":[{"type":"declaration","property":"border-color","value":"#0088c9"}]},{"type":"rule","selectors":[".ns-dark PropertyEditor:focus DataFormEditorCore"],"declarations":[{"type":"declaration","property":"border-color","value":"#96ddff"}]},{"type":"rule","selectors":["RadAutoCompleteTextView Token"],"declarations":[{"type":"declaration","property":"background-color","value":"#96ddff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView Token"],"declarations":[{"type":"declaration","property":"background-color","value":"#0088c9"}]},{"type":"rule","selectors":["RadAutoCompleteTextView Token:selected"],"declarations":[{"type":"declaration","property":"background-color","value":"#63cdff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView Token:selected"],"declarations":[{"type":"declaration","property":"background-color","value":"#00aafc"}]},{"type":"rule","selectors":["RadAutoCompleteTextView ClearButton"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView ClearButton"],"declarations":[{"type":"declaration","property":"color","value":"#30bcff"}]},{"type":"rule","selectors":["RadAutoCompleteTextView SuggestionView"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark RadAutoCompleteTextView SuggestionView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":["RadDataForm"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"placeholder-color","value":"#737373"}]},{"type":"rule","selectors":[".ns-dark RadDataForm"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"placeholder-color","value":"#b3b3b3"}]},{"type":"rule","selectors":["RadDataForm PropertyEditor"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark RadDataForm PropertyEditor"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":["PickerPage ListView"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark PickerPage ListView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":["PickerPage ListView>*"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":[".ns-dark PickerPage ListView>*"],"declarations":[{"type":"declaration","property":"border-bottom-color","value":"rgba(48,188,255,.4)"}]},{"type":"rule","selectors":["PickerPage.ns-dark ListView",".ns-dark SuggestionView"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":[".date-time-picker"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background","value":"#fff"}]},{"type":"rule","selectors":[".date-time-picker.ns-dark"],"declarations":[{"type":"declaration","property":"color","value":"#fff"},{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":[".date-time-picker-buttons"],"declarations":[{"type":"declaration","property":"color","value":"#004363"}]},{"type":"rule","selectors":[".date-time-picker-buttons.ns-dark"],"declarations":[{"type":"declaration","property":"color","value":"#fcfeff"}]},{"type":"rule","selectors":[".ns-dark.date-time-picker-button-cancel"],"declarations":[{"type":"declaration","property":"background","value":"#303030"}]},{"type":"rule","selectors":[".date-time-picker-spinners"],"declarations":[{"type":"declaration","property":"color","value":"#006596"}]},{"type":"rule","selectors":[".date-time-picker-spinners.ns-dark"],"declarations":[{"type":"declaration","property":"color","value":"#c9eeff"}]},{"type":"rule","selectors":["DataFormEditorLabel","NTInput>Label",".nt-input>Label"],"declarations":[{"type":"declaration","property":"color","value":"#006596"}]},{"type":"rule","selectors":[".ns-dark DataFormEditorLabel",".ns-dark NTInput>Label",".ns-dark .nt-input>Label"],"declarations":[{"type":"declaration","property":"color","value":"#c9eeff"}]},{"type":"rule","selectors":["ActionBar","NTActionBar",".nt-action-bar"],"declarations":[{"type":"declaration","property":"color","value":"#262626"},{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark ActionBar",".ns-dark NTActionBar",".ns-dark .nt-action-bar"],"declarations":[{"type":"declaration","property":"color","value":"#d4d4d4"},{"type":"declaration","property":"background-color","value":"#303030"}]},{"type":"rule","selectors":["ActionBar NTIcon","ActionBar Label","ActionBar Button","ActionBar .nt-action-bar__item","NTActionBar NTIcon","NTActionBar Label","NTActionBar Button","NTActionBar .nt-action-bar__item",".nt-action-bar NTIcon",".nt-action-bar Label",".nt-action-bar Button",".nt-action-bar .nt-action-bar__item"],"declarations":[{"type":"declaration","property":"color","value":"#262626"}]},{"type":"rule","selectors":[".ns-dark ActionBar NTIcon",".ns-dark ActionBar Label",".ns-dark ActionBar Button",".ns-dark ActionBar .nt-action-bar__item",".ns-dark NTActionBar NTIcon",".ns-dark NTActionBar Label",".ns-dark NTActionBar Button",".ns-dark NTActionBar .nt-action-bar__item",".ns-dark .nt-action-bar NTIcon",".ns-dark .nt-action-bar Label",".ns-dark .nt-action-bar Button",".ns-dark .nt-action-bar .nt-action-bar__item"],"declarations":[{"type":"declaration","property":"color","value":"#d4d4d4"}]},{"type":"rule","selectors":["ActionBar NTIcon:active","ActionBar NTIcon.-active","ActionBar Label:active","ActionBar Label.-active","ActionBar Button:active","ActionBar Button.-active","ActionBar .nt-action-bar__item:active","ActionBar .nt-action-bar__item.-active","NTActionBar NTIcon:active","NTActionBar NTIcon.-active","NTActionBar Label:active","NTActionBar Label.-active","NTActionBar Button:active","NTActionBar Button.-active","NTActionBar .nt-action-bar__item:active","NTActionBar .nt-action-bar__item.-active",".nt-action-bar NTIcon:active",".nt-action-bar NTIcon.-active",".nt-action-bar Label:active",".nt-action-bar Label.-active",".nt-action-bar Button:active",".nt-action-bar Button.-active",".nt-action-bar .nt-action-bar__item:active",".nt-action-bar .nt-action-bar__item.-active"],"declarations":[{"type":"declaration","property":"color","value":"#262626"}]},{"type":"rule","selectors":[".ns-dark ActionBar NTIcon:active",".ns-dark ActionBar NTIcon.-active",".ns-dark ActionBar Label:active",".ns-dark ActionBar Label.-active",".ns-dark ActionBar Button:active",".ns-dark ActionBar Button.-active",".ns-dark ActionBar .nt-action-bar__item:active",".ns-dark ActionBar .nt-action-bar__item.-active",".ns-dark NTActionBar NTIcon:active",".ns-dark NTActionBar NTIcon.-active",".ns-dark NTActionBar Label:active",".ns-dark NTActionBar Label.-active",".ns-dark NTActionBar Button:active",".ns-dark NTActionBar Button.-active",".ns-dark NTActionBar .nt-action-bar__item:active",".ns-dark NTActionBar .nt-action-bar__item.-active",".ns-dark .nt-action-bar NTIcon:active",".ns-dark .nt-action-bar NTIcon.-active",".ns-dark .nt-action-bar Label:active",".ns-dark .nt-action-bar Label.-active",".ns-dark .nt-action-bar Button:active",".ns-dark .nt-action-bar Button.-active",".ns-dark .nt-action-bar .nt-action-bar__item:active",".ns-dark .nt-action-bar .nt-action-bar__item.-active"],"declarations":[{"type":"declaration","property":"color","value":"#d4d4d4"}]},{"type":"rule","selectors":[".ns-ios ActionBar NTIcon",".ns-ios ActionBar NTIcon:active",".ns-ios ActionBar Label",".ns-ios ActionBar Label:active",".ns-ios ActionBar Button",".ns-ios ActionBar Button:active",".ns-ios ActionBar .nt-action-bar__item",".ns-ios ActionBar .nt-action-bar__item:active",".ns-ios NTActionBar NTIcon",".ns-ios NTActionBar NTIcon:active",".ns-ios NTActionBar Label",".ns-ios NTActionBar Label:active",".ns-ios NTActionBar Button",".ns-ios NTActionBar Button:active",".ns-ios NTActionBar .nt-action-bar__item",".ns-ios NTActionBar .nt-action-bar__item:active",".ns-ios .nt-action-bar NTIcon",".ns-ios .nt-action-bar NTIcon:active",".ns-ios .nt-action-bar Label",".ns-ios .nt-action-bar Label:active",".ns-ios .nt-action-bar Button",".ns-ios .nt-action-bar Button:active",".ns-ios .nt-action-bar .nt-action-bar__item",".ns-ios .nt-action-bar .nt-action-bar__item:active"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-dark.ns-ios ActionBar NTIcon",".ns-dark.ns-ios ActionBar NTIcon:active",".ns-dark.ns-ios ActionBar Label",".ns-dark.ns-ios ActionBar Label:active",".ns-dark.ns-ios ActionBar Button",".ns-dark.ns-ios ActionBar Button:active",".ns-dark.ns-ios ActionBar .nt-action-bar__item",".ns-dark.ns-ios ActionBar .nt-action-bar__item:active",".ns-dark.ns-ios NTActionBar NTIcon",".ns-dark.ns-ios NTActionBar NTIcon:active",".ns-dark.ns-ios NTActionBar Label",".ns-dark.ns-ios NTActionBar Label:active",".ns-dark.ns-ios NTActionBar Button",".ns-dark.ns-ios NTActionBar Button:active",".ns-dark.ns-ios NTActionBar .nt-action-bar__item",".ns-dark.ns-ios NTActionBar .nt-action-bar__item:active",".ns-dark.ns-ios .nt-action-bar NTIcon",".ns-dark.ns-ios .nt-action-bar NTIcon:active",".ns-dark.ns-ios .nt-action-bar Label",".ns-dark.ns-ios .nt-action-bar Label:active",".ns-dark.ns-ios .nt-action-bar Button",".ns-dark.ns-ios .nt-action-bar Button:active",".ns-dark.ns-ios .nt-action-bar .nt-action-bar__item",".ns-dark.ns-ios .nt-action-bar .nt-action-bar__item:active"],"declarations":[{"type":"declaration","property":"background-color","value":"transparent"}]},{"type":"rule","selectors":[".ns-android ActionBar Button",".ns-android ActionBar .nt-button",".ns-android NTActionBar Button",".ns-android NTActionBar .nt-button",".ns-android .nt-action-bar Button",".ns-android .nt-action-bar .nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#fff"}]},{"type":"rule","selectors":[".ns-dark.ns-android ActionBar Button",".ns-dark.ns-android ActionBar .nt-button",".ns-dark.ns-android NTActionBar Button",".ns-dark.ns-android NTActionBar .nt-button",".ns-dark.ns-android .nt-action-bar Button",".ns-dark.ns-android .nt-action-bar .nt-button"],"declarations":[{"type":"declaration","property":"background-color","value":"#303030"}]}],"parsingErrors":[]}};; 
if ( true && global._isModuleLoadedForUI && global._isModuleLoadedForUI("/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/nativescript-theme-core/css/core.css") ) {
    
    module.hot.accept();
    module.hot.dispose(() => {
        global.hmrRefresh({ type: "style", path: "/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/nativescript-theme-core/css/core.css" });
    });
} 
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../node_modules/svelte-loader-hot/lib/svelte3/hot-api.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "applyHmr", function() { return applyHmr; });
/* harmony import */ var svelte_hmr_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/index.js");


// eslint-disable-next-line no-undef
const g = typeof window !== 'undefined' ? window : global;

const globalKey =
	typeof Symbol !== 'undefined'
		? Symbol('SVELTE_LOADER_HOT')
		: '__SVELTE_LOADER_HOT';

if (!g[globalKey]) {
	// do updating refs counting to know when a full update has been applied
	let updatingCount = 0;

	const notifyStart = () => {
		updatingCount++;
	};

	const notifyError = reload => err => {
		const errString = (err && err.stack) || err;
		// eslint-disable-next-line no-console
		console.error(
			'[HMR] Failed to accept update (nollup compat mode)',
			errString
		);
		reload();
		notifyEnd();
	};

	const notifyEnd = () => {
		updatingCount--;
		if (updatingCount === 0) {
			// NOTE this message is important for timing in tests
			// eslint-disable-next-line no-console
			console.log('[HMR:Svelte] Up to date');
		}
	};

	g[globalKey] = {
		hotStates: {},
		notifyStart,
		notifyError,
		notifyEnd,
	};
}

const runAcceptHandlers = acceptHandlers => {
	const queue = [...acceptHandlers];
	const next = () => {
		const cur = queue.shift();
		if (cur) {
			return cur(null).then(next);
		} else {
			return Promise.resolve(null);
		}
	};
	return next();
};

const applyHmr = Object(svelte_hmr_runtime__WEBPACK_IMPORTED_MODULE_0__["makeApplyHmr"])(args => {
	const { notifyStart, notifyError, notifyEnd } = g[globalKey];
	const { m, reload } = args;

	let acceptHandlers = (m.hot.data && m.hot.data.acceptHandlers) || [];
	let nextAcceptHandlers = [];

	m.hot.dispose(data => {
		data.acceptHandlers = nextAcceptHandlers;
	});

	const dispose = (...args) => m.hot.dispose(...args);

	const accept = handler => {
		if (nextAcceptHandlers.length === 0) {
			m.hot.accept();
		}
		nextAcceptHandlers.push(handler);
	};

	const check = status => {
		if (status === 'ready') {
			notifyStart();
		} else if (status === 'idle') {
			runAcceptHandlers(acceptHandlers)
				.then(notifyEnd)
				.catch(notifyError(reload));
		}
	};

	m.hot.addStatusHandler(check);

	m.hot.dispose(() => {
		m.hot.removeStatusHandler(check);
	});

	const hot = {
		data: m.hot.data,
		dispose,
		accept,
	};

	return Object.assign({}, args, { hot });
});

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/hot-api.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "makeApplyHmr", function() { return makeApplyHmr; });
/* harmony import */ var _proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/proxy.js");


const logPrefix = '[HMR:Svelte]'

const defaultHotOptions = {
  // don't preserve local state
  noPreserveState: false,
  // don't reload on fatal error
  noReload: false,
  // try to recover after runtime errors during component init
  optimistic: false,
}

const registry = new Map()

const log = (...args) => console.log(logPrefix, ...args)

const domReload = () => {
  if (
    typeof window !== 'undefined' &&
    window.location &&
    window.location.reload
  ) {
    log('Reload')
    window.location.reload()
  } else {
    log('Full reload required')
  }
}

const defaultArgs = {
  reload: domReload,
}

const makeApplyHmr = transformArgs => args => {
  const allArgs = transformArgs({ ...defaultArgs, ...args })
  return applyHmr(allArgs)
}

function applyHmr(args) {
  const {
    id,
    reload = domReload,
    // normalized hot API (must conform to rollup-plugin-hot)
    hot,
    hotOptions: hotOptionsArg,
    Component,
    compileData,
    ProxyAdapter,
  } = args

  const hotOptions = Object.assign({}, defaultHotOptions, hotOptionsArg)

  // meta info from compilation (vars, things that could be inspected in AST...)
  // can be used to help the proxy better emulate the proxied component (and
  // better mock svelte hooks, in the wait for official support)
  if (compileData) {
    // NOTE we're making Component carry the load to minimize diff with base branch
    Component.$compile = compileData
  }

  const existing = hot.data && hot.data.record
  const r = existing || Object(_proxy__WEBPACK_IMPORTED_MODULE_0__["createProxy"])(ProxyAdapter, id, Component, hotOptions)

  if (r.hasFatalError()) {
    if (hotOptions && hotOptions.noReload) {
      log('Full reload required')
    } else {
      reload()
    }
  }

  r.update({ Component, hotOptions })

  hot.dispose(data => {
    data.record = r
  })

  hot.accept(async () => {
    await r.reload()
    if (r.hasFatalError()) {
      if (hotOptions && hotOptions.noReload) {
        log('Full reload required')
      } else {
        reload()
      }
    }
  })

  // well, endgame... we won't be able to render next updates, even successful,
  // if we don't have proxies in svelte's tree
  //
  // since we won't return the proxy and the app will expect a svelte component,
  // it's gonna crash... so it's best to report the real cause
  //
  // full reload required
  //
  const proxyOk = r && r.proxy
  if (!proxyOk) {
    throw new Error(`Failed to create HMR proxy for Svelte component ${id}`)
  }

  return r.proxy
}


/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/index.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _hot_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/hot-api.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "makeApplyHmr", function() { return _hot_api__WEBPACK_IMPORTED_MODULE_0__["makeApplyHmr"]; });




/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/overlay.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const removeElement = el => el && el.parentNode && el.parentNode.removeChild(el)

const ErrorOverlay = () => {
  let errors = []
  let compileError = null

  const errorsTitle = 'Failed to init component'
  const compileErrorTitle = 'Failed to compile'

  const style = {
    section: `
      position: fixed;
      top: 0;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 32px;
      background: rgba(0, 0, 0, .85);
      font-family: Menlo, Consolas, monospace;
      font-size: large;
      color: rgb(232, 232, 232);
      overflow: auto;
    `,
    h1: `
      margin-top: 0;
      color: #E36049;
      font-size: large;
      font-weight: normal;
    `,
    h2: `
      margin: 32px 0 0;
      font-size: large;
      font-weight: normal;
    `,
    pre: ``,
  }

  const createOverlay = () => {
    const h1 = document.createElement('h1')
    h1.style = style.h1
    const section = document.createElement('section')
    section.appendChild(h1)
    section.style = style.section
    const body = document.createElement('div')
    section.appendChild(body)
    return { h1, el: section, body }
  }

  const setTitle = title => {
    overlay.h1.textContent = title
  }

  const show = () => {
    const { el } = overlay
    if (!el.parentNode) {
      const target = document.body
      target.appendChild(overlay.el)
    }
  }

  const hide = () => {
    const { el } = overlay
    if (el.parentNode) {
      overlay.el.remove()
    }
  }

  const update = () => {
    if (compileError) {
      overlay.body.innerHTML = ''
      setTitle(compileErrorTitle)
      const errorEl = renderError(compileError)
      overlay.body.appendChild(errorEl)
      show()
    } else if (errors.length > 0) {
      overlay.body.innerHTML = ''
      setTitle(errorsTitle)
      errors.forEach(({ title, message }) => {
        const errorEl = renderError(message, title)
        overlay.body.appendChild(errorEl)
      })
      show()
    } else {
      hide()
    }
  }

  const renderError = (message, title) => {
    const div = document.createElement('div')
    if (title) {
      const h2 = document.createElement('h2')
      h2.textContent = title
      h2.style = style.h2
      div.appendChild(h2)
    }
    const pre = document.createElement('pre')
    pre.textContent = message
    div.appendChild(pre)
    return div
  }

  const addError = (error, title) => {
    const message = (error && error.stack) || error
    errors.push({ title, message })
    update()
  }

  const clearErrors = () => {
    errors.forEach(({ element }) => {
      removeElement(element)
    })
    errors = []
    update()
  }

  const setCompileError = message => {
    compileError = message
    update()
  }

  const overlay = createOverlay()

  return {
    addError,
    clearErrors,
    setCompileError,
  }
}

/* harmony default export */ __webpack_exports__["default"] = (ErrorOverlay);


/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/proxy-adapter-dom.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxyAdapterDom; });
/* harmony import */ var _overlay__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/overlay.js");
/* global document */


const removeElement = el => el && el.parentNode && el.parentNode.removeChild(el)

class ProxyAdapterDom {
  constructor(instance) {
    this.instance = instance
    this.insertionPoint = null

    this.afterMount = this.afterMount.bind(this)
    this.rerender = this.rerender.bind(this)
  }

  // NOTE overlay is only created before being actually shown to help test
  // runner (it won't have to account for error overlay when running assertions
  // about the contents of the rendered page)
  static getErrorOverlay(noCreate = false) {
    if (!noCreate && !this.errorOverlay) {
      this.errorOverlay = Object(_overlay__WEBPACK_IMPORTED_MODULE_0__["default"])()
    }
    return this.errorOverlay
  }

  static renderCompileError(message) {
    const noCreate = !message
    const overlay = this.getErrorOverlay(noCreate)
    if (!overlay) return
    overlay.setCompileError(message)
  }

  dispose() {
    // Component is being destroyed, detaching is not optional in Svelte3's
    // component API, so we can dispose of the insertion point in every case.
    if (this.insertionPoint) {
      removeElement(this.insertionPoint)
      this.insertionPoint = null
    }
    this.clearError()
  }

  // NOTE afterMount CAN be called multiple times (e.g. keyed list)
  afterMount(target, anchor) {
    const {
      instance: { debugName },
    } = this
    if (!this.insertionPoint) {
      this.insertionPoint = document.createComment(debugName)
    }
    target.insertBefore(this.insertionPoint, anchor)
  }

  rerender() {
    this.clearError()
    const {
      instance: { refreshComponent },
      insertionPoint,
    } = this
    if (!insertionPoint) {
      const err = new Error('Cannot rerender: Missing insertion point')
      err.hmrFatal = true
      return err
    }
    refreshComponent(insertionPoint.parentNode, insertionPoint)
  }

  renderError(err) {
    const {
      instance: { debugName },
    } = this
    const title = debugName || err.moduleName || 'Error'
    this.constructor.getErrorOverlay().addError(err, title)
  }

  clearError() {
    const overlay = this.constructor.getErrorOverlay(true)
    if (!overlay) return
    overlay.clearErrors()
  }
}

if (typeof window !== 'undefined') {
  window.__SVELTE_HMR_ADAPTER = ProxyAdapterDom
}


/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/proxy.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createProxy", function() { return createProxy; });
/* harmony import */ var _svelte_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/svelte-hooks.js");
/**
 * The HMR proxy is a component-like object whose task is to sit in the
 * component tree in place of the proxied component, and rerender each
 * successive versions of said component.
 */



const handledMethods = ['constructor', '$destroy']
const forwardedMethods = ['$set', '$on']

const noop = () => {}

const logError = (...args) => console.error('[HMR][Svelte]', ...args)

const posixify = file => file.replace(/[/\\]/g, '/')

const getBaseName = id =>
  id
    .split('/')
    .pop()
    .split('.')
    .slice(0, -1)
    .join('.')

const capitalize = str => str[0].toUpperCase() + str.slice(1)

const getFriendlyName = id => capitalize(getBaseName(posixify(id)))

const getDebugName = id => `<${getFriendlyName(id)}>`

const relayCalls = (getTarget, names, dest = {}) => {
  for (const key of names) {
    dest[key] = function(...args) {
      const target = getTarget()
      if (!target) {
        return
      }
      return target[key] && target[key].call(this, ...args)
    }
  }
  return dest
}

const copyComponentMethods = (proxy, cmp, debugName) => {
  //proxy custom methods
  const methods = Object.getOwnPropertyNames(Object.getPrototypeOf(cmp))
  methods.forEach(method => {
    if (
      !handledMethods.includes(method) &&
      !forwardedMethods.includes(method)
    ) {
      Object.defineProperty(proxy, method, {
        configurable: true,
        get() {
          return cmp[method]
        },
        set(value) {
          // we're chaning it on the real component first to see what it
          // gives... if it throws an error, we want to throw the same error in
          // order to most closely follow non-hmr behaviour.
          cmp[method] = value
          // who knows? maybe the value has been transformed somehow
          proxy[method] = cmp[method]
        }
      })
    }
  })
}

// everything in the constructor!
//
// so we don't polute the component class with new members
//
// specificity & conformance with Svelte component constructor is achieved
// in the "component level" (as opposed "instance level") createRecord
//
class ProxyComponent {
  constructor(
    {
      Adapter,
      id,
      debugName,
      current, // { Component, hotOptions: { noPreserveState, ... } }
      register,
      reportError,
    },
    options // { target, anchor, ... }
  ) {
    let cmp
    let disposed = false
    let lastError = null

    const destroyComponent = () => {
      // destroyComponent is tolerant (don't crash on no cmp) because it
      // is possible that reload/rerender is called after a previous
      // createComponent has failed (hence we have a proxy, but no cmp)
      if (cmp) {
        cmp.$destroy()
        cmp = null
      }
    }

    const refreshComponent = (target, anchor, conservativeDestroy) => {
      if (lastError) {
        lastError = null
        adapter.rerender()
      } else {
        try {
          if (conservativeDestroy) {
            cmp = cmp.$replace(current.Component, {
              target,
              anchor,
              conservative: true,
            })
          } else {
            cmp = cmp.$replace(current.Component, { target, anchor })
          }
        } catch (err) {
          const errString = String((err && err.stack) || err)
          setError(err, target, anchor)
          if (!current.hotOptions.optimistic || (err && err.hmrFatal)) {
            throw err
          } else {
            logError(`Error during component init ${debugName}: ${errString}`)
          }
        }
      }
    }

    // TODO need to use cmp.$replace
    const setError = (err, target, anchor) => {
      lastError = err
      adapter.renderError(err)
    }

    const instance = {
      hotOptions: current.hotOptions,
      proxy: this,
      id,
      debugName,
      refreshComponent,
    }

    const adapter = new Adapter(instance)

    const { afterMount, rerender } = adapter

    // $destroy is not called when a child component is disposed, so we
    // need to hook from fragment.
    const onDestroy = () => {
      // NOTE do NOT call $destroy on the cmp from here; the cmp is already
      //   dead, this would not work
      if (!disposed) {
        disposed = true
        adapter.dispose()
        unregister()
      }
    }

    // ---- register proxy instance ----

    const unregister = register(rerender)

    // ---- augmented methods ----

    this.$destroy = () => {
      destroyComponent()
      onDestroy()
    }

    // ---- forwarded methods ----

    const getComponent = () => cmp

    relayCalls(getComponent, forwardedMethods, this)

    // ---- create & mount target component instance ---

    try {
      cmp = Object(_svelte_hooks__WEBPACK_IMPORTED_MODULE_0__["createProxiedComponent"])(current.Component, options, {
        noPreserveState: current.hotOptions.noPreserveState,
        onDestroy,
        onMount: afterMount,
        onInstance: comp => {
          // WARNING the proxy MUST use the same $$ object as its component
          // instance, because a lot of wiring happens during component
          // initialisation... lots of references to $$ and $$.fragment have
          // already been distributed around when the component constructor
          // returns, before we have a chance to wrap them (and so we can't
          // wrap them no more, because existing references would become
          // invalid)
          this.$$ = comp.$$
          copyComponentMethods(this, comp, debugName)
        },
      })
    } catch (err) {
      const { target, anchor } = options
      setError(err, target, anchor)
      throw err
    }
  }
}

const copyStatics = (component, proxy) => {
  //forward static properties and methods
  for (let key in component) {
    proxy[key] = component[key]
  }
}

/**
 * Creates a HMR proxy and its associated `reload` function that pushes a new
 * version to all existing instances of the component.
 */
function createProxy(Adapter, id, Component, hotOptions) {
  let fatalError = false

  const debugName = getDebugName(id)
  const instances = []

  // current object will be updated, proxy instances will keep a ref
  const current = {
    Component,
    hotOptions,
  }

  const name = `Proxy${debugName}`

  // this trick gives the dynamic name Proxy<Component> to the concrete
  // proxy class... unfortunately, this doesn't shows in dev tools, but
  // it stills allow to inspect cmp.constructor.name to confirm an instance
  // is a proxy
  const proxy = {
    [name]: class extends ProxyComponent {
      constructor(options) {
        try {
          super(
            {
              Adapter,
              id,
              debugName,
              current,
              register: rerender => {
                instances.push(rerender)
                const unregister = () => {
                  const i = instances.indexOf(rerender)
                  instances.splice(i, 1)
                }
                return unregister
              },
            },
            options
          )
        } catch (err) {
          // If we fail to create a proxy instance, any instance, that means
          // that we won't be able to fix this instance when it is updated.
          // Recovering to normal state will be impossible. HMR's dead.
          //
          // Fatal error will trigger a full reload on next update (reloading
          // right now is kinda pointless since buggy code still exists).
          //
          fatalError = true
          logError(
            `Unrecoverable error in ${debugName}: next update will trigger full reload`
          )
          throw err
        }
      }
    },
  }[name]

  // initialize static members
  copyStatics(current.Component, proxy)

  const update = newState => Object.assign(current, newState)

  // reload all existing instances of this component
  const reload = () => {
    // update current references
    // Object.assign(current, { Component, hotOptions })
    // const { Component, hotOptions } = current

    // copy statics before doing anything because a static prop/method
    // could be used somewhere in the create/render call
    // TODO delete props/methods previously added and of which value has
    // not changed since
    copyStatics(current.Component, proxy)

    const errors = []

    instances.forEach(rerender => {
      try {
        rerender()
      } catch (err) {
        logError(
          `Failed to rerender ${debugName}: ${(err && err.stack) || err}`
        )
        errors.push(err)
      }
    })

    if (errors.length > 0) {
      return false
    }

    return true
  }

  const hasFatalError = () => fatalError

  return { id, proxy, update, reload, hasFatalError }
}


/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/svelte-hooks.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createProxiedComponent", function() { return createProxiedComponent; });
/* harmony import */ var svelte_internal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/svelte/internal/index.mjs");
/**
 * Emulates forthcoming HMR hooks in Svelte.
 *
 * All references to private component state ($$) are now isolated in this
 * module.
 */


// NOTE excludes store subscriptions because it causes crashes (and also
// probably not intented to restore stores state -- stores lives outside of
// the HMR'd component normally)
const isWritable = v => !v.module && v.writable && v.name.substr(0, 1) !== '$'

const isProp = v => isWritable(v) && v.export_name != null

// Core $capture_state should be able to capture either only props or the whole
// local state (i.e. any `let` value). The best behaviour regarding HMR varies
// between projects, and even situations of what you're currently working on...
// It's better to leave it as an option to the end user.
const $capture_state = (cmp, { captureLocalState }) => {
  const compileData = cmp.constructor.$compile
  // actual $capture_state is the only thing that works in 3.16+ (correct
  // local state behaviour will be made possible when #3822 is merged)
  if (cmp.$capture_state) {
    // NOTE the captureLocalState option is fantasy for now
    return cmp.$capture_state({ captureLocalState })
  }
  if (compileData && compileData.vars) {
    const state = {}
    const filter = captureLocalState ? isWritable : isProp
    const vars = compileData.vars.filter(filter)
    const ctx = cmp.$$.ctx
    for (const { name } of vars) {
      state[name] = ctx[name]
    }
    return state
  }
  // else nothing, state won't be used for restore...
}

const captureState = (cmp, captureLocalState = true) => {
  // sanity check: propper behaviour here is to crash noisily so that
  // user knows that they're looking at something broken
  if (!cmp) {
    throw new Error('Missing component')
  }
  if (!cmp.$$) {
    throw new Error('Invalid component')
  }
  const {
    $$: { callbacks, bound, ctx },
  } = cmp
  const state = $capture_state(cmp, { captureLocalState })
  return { ctx, callbacks, bound, state }
}

// restoreState
//
// It is too late to restore context at this point because component instance
// function has already been called (and so context has already been read).
// Instead, we rely on setting current_component to the same value it has when
// the component was first rendered -- which fix support for context, and is
// also generally more respectful of normal operation.
//
const restoreState = (cmp, restore) => {
  if (!restore) {
    return
  }
  const { callbacks, bound, state } = restore
  if (callbacks) {
    cmp.$$.callbacks = callbacks
  }
  if (bound) {
    cmp.$$.bound = bound
  }
  if (state && cmp.$inject_state) {
    cmp.$inject_state(state)
  }
  // props, props.$$slots are restored at component creation (works
  // better -- well, at all actually)
}

const filterProps = (props, { vars } = {}) => {
  if (!vars) {
    return props
  }
  const result = {}
  vars
    .filter(v => !!v.export_name)
    .forEach(({ export_name }) => {
      result[export_name] = props[export_name]
    })
  Object.keys(props)
    .filter(name => name.substr(0, 2) === '$$')
    .forEach(key => {
      result[key] = props[key]
    })
  return result
}

const createProxiedComponent = (
  Component,
  initialOptions,
  { noPreserveState, onInstance, onMount, onDestroy }
) => {
  let cmp
  let last
  let parentComponent
  let compileData
  let options = initialOptions

  const isCurrent = _cmp => cmp === _cmp

  const restoreOptions = restore => {
    const ctx = restore && restore.ctx
    if (ctx) {
      // if $inject_state is available (restore.state), then it will be used to
      // restore prop values, after the component has been recreated with the
      // initial props passed during component creation.
      //
      // NOTE original props contain slots: ctx.props.$$slots
      //
      // NOTE maybe compile data should be the preferred strategy because it
      // avoids creating the component with outdated prop values, and maybe it
      // can impact transitions or such. On the other hand, it seems somehow
      // more representative of the normal (i.e. non HMR) component behaviour,
      // to be created with the initial props and then transitionned to the
      // current value.
      if (!restore.state) {
        const props = filterProps(ctx, compileData)
        return { props }
      }
    }
  }

  const assignOptions = (target, anchor, restore) =>
    (options = Object.assign(
      {},
      initialOptions,
      { target, anchor },
      restoreOptions(restore)
    ))

  const instrument = targetCmp => {
    const createComponent = (Component, restore, previousCmp) => {
      Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_current_component"])(parentComponent || previousCmp)
      const comp = new Component(options)
      restoreState(comp, restore)
      instrument(comp)
      return comp
    }

    // `conservative: true` means we want to be sure that the new component has
    // actually been successfuly created before destroying the old instance.
    // This could be useful for preventing runtime errors in component init to
    // bring down the whole HMR. Unfortunately the implementation bellow is
    // broken (FIXME), but that remains an interesting target for when HMR hooks
    // will actually land in Svelte itself.
    //
    // The goal would be to render an error inplace in case of error, to avoid
    // losing the navigation stack (especially annoying in native, that is not
    // based on URL navigation, so we lose the current page on each error).
    //
    targetCmp.$replace = (
      Component,
      { target = options.target, anchor = options.anchor, conservative = false }
    ) => {
      compileData = Component.$compile
      const restore = captureState(targetCmp, !noPreserveState)
      assignOptions(target, anchor, restore)
      const previous = cmp
      if (conservative) {
        try {
          const next = createComponent(Component, restore, previous)
          // prevents on_destroy from firing on non-final cmp instance
          cmp = null
          previous.$destroy()
          cmp = next
        } catch (err) {
          cmp = previous
          throw err
        }
      } else {
        // prevents on_destroy from firing on non-final cmp instance
        cmp = null
        if (previous) {
          // previous can be null if last constructor has crashed
          previous.$destroy()
        }
        cmp = createComponent(Component, restore, last)
        last = cmp
      }
      return cmp
    }

    // NOTE onMount must provide target & anchor (for us to be able to determinate
    // 			actual DOM insertion point)
    //
    // 			And also, to support keyed list, it needs to be called each time the
    // 			component is moved (same as $$.fragment.m)
    if (onMount) {
      const m = targetCmp.$$.fragment.m
      targetCmp.$$.fragment.m = (...args) => {
        const result = m(...args)
        onMount(...args)
        return result
      }
    }

    // NOTE onDestroy must be called even if the call doesn't pass through the
    //      component's $destroy method (that we can hook onto by ourselves, since
    //      it's public API) -- this happens a lot in svelte's internals, that
    //      manipulates cmp.$$.fragment directly, often binding to fragment.d,
    //      for example
    if (onDestroy) {
      targetCmp.$$.on_destroy.push(() => {
        if (isCurrent(targetCmp)) {
          onDestroy()
        }
      })
    }

    if (onInstance) {
      onInstance(targetCmp)
    }

    // Svelte 3 creates and mount components from their constructor if
    // options.target is present.
    //
    // This means that at this point, the component's `fragment.c` and,
    // most notably, `fragment.m` will already have been called _from inside
    // createComponent_. That is: before we have a chance to hook on it.
    //
    // Proxy's constructor
    //   -> createComponent
    //     -> component constructor
    //       -> component.$$.fragment.c(...) (or l, if hydrate:true)
    //       -> component.$$.fragment.m(...)
    //
    //   -> you are here <-
    //
    if (onMount) {
      const { target, anchor } = options
      if (target) {
        onMount(target, anchor)
      }
    }
  }

  // NOTE relying on dynamic bindings (current_component) makes us dependent on
  // bundler config (and apparently it does not work in demo-svelte-nollup)
  try {
    // unfortunately, unlike current_component, get_current_component() can
    // crash in the normal path (when there is really no parent)
    parentComponent = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["get_current_component"])()
  } catch (err) {
    // ... so we need to consider that this error means that there is no parent
    //
    // that makes us tightly coupled to the error message but, at least, we
    // won't mute an unexpected error, which is quite a horrible thing to do
    if (err.message === 'Function called outside component initialization') {
      // who knows...
      parentComponent = svelte_internal__WEBPACK_IMPORTED_MODULE_0__["current_component"]
    } else {
      throw err
    }
  }

  cmp = new Component(options)

  instrument(cmp)

  return cmp
}


/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/svelte-native/patch-page-show-modal.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "patchShowModal", function() { return patchShowModal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getModalData", function() { return getModalData; });
/* harmony import */ var tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("tns-core-modules/ui/page");
/* harmony import */ var tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_0__);
/* global Symbol */

// This module monkey patches Page#showModal in order to be able to
// access from the HMR proxy data passed to `showModal` in svelte-native.
//
// Data are stored in a opaque prop accessible with `getModalData`.
//
// It also switches the `closeCallback` option with a custom brewed one
// in order to give the proxy control over when its own instance will be
// destroyed.
//
// Obviously this method suffer from extreme coupling with the target code
// in svelte-native. So it would be wise to recheck compatibility on SN
// version upgrades.
//
// Relevant code is there (last checked version):
//
// https://github.com/halfnelson/svelte-native/blob/48fdc97d2eb4d3958cfcb4ff6cf5755a220829eb/src/dom/navigation.ts#L132
//

// FIXME should we override ViewBase#showModal instead?


const prop =
  typeof Symbol !== 'undefined'
    ? Symbol('hmr_svelte_native_modal')
    : '___HMR_SVELTE_NATIVE_MODAL___'

const sup = tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_0__["Page"].prototype.showModal

let patched = false

const patchShowModal = () => {
  // guard: already patched
  if (patched) return
  patched = true

  tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_0__["Page"].prototype.showModal = function(modalView, options) {
    const modalData = {
      originalOptions: options,
      closeCallback: options.closeCallback,
    }

    modalView[prop] = modalData

    // Proxies to a function that can be swapped on the fly by HMR proxy.
    //
    // The default is still to call the original closeCallback from svelte
    // navtive, which will destroy the modal view & component. This way, if
    // no HMR happens on the modal content, normal behaviour is preserved
    // without the proxy having any work to do.
    //
    const closeCallback = (...args) => {
      return modalData.closeCallback(...args)
    }

    const tamperedOptions = Object.assign({}, options, { closeCallback })

    return sup.call(this, modalView, tamperedOptions)
  }
}

const getModalData = modalView => modalView[prop]


/***/ }),

/***/ "../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/svelte-native/proxy-adapter-native.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ProxyAdapterNative; });
/* harmony import */ var tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("tns-core-modules/ui/frame");
/* harmony import */ var tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _proxy_adapter_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/proxy-adapter-dom.js");
/* harmony import */ var _patch_page_show_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("../node_modules/svelte-loader-hot/node_modules/svelte-hmr/runtime/svelte-native/patch-page-show-modal.js");
/* global document */







Object(_patch_page_show_modal__WEBPACK_IMPORTED_MODULE_2__["patchShowModal"])()

// Svelte Native support
// =====================
//
// Rerendering Svelte Native page proves challenging...
//
// In NativeScript, pages are the top level component. They are normally
// introduced into NativeScript's runtime by its `navigate` function. This
// is how Svelte Natives handles it: it renders the Page component to a
// dummy fragment, and "navigate" to the page element thus created.
//
// As long as modifications only impact child components of the page, then
// we can keep the existing page and replace its content for HMR.
//
// However, if the page component itself is modified (including its system
// title bar), things get hairy...
//
// Apparently, the sole way of introducing a new page in a NS application is
// to navigate to it (no way to just replace it in its parent "element", for
// example). This is how it is done in NS's own "core" HMR.
//
// NOTE The last paragraph has not really been confirmed with NS6.
//
// Unfortunately the API they're using to do that is not public... Its various
// parts remain exposed though (but documented as private), so this exploratory
// work now relies on it. It might be fragile...
//
// The problem is that there is no public API that can navigate to a page and
// replace (like location.replace) the current history entry. Actually there
// is an active issue at NS asking for that. Incidentally, members of
// NativeScript-Vue have commented on the issue to weight in for it -- they
// probably face some similar challenge.
//
// https://github.com/NativeScript/NativeScript/issues/6283

const getNavTransition = ({ transition }) => {
  if (typeof transition === 'string') {
    transition = { name: transition }
  }
  return transition ? { animated: true, transition } : { animated: false }
}

// copied from TNS FrameBase.replacePage
//
// it is not public but there is a comment in there indicating it is for
// HMR (probably their own core HMR though)
//
// NOTE this "worked" in TNS 5, but not anymore in TNS 6: updated version bellow
//
// eslint-disable-next-line no-unused-vars
const replacePage_tns5 = (frame, newPageElement, hotOptions) => {
  const currentBackstackEntry = frame._currentEntry
  frame.navigationType = 2
  frame.performNavigation({
    isBackNavigation: false,
    entry: {
      resolvedPage: newPageElement.nativeView,
      //
      // entry: currentBackstackEntry.entry,
      entry: Object.assign(
        currentBackstackEntry.entry,
        getNavTransition(hotOptions)
      ),
      navDepth: currentBackstackEntry.navDepth,
      fragmentTag: currentBackstackEntry.fragmentTag,
      frameId: currentBackstackEntry.frameId,
    },
  })
}

// Updated for TNS v6
//
// https://github.com/NativeScript/NativeScript/blob/6.1.1/tns-core-modules/ui/frame/frame-common.ts#L656
const replacePage = (frame, newPageElement) => {
  const currentBackstackEntry = frame._currentEntry
  const newPage = newPageElement.nativeView
  const newBackstackEntry = {
    entry: currentBackstackEntry.entry,
    resolvedPage: newPage,
    navDepth: currentBackstackEntry.navDepth,
    fragmentTag: currentBackstackEntry.fragmentTag,
    frameId: currentBackstackEntry.frameId,
  }
  const navigationContext = {
    entry: newBackstackEntry,
    isBackNavigation: false,
    navigationType: tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["NavigationType"].replace,
  }
  frame._navigationQueue.push(navigationContext)
  frame._processNextNavigationEntry()
}

class ProxyAdapterNative extends _proxy_adapter_dom__WEBPACK_IMPORTED_MODULE_1__["default"] {
  constructor(instance) {
    super(instance)

    this.nativePageElement = null
    this.originalNativeView = null
    this.navigatedFromHandler = null

    this.relayNativeNavigatedFrom = this.relayNativeNavigatedFrom.bind(this)
  }

  dispose() {
    super.dispose()
    this.releaseNativePageElement()
  }

  releaseNativePageElement() {
    if (this.nativePageElement) {
      // native cleaning will happen when navigating back from the page
      this.nativePageElement = null
    }
  }

  // svelte-native uses navigateFrom event + e.isBackNavigation to know
  // when to $destroy the component -- but we don't want our proxy instance
  // destroyed when we renavigate to the same page for navigation purposes!
  interceptPageNavigation(pageElement) {
    const originalNativeView = pageElement.nativeView
    const { on } = originalNativeView
    const ownOn = originalNativeView.hasOwnProperty('on')
    // tricks svelte-native into giving us its handler
    originalNativeView.on = function(type, handler, ...rest) {
      if (type === 'navigatedFrom') {
        this.navigatedFromHandler = handler
        if (ownOn) {
          originalNativeView.on = on
        } else {
          delete originalNativeView.on
        }
      } else {
        throw new Error(
          'Unexpected call: has underlying svelte-native code changed?'
        )
      }
    }
  }

  afterMount(target, anchor) {
    // nativePageElement needs to be updated each time (only for page
    // components, native component that are not pages follow normal flow)
    //
    // DEBUG quid of components that are initially a page, but then have the
    // <page> tag removed while running? or the opposite?
    //
    // insertionPoint needs to be updated _only when the target changes_ --
    // i.e. when the component is mount, i.e. (in svelte3) when the component
    // is _created_, and svelte3 doesn't allow it to move afterward -- that
    // is, insertionPoint only needs to be created once when the component is
    // first mounted.
    //
    // DEBUG is it really true that components' elements cannot move in the
    // DOM? what about keyed list?
    //
    const isNativePage = target.tagName === 'fragment'
    if (isNativePage) {
      const nativePageElement = target.firstChild
      this.interceptPageNavigation(nativePageElement)
      this.nativePageElement = nativePageElement
    } else {
      // try to protect against components changing from page to no-page
      // or vice versa -- see DEBUG 1 above. NOT TESTED so prolly not working
      this.nativePageElement = null
      super.afterMount(target, anchor)
    }
  }

  rerender() {
    const { nativePageElement } = this
    if (nativePageElement) {
      this.rerenderNative()
    } else {
      super.rerender()
    }
  }

  rerenderNative() {
    const { nativePageElement: oldPageElement } = this
    const nativeView = oldPageElement.nativeView
    const frame = nativeView.frame
    if (frame) {
      return this.rerenderPage(frame, nativeView)
    }
    const modalParent = nativeView._modalParent // FIXME private API
    if (modalParent) {
      return this.rerenderModal(modalParent, nativeView)
    }
    // wtf? hopefully a race condition with a destroyed component, so
    // we have nothing more to do here
    //
    // for once, it happens when hot reloading dev deps, like this file
    //
  }

  rerenderPage(frame, previousPageView) {
    const isCurrentPage = frame.currentPage === previousPageView
    if (isCurrentPage) {
      const {
        instance: { hotOptions },
      } = this
      const newPageElement = this.createPage()
      if (!newPageElement) {
        throw new Error('Failed to create updated page')
      }
      const isFirstPage = !frame.canGoBack()

      if (isFirstPage) {
        // NOTE not so sure of bellow with the new NS6 method for replace
        // 
        // The "replacePage" strategy does not work on the first page
        // of the stack.
        //
        // Resulting bug:
        // - launch
        // - change first page => HMR
        // - navigate to other page
        // - back
        //   => actual: back to OS
        //   => expected: back to page 1
        //
        // Fortunately, we can overwrite history in this case.
        //
        const nativeView = newPageElement.nativeView
        frame.navigate(
          Object.assign(
            {},
            {
              create: () => nativeView,
              clearHistory: true,
            },
            getNavTransition(hotOptions)
          )
        )
      } else {
        replacePage(frame, newPageElement, hotOptions)
      }
    } else {
      const backEntry = frame.backStack.find(
        ({ resolvedPage: page }) => page === previousPageView
      )
      if (!backEntry) {
        // well... looks like we didn't make it to history after all
        return
      }
      // replace existing nativeView
      const newPageElement = this.createPage()
      if (newPageElement) {
        backEntry.resolvedPage = newPageElement.nativeView
      } else {
        throw new Error('Failed to create updated page')
      }
    }
  }

  // modalParent is the page on which showModal(...) was called
  // oldPageElement is the modal content, that we're actually trying to reload
  rerenderModal(modalParent, modalView) {
    const modalData = Object(_patch_page_show_modal__WEBPACK_IMPORTED_MODULE_2__["getModalData"])(modalView)

    modalData.closeCallback = () => {
      const nativePageElement = this.createPage()
      if (!nativePageElement) {
        throw new Error('Failed to created updated modal page')
      }
      const { nativeView } = nativePageElement
      const { originalOptions } = modalData
      // Options will get monkey patched again, the only work left for us
      // is to try to reduce visual disturbances.
      //
      // FIXME Even that proves too much unfortunately... Apparently TNS
      // does not respect the `animated` option in this context:
      // https://docs.nativescript.org/api-reference/interfaces/_ui_core_view_base_.showmodaloptions#animated
      //
      const options = Object.assign({}, originalOptions, { animated: false })
      modalParent.showModal(nativeView, options)
    }

    modalView.closeModal()
  }

  createPage() {
    const {
      instance: { refreshComponent },
    } = this
    const { nativePageElement, relayNativeNavigatedFrom } = this
    const oldNativeView = nativePageElement.nativeView
    // rerender
    const target = document.createElement('fragment')
    // not using conservative for now, since there's nothing in place here to
    // leverage it (yet?) -- and it might be easier to miss breakages in native
    // only code paths
    refreshComponent(target, null)
    // this.nativePageElement is updated in afterMount, triggered by proxy / hooks
    const newPageElement = this.nativePageElement
    // update event proxy
    oldNativeView.off('navigatedFrom', relayNativeNavigatedFrom)
    nativePageElement.nativeView.on('navigatedFrom', relayNativeNavigatedFrom)
    return newPageElement
  }

  relayNativeNavigatedFrom({ isBackNavigation }) {
    const { originalNativeView, navigatedFromHandler } = this
    if (!isBackNavigation) {
      return
    }
    if (originalNativeView) {
      const { off } = originalNativeView
      const ownOff = originalNativeView.hasOwnProperty('off')
      originalNativeView.off = function() {
        this.navigatedFromHandler = null
        if (ownOff) {
          originalNativeView.off = off
        } else {
          delete originalNativeView.off
        }
      }
    }
    if (navigatedFromHandler) {
      return navigatedFromHandler.apply(this, arguments)
    }
  }

  renderError(err, target, anchor) {
    // TODO fallback on TNS error handler for now... at least our error
    // is more informative
    throw err
  }
}


/***/ }),

/***/ "../node_modules/svelte-native/components/index.mjs":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Template", function() { return Template; });
/* harmony import */ var svelte_internal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/svelte/internal/index.mjs");


/* src\components\SlotComponent.svelte generated by Svelte v3.16.4 */

const get_default_slot_changes = dirty => ({ props: dirty[0] & /*p*/ 1 });
const get_default_slot_context = ctx => ({ props: /*p*/ ctx[0] });

function create_fragment(ctx) {
	let current;
	const default_slot_template = /*$$slots*/ ctx[3].default;
	const default_slot = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["create_slot"])(default_slot_template, ctx, /*$$scope*/ ctx[2], get_default_slot_context);

	return {
		c() {
			if (default_slot) default_slot.c();
		},
		m(target, anchor) {
			if (default_slot) {
				default_slot.m(target, anchor);
			}

			current = true;
		},
		p(ctx, dirty) {
			if (default_slot && default_slot.p && dirty[0] & /*$$scope, p*/ 5) {
				default_slot.p(Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["get_slot_context"])(default_slot_template, ctx, /*$$scope*/ ctx[2], get_default_slot_context), Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["get_slot_changes"])(default_slot_template, /*$$scope*/ ctx[2], dirty, get_default_slot_changes));
			}
		},
		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(default_slot, local);
			current = true;
		},
		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(default_slot, local);
			current = false;
		},
		d(detaching) {
			if (default_slot) default_slot.d(detaching);
		}
	};
}

function instance($$self, $$props, $$invalidate) {
	let { $$slots = {}, $$scope } = $$props;

	$$self.$set = $$new_props => {
		$$invalidate(1, $$props = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["assign"])(Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["assign"])({}, $$props), Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["exclude_internal_props"])($$new_props)));
		if ("$$scope" in $$new_props) $$invalidate(2, $$scope = $$new_props.$$scope);
	};

	let p;

	$$self.$$.update = () => {
		 $$invalidate(0, p = $$props);
	};

	$$props = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["exclude_internal_props"])($$props);
	return [p, $$props, $$scope, $$slots];
}

class SlotComponent extends svelte_internal__WEBPACK_IMPORTED_MODULE_0__["SvelteComponent"] {
	constructor(options) {
		super();
		Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["init"])(this, options, instance, create_fragment, svelte_internal__WEBPACK_IMPORTED_MODULE_0__["safe_not_equal"], {});
	}
}

/* src\components\AsComponent.svelte generated by Svelte v3.16.4 */

function instance$1($$self, $$props, $$invalidate) {
	let slots = $$props.$$slots;
	let scope = $$props.$$scope;

	const component = class extends SlotComponent {
		constructor(options) {
			let new_options = Object.assign({}, options);
			new_options.props = Object.assign({}, options.props, { $$slots: slots, $$scope: scope });
			super(new_options);
		}
	};

	$$self.$set = $$new_props => {
		$$invalidate(3, $$props = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["assign"])(Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["assign"])({}, $$props), Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["exclude_internal_props"])($$new_props)));
	};

	$$props = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["exclude_internal_props"])($$props);
	return [component];
}

class AsComponent extends svelte_internal__WEBPACK_IMPORTED_MODULE_0__["SvelteComponent"] {
	constructor(options) {
		super();
		Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["init"])(this, options, instance$1, null, svelte_internal__WEBPACK_IMPORTED_MODULE_0__["safe_not_equal"], { component: 0 });
	}

	get component() {
		return this.$$.ctx[0];
	}
}

/* src\components\Template.svelte generated by Svelte v3.16.4 */
const get_default_slot_changes$1 = dirty => ({ item: dirty[0] & /*props*/ 32 });

const get_default_slot_context$1 = ctx => ({
	item: /*props*/ ctx[5] ? /*props*/ ctx[5].item : null
});

// (2:0) <AsComponent bind:component="{template}" let:props>
function create_default_slot(ctx) {
	let current;
	const default_slot_template = /*$$slots*/ ctx[2].default;
	const default_slot = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["create_slot"])(default_slot_template, ctx, /*$$scope*/ ctx[4], get_default_slot_context$1);

	return {
		c() {
			if (default_slot) default_slot.c();
		},
		m(target, anchor) {
			if (default_slot) {
				default_slot.m(target, anchor);
			}

			current = true;
		},
		p(ctx, dirty) {
			if (default_slot && default_slot.p && dirty[0] & /*$$scope, props*/ 48) {
				default_slot.p(Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["get_slot_context"])(default_slot_template, ctx, /*$$scope*/ ctx[4], get_default_slot_context$1), Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["get_slot_changes"])(default_slot_template, /*$$scope*/ ctx[4], dirty, get_default_slot_changes$1));
			}
		},
		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(default_slot, local);
			current = true;
		},
		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(default_slot, local);
			current = false;
		},
		d(detaching) {
			if (default_slot) default_slot.d(detaching);
		}
	};
}

function create_fragment$1(ctx) {
	let template_1;
	let t;
	let updating_component;
	let current;
	let template_1_levels = [/*$$props*/ ctx[1], { component: /*template*/ ctx[0] }, { xmlns: "tns" }];
	let template_1_data = {};

	for (let i = 0; i < template_1_levels.length; i += 1) {
		template_1_data = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["assign"])(template_1_data, template_1_levels[i]);
	}

	function ascomponent_component_binding(value) {
		/*ascomponent_component_binding*/ ctx[3].call(null, value);
	}

	let ascomponent_props = {
		$$slots: {
			default: [
				create_default_slot,
				({ props }) => ({ 5: props }),
				({ props }) => [props ? 32 : 0]
			]
		},
		$$scope: { ctx }
	};

	if (/*template*/ ctx[0] !== void 0) {
		ascomponent_props.component = /*template*/ ctx[0];
	}

	const ascomponent = new AsComponent({ props: ascomponent_props });
	svelte_internal__WEBPACK_IMPORTED_MODULE_0__["binding_callbacks"].push(() => Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["bind"])(ascomponent, "component", ascomponent_component_binding));

	return {
		c() {
			template_1 = document.createElementNS("tns", "template");
			t = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["space"])();
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["create_component"])(ascomponent.$$.fragment);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_attributes"])(template_1, template_1_data);
		},
		m(target, anchor) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, template_1, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["insert"])(target, t, anchor);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["mount_component"])(ascomponent, target, anchor);
			current = true;
		},
		p(ctx, dirty) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["set_attributes"])(template_1, Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["get_spread_update"])(template_1_levels, [
				dirty[0] & /*$$props*/ 2 && /*$$props*/ ctx[1],
				dirty[0] & /*template*/ 1 && ({ component: /*template*/ ctx[0] }),
				{ xmlns: "tns" }
			]));

			const ascomponent_changes = {};

			if (dirty[0] & /*$$scope, props*/ 48) {
				ascomponent_changes.$$scope = { dirty, ctx };
			}

			if (!updating_component && dirty[0] & /*template*/ 1) {
				updating_component = true;
				ascomponent_changes.component = /*template*/ ctx[0];
				Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["add_flush_callback"])(() => updating_component = false);
			}

			ascomponent.$set(ascomponent_changes);
		},
		i(local) {
			if (current) return;
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_in"])(ascomponent.$$.fragment, local);
			current = true;
		},
		o(local) {
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["transition_out"])(ascomponent.$$.fragment, local);
			current = false;
		},
		d(detaching) {
			if (detaching) Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(template_1);
			if (detaching) Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["detach"])(t);
			Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["destroy_component"])(ascomponent, detaching);
		}
	};
}

function instance$2($$self, $$props, $$invalidate) {
	let template;
	let { $$slots = {}, $$scope } = $$props;

	function ascomponent_component_binding(value) {
		template = value;
		$$invalidate(0, template);
	}

	$$self.$set = $$new_props => {
		$$invalidate(1, $$props = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["assign"])(Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["assign"])({}, $$props), Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["exclude_internal_props"])($$new_props)));
		if ("$$scope" in $$new_props) $$invalidate(4, $$scope = $$new_props.$$scope);
	};

	$$props = Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["exclude_internal_props"])($$props);
	return [template, $$props, $$slots, ascomponent_component_binding, $$scope];
}

class Template extends svelte_internal__WEBPACK_IMPORTED_MODULE_0__["SvelteComponent"] {
	constructor(options) {
		super();
		Object(svelte_internal__WEBPACK_IMPORTED_MODULE_0__["init"])(this, options, instance$2, create_fragment$1, svelte_internal__WEBPACK_IMPORTED_MODULE_0__["safe_not_equal"], {});
	}
}




/***/ }),

/***/ "../node_modules/svelte-native/dom/index.mjs":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActionBarElement", function() { return ActionBarElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BottomNavigationElement", function() { return BottomNavigationElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DomTraceCategory", function() { return DomTraceCategory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ElementNode", function() { return ElementNode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FrameElement", function() { return FrameElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeadElement", function() { return HeadElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListViewElement", function() { return ListViewElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogLevel", function() { return LogLevel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NativeElementNode", function() { return NativeElementNode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NativeElementPropType", function() { return NativeElementPropType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NativeViewElementNode", function() { return NativeViewElementNode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PageElement", function() { return PageElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StyleElement", function() { return StyleElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SvelteKeyedTemplate", function() { return SvelteKeyedTemplate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SvelteNativeDocument", function() { return SvelteNativeDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsElement", function() { return TabsElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TemplateElement", function() { return TemplateElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewNode", function() { return ViewNode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "closeModal", function() { return closeModal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createElement", function() { return createElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "goBack", function() { return goBack; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeDom", function() { return initializeDom; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "logger", function() { return logger; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "navigate", function() { return navigate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "registerElement", function() { return registerElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "registerNativeConfigElement", function() { return registerNativeConfigElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "registerNativeViewElement", function() { return registerNativeViewElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showModal", function() { return showModal; });
/* harmony import */ var tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("tns-core-modules/ui/frame");
/* harmony import */ var tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var tns_core_modules_application__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("tns-core-modules/application");
/* harmony import */ var tns_core_modules_application__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_application__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("tns-core-modules/ui/page");
/* harmony import */ var tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var tns_core_modules_ui_animation_keyframe_animation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("tns-core-modules/ui/animation/keyframe-animation");
/* harmony import */ var tns_core_modules_ui_animation_keyframe_animation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_animation_keyframe_animation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var tns_core_modules_ui_styling_css_animation_parser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("tns-core-modules/ui/styling/css-animation-parser");
/* harmony import */ var tns_core_modules_ui_styling_css_animation_parser__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_styling_css_animation_parser__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var tns_core_modules_ui_layouts_layout_base__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("tns-core-modules/ui/layouts/layout-base");
/* harmony import */ var tns_core_modules_ui_layouts_layout_base__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_layouts_layout_base__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var tns_core_modules_data_observable_array_observable_array__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("tns-core-modules/data/observable-array/observable-array");
/* harmony import */ var tns_core_modules_data_observable_array_observable_array__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_data_observable_array_observable_array__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var tns_core_modules_ui_list_view__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("tns-core-modules/ui/list-view");
/* harmony import */ var tns_core_modules_ui_list_view__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_list_view__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var tns_core_modules_ui_tab_view__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("tns-core-modules/ui/tab-view");
/* harmony import */ var tns_core_modules_ui_tab_view__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_tab_view__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var tns_core_modules_ui_tab_navigation_base_tab_content_item__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("tns-core-modules/ui/tab-navigation-base/tab-content-item");
/* harmony import */ var tns_core_modules_ui_tab_navigation_base_tab_content_item__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_tab_navigation_base_tab_content_item__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var tns_core_modules_ui_bottom_navigation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("tns-core-modules/ui/bottom-navigation");
/* harmony import */ var tns_core_modules_ui_bottom_navigation__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_bottom_navigation__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var tns_core_modules_ui_tabs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("tns-core-modules/ui/tabs");
/* harmony import */ var tns_core_modules_ui_tabs__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_tabs__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var tns_core_modules_ui_action_bar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("tns-core-modules/ui/action-bar");
/* harmony import */ var tns_core_modules_ui_action_bar__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_action_bar__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var tns_core_modules_ui_tab_navigation_base_tab_strip__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__("tns-core-modules/ui/tab-navigation-base/tab-strip");
/* harmony import */ var tns_core_modules_ui_tab_navigation_base_tab_strip__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_tab_navigation_base_tab_strip__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var tns_core_modules_ui_tab_navigation_base_tab_strip_item__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__("tns-core-modules/ui/tab-navigation-base/tab-strip-item");
/* harmony import */ var tns_core_modules_ui_tab_navigation_base_tab_strip_item__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_ui_tab_navigation_base_tab_strip_item__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__("tns-core-modules/trace");
/* harmony import */ var tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__);

















var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["Debug"] = 0] = "Debug";
    LogLevel[LogLevel["Info"] = 1] = "Info";
    LogLevel[LogLevel["Warn"] = 2] = "Warn";
    LogLevel[LogLevel["Error"] = 3] = "Error";
})(LogLevel || (LogLevel = {}));
const nullLogger = () => { };
class Logger {
    constructor() {
        this.onLog = () => nullLogger;
    }
    setHandler(logger) {
        this.onLog = logger || nullLogger;
    }
    debug(message) {
        this.onLog(message, LogLevel.Debug);
    }
    info(message) {
        this.onLog(message, LogLevel.Info);
    }
    warn(message) {
        this.onLog(message, LogLevel.Warn);
    }
    error(message) {
        this.onLog(message, LogLevel.Error);
    }
}
const logger = new Logger();

const dashRegExp = /-/g;
function normalizeElementName(elementName) {
    return `${elementName
        .replace(dashRegExp, '')
        .toLowerCase()}`;
}
function* elementIterator(el) {
    yield el;
    for (let child of el.childNodes) {
        yield* elementIterator(child);
    }
}
class ViewNode {
    constructor() {
        this.nodeType = null;
        this._tagName = null;
        this.parentNode = null;
        this.childNodes = [];
        this.prevSibling = null;
        this.nextSibling = null;
        this._ownerDocument = null;
        this._attributes = {};
    }
    hasAttribute(name) {
        return Object.keys(this._attributes).indexOf(name) > -1;
    }
    removeAttribute(name) {
        delete this._attributes[name];
    }
    /* istanbul ignore next */
    toString() {
        return `${this.constructor.name}(${this.tagName})`;
    }
    set tagName(name) {
        this._tagName = normalizeElementName(name);
    }
    get tagName() {
        return this._tagName;
    }
    get firstChild() {
        return this.childNodes.length ? this.childNodes[0] : null;
    }
    get lastChild() {
        return this.childNodes.length
            ? this.childNodes[this.childNodes.length - 1]
            : null;
    }
    /* istanbul ignore next */
    get ownerDocument() {
        if (this._ownerDocument) {
            return this._ownerDocument;
        }
        let el = this;
        while (el != null && el.nodeType !== 9) {
            el = el.parentNode;
        }
        return (this._ownerDocument = el);
    }
    getAttribute(key) {
        return this._attributes[key];
    }
    /* istanbul ignore next */
    setAttribute(key, value) {
        this._attributes[key] = value;
    }
    /* istanbul ignore next */
    setText(text) {
        logger.debug(`setText ${this} ${text}`);
        if (this.nodeType === 3) {
            this.parentNode.setText(text);
        }
        else {
            this.setAttribute('text', text);
        }
    }
    onInsertedChild(childNode, index) { }
    onRemovedChild(childNode) { }
    insertBefore(childNode, referenceNode) {
        logger.debug(`insert before ${this} ${childNode} ${referenceNode}`);
        if (!childNode) {
            throw new Error(`Can't insert child.`);
        }
        // in some rare cases insertBefore is called with a null referenceNode
        // this makes sure that it get's appended as the last child
        if (!referenceNode) {
            return this.appendChild(childNode);
        }
        if (referenceNode.parentNode !== this) {
            throw new Error(`Can't insert child, because the reference node has a different parent.`);
        }
        if (childNode.parentNode && childNode.parentNode !== this) {
            throw new Error(`Can't insert child, because it already has a different parent.`);
        }
        if (childNode.parentNode === this) ;
        let index = this.childNodes.indexOf(referenceNode);
        childNode.parentNode = this;
        childNode.nextSibling = referenceNode;
        childNode.prevSibling = this.childNodes[index - 1];
        referenceNode.prevSibling = childNode;
        this.childNodes.splice(index, 0, childNode);
        this.onInsertedChild(childNode, index);
    }
    appendChild(childNode) {
        logger.debug(`append child ${this} ${childNode}`);
        if (!childNode) {
            throw new Error(`Can't append child.`);
        }
        if (childNode.parentNode && childNode.parentNode !== this) {
            throw new Error(`Can't append child, because it already has a different parent.`);
        }
        if (childNode.parentNode === this) ;
        childNode.parentNode = this;
        if (this.lastChild) {
            childNode.prevSibling = this.lastChild;
            this.lastChild.nextSibling = childNode;
        }
        this.childNodes.push(childNode);
        this.onInsertedChild(childNode, this.childNodes.length - 1);
    }
    removeChild(childNode) {
        logger.debug(`remove child ${this} ${childNode}`);
        if (!childNode) {
            throw new Error(`Can't remove child.`);
        }
        if (!childNode.parentNode) {
            throw new Error(`Can't remove child, because it has no parent.`);
        }
        if (childNode.parentNode !== this) {
            throw new Error(`Can't remove child, because it has a different parent.`);
        }
        childNode.parentNode = null;
        if (childNode.prevSibling) {
            childNode.prevSibling.nextSibling = childNode.nextSibling;
        }
        if (childNode.nextSibling) {
            childNode.nextSibling.prevSibling = childNode.prevSibling;
        }
        // reset the prevSibling and nextSibling. If not, a keep-alived component will
        // still have a filled nextSibling attribute so vue will not
        // insert the node again to the parent. See #220
        childNode.prevSibling = null;
        childNode.nextSibling = null;
        this.childNodes = this.childNodes.filter(node => node !== childNode);
        this.onRemovedChild(childNode);
    }
    firstElement() {
        for (var child of this.childNodes) {
            if (child.nodeType == 1) {
                return child;
            }
        }
        return null;
    }
}

class ElementNode extends ViewNode {
    constructor(tagName) {
        super();
        this.nodeType = 1;
        this.tagName = tagName;
    }
    get id() {
        return this.getAttribute('id');
    }
    set id(value) {
        this.setAttribute('id', value);
    }
    get classList() {
        if (!this._classList) {
            const getClasses = () => (this.getAttribute('class') || "").split(/\s+/).filter((k) => k != "");
            this._classList = {
                add: (...classNames) => {
                    this.setAttribute('class', [...new Set(getClasses().concat(classNames))].join(" "));
                },
                remove: (...classNames) => {
                    this.setAttribute('class', getClasses().filter((i) => classNames.indexOf(i) == -1).join(" "));
                },
                get length() {
                    return getClasses().length;
                }
            };
        }
        return this._classList;
    }
    appendChild(childNode) {
        super.appendChild(childNode);
        if (childNode.nodeType === 3) {
            this.setText(childNode.text);
        }
        if (childNode.nodeType === 7) {
            childNode.setOnNode(this);
        }
    }
    insertBefore(childNode, referenceNode) {
        super.insertBefore(childNode, referenceNode);
        if (childNode.nodeType === 3) {
            this.setText(childNode.text);
        }
        if (childNode.nodeType === 7) {
            childNode.setOnNode(this);
        }
    }
    removeChild(childNode) {
        super.removeChild(childNode);
        if (childNode.nodeType === 3) {
            this.setText('');
        }
        if (childNode.nodeType === 7) {
            childNode.clearOnNode(this);
        }
    }
}

class CommentNode extends ElementNode {
    constructor(text) {
        super('comment');
        this.nodeType = 8;
        this.text = text;
    }
}

class TextNode extends ViewNode {
    constructor(text) {
        super();
        this.nodeType = 3;
        this.text = text;
    }
    setText(text) {
        this.text = text;
        this.parentNode.setText(text);
    }
    set data(text) {
        this.setText(text);
    }
    get data() {
        return this.text;
    }
}

class PropertyNode extends ElementNode {
    constructor(tagName, propertyName) {
        super(`${tagName}.${propertyName}`);
        this.propertyName = propertyName;
        this.propertyTagName = normalizeElementName(tagName);
        this.nodeType = 7; //processing instruction
    }
    onInsertedChild() {
        this.setOnNode(this.parentNode);
    }
    onRemovedChild() {
        this.setOnNode(this.parentNode);
    }
    /* istanbul ignore next */
    toString() {
        return `${this.constructor.name}(${this.tagName}, ${this.propertyName})`;
    }
    setOnNode(parent) {
        if (parent && (parent.tagName === this.propertyTagName)) {
            const el = this.firstElement();
            parent.setAttribute(this.propertyName, el);
        }
    }
    clearOnNode(parent) {
        if (parent && (parent.tagName === this.propertyTagName)) {
            parent.setAttribute(this.propertyName, null);
        }
    }
}

const elementMap = {};
function registerElementResolver(elementName, entry) {
    const normalizedName = normalizeElementName(elementName);
    if (elementMap[normalizedName]) {
        throw new Error(`Element for ${normalizedName} already registered.`);
    }
    elementMap[normalizedName] = entry;
}
function registerElement(elementName, resolver) {
    registerElementResolver(elementName, { resolver: resolver });
}
function createElement(elementName) {
    const normalizedName = normalizeElementName(elementName);
    const elementDefinition = elementMap[normalizedName];
    if (!elementDefinition) {
        throw new TypeError(`No known component for element ${elementName}.`);
    }
    return elementDefinition.resolver();
}

class DocumentNode extends ViewNode {
    constructor() {
        super();
        this.tagName = "docNode";
        this.nodeType = 9;
    }
    createComment(text) {
        return new CommentNode(text);
    }
    createPropertyNode(tagName, propertyName) {
        return new PropertyNode(tagName, propertyName);
    }
    createElement(tagName) {
        if (tagName.indexOf(".") >= 0) {
            let bits = tagName.split(".", 2);
            return this.createPropertyNode(bits[0], bits[1]);
        }
        return createElement(tagName);
    }
    createElementNS(namespace, tagName) {
        return this.createElement(tagName);
    }
    createTextNode(text) {
        return new TextNode(text);
    }
    getElementById(id) {
        for (let el of elementIterator(this)) {
            if (el.nodeType === 1 && el.id === id)
                return el;
        }
    }
    dispatchEvent(event) {
        //Svelte dev fires these for tool support
    }
}

class StyleSheet {
    constructor() {
        this._rules = [];
    }
    // The css rules generated by svelte have a keyframe every 16 milliseconds and are quite slow to create and run
    // this is here to support the simple and short ones, but ideally we would promote our own transitions in svelte-native/transitions
    // which would delegate to the more direct nativescript way of working.
    deleteRule(index) {
        let removed = this._rules.splice(index, 1);
        for (let r in removed) {
            logger.debug(`removing transition rule ${r}`);
            // Turns out nativescript doesn't support "removing" css.
            // this is pretty horrible but better than a memory leak. 
            // since this code is called mainly for keyframes, and keyframes don't add new selectors (they just end up in _keyframes)
            // we can almost remove the rules ourselves.
            if (r.startsWith('@keyframes')) {
                const name = r.split(" ")[1];
                let frame = Object(tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["topmost"])();
                if (frame && frame._styleScope) {
                    let scope = frame._styleScope;
                    delete scope._keyframes[name];
                    scope._css = scope._css.replace(r, "");
                }
            }
        }
    }
    insertRule(rule, index = 0) {
        logger.debug(`Adding transition rule ${rule}`);
        let frame = Object(tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["topmost"])();
        frame.addCss(rule);
        this._rules.splice(index, 0, rule);
    }
    get cssRules() {
        return this._rules;
    }
}
class StyleElement extends ElementNode {
    constructor() {
        super('style');
        this._sheet = new StyleSheet();
    }
    get sheet() {
        return this._sheet;
    }
}

class HeadElement extends ElementNode {
    constructor() {
        super('head');
    }
    onInsertedChild(childNode, atIndex) {
        if (childNode instanceof StyleElement) {
            let css = childNode.textContent;
            let id = childNode.id;
            let style_hash = id.replace('-style', '');
            //style rules are one per line as long as each selector in the rule has the style hash we are all scoped styles and can pass true to addCss
            let all_scoped = css.split("\n").every(r => r.split(",").every(i => i.indexOf(style_hash) >= 0));
            if (css) {
                Object(tns_core_modules_application__WEBPACK_IMPORTED_MODULE_1__["addCss"])(css, all_scoped);
            }
        }
    }
}

class TemplateElement extends ElementNode {
    constructor() {
        super('template');
    }
    set component(value) {
        this.setAttribute('component', value);
    }
    get component() {
        return this.getAttribute('component');
    }
}

// Dom elements that svelte expects to be able to create or use.
// or custom additions to make life easier
function registerSvelteElements() {
    registerElement('head', () => new HeadElement());
    registerElement('style', () => new StyleElement());
    registerElement('fragment', () => new ElementNode('fragment'));
    registerElement('template', () => new TemplateElement());
}

var NativeElementPropType;
(function (NativeElementPropType) {
    NativeElementPropType[NativeElementPropType["Value"] = 0] = "Value";
    NativeElementPropType[NativeElementPropType["Array"] = 1] = "Array";
    NativeElementPropType[NativeElementPropType["ObservableArray"] = 2] = "ObservableArray";
})(NativeElementPropType || (NativeElementPropType = {}));
function setOnArrayProp(parent, value, propName, build = null) {
    let current = parent[propName];
    if (!current || !current.push) {
        parent[propName] = build ? build(value) : [value];
    }
    else {
        current.push(value);
    }
}
function removeFromArrayProp(parent, value, propName) {
    let current = parent[propName];
    if (!current || !current.splice) {
        let idx = current.indexOf(value);
        if (idx >= 0)
            current.splice(idx, 1);
    }
}
const _normalizedKeys = new Map();
function getNormalizedKeysForObject(obj, knownPropNames) {
    let proto = Object.getPrototypeOf(obj);
    let m = _normalizedKeys.get(proto);
    if (m)
        return m;
    //calculate our prop names
    let props = new Map();
    _normalizedKeys.set(proto, props);
    //include known props
    knownPropNames.forEach(p => props.set(p.toLowerCase(), p));
    //infer the rest from the passed object (including updating any incorrect known prop names if found)
    for (let p in obj) {
        props.set(p.toLowerCase(), p);
    }
    return props;
}
function normalizeKeyFromObject(obj, key) {
    let lowerkey = key.toLowerCase();
    for (let p in obj) {
        if (p.toLowerCase() == lowerkey) {
            return p;
        }
    }
    return key;
}
// Implements an ElementNode that wraps a NativeScript object. It uses the object as the source of truth for its attributes
class NativeElementNode extends ElementNode {
    constructor(tagName, elementClass, setsParentProp = null, propConfig = {}) {
        super(tagName);
        this.propAttribute = null;
        this.propConfig = propConfig;
        this.propAttribute = setsParentProp;
        this._nativeElement = new elementClass();
        this._normalizedKeys = getNormalizedKeysForObject(this._nativeElement, Object.keys(this.propConfig));
        this._nativeElement.__SvelteNativeElement__ = this;
        logger.debug(`created ${this} ${this._nativeElement}`);
    }
    get nativeElement() {
        return this._nativeElement;
    }
    set nativeElement(el) {
        if (this._nativeElement) {
            throw new Error(`Can't overwrite native element.`);
        }
        this._nativeElement = el;
    }
    getAttribute(fullkey) {
        let getTarget = this.nativeElement;
        let keypath = fullkey.split(".");
        let resolvedKeys = [];
        while (keypath.length > 0) {
            if (!getTarget)
                return null;
            let key = keypath.shift();
            if (resolvedKeys.length == 0) {
                key = this._normalizedKeys.get(key) || key;
            }
            else {
                key = normalizeKeyFromObject(getTarget, key);
            }
            resolvedKeys.push(key);
            if (keypath.length > 0) {
                getTarget = getTarget[key];
            }
            else {
                return getTarget[key];
            }
        }
        return null;
    }
    onInsertedChild(childNode, index) {
        super.onInsertedChild(childNode, index);
        // support for the prop: shorthand for setting parent property to native element
        if (!(childNode instanceof NativeElementNode))
            return;
        let propName = childNode.propAttribute;
        if (!propName)
            return;
        //Special case Array and Observable Array keys
        propName = this._normalizedKeys.get(propName) || propName;
        switch (this.propConfig[propName]) {
            case NativeElementPropType.Array:
                setOnArrayProp(this.nativeElement, childNode.nativeElement, propName);
                return;
            case NativeElementPropType.ObservableArray:
                setOnArrayProp(this.nativeElement, childNode.nativeElement, propName, (v) => new tns_core_modules_data_observable_array_observable_array__WEBPACK_IMPORTED_MODULE_6__["ObservableArray"](v));
                return;
            default:
                this.setAttribute(propName, childNode);
        }
    }
    onRemovedChild(childNode) {
        if (!(childNode instanceof NativeElementNode))
            return;
        let propName = childNode.propAttribute;
        if (!propName)
            return;
        //Special case Array and Observable Array keys
        propName = this._normalizedKeys.get(propName) || propName;
        switch (this.propConfig[propName]) {
            case NativeElementPropType.Array:
            case NativeElementPropType.ObservableArray:
                removeFromArrayProp(this.nativeElement, childNode, propName);
                return;
            default:
                this.setAttribute(propName, null);
        }
        super.onRemovedChild(childNode);
    }
    setAttribute(fullkey, value) {
        const nv = this.nativeElement;
        let setTarget = nv;
        // normalize key
        if (tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__["isAndroid"] && fullkey.startsWith('android:')) {
            fullkey = fullkey.substr(8);
        }
        if (tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__["isIOS"] && fullkey.startsWith('ios:')) {
            fullkey = fullkey.substr(4);
        }
        if (fullkey.startsWith("prop:")) {
            this.propAttribute = fullkey.substr(5);
            return;
        }
        //we might be getting an element from a propertyNode eg page.actionBar, unwrap
        if (value instanceof NativeElementNode) {
            value = value.nativeElement;
        }
        let keypath = fullkey.split(".");
        let resolvedKeys = [];
        while (keypath.length > 0) {
            if (!setTarget)
                return;
            let key = keypath.shift();
            // normalize to correct case
            if (resolvedKeys.length == 0) {
                key = this._normalizedKeys.get(key) || key;
            }
            else {
                key = normalizeKeyFromObject(setTarget, key);
            }
            resolvedKeys.push(key);
            if (keypath.length > 0) {
                setTarget = setTarget[key];
            }
            else {
                try {
                    logger.debug(`setAttr value ${this} ${resolvedKeys.join(".")} ${value}`);
                    setTarget[key] = value;
                }
                catch (e) {
                    // ignore but log
                    logger.error(`set attribute threw an error, attr:${key} on ${this._tagName}: ${e.message}`);
                }
            }
        }
    }
}
function registerNativeConfigElement(elementName, resolver, parentProp = null, propConfig = {}) {
    registerElement(elementName, () => new NativeElementNode(elementName, resolver(), parentProp, propConfig));
}

function camelize(kebab) {
    return kebab.replace(/[\-]+(\w)/g, (m, l) => l.toUpperCase());
}
function registerNativeViewElement(elementName, resolver, parentProp = null, propConfig = {}) {
    registerElement(elementName, () => new NativeViewElementNode(elementName, resolver(), parentProp, propConfig));
}
// A NativeViewElementNode, wraps a native View and handles style, event dispatch, and native view hierarchy management.
class NativeViewElementNode extends NativeElementNode {
    constructor(tagName, viewClass, setsParentProp = null, propConfig = {}) {
        super(tagName, viewClass, setsParentProp, propConfig);
        let setStyleAttribute = (value) => {
            this.setAttribute('style', value);
        };
        let getStyleAttribute = () => {
            return this.getAttribute('style');
        };
        let getParentPage = () => {
            if (this.nativeView && this.nativeView.page) {
                return this.nativeView.page.__SvelteNativeElement__;
            }
            return null;
        };
        let animations = new Map();
        let oldAnimations = [];
        const addAnimation = (animation) => {
            logger.debug(`Adding animation ${animation}`);
            if (!this.nativeView) {
                throw Error("Attempt to apply animation to tag without a native view" + this.tagName);
            }
            let page = getParentPage();
            if (page == null) {
                animations.set(animation, null);
                return;
            }
            //quickly cancel any old ones
            while (oldAnimations.length) {
                let oldAnimation = oldAnimations.shift();
                if (oldAnimation.isPlaying) {
                    oldAnimation.cancel();
                }
            }
            //Parse our "animation" style property into an animation info instance (this won't include the keyframes from the css)
            let animationInfos = tns_core_modules_ui_styling_css_animation_parser__WEBPACK_IMPORTED_MODULE_4__["CssAnimationParser"].keyframeAnimationsFromCSSDeclarations([{ property: "animation", value: animation }]);
            if (!animationInfos) {
                animations.set(animation, null);
                return;
            }
            let animationInfo = animationInfos[0];
            //Fetch an animationInfo instance that includes the keyframes from the css (this won't include the animation properties parsed above)
            let animationWithKeyframes = page.nativeView.getKeyframeAnimationWithName(animationInfo.name);
            if (!animationWithKeyframes) {
                animations.set(animation, null);
                return;
            }
            animationInfo.keyframes = animationWithKeyframes.keyframes;
            //combine the keyframes from the css with the animation from the parsed attribute to get a complete animationInfo object
            let animationInstance = tns_core_modules_ui_animation_keyframe_animation__WEBPACK_IMPORTED_MODULE_3__["KeyframeAnimation"].keyframeAnimationFromInfo(animationInfo);
            // save and launch the animation
            animations.set(animation, animationInstance);
            animationInstance.play(this.nativeView);
        };
        const removeAnimation = (animation) => {
            logger.debug(`Removing animation ${animation}`);
            if (animations.has(animation)) {
                let animationInstance = animations.get(animation);
                animations.delete(animation);
                if (animationInstance) {
                    if (animationInstance.isPlaying) {
                        //we don't want to stop right away since svelte removes the animation before it is finished due to our lag time starting the animation.
                        oldAnimations.push(animationInstance);
                    }
                }
            }
        };
        this.style = {
            setProperty: (propertyName, value, priority) => {
                this.setStyle(camelize(propertyName), value);
            },
            removeProperty: (propertyName) => {
                this.setStyle(camelize(propertyName), null);
            },
            get animation() {
                return [...animations.keys()].join(", ");
            },
            set animation(value) {
                logger.debug(`setting animation ${value}`);
                let new_animations = value.trim() == "" ? [] : value.split(',').map(a => a.trim());
                //add new ones
                for (let anim of new_animations) {
                    if (!animations.has(anim)) {
                        addAnimation(anim);
                    }
                }
                //remove old ones
                for (let anim of animations.keys()) {
                    if (new_animations.indexOf(anim) < 0) {
                        removeAnimation(anim);
                    }
                }
            },
            get cssText() {
                logger.debug("got css text");
                return getStyleAttribute();
            },
            set cssText(value) {
                logger.debug("set css text");
                setStyleAttribute(value);
            }
        };
    }
    /* istanbul ignore next */
    setStyle(property, value) {
        logger.debug(`setStyle ${this} ${property} ${value}`);
        if (!(value = value.toString().trim()).length) {
            return;
        }
        if (property.endsWith('Align')) {
            // NativeScript uses Alignment instead of Align, this ensures that text-align works
            property += 'ment';
        }
        this.nativeView.style[property] = value;
    }
    get nativeView() {
        return this.nativeElement;
    }
    set nativeView(view) {
        this.nativeElement = view;
    }
    /* istanbul ignore next */
    addEventListener(event, handler) {
        logger.debug(`add event listener ${this} ${event}`);
        this.nativeView.on(event, handler);
    }
    /* istanbul ignore next */
    removeEventListener(event, handler) {
        logger.debug(`remove event listener ${this} ${event}`);
        this.nativeView.off(event, handler);
    }
    onInsertedChild(childNode, index) {
        super.onInsertedChild(childNode, index);
        if (!(childNode instanceof NativeViewElementNode)) {
            return;
        }
        //if we are a property value, then skip adding to parent
        if (childNode.propAttribute)
            return;
        const parentView = this.nativeView;
        const childView = childNode.nativeView;
        if (!parentView || !childView) {
            return;
        }
        //use the builder logic if we aren't being dynamic, to catch config items like <actionbar> that are not likely to be toggled
        if (index < 0 && parentView._addChildFromBuilder) {
            parentView._addChildFromBuilder(childView.constructor.name, childView);
            return;
        }
        if (parentView instanceof tns_core_modules_ui_layouts_layout_base__WEBPACK_IMPORTED_MODULE_5__["LayoutBase"]) {
            if (index >= 0) {
                //our dom includes "textNode" and "commentNode" which does not appear in the nativeview's children. 
                //we recalculate the index required for the insert operation by only including native view element nodes in the count
                //that aren't property setter nodes
                let nativeIndex = this.childNodes.filter(e => e instanceof NativeViewElementNode && !e.propAttribute).indexOf(childNode);
                parentView.insertChild(childView, nativeIndex);
            }
            else {
                parentView.addChild(childView);
            }
            return;
        }
        // we aren't a layout view, but we were given an index, try the _addChildFromBuilder first
        if (parentView._addChildFromBuilder) {
            return parentView._addChildFromBuilder(childView.constructor.name, childView);
        }
        if (parentView instanceof tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__["ContentView"]) {
            parentView.content = childView;
            return;
        }
        throw new Error("Parent can't contain children: " + this + ", " + childNode);
    }
    onRemovedChild(childNode) {
        super.onRemovedChild(childNode);
        if (!(childNode instanceof NativeViewElementNode)) {
            return;
        }
        //childnodes with propAttributes aren't added to native views
        if (childNode.propAttribute)
            return;
        if (!this.nativeView || !childNode.nativeView) {
            return;
        }
        const parentView = this.nativeView;
        const childView = childNode.nativeView;
        if (parentView instanceof tns_core_modules_ui_layouts_layout_base__WEBPACK_IMPORTED_MODULE_5__["LayoutBase"]) {
            parentView.removeChild(childView);
        }
        else if (parentView instanceof tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__["ContentView"]) {
            if (parentView.content === childView) {
                parentView.content = null;
            }
            if (childNode.nodeType === 8) {
                parentView._removeView(childView);
            }
        }
        else if (parentView instanceof tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__["View"]) {
            parentView._removeView(childView);
        }
        else {
            logger.warn("Unknown parent view type: " + parentView);
        }
    }
    dispatchEvent(event) {
        if (this.nativeView) {
            //nativescript uses the EventName while dom uses Type
            event.eventName = event.type;
            this.nativeView.notify(event);
        }
    }
}

class PageElement extends NativeViewElementNode {
    constructor() {
        super('page', tns_core_modules_ui_page__WEBPACK_IMPORTED_MODULE_2__["Page"]);
    }
}

class FrameElement extends NativeViewElementNode {
    constructor() {
        super('frame', tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["Frame"]);
    }
    setAttribute(key, value) {
        if (key.toLowerCase() == "defaultpage") {
            logger.debug(`loading page ${value}`);
            let dummy = createElement('fragment');
            let page = new value({ target: dummy, props: {} });
            this.nativeView.navigate({ create: () => dummy.firstElement().nativeView });
            return;
        }
        super.setAttribute(key, value);
    }
    //In regular native script, Frame elements aren't meant to have children, we instead allow it to have one.. a page.. as a convenience
    // and set the instance as the default page by navigating to it.
    onInsertedChild(childNode, index) {
        //only handle page nodes
        if (!(childNode instanceof PageElement))
            return;
        this.nativeView.navigate({ create: () => childNode.nativeView, clearHistory: true });
    }
}

class SvelteKeyedTemplate {
    constructor(key, templateEl) {
        this._key = key;
        this._templateEl = templateEl;
    }
    get component() {
        return this._templateEl.component;
    }
    get key() {
        return this._key;
    }
    createView() {
        //create a proxy element to eventually contain our item (once we have one to render)
        //TODO is StackLayout the best choice here? 
        logger.debug(`creating view for key ${this.key}`);
        let wrapper = createElement('StackLayout');
        wrapper.setStyle("padding", 0);
        wrapper.setStyle("margin", 0);
        let nativeEl = wrapper.nativeView;
        nativeEl.__SvelteComponentBuilder__ = (props) => {
            let instance = new this.component({
                target: wrapper,
                props: props
            });
            nativeEl.__SvelteComponent__ = instance;
        };
        return nativeEl;
    }
}
class ListViewElement extends NativeViewElementNode {
    constructor() {
        super('listview', tns_core_modules_ui_list_view__WEBPACK_IMPORTED_MODULE_7__["ListView"]);
        this.nativeView.on(tns_core_modules_ui_list_view__WEBPACK_IMPORTED_MODULE_7__["ListView"].itemLoadingEvent, (args) => { this.updateListItem(args); });
    }
    updateListItem(args) {
        let item;
        let listView = this.nativeView;
        let items = listView.items;
        if (args.index >= items.length) {
            logger.error(`Got request for item at index that didn't exist ${args.index}`);
            return;
        }
        if (items.getItem) {
            item = items.getItem(args.index);
        }
        else {
            item = items[args.index];
        }
        if (!args.view || !args.view.__SvelteComponent__) {
            let component;
            if (args.view && args.view.__SvelteComponentBuilder__) {
                logger.debug(`instantiating component in keyed view item at ${args.index}`);
                //now we have an item, we can create and mount this component
                args.view.__SvelteComponentBuilder__({ item });
                args.view.__SvelteComponentBuilder__ = null; //free the memory
                return;
            }
            logger.debug(`creating default view for item at ${args.index}`);
            if (typeof listView.itemTemplates == "object") {
                component = listView.itemTemplates.filter(x => x.key == "default").map(x => x.component)[0];
            }
            if (!component) {
                logger.error(`Couldn't determine component to use for item at ${args.index}`);
                return;
            }
            let wrapper = createElement('ProxyViewContainer');
            let componentInstance = new component({
                target: wrapper,
                props: {
                    item
                }
            });
            let nativeEl = wrapper.nativeView;
            nativeEl.__SvelteComponent__ = componentInstance;
            args.view = nativeEl;
        }
        else {
            let componentInstance = args.view.__SvelteComponent__;
            logger.debug(`updating view for ${args.index} which is a ${args.view}`);
            componentInstance.$set({ item });
        }
    }
    onInsertedChild(childNode, index) {
        super.onInsertedChild(childNode, index);
        if (childNode instanceof TemplateElement) {
            let key = childNode.getAttribute('key') || "default";
            logger.debug(`Adding template for key ${key}`);
            if (!this.nativeView.itemTemplates || typeof this.nativeView.itemTemplates == "string") {
                this.nativeView.itemTemplates = [];
            }
            this.nativeView.itemTemplates.push(new SvelteKeyedTemplate(key, childNode));
        }
    }
    onRemovedChild(childNode) {
        super.onRemovedChild(childNode);
        if (childNode instanceof TemplateElement) {
            let key = childNode.getAttribute('key') || "default";
            if (this.nativeView.itemTemplates && typeof this.nativeView.itemTemplates != "string") {
                this.nativeView.itemTemplates = this.nativeView.itemTemplates.filter(t => t.key != key);
            }
        }
    }
}

class TabViewElement extends NativeViewElementNode {
    constructor() {
        super('TabView', tns_core_modules_ui_tab_view__WEBPACK_IMPORTED_MODULE_8__["TabView"]);
        this.needs_update = false;
    }
    doUpdate() {
        let items = this.childNodes.filter(x => x instanceof NativeViewElementNode && x.nativeView instanceof tns_core_modules_ui_tab_view__WEBPACK_IMPORTED_MODULE_8__["TabViewItem"]).map(x => x.nativeView);
        logger.debug(`updating tab items. now has ${items.length} items`);
        this.nativeView.items = items;
    }
    onInsertedChild(childNode, index) {
        try {
            //We only want to handle TabViewItem and only if it is the last item!
            if (!(childNode instanceof NativeViewElementNode && childNode.nativeView instanceof tns_core_modules_ui_tab_view__WEBPACK_IMPORTED_MODULE_8__["TabViewItem"]))
                return super.onInsertedChild(childNode, index);
            this.needs_update = true;
            //resolve after this event loop to catch all added tabviewitems in one update, and to handle the fact that svelte adds the
            //tabviewitem to tabview while it is still empty which causes problems.
            Promise.resolve().then(() => {
                if (this.needs_update) {
                    this.doUpdate();
                    this.needs_update = false;
                }
            }).catch(e => console.error(e));
        }
        catch (e) {
            console.error(e);
        }
    }
    onRemovedChild(childNode) {
        if (!(childNode instanceof NativeViewElementNode && childNode.nativeView instanceof tns_core_modules_ui_tab_view__WEBPACK_IMPORTED_MODULE_8__["TabViewItem"]))
            return super.onRemovedChild(childNode);
        console.error("Removing a TabViewItem is not supported atm see:  https://github.com/NativeScript/nativescript-angular/issues/621");
    }
}

class BaseTabNavigationElement extends NativeViewElementNode {
    constructor(tagName, viewClass) {
        super(tagName, viewClass);
        this.pendingInserts = [];
    }
    onInsertedChild(childNode, index) {
        try {
            if (childNode instanceof NativeViewElementNode && childNode.nativeView instanceof tns_core_modules_ui_tab_navigation_base_tab_content_item__WEBPACK_IMPORTED_MODULE_9__["TabContentItem"]) {
                logger.debug(`adding tab content to nav`);
                this.pendingInserts.push(childNode.nativeView);
                //wait for next turn so that any content for our tab is attached to the dom
                Promise.resolve().then(() => {
                    if (this.pendingInserts.length == 0)
                        return;
                    let items = (this.nativeView.items || []).concat(this.pendingInserts);
                    this.pendingInserts = [];
                    this.nativeView.items = [];
                    this.nativeView.items = items;
                });
                return;
            }
        }
        catch (e) {
            console.error(e);
        }
        super.onInsertedChild(childNode, index);
    }
    onRemovedChild(childNode) {
        try {
            if (childNode instanceof NativeViewElementNode && childNode.nativeView instanceof tns_core_modules_ui_tab_navigation_base_tab_content_item__WEBPACK_IMPORTED_MODULE_9__["TabContentItem"]) {
                logger.debug(`removing content item from nav`);
                let items = (this.nativeView.items || []).filter(i => i != childNode.nativeView);
                this.nativeView.items = [];
                this.nativeView.items = items;
                return;
            }
        }
        catch (e) {
            console.error(e);
        }
        super.onRemovedChild(childNode);
    }
}

class BottomNavigationElement extends BaseTabNavigationElement {
    constructor() {
        super("BottomNavigation", tns_core_modules_ui_bottom_navigation__WEBPACK_IMPORTED_MODULE_10__["BottomNavigation"]);
    }
}

class TabsElement extends BaseTabNavigationElement {
    constructor() {
        super("Tabs", tns_core_modules_ui_tabs__WEBPACK_IMPORTED_MODULE_11__["Tabs"]);
    }
}

class ActionBarElement extends NativeViewElementNode {
    constructor() {
        super('ActionBar', tns_core_modules_ui_action_bar__WEBPACK_IMPORTED_MODULE_12__["ActionBar"]);
    }
    onInsertedChild(childNode, index) {
        //ActionItems isn't an array or ObservableArray, it is a special ActionItems type, so we handle it here
        if (childNode instanceof NativeElementNode) {
            let propName = childNode.propAttribute;
            if (propName) {
                propName = this._normalizedKeys.get(propName) || propName;
                if (propName.toLowerCase() == "actionitems") {
                    this.nativeView.actionItems.addItem(childNode.nativeElement);
                    return; //skip rest of the processing.
                }
            }
        }
        super.onInsertedChild(childNode, index);
    }
    onRemovedChild(childNode) {
        if (childNode instanceof NativeElementNode) {
            let propName = childNode.propAttribute;
            if (propName) {
                propName = this._normalizedKeys.get(propName) || propName;
                if (propName.toLowerCase() == "actionitems") {
                    this.nativeView.actionItems.removeItem(childNode.nativeElement);
                    return; //skip rest of the processing.
                }
            }
        }
        super.onRemovedChild(childNode);
    }
}

class TabStripElement extends NativeViewElementNode {
    constructor() {
        super("TabStrip", tns_core_modules_ui_tab_navigation_base_tab_strip__WEBPACK_IMPORTED_MODULE_13__["TabStrip"], null);
    }
    onInsertedChild(childNode, index) {
        // As of tns-core-modules 6.1.2 setting a new array here doesn't set the parent property of any new tabstripitems
        // and causes a crash. a workaround suggested https://github.com/NativeScript/NativeScript/issues/7608
        // is to set items to [] before setting it to the new array.
        try {
            if (childNode instanceof NativeViewElementNode && childNode.nativeView instanceof tns_core_modules_ui_tab_navigation_base_tab_strip_item__WEBPACK_IMPORTED_MODULE_14__["TabStripItem"]) {
                logger.debug(`adding tab strip item ${childNode.nativeView.title}`);
                const items = this.nativeView.items || [];
                this.nativeView.items = [];
                this.nativeView.items = items.concat([childNode.nativeView]);
                return;
            }
        }
        catch (e) {
            console.error(e);
        }
        super.onInsertedChild(childNode, index);
    }
    onRemovedChild(childNode) {
        try {
            if (childNode instanceof NativeViewElementNode && childNode.nativeView instanceof tns_core_modules_ui_tab_navigation_base_tab_strip_item__WEBPACK_IMPORTED_MODULE_14__["TabStripItem"]) {
                logger.debug(`removing tab strip item ${childNode.nativeView.title}`);
                let items = (this.nativeView.items || []).filter(i => i != childNode.nativeView);
                this.nativeView.items = [];
                this.nativeView.items = items;
            }
        }
        catch (e) {
            console.error(e);
        }
        super.onRemovedChild(childNode);
    }
}

function registerNativeElements() {
    registerNativeViewElement('ActionItem', () => __webpack_require__("tns-core-modules/ui/action-bar").ActionItem, 'actionItems');
    registerNativeViewElement('NavigationButton', () => __webpack_require__("tns-core-modules/ui/action-bar").NavigationButton, 'navigationButton');
    registerNativeViewElement('TabViewItem', () => __webpack_require__("tns-core-modules/ui/tab-view").TabViewItem);
    // NS components which uses the automatic registerElement Vue wrapper
    // as they do not need any special logic
    registerNativeViewElement('Label', () => __webpack_require__("tns-core-modules/ui/label").Label);
    registerNativeViewElement('DatePicker', () => __webpack_require__("tns-core-modules/ui/date-picker").DatePicker);
    registerNativeViewElement('AbsoluteLayout', () => __webpack_require__("tns-core-modules/ui/layouts/absolute-layout").AbsoluteLayout);
    registerNativeViewElement('ActivityIndicator', () => __webpack_require__("tns-core-modules/ui/activity-indicator").ActivityIndicator);
    registerNativeViewElement('Border', () => __webpack_require__("tns-core-modules/ui/border").Border);
    registerNativeViewElement('Button', () => __webpack_require__("tns-core-modules/ui/button").Button);
    registerNativeViewElement('ContentView', () => __webpack_require__("tns-core-modules/ui/content-view").ContentView);
    registerNativeViewElement('DockLayout', () => __webpack_require__("tns-core-modules/ui/layouts/dock-layout").DockLayout);
    registerNativeViewElement('GridLayout', () => __webpack_require__("tns-core-modules/ui/layouts/grid-layout").GridLayout);
    registerNativeViewElement('HtmlView', () => __webpack_require__("tns-core-modules/ui/html-view").HtmlView);
    registerNativeViewElement('Image', () => __webpack_require__("tns-core-modules/ui/image").Image);
    registerNativeViewElement('ListPicker', () => __webpack_require__("tns-core-modules/ui/list-picker").ListPicker);
    registerNativeViewElement('Placeholder', () => __webpack_require__("tns-core-modules/ui/placeholder").Placeholder);
    registerNativeViewElement('Progress', () => __webpack_require__("tns-core-modules/ui/progress").Progress);
    registerNativeViewElement('ProxyViewContainer', () => __webpack_require__("tns-core-modules/ui/proxy-view-container").ProxyViewContainer);
    // registerElement(
    //   'Repeater',
    //   () => require('tns-core-modules/ui/repeater').Repeater
    // )
    registerNativeViewElement('ScrollView', () => __webpack_require__("tns-core-modules/ui/scroll-view").ScrollView);
    registerNativeViewElement('SearchBar', () => __webpack_require__("tns-core-modules/ui/search-bar").SearchBar);
    registerNativeViewElement('SegmentedBar', () => __webpack_require__("tns-core-modules/ui/segmented-bar").SegmentedBar, null, { "items": NativeElementPropType.Array });
    registerNativeViewElement('SegmentedBarItem', () => __webpack_require__("tns-core-modules/ui/segmented-bar").SegmentedBarItem, "items");
    registerNativeViewElement('Slider', () => __webpack_require__("tns-core-modules/ui/slider").Slider);
    registerNativeViewElement('StackLayout', () => __webpack_require__("tns-core-modules/ui/layouts/stack-layout").StackLayout);
    registerNativeViewElement('FlexboxLayout', () => __webpack_require__("tns-core-modules/ui/layouts/flexbox-layout").FlexboxLayout);
    registerNativeViewElement('Switch', () => __webpack_require__("tns-core-modules/ui/switch").Switch);
    registerNativeViewElement('TextField', () => __webpack_require__("tns-core-modules/ui/text-field").TextField);
    registerNativeViewElement('TextView', () => __webpack_require__("tns-core-modules/ui/text-view").TextView);
    registerNativeViewElement('TimePicker', () => __webpack_require__("tns-core-modules/ui/time-picker").TimePicker);
    registerNativeViewElement('WebView', () => __webpack_require__("tns-core-modules/ui/web-view").WebView);
    registerNativeViewElement('WrapLayout', () => __webpack_require__("tns-core-modules/ui/layouts/wrap-layout").WrapLayout);
    registerNativeViewElement('FormattedString', () => __webpack_require__("tns-core-modules/text/formatted-string").FormattedString);
    registerNativeViewElement('Span', () => __webpack_require__("tns-core-modules/text/span").Span);
    registerElement('ActionBar', () => new ActionBarElement());
    registerElement('Frame', () => new FrameElement());
    registerElement('Page', () => new PageElement());
    registerElement('ListView', () => new ListViewElement());
    registerElement('TabView', () => new TabViewElement());
    registerElement('BottomNavigation', () => new BottomNavigationElement());
    registerElement('Tabs', () => new TabsElement());
    registerElement('TabStrip', () => new TabStripElement());
    registerNativeViewElement('TabStripItem', () => __webpack_require__("tns-core-modules/ui/tab-navigation-base/tab-strip-item").TabStripItem);
    registerNativeViewElement('TabContentItem', () => __webpack_require__("tns-core-modules/ui/tab-navigation-base/tab-content-item").TabContentItem);
}

class SvelteNativeDocument extends DocumentNode {
    constructor() {
        super();
        this.head = createElement('head');
        this.appendChild(this.head);
        logger.debug(`created ${this}`);
    }
    createTextNode(text) {
        const el = new TextNode(text);
        logger.debug(`created ${el}`);
        return el;
    }
    createElementNS(namespace, tagName) {
        return this.createElement(tagName);
    }
    createEvent(type) {
        let e = {};
        e.initCustomEvent = (type, ignored1, ignored2, detail) => {
            e.type = type;
            e.detail = detail;
            e.eventName = type;
        };
        return e;
    }
}

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function resolveFrame(frameSpec) {
    let targetFrame;
    if (!frameSpec)
        targetFrame = Object(tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["topmost"])();
    if (frameSpec instanceof FrameElement)
        targetFrame = frameSpec.nativeView;
    if (frameSpec instanceof tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["Frame"])
        targetFrame = frameSpec;
    if (typeof frameSpec == "string") {
        targetFrame = tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["Frame"].getFrameById(frameSpec);
        if (!targetFrame)
            logger.error(`Navigate could not find frame with id ${frameSpec}`);
    }
    return targetFrame;
}
function resolveComponentElement(pageSpec, props) {
    let dummy = createElement('fragment');
    let pageInstance = new pageSpec({ target: dummy, props: props });
    let element = dummy.firstElement();
    return { element, pageInstance };
}
function navigate(options) {
    let { frame, page, props = {} } = options, navOptions = __rest(options, ["frame", "page", "props"]);
    let targetFrame = resolveFrame(frame);
    if (!targetFrame) {
        throw new Error("navigate requires frame option to be a native Frame, a FrameElement, a frame Id, or null");
    }
    if (!page) {
        throw new Error("navigate requires page to be set to the svelte component class that implements the page or reference to a page element");
    }
    let { element, pageInstance } = resolveComponentElement(page, props);
    if (!(element instanceof PageElement))
        throw new Error("navigate requires a svelte component with a page element at the root");
    let nativePage = element.nativeView;
    const handler = (args) => {
        if (args.isBackNavigation) {
            nativePage.off('navigatedFrom', handler);
            pageInstance.$destroy();
        }
    };
    nativePage.on('navigatedFrom', handler);
    targetFrame.navigate(Object.assign(Object.assign({}, navOptions), { create: () => nativePage }));
    return pageInstance;
}
function goBack(options = {}) {
    let targetFrame = resolveFrame(options.frame);
    if (!targetFrame) {
        throw new Error("goback requires frame option to be a native Frame, a FrameElement, a frame Id, or null");
    }
    let backStackEntry = null;
    if (options.to) {
        backStackEntry = targetFrame.backStack.find(e => e.resolvedPage === options.to.nativeView);
        if (!backStackEntry) {
            throw new Error("Couldn't find the destination page in the frames backstack");
        }
    }
    return targetFrame.goBack(backStackEntry);
}
const modalStack = [];
function showModal(modalOptions) {
    let { page, props = {} } = modalOptions, options = __rest(modalOptions, ["page", "props"]);
    //Get this before any potential new frames are created by component below
    let modalLauncher = Object(tns_core_modules_ui_frame__WEBPACK_IMPORTED_MODULE_0__["topmost"])().currentPage;
    let componentInstanceInfo = resolveComponentElement(page, props);
    let modalView = componentInstanceInfo.element.nativeView;
    return new Promise((resolve, reject) => {
        let resolved = false;
        const closeCallback = (result) => {
            if (resolved)
                return;
            resolved = true;
            try {
                componentInstanceInfo.pageInstance.$destroy(); //don't let an exception in destroy kill the promise callback
            }
            finally {
                resolve(result);
            }
        };
        modalStack.push(componentInstanceInfo);
        modalLauncher.showModal(modalView, Object.assign(Object.assign({}, options), { context: {}, closeCallback }));
    });
}
function closeModal(result) {
    let modalPageInstanceInfo = modalStack.pop();
    modalPageInstanceInfo.element.nativeView.closeModal(result);
}

function installGlobalShims() {
    //expose our fake dom as global document for svelte components
    let window = global;
    window.window = global;
    window.document = new SvelteNativeDocument();
    if (!window.requestAnimationFrame) {
        window.requestAnimationFrame = (action) => {
            setTimeout(() => action(window.performance.now()), 33); //about 30 fps
        };
    }
    window.getComputedStyle = (node) => {
        return node.nativeView.style;
    };
    window.performance = {
        now() {
            return Date.now();
        }
    };
    window.CustomEvent = class {
        constructor(name, detail = null) {
            this.eventName = name; //event name for nativescript
            this.type = name; // type for svelte
            this.detail = detail;
        }
    };
    return window.document;
}
const DomTraceCategory = 'SvelteNativeDom';
function initializeLogger() {
    logger.setHandler((message, level) => {
        let traceLevel = tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__["messageType"].log;
        switch (level) {
            case LogLevel.Debug:
                traceLevel = tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__["messageType"].log;
                break;
            case LogLevel.Info:
                traceLevel = tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__["messageType"].info;
                break;
            case LogLevel.Warn:
                traceLevel = tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__["messageType"].warn;
                break;
            case LogLevel.Error:
                traceLevel = tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__["messageType"].error;
                break;
        }
        Object(tns_core_modules_trace__WEBPACK_IMPORTED_MODULE_15__["write"])(message, DomTraceCategory, traceLevel);
    });
}
function initializeDom() {
    initializeLogger();
    registerSvelteElements();
    registerNativeElements();
    return installGlobalShims();
}



/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../node_modules/svelte-native/index.js":
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(global) {

Object.defineProperty(exports, '__esModule', { value: true });

var application = __webpack_require__("tns-core-modules/application");
var dom = __webpack_require__("../node_modules/svelte-native/dom/index.mjs");

function svelteNativeNoFrame(rootElement, data) {
    dom.initializeDom();
    return new Promise((resolve, reject) => {
        let elementInstance;
        const buildElement = () => {
            let frag = dom.createElement('fragment');
            elementInstance = new rootElement({
                target: frag,
                props: data || {}
            });
            return frag.firstChild.nativeElement;
        };
        //wait for launch before returning
        application.on(application.launchEvent, () => {
            console.log("Application Launched");
            resolve(elementInstance);
        });
        try {
            application.run({ create: buildElement });
        }
        catch (e) {
            reject(e);
        }
    });
}
function svelteNative(startPage, data) {
    dom.initializeDom();
    let rootFrame;
    let pageInstance;
    return new Promise((resolve, reject) => {
        //wait for launch
        application.on(application.launchEvent, () => {
            console.log("Application Launched");
            resolve(pageInstance);
        });
        try {
            application.run({ create: () => {
                    rootFrame = dom.createElement('frame');
                    rootFrame.setAttribute("id", "app-root-frame");
                    pageInstance = dom.navigate({
                        page: startPage,
                        props: data || {},
                        frame: rootFrame
                    });
                    return rootFrame.nativeView;
                } });
        }
        catch (e) {
            reject(e);
        }
    });
}
// Svelte looks to see if window is undefined in order to determine if it is running on the client or in SSR.
// window is undefined until initializeDom is called. We will set it to a temporary value here and overwrite it in intializedom.
global.window = { env: "Svelte Native" };

Object.defineProperty(exports, 'DomTraceCategory', {
    enumerable: true,
    get: function () {
        return dom.DomTraceCategory;
    }
});
Object.defineProperty(exports, 'closeModal', {
    enumerable: true,
    get: function () {
        return dom.closeModal;
    }
});
Object.defineProperty(exports, 'goBack', {
    enumerable: true,
    get: function () {
        return dom.goBack;
    }
});
Object.defineProperty(exports, 'initializeDom', {
    enumerable: true,
    get: function () {
        return dom.initializeDom;
    }
});
Object.defineProperty(exports, 'navigate', {
    enumerable: true,
    get: function () {
        return dom.navigate;
    }
});
Object.defineProperty(exports, 'showModal', {
    enumerable: true,
    get: function () {
        return dom.showModal;
    }
});
exports.svelteNative = svelteNative;
exports.svelteNativeNoFrame = svelteNativeNoFrame;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../node_modules/svelte/internal/index.mjs":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HtmlTag", function() { return HtmlTag; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SvelteComponent", function() { return SvelteComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SvelteComponentDev", function() { return SvelteComponentDev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SvelteElement", function() { return SvelteElement; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add_attribute", function() { return add_attribute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add_classes", function() { return add_classes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add_flush_callback", function() { return add_flush_callback; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add_location", function() { return add_location; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add_render_callback", function() { return add_render_callback; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add_resize_listener", function() { return add_resize_listener; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "add_transform", function() { return add_transform; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "afterUpdate", function() { return afterUpdate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "append", function() { return append; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "append_dev", function() { return append_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "assign", function() { return assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attr", function() { return attr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "attr_dev", function() { return attr_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "beforeUpdate", function() { return beforeUpdate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bind", function() { return bind; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "binding_callbacks", function() { return binding_callbacks; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "blank_object", function() { return blank_object; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bubble", function() { return bubble; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "check_outros", function() { return check_outros; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "children", function() { return children; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "claim_component", function() { return claim_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "claim_element", function() { return claim_element; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "claim_space", function() { return claim_space; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "claim_text", function() { return claim_text; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clear_loops", function() { return clear_loops; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "component_subscribe", function() { return component_subscribe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createEventDispatcher", function() { return createEventDispatcher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "create_animation", function() { return create_animation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "create_bidirectional_transition", function() { return create_bidirectional_transition; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "create_component", function() { return create_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "create_in_transition", function() { return create_in_transition; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "create_out_transition", function() { return create_out_transition; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "create_slot", function() { return create_slot; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "create_ssr_component", function() { return create_ssr_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "current_component", function() { return current_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "custom_event", function() { return custom_event; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dataset_dev", function() { return dataset_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "debug", function() { return debug; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "destroy_block", function() { return destroy_block; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "destroy_component", function() { return destroy_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "destroy_each", function() { return destroy_each; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detach", function() { return detach; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detach_after_dev", function() { return detach_after_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detach_before_dev", function() { return detach_before_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detach_between_dev", function() { return detach_between_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detach_dev", function() { return detach_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dirty_components", function() { return dirty_components; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dispatch_dev", function() { return dispatch_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "each", function() { return each; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "element", function() { return element; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "element_is", function() { return element_is; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "empty", function() { return empty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "escape", function() { return escape; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "escaped", function() { return escaped; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exclude_internal_props", function() { return exclude_internal_props; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fix_and_destroy_block", function() { return fix_and_destroy_block; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fix_and_outro_and_destroy_block", function() { return fix_and_outro_and_destroy_block; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fix_position", function() { return fix_position; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "flush", function() { return flush; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getContext", function() { return getContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "get_binding_group_value", function() { return get_binding_group_value; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "get_current_component", function() { return get_current_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "get_slot_changes", function() { return get_slot_changes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "get_slot_context", function() { return get_slot_context; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "get_spread_object", function() { return get_spread_object; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "get_spread_update", function() { return get_spread_update; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "get_store_value", function() { return get_store_value; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "globals", function() { return globals; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "group_outros", function() { return group_outros; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handle_promise", function() { return handle_promise; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "has_prop", function() { return has_prop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "identity", function() { return identity; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "init", function() { return init; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insert", function() { return insert; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insert_dev", function() { return insert_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "intros", function() { return intros; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "invalid_attribute_name_character", function() { return invalid_attribute_name_character; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "is_client", function() { return is_client; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "is_function", function() { return is_function; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "is_promise", function() { return is_promise; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "listen", function() { return listen; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "listen_dev", function() { return listen_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loop", function() { return loop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loop_guard", function() { return loop_guard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "measure", function() { return measure; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "missing_component", function() { return missing_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mount_component", function() { return mount_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noop", function() { return noop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "not_equal", function() { return not_equal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "now", function() { return now; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "null_to_empty", function() { return null_to_empty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "object_without_properties", function() { return object_without_properties; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onDestroy", function() { return onDestroy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onMount", function() { return onMount; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "once", function() { return once; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "outro_and_destroy_block", function() { return outro_and_destroy_block; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "prevent_default", function() { return prevent_default; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "prop_dev", function() { return prop_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "raf", function() { return raf; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "run", function() { return run; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "run_all", function() { return run_all; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "safe_not_equal", function() { return safe_not_equal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "schedule_update", function() { return schedule_update; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "select_multiple_value", function() { return select_multiple_value; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "select_option", function() { return select_option; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "select_options", function() { return select_options; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "select_value", function() { return select_value; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "self", function() { return self; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setContext", function() { return setContext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_attributes", function() { return set_attributes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_current_component", function() { return set_current_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_custom_element_data", function() { return set_custom_element_data; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_data", function() { return set_data; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_data_dev", function() { return set_data_dev; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_input_type", function() { return set_input_type; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_input_value", function() { return set_input_value; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_now", function() { return set_now; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_raf", function() { return set_raf; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_store_value", function() { return set_store_value; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_style", function() { return set_style; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "set_svg_attributes", function() { return set_svg_attributes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "space", function() { return space; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spread", function() { return spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stop_propagation", function() { return stop_propagation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "subscribe", function() { return subscribe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "svg_element", function() { return svg_element; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "text", function() { return text; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tick", function() { return tick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "time_ranges_to_array", function() { return time_ranges_to_array; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "to_number", function() { return to_number; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggle_class", function() { return toggle_class; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transition_in", function() { return transition_in; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "transition_out", function() { return transition_out; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "update_keyed_each", function() { return update_keyed_each; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validate_component", function() { return validate_component; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validate_store", function() { return validate_store; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "xlink_attr", function() { return xlink_attr; });
function noop() { }
const identity = x => x;
function assign(tar, src) {
    // @ts-ignore
    for (const k in src)
        tar[k] = src[k];
    return tar;
}
function is_promise(value) {
    return value && typeof value === 'object' && typeof value.then === 'function';
}
function add_location(element, file, line, column, char) {
    element.__svelte_meta = {
        loc: { file, line, column, char }
    };
}
function run(fn) {
    return fn();
}
function blank_object() {
    return Object.create(null);
}
function run_all(fns) {
    fns.forEach(run);
}
function is_function(thing) {
    return typeof thing === 'function';
}
function safe_not_equal(a, b) {
    return a != a ? b == b : a !== b || ((a && typeof a === 'object') || typeof a === 'function');
}
function not_equal(a, b) {
    return a != a ? b == b : a !== b;
}
function validate_store(store, name) {
    if (!store || typeof store.subscribe !== 'function') {
        throw new Error(`'${name}' is not a store with a 'subscribe' method`);
    }
}
function subscribe(store, callback) {
    const unsub = store.subscribe(callback);
    return unsub.unsubscribe ? () => unsub.unsubscribe() : unsub;
}
function get_store_value(store) {
    let value;
    subscribe(store, _ => value = _)();
    return value;
}
function component_subscribe(component, store, callback) {
    component.$$.on_destroy.push(subscribe(store, callback));
}
function create_slot(definition, ctx, $$scope, fn) {
    if (definition) {
        const slot_ctx = get_slot_context(definition, ctx, $$scope, fn);
        return definition[0](slot_ctx);
    }
}
function get_slot_context(definition, ctx, $$scope, fn) {
    return definition[1] && fn
        ? assign($$scope.ctx.slice(), definition[1](fn(ctx)))
        : $$scope.ctx;
}
function get_slot_changes(definition, $$scope, dirty, fn) {
    if (definition[2] && fn) {
        const lets = definition[2](fn(dirty));
        if ($$scope.dirty) {
            const merged = [];
            const len = Math.max($$scope.dirty.length, lets.length);
            for (let i = 0; i < len; i += 1) {
                merged[i] = $$scope.dirty[i] | lets[i];
            }
            return merged;
        }
        return lets;
    }
    return $$scope.dirty;
}
function exclude_internal_props(props) {
    const result = {};
    for (const k in props)
        if (k[0] !== '$')
            result[k] = props[k];
    return result;
}
function once(fn) {
    let ran = false;
    return function (...args) {
        if (ran)
            return;
        ran = true;
        fn.call(this, ...args);
    };
}
function null_to_empty(value) {
    return value == null ? '' : value;
}
function set_store_value(store, ret, value = ret) {
    store.set(value);
    return ret;
}
const has_prop = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop);

const is_client = typeof window !== 'undefined';
let now = is_client
    ? () => window.performance.now()
    : () => Date.now();
let raf = is_client ? cb => requestAnimationFrame(cb) : noop;
// used internally for testing
function set_now(fn) {
    now = fn;
}
function set_raf(fn) {
    raf = fn;
}

const tasks = new Set();
function run_tasks(now) {
    tasks.forEach(task => {
        if (!task.c(now)) {
            tasks.delete(task);
            task.f();
        }
    });
    if (tasks.size !== 0)
        raf(run_tasks);
}
/**
 * For testing purposes only!
 */
function clear_loops() {
    tasks.clear();
}
/**
 * Creates a new task that runs on each raf frame
 * until it returns a falsy value or is aborted
 */
function loop(callback) {
    let task;
    if (tasks.size === 0)
        raf(run_tasks);
    return {
        promise: new Promise(fulfill => {
            tasks.add(task = { c: callback, f: fulfill });
        }),
        abort() {
            tasks.delete(task);
        }
    };
}

function append(target, node) {
    target.appendChild(node);
}
function insert(target, node, anchor) {
    target.insertBefore(node, anchor || null);
}
function detach(node) {
    node.parentNode.removeChild(node);
}
function destroy_each(iterations, detaching) {
    for (let i = 0; i < iterations.length; i += 1) {
        if (iterations[i])
            iterations[i].d(detaching);
    }
}
function element(name) {
    return document.createElement(name);
}
function element_is(name, is) {
    return document.createElement(name, { is });
}
function object_without_properties(obj, exclude) {
    const target = {};
    for (const k in obj) {
        if (has_prop(obj, k)
            // @ts-ignore
            && exclude.indexOf(k) === -1) {
            // @ts-ignore
            target[k] = obj[k];
        }
    }
    return target;
}
function svg_element(name) {
    return document.createElementNS('http://www.w3.org/2000/svg', name);
}
function text(data) {
    return document.createTextNode(data);
}
function space() {
    return text(' ');
}
function empty() {
    return text('');
}
function listen(node, event, handler, options) {
    node.addEventListener(event, handler, options);
    return () => node.removeEventListener(event, handler, options);
}
function prevent_default(fn) {
    return function (event) {
        event.preventDefault();
        // @ts-ignore
        return fn.call(this, event);
    };
}
function stop_propagation(fn) {
    return function (event) {
        event.stopPropagation();
        // @ts-ignore
        return fn.call(this, event);
    };
}
function self(fn) {
    return function (event) {
        // @ts-ignore
        if (event.target === this)
            fn.call(this, event);
    };
}
function attr(node, attribute, value) {
    if (value == null)
        node.removeAttribute(attribute);
    else if (node.getAttribute(attribute) !== value)
        node.setAttribute(attribute, value);
}
function set_attributes(node, attributes) {
    // @ts-ignore
    const descriptors = Object.getOwnPropertyDescriptors(node.__proto__);
    for (const key in attributes) {
        if (attributes[key] == null) {
            node.removeAttribute(key);
        }
        else if (key === 'style') {
            node.style.cssText = attributes[key];
        }
        else if (descriptors[key] && descriptors[key].set) {
            node[key] = attributes[key];
        }
        else {
            attr(node, key, attributes[key]);
        }
    }
}
function set_svg_attributes(node, attributes) {
    for (const key in attributes) {
        attr(node, key, attributes[key]);
    }
}
function set_custom_element_data(node, prop, value) {
    if (prop in node) {
        node[prop] = value;
    }
    else {
        attr(node, prop, value);
    }
}
function xlink_attr(node, attribute, value) {
    node.setAttributeNS('http://www.w3.org/1999/xlink', attribute, value);
}
function get_binding_group_value(group) {
    const value = [];
    for (let i = 0; i < group.length; i += 1) {
        if (group[i].checked)
            value.push(group[i].__value);
    }
    return value;
}
function to_number(value) {
    return value === '' ? undefined : +value;
}
function time_ranges_to_array(ranges) {
    const array = [];
    for (let i = 0; i < ranges.length; i += 1) {
        array.push({ start: ranges.start(i), end: ranges.end(i) });
    }
    return array;
}
function children(element) {
    return Array.from(element.childNodes);
}
function claim_element(nodes, name, attributes, svg) {
    for (let i = 0; i < nodes.length; i += 1) {
        const node = nodes[i];
        if (node.nodeName === name) {
            for (let j = 0; j < node.attributes.length; j += 1) {
                const attribute = node.attributes[j];
                if (!attributes[attribute.name])
                    node.removeAttribute(attribute.name);
            }
            return nodes.splice(i, 1)[0]; // TODO strip unwanted attributes
        }
    }
    return svg ? svg_element(name) : element(name);
}
function claim_text(nodes, data) {
    for (let i = 0; i < nodes.length; i += 1) {
        const node = nodes[i];
        if (node.nodeType === 3) {
            node.data = '' + data;
            return nodes.splice(i, 1)[0];
        }
    }
    return text(data);
}
function claim_space(nodes) {
    return claim_text(nodes, ' ');
}
function set_data(text, data) {
    data = '' + data;
    if (text.data !== data)
        text.data = data;
}
function set_input_value(input, value) {
    if (value != null || input.value) {
        input.value = value;
    }
}
function set_input_type(input, type) {
    try {
        input.type = type;
    }
    catch (e) {
        // do nothing
    }
}
function set_style(node, key, value, important) {
    node.style.setProperty(key, value, important ? 'important' : '');
}
function select_option(select, value) {
    for (let i = 0; i < select.options.length; i += 1) {
        const option = select.options[i];
        if (option.__value === value) {
            option.selected = true;
            return;
        }
    }
}
function select_options(select, value) {
    for (let i = 0; i < select.options.length; i += 1) {
        const option = select.options[i];
        option.selected = ~value.indexOf(option.__value);
    }
}
function select_value(select) {
    const selected_option = select.querySelector(':checked') || select.options[0];
    return selected_option && selected_option.__value;
}
function select_multiple_value(select) {
    return [].map.call(select.querySelectorAll(':checked'), option => option.__value);
}
function add_resize_listener(element, fn) {
    if (getComputedStyle(element).position === 'static') {
        element.style.position = 'relative';
    }
    const object = document.createElement('object');
    object.setAttribute('style', 'display: block; position: absolute; top: 0; left: 0; height: 100%; width: 100%; overflow: hidden; pointer-events: none; z-index: -1;');
    object.setAttribute('aria-hidden', 'true');
    object.type = 'text/html';
    object.tabIndex = -1;
    let win;
    object.onload = () => {
        win = object.contentDocument.defaultView;
        win.addEventListener('resize', fn);
    };
    if (/Trident/.test(navigator.userAgent)) {
        element.appendChild(object);
        object.data = 'about:blank';
    }
    else {
        object.data = 'about:blank';
        element.appendChild(object);
    }
    return {
        cancel: () => {
            win && win.removeEventListener && win.removeEventListener('resize', fn);
            element.removeChild(object);
        }
    };
}
function toggle_class(element, name, toggle) {
    element.classList[toggle ? 'add' : 'remove'](name);
}
function custom_event(type, detail) {
    const e = document.createEvent('CustomEvent');
    e.initCustomEvent(type, false, false, detail);
    return e;
}
class HtmlTag {
    constructor(html, anchor = null) {
        this.e = element('div');
        this.a = anchor;
        this.u(html);
    }
    m(target, anchor = null) {
        for (let i = 0; i < this.n.length; i += 1) {
            insert(target, this.n[i], anchor);
        }
        this.t = target;
    }
    u(html) {
        this.e.innerHTML = html;
        this.n = Array.from(this.e.childNodes);
    }
    p(html) {
        this.d();
        this.u(html);
        this.m(this.t, this.a);
    }
    d() {
        this.n.forEach(detach);
    }
}

let stylesheet;
let active = 0;
let current_rules = {};
// https://github.com/darkskyapp/string-hash/blob/master/index.js
function hash(str) {
    let hash = 5381;
    let i = str.length;
    while (i--)
        hash = ((hash << 5) - hash) ^ str.charCodeAt(i);
    return hash >>> 0;
}
function create_rule(node, a, b, duration, delay, ease, fn, uid = 0) {
    const step = 16.666 / duration;
    let keyframes = '{\n';
    for (let p = 0; p <= 1; p += step) {
        const t = a + (b - a) * ease(p);
        keyframes += p * 100 + `%{${fn(t, 1 - t)}}\n`;
    }
    const rule = keyframes + `100% {${fn(b, 1 - b)}}\n}`;
    const name = `__svelte_${hash(rule)}_${uid}`;
    if (!current_rules[name]) {
        if (!stylesheet) {
            const style = element('style');
            document.head.appendChild(style);
            stylesheet = style.sheet;
        }
        current_rules[name] = true;
        stylesheet.insertRule(`@keyframes ${name} ${rule}`, stylesheet.cssRules.length);
    }
    const animation = node.style.animation || '';
    node.style.animation = `${animation ? `${animation}, ` : ``}${name} ${duration}ms linear ${delay}ms 1 both`;
    active += 1;
    return name;
}
function delete_rule(node, name) {
    node.style.animation = (node.style.animation || '')
        .split(', ')
        .filter(name
        ? anim => anim.indexOf(name) < 0 // remove specific animation
        : anim => anim.indexOf('__svelte') === -1 // remove all Svelte animations
    )
        .join(', ');
    if (name && !--active)
        clear_rules();
}
function clear_rules() {
    raf(() => {
        if (active)
            return;
        let i = stylesheet.cssRules.length;
        while (i--)
            stylesheet.deleteRule(i);
        current_rules = {};
    });
}

function create_animation(node, from, fn, params) {
    if (!from)
        return noop;
    const to = node.getBoundingClientRect();
    if (from.left === to.left && from.right === to.right && from.top === to.top && from.bottom === to.bottom)
        return noop;
    const { delay = 0, duration = 300, easing = identity, 
    // @ts-ignore todo: should this be separated from destructuring? Or start/end added to public api and documentation?
    start: start_time = now() + delay, 
    // @ts-ignore todo:
    end = start_time + duration, tick = noop, css } = fn(node, { from, to }, params);
    let running = true;
    let started = false;
    let name;
    function start() {
        if (css) {
            name = create_rule(node, 0, 1, duration, delay, easing, css);
        }
        if (!delay) {
            started = true;
        }
    }
    function stop() {
        if (css)
            delete_rule(node, name);
        running = false;
    }
    loop(now => {
        if (!started && now >= start_time) {
            started = true;
        }
        if (started && now >= end) {
            tick(1, 0);
            stop();
        }
        if (!running) {
            return false;
        }
        if (started) {
            const p = now - start_time;
            const t = 0 + 1 * easing(p / duration);
            tick(t, 1 - t);
        }
        return true;
    });
    start();
    tick(0, 1);
    return stop;
}
function fix_position(node) {
    const style = getComputedStyle(node);
    if (style.position !== 'absolute' && style.position !== 'fixed') {
        const { width, height } = style;
        const a = node.getBoundingClientRect();
        node.style.position = 'absolute';
        node.style.width = width;
        node.style.height = height;
        add_transform(node, a);
    }
}
function add_transform(node, a) {
    const b = node.getBoundingClientRect();
    if (a.left !== b.left || a.top !== b.top) {
        const style = getComputedStyle(node);
        const transform = style.transform === 'none' ? '' : style.transform;
        node.style.transform = `${transform} translate(${a.left - b.left}px, ${a.top - b.top}px)`;
    }
}

let current_component;
function set_current_component(component) {
    current_component = component;
}
function get_current_component() {
    if (!current_component)
        throw new Error(`Function called outside component initialization`);
    return current_component;
}
function beforeUpdate(fn) {
    get_current_component().$$.before_update.push(fn);
}
function onMount(fn) {
    get_current_component().$$.on_mount.push(fn);
}
function afterUpdate(fn) {
    get_current_component().$$.after_update.push(fn);
}
function onDestroy(fn) {
    get_current_component().$$.on_destroy.push(fn);
}
function createEventDispatcher() {
    const component = get_current_component();
    return (type, detail) => {
        const callbacks = component.$$.callbacks[type];
        if (callbacks) {
            // TODO are there situations where events could be dispatched
            // in a server (non-DOM) environment?
            const event = custom_event(type, detail);
            callbacks.slice().forEach(fn => {
                fn.call(component, event);
            });
        }
    };
}
function setContext(key, context) {
    get_current_component().$$.context.set(key, context);
}
function getContext(key) {
    return get_current_component().$$.context.get(key);
}
// TODO figure out if we still want to support
// shorthand events, or if we want to implement
// a real bubbling mechanism
function bubble(component, event) {
    const callbacks = component.$$.callbacks[event.type];
    if (callbacks) {
        callbacks.slice().forEach(fn => fn(event));
    }
}

const dirty_components = [];
const intros = { enabled: false };
const binding_callbacks = [];
const render_callbacks = [];
const flush_callbacks = [];
const resolved_promise = Promise.resolve();
let update_scheduled = false;
function schedule_update() {
    if (!update_scheduled) {
        update_scheduled = true;
        resolved_promise.then(flush);
    }
}
function tick() {
    schedule_update();
    return resolved_promise;
}
function add_render_callback(fn) {
    render_callbacks.push(fn);
}
function add_flush_callback(fn) {
    flush_callbacks.push(fn);
}
function flush() {
    const seen_callbacks = new Set();
    do {
        // first, call beforeUpdate functions
        // and update components
        while (dirty_components.length) {
            const component = dirty_components.shift();
            set_current_component(component);
            update(component.$$);
        }
        while (binding_callbacks.length)
            binding_callbacks.pop()();
        // then, once components are updated, call
        // afterUpdate functions. This may cause
        // subsequent updates...
        for (let i = 0; i < render_callbacks.length; i += 1) {
            const callback = render_callbacks[i];
            if (!seen_callbacks.has(callback)) {
                callback();
                // ...so guard against infinite loops
                seen_callbacks.add(callback);
            }
        }
        render_callbacks.length = 0;
    } while (dirty_components.length);
    while (flush_callbacks.length) {
        flush_callbacks.pop()();
    }
    update_scheduled = false;
}
function update($$) {
    if ($$.fragment !== null) {
        $$.update();
        run_all($$.before_update);
        $$.fragment && $$.fragment.p($$.ctx, $$.dirty);
        $$.dirty = [-1];
        $$.after_update.forEach(add_render_callback);
    }
}

let promise;
function wait() {
    if (!promise) {
        promise = Promise.resolve();
        promise.then(() => {
            promise = null;
        });
    }
    return promise;
}
function dispatch(node, direction, kind) {
    node.dispatchEvent(custom_event(`${direction ? 'intro' : 'outro'}${kind}`));
}
const outroing = new Set();
let outros;
function group_outros() {
    outros = {
        r: 0,
        c: [],
        p: outros // parent group
    };
}
function check_outros() {
    if (!outros.r) {
        run_all(outros.c);
    }
    outros = outros.p;
}
function transition_in(block, local) {
    if (block && block.i) {
        outroing.delete(block);
        block.i(local);
    }
}
function transition_out(block, local, detach, callback) {
    if (block && block.o) {
        if (outroing.has(block))
            return;
        outroing.add(block);
        outros.c.push(() => {
            outroing.delete(block);
            if (callback) {
                if (detach)
                    block.d(1);
                callback();
            }
        });
        block.o(local);
    }
}
const null_transition = { duration: 0 };
function create_in_transition(node, fn, params) {
    let config = fn(node, params);
    let running = false;
    let animation_name;
    let task;
    let uid = 0;
    function cleanup() {
        if (animation_name)
            delete_rule(node, animation_name);
    }
    function go() {
        const { delay = 0, duration = 300, easing = identity, tick = noop, css } = config || null_transition;
        if (css)
            animation_name = create_rule(node, 0, 1, duration, delay, easing, css, uid++);
        tick(0, 1);
        const start_time = now() + delay;
        const end_time = start_time + duration;
        if (task)
            task.abort();
        running = true;
        add_render_callback(() => dispatch(node, true, 'start'));
        task = loop(now => {
            if (running) {
                if (now >= end_time) {
                    tick(1, 0);
                    dispatch(node, true, 'end');
                    cleanup();
                    return running = false;
                }
                if (now >= start_time) {
                    const t = easing((now - start_time) / duration);
                    tick(t, 1 - t);
                }
            }
            return running;
        });
    }
    let started = false;
    return {
        start() {
            if (started)
                return;
            delete_rule(node);
            if (is_function(config)) {
                config = config();
                wait().then(go);
            }
            else {
                go();
            }
        },
        invalidate() {
            started = false;
        },
        end() {
            if (running) {
                cleanup();
                running = false;
            }
        }
    };
}
function create_out_transition(node, fn, params) {
    let config = fn(node, params);
    let running = true;
    let animation_name;
    const group = outros;
    group.r += 1;
    function go() {
        const { delay = 0, duration = 300, easing = identity, tick = noop, css } = config || null_transition;
        if (css)
            animation_name = create_rule(node, 1, 0, duration, delay, easing, css);
        const start_time = now() + delay;
        const end_time = start_time + duration;
        add_render_callback(() => dispatch(node, false, 'start'));
        loop(now => {
            if (running) {
                if (now >= end_time) {
                    tick(0, 1);
                    dispatch(node, false, 'end');
                    if (!--group.r) {
                        // this will result in `end()` being called,
                        // so we don't need to clean up here
                        run_all(group.c);
                    }
                    return false;
                }
                if (now >= start_time) {
                    const t = easing((now - start_time) / duration);
                    tick(1 - t, t);
                }
            }
            return running;
        });
    }
    if (is_function(config)) {
        wait().then(() => {
            // @ts-ignore
            config = config();
            go();
        });
    }
    else {
        go();
    }
    return {
        end(reset) {
            if (reset && config.tick) {
                config.tick(1, 0);
            }
            if (running) {
                if (animation_name)
                    delete_rule(node, animation_name);
                running = false;
            }
        }
    };
}
function create_bidirectional_transition(node, fn, params, intro) {
    let config = fn(node, params);
    let t = intro ? 0 : 1;
    let running_program = null;
    let pending_program = null;
    let animation_name = null;
    function clear_animation() {
        if (animation_name)
            delete_rule(node, animation_name);
    }
    function init(program, duration) {
        const d = program.b - t;
        duration *= Math.abs(d);
        return {
            a: t,
            b: program.b,
            d,
            duration,
            start: program.start,
            end: program.start + duration,
            group: program.group
        };
    }
    function go(b) {
        const { delay = 0, duration = 300, easing = identity, tick = noop, css } = config || null_transition;
        const program = {
            start: now() + delay,
            b
        };
        if (!b) {
            // @ts-ignore todo: improve typings
            program.group = outros;
            outros.r += 1;
        }
        if (running_program) {
            pending_program = program;
        }
        else {
            // if this is an intro, and there's a delay, we need to do
            // an initial tick and/or apply CSS animation immediately
            if (css) {
                clear_animation();
                animation_name = create_rule(node, t, b, duration, delay, easing, css);
            }
            if (b)
                tick(0, 1);
            running_program = init(program, duration);
            add_render_callback(() => dispatch(node, b, 'start'));
            loop(now => {
                if (pending_program && now > pending_program.start) {
                    running_program = init(pending_program, duration);
                    pending_program = null;
                    dispatch(node, running_program.b, 'start');
                    if (css) {
                        clear_animation();
                        animation_name = create_rule(node, t, running_program.b, running_program.duration, 0, easing, config.css);
                    }
                }
                if (running_program) {
                    if (now >= running_program.end) {
                        tick(t = running_program.b, 1 - t);
                        dispatch(node, running_program.b, 'end');
                        if (!pending_program) {
                            // we're done
                            if (running_program.b) {
                                // intro — we can tidy up immediately
                                clear_animation();
                            }
                            else {
                                // outro — needs to be coordinated
                                if (!--running_program.group.r)
                                    run_all(running_program.group.c);
                            }
                        }
                        running_program = null;
                    }
                    else if (now >= running_program.start) {
                        const p = now - running_program.start;
                        t = running_program.a + running_program.d * easing(p / running_program.duration);
                        tick(t, 1 - t);
                    }
                }
                return !!(running_program || pending_program);
            });
        }
    }
    return {
        run(b) {
            if (is_function(config)) {
                wait().then(() => {
                    // @ts-ignore
                    config = config();
                    go(b);
                });
            }
            else {
                go(b);
            }
        },
        end() {
            clear_animation();
            running_program = pending_program = null;
        }
    };
}

function handle_promise(promise, info) {
    const token = info.token = {};
    function update(type, index, key, value) {
        if (info.token !== token)
            return;
        info.resolved = value;
        let child_ctx = info.ctx;
        if (key !== undefined) {
            child_ctx = child_ctx.slice();
            child_ctx[key] = value;
        }
        const block = type && (info.current = type)(child_ctx);
        let needs_flush = false;
        if (info.block) {
            if (info.blocks) {
                info.blocks.forEach((block, i) => {
                    if (i !== index && block) {
                        group_outros();
                        transition_out(block, 1, 1, () => {
                            info.blocks[i] = null;
                        });
                        check_outros();
                    }
                });
            }
            else {
                info.block.d(1);
            }
            block.c();
            transition_in(block, 1);
            block.m(info.mount(), info.anchor);
            needs_flush = true;
        }
        info.block = block;
        if (info.blocks)
            info.blocks[index] = block;
        if (needs_flush) {
            flush();
        }
    }
    if (is_promise(promise)) {
        const current_component = get_current_component();
        promise.then(value => {
            set_current_component(current_component);
            update(info.then, 1, info.value, value);
            set_current_component(null);
        }, error => {
            set_current_component(current_component);
            update(info.catch, 2, info.error, error);
            set_current_component(null);
        });
        // if we previously had a then/catch block, destroy it
        if (info.current !== info.pending) {
            update(info.pending, 0);
            return true;
        }
    }
    else {
        if (info.current !== info.then) {
            update(info.then, 1, info.value, promise);
            return true;
        }
        info.resolved = promise;
    }
}

const globals = (typeof window !== 'undefined' ? window : global);

function destroy_block(block, lookup) {
    block.d(1);
    lookup.delete(block.key);
}
function outro_and_destroy_block(block, lookup) {
    transition_out(block, 1, 1, () => {
        lookup.delete(block.key);
    });
}
function fix_and_destroy_block(block, lookup) {
    block.f();
    destroy_block(block, lookup);
}
function fix_and_outro_and_destroy_block(block, lookup) {
    block.f();
    outro_and_destroy_block(block, lookup);
}
function update_keyed_each(old_blocks, dirty, get_key, dynamic, ctx, list, lookup, node, destroy, create_each_block, next, get_context) {
    let o = old_blocks.length;
    let n = list.length;
    let i = o;
    const old_indexes = {};
    while (i--)
        old_indexes[old_blocks[i].key] = i;
    const new_blocks = [];
    const new_lookup = new Map();
    const deltas = new Map();
    i = n;
    while (i--) {
        const child_ctx = get_context(ctx, list, i);
        const key = get_key(child_ctx);
        let block = lookup.get(key);
        if (!block) {
            block = create_each_block(key, child_ctx);
            block.c();
        }
        else if (dynamic) {
            block.p(child_ctx, dirty);
        }
        new_lookup.set(key, new_blocks[i] = block);
        if (key in old_indexes)
            deltas.set(key, Math.abs(i - old_indexes[key]));
    }
    const will_move = new Set();
    const did_move = new Set();
    function insert(block) {
        transition_in(block, 1);
        block.m(node, next);
        lookup.set(block.key, block);
        next = block.first;
        n--;
    }
    while (o && n) {
        const new_block = new_blocks[n - 1];
        const old_block = old_blocks[o - 1];
        const new_key = new_block.key;
        const old_key = old_block.key;
        if (new_block === old_block) {
            // do nothing
            next = new_block.first;
            o--;
            n--;
        }
        else if (!new_lookup.has(old_key)) {
            // remove old block
            destroy(old_block, lookup);
            o--;
        }
        else if (!lookup.has(new_key) || will_move.has(new_key)) {
            insert(new_block);
        }
        else if (did_move.has(old_key)) {
            o--;
        }
        else if (deltas.get(new_key) > deltas.get(old_key)) {
            did_move.add(new_key);
            insert(new_block);
        }
        else {
            will_move.add(old_key);
            o--;
        }
    }
    while (o--) {
        const old_block = old_blocks[o];
        if (!new_lookup.has(old_block.key))
            destroy(old_block, lookup);
    }
    while (n)
        insert(new_blocks[n - 1]);
    return new_blocks;
}
function measure(blocks) {
    const rects = {};
    let i = blocks.length;
    while (i--)
        rects[blocks[i].key] = blocks[i].node.getBoundingClientRect();
    return rects;
}

function get_spread_update(levels, updates) {
    const update = {};
    const to_null_out = {};
    const accounted_for = { $$scope: 1 };
    let i = levels.length;
    while (i--) {
        const o = levels[i];
        const n = updates[i];
        if (n) {
            for (const key in o) {
                if (!(key in n))
                    to_null_out[key] = 1;
            }
            for (const key in n) {
                if (!accounted_for[key]) {
                    update[key] = n[key];
                    accounted_for[key] = 1;
                }
            }
            levels[i] = n;
        }
        else {
            for (const key in o) {
                accounted_for[key] = 1;
            }
        }
    }
    for (const key in to_null_out) {
        if (!(key in update))
            update[key] = undefined;
    }
    return update;
}
function get_spread_object(spread_props) {
    return typeof spread_props === 'object' && spread_props !== null ? spread_props : {};
}

// source: https://html.spec.whatwg.org/multipage/indices.html
const boolean_attributes = new Set([
    'allowfullscreen',
    'allowpaymentrequest',
    'async',
    'autofocus',
    'autoplay',
    'checked',
    'controls',
    'default',
    'defer',
    'disabled',
    'formnovalidate',
    'hidden',
    'ismap',
    'loop',
    'multiple',
    'muted',
    'nomodule',
    'novalidate',
    'open',
    'playsinline',
    'readonly',
    'required',
    'reversed',
    'selected'
]);

const invalid_attribute_name_character = /[\s'">/=\u{FDD0}-\u{FDEF}\u{FFFE}\u{FFFF}\u{1FFFE}\u{1FFFF}\u{2FFFE}\u{2FFFF}\u{3FFFE}\u{3FFFF}\u{4FFFE}\u{4FFFF}\u{5FFFE}\u{5FFFF}\u{6FFFE}\u{6FFFF}\u{7FFFE}\u{7FFFF}\u{8FFFE}\u{8FFFF}\u{9FFFE}\u{9FFFF}\u{AFFFE}\u{AFFFF}\u{BFFFE}\u{BFFFF}\u{CFFFE}\u{CFFFF}\u{DFFFE}\u{DFFFF}\u{EFFFE}\u{EFFFF}\u{FFFFE}\u{FFFFF}\u{10FFFE}\u{10FFFF}]/u;
// https://html.spec.whatwg.org/multipage/syntax.html#attributes-2
// https://infra.spec.whatwg.org/#noncharacter
function spread(args, classes_to_add) {
    const attributes = Object.assign({}, ...args);
    if (classes_to_add) {
        if (attributes.class == null) {
            attributes.class = classes_to_add;
        }
        else {
            attributes.class += ' ' + classes_to_add;
        }
    }
    let str = '';
    Object.keys(attributes).forEach(name => {
        if (invalid_attribute_name_character.test(name))
            return;
        const value = attributes[name];
        if (value === true)
            str += " " + name;
        else if (boolean_attributes.has(name.toLowerCase())) {
            if (value)
                str += " " + name;
        }
        else if (value != null) {
            str += " " + name + "=" + JSON.stringify(String(value)
                .replace(/"/g, '&#34;')
                .replace(/'/g, '&#39;'));
        }
    });
    return str;
}
const escaped = {
    '"': '&quot;',
    "'": '&#39;',
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;'
};
function escape(html) {
    return String(html).replace(/["'&<>]/g, match => escaped[match]);
}
function each(items, fn) {
    let str = '';
    for (let i = 0; i < items.length; i += 1) {
        str += fn(items[i], i);
    }
    return str;
}
const missing_component = {
    $$render: () => ''
};
function validate_component(component, name) {
    if (!component || !component.$$render) {
        if (name === 'svelte:component')
            name += ' this={...}';
        throw new Error(`<${name}> is not a valid SSR component. You may need to review your build config to ensure that dependencies are compiled, rather than imported as pre-compiled modules`);
    }
    return component;
}
function debug(file, line, column, values) {
    console.log(`{@debug} ${file ? file + ' ' : ''}(${line}:${column})`); // eslint-disable-line no-console
    console.log(values); // eslint-disable-line no-console
    return '';
}
let on_destroy;
function create_ssr_component(fn) {
    function $$render(result, props, bindings, slots) {
        const parent_component = current_component;
        const $$ = {
            on_destroy,
            context: new Map(parent_component ? parent_component.$$.context : []),
            // these will be immediately discarded
            on_mount: [],
            before_update: [],
            after_update: [],
            callbacks: blank_object()
        };
        set_current_component({ $$ });
        const html = fn(result, props, bindings, slots);
        set_current_component(parent_component);
        return html;
    }
    return {
        render: (props = {}, options = {}) => {
            on_destroy = [];
            const result = { head: '', css: new Set() };
            const html = $$render(result, props, {}, options);
            run_all(on_destroy);
            return {
                html,
                css: {
                    code: Array.from(result.css).map(css => css.code).join('\n'),
                    map: null // TODO
                },
                head: result.head
            };
        },
        $$render
    };
}
function add_attribute(name, value, boolean) {
    if (value == null || (boolean && !value))
        return '';
    return ` ${name}${value === true ? '' : `=${typeof value === 'string' ? JSON.stringify(escape(value)) : `"${value}"`}`}`;
}
function add_classes(classes) {
    return classes ? ` class="${classes}"` : ``;
}

function bind(component, name, callback) {
    const index = component.$$.props[name];
    if (index !== undefined) {
        component.$$.bound[index] = callback;
        callback(component.$$.ctx[index]);
    }
}
function create_component(block) {
    block && block.c();
}
function claim_component(block, parent_nodes) {
    block && block.l(parent_nodes);
}
function mount_component(component, target, anchor) {
    const { fragment, on_mount, on_destroy, after_update } = component.$$;
    fragment && fragment.m(target, anchor);
    // onMount happens before the initial afterUpdate
    add_render_callback(() => {
        const new_on_destroy = on_mount.map(run).filter(is_function);
        if (on_destroy) {
            on_destroy.push(...new_on_destroy);
        }
        else {
            // Edge case - component was destroyed immediately,
            // most likely as a result of a binding initialising
            run_all(new_on_destroy);
        }
        component.$$.on_mount = [];
    });
    after_update.forEach(add_render_callback);
}
function destroy_component(component, detaching) {
    const $$ = component.$$;
    if ($$.fragment !== null) {
        run_all($$.on_destroy);
        $$.fragment && $$.fragment.d(detaching);
        // TODO null out other refs, including component.$$ (but need to
        // preserve final state?)
        $$.on_destroy = $$.fragment = null;
        $$.ctx = [];
    }
}
function make_dirty(component, i) {
    if (component.$$.dirty[0] === -1) {
        dirty_components.push(component);
        schedule_update();
        component.$$.dirty.fill(0);
    }
    component.$$.dirty[(i / 31) | 0] |= (1 << (i % 31));
}
function init(component, options, instance, create_fragment, not_equal, props, dirty = [-1]) {
    const parent_component = current_component;
    set_current_component(component);
    const prop_values = options.props || {};
    const $$ = component.$$ = {
        fragment: null,
        ctx: null,
        // state
        props,
        update: noop,
        not_equal,
        bound: blank_object(),
        // lifecycle
        on_mount: [],
        on_destroy: [],
        before_update: [],
        after_update: [],
        context: new Map(parent_component ? parent_component.$$.context : []),
        // everything else
        callbacks: blank_object(),
        dirty
    };
    let ready = false;
    $$.ctx = instance
        ? instance(component, prop_values, (i, ret, value = ret) => {
            if ($$.ctx && not_equal($$.ctx[i], $$.ctx[i] = value)) {
                if ($$.bound[i])
                    $$.bound[i](value);
                if (ready)
                    make_dirty(component, i);
            }
            return ret;
        })
        : [];
    $$.update();
    ready = true;
    run_all($$.before_update);
    // `false` as a special case of no DOM component
    $$.fragment = create_fragment ? create_fragment($$.ctx) : false;
    if (options.target) {
        if (options.hydrate) {
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            $$.fragment && $$.fragment.l(children(options.target));
        }
        else {
            // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
            $$.fragment && $$.fragment.c();
        }
        if (options.intro)
            transition_in(component.$$.fragment);
        mount_component(component, options.target, options.anchor);
        flush();
    }
    set_current_component(parent_component);
}
let SvelteElement;
if (typeof HTMLElement === 'function') {
    SvelteElement = class extends HTMLElement {
        constructor() {
            super();
            this.attachShadow({ mode: 'open' });
        }
        connectedCallback() {
            // @ts-ignore todo: improve typings
            for (const key in this.$$.slotted) {
                // @ts-ignore todo: improve typings
                this.appendChild(this.$$.slotted[key]);
            }
        }
        attributeChangedCallback(attr, _oldValue, newValue) {
            this[attr] = newValue;
        }
        $destroy() {
            destroy_component(this, 1);
            this.$destroy = noop;
        }
        $on(type, callback) {
            // TODO should this delegate to addEventListener?
            const callbacks = (this.$$.callbacks[type] || (this.$$.callbacks[type] = []));
            callbacks.push(callback);
            return () => {
                const index = callbacks.indexOf(callback);
                if (index !== -1)
                    callbacks.splice(index, 1);
            };
        }
        $set() {
            // overridden by instance, if it has props
        }
    };
}
class SvelteComponent {
    $destroy() {
        destroy_component(this, 1);
        this.$destroy = noop;
    }
    $on(type, callback) {
        const callbacks = (this.$$.callbacks[type] || (this.$$.callbacks[type] = []));
        callbacks.push(callback);
        return () => {
            const index = callbacks.indexOf(callback);
            if (index !== -1)
                callbacks.splice(index, 1);
        };
    }
    $set() {
        // overridden by instance, if it has props
    }
}

function dispatch_dev(type, detail) {
    document.dispatchEvent(custom_event(type, detail));
}
function append_dev(target, node) {
    dispatch_dev("SvelteDOMInsert", { target, node });
    append(target, node);
}
function insert_dev(target, node, anchor) {
    dispatch_dev("SvelteDOMInsert", { target, node, anchor });
    insert(target, node, anchor);
}
function detach_dev(node) {
    dispatch_dev("SvelteDOMRemove", { node });
    detach(node);
}
function detach_between_dev(before, after) {
    while (before.nextSibling && before.nextSibling !== after) {
        detach_dev(before.nextSibling);
    }
}
function detach_before_dev(after) {
    while (after.previousSibling) {
        detach_dev(after.previousSibling);
    }
}
function detach_after_dev(before) {
    while (before.nextSibling) {
        detach_dev(before.nextSibling);
    }
}
function listen_dev(node, event, handler, options, has_prevent_default, has_stop_propagation) {
    const modifiers = options === true ? ["capture"] : options ? Array.from(Object.keys(options)) : [];
    if (has_prevent_default)
        modifiers.push('preventDefault');
    if (has_stop_propagation)
        modifiers.push('stopPropagation');
    dispatch_dev("SvelteDOMAddEventListener", { node, event, handler, modifiers });
    const dispose = listen(node, event, handler, options);
    return () => {
        dispatch_dev("SvelteDOMRemoveEventListener", { node, event, handler, modifiers });
        dispose();
    };
}
function attr_dev(node, attribute, value) {
    attr(node, attribute, value);
    if (value == null)
        dispatch_dev("SvelteDOMRemoveAttribute", { node, attribute });
    else
        dispatch_dev("SvelteDOMSetAttribute", { node, attribute, value });
}
function prop_dev(node, property, value) {
    node[property] = value;
    dispatch_dev("SvelteDOMSetProperty", { node, property, value });
}
function dataset_dev(node, property, value) {
    node.dataset[property] = value;
    dispatch_dev("SvelteDOMSetDataset", { node, property, value });
}
function set_data_dev(text, data) {
    data = '' + data;
    if (text.data === data)
        return;
    dispatch_dev("SvelteDOMSetData", { node: text, data });
    text.data = data;
}
class SvelteComponentDev extends SvelteComponent {
    constructor(options) {
        if (!options || (!options.target && !options.$$inline)) {
            throw new Error(`'target' is a required option`);
        }
        super();
    }
    $destroy() {
        super.$destroy();
        this.$destroy = () => {
            console.warn(`Component was already destroyed`); // eslint-disable-line no-console
        };
    }
}
function loop_guard(timeout) {
    const start = Date.now();
    return () => {
        if (Date.now() - start > timeout) {
            throw new Error(`Infinite loop detected`);
        }
    };
}



/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "../node_modules/webpack/buildin/global.js":
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "../node_modules/webpack/buildin/harmony-module.js":
/***/ (function(module, exports) {

module.exports = function(originalModule) {
	if (!originalModule.webpackPolyfill) {
		var module = Object.create(originalModule);
		// module.parent = undefined by default
		if (!module.children) module.children = [];
		Object.defineProperty(module, "loaded", {
			enumerable: true,
			get: function() {
				return module.l;
			}
		});
		Object.defineProperty(module, "id", {
			enumerable: true,
			get: function() {
				return module.i;
			}
		});
		Object.defineProperty(module, "exports", {
			enumerable: true
		});
		module.webpackPolyfill = 1;
	}
	return module;
};


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL25hdGl2ZXNjcmlwdC1kZXYtd2VicGFjay9obXIvaG1yLXVwZGF0ZS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL25hdGl2ZXNjcmlwdC1kZXYtd2VicGFjay9obXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9uYXRpdmVzY3JpcHQtZGV2LXdlYnBhY2svaG90LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvbmF0aXZlc2NyaXB0LWRldi13ZWJwYWNrL2xvYWQtYXBwbGljYXRpb24tY3NzLXJlZ3VsYXIuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9uYXRpdmVzY3JpcHQtZGV2LXdlYnBhY2svbG9hZC1hcHBsaWNhdGlvbi1jc3MuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9uYXRpdmVzY3JpcHQtdGhlbWUtY29yZS9jc3MvYmx1ZS5jc3MiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9uYXRpdmVzY3JpcHQtdGhlbWUtY29yZS9jc3MvY29yZS5jc3MiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9zdmVsdGUtbG9hZGVyLWhvdC9saWIvc3ZlbHRlMy9ob3QtYXBpLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlLWxvYWRlci1ob3Qvbm9kZV9tb2R1bGVzL3N2ZWx0ZS1obXIvcnVudGltZS9ob3QtYXBpLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlLWxvYWRlci1ob3Qvbm9kZV9tb2R1bGVzL3N2ZWx0ZS1obXIvcnVudGltZS9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3N2ZWx0ZS1sb2FkZXItaG90L25vZGVfbW9kdWxlcy9zdmVsdGUtaG1yL3J1bnRpbWUvb3ZlcmxheS5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3N2ZWx0ZS1sb2FkZXItaG90L25vZGVfbW9kdWxlcy9zdmVsdGUtaG1yL3J1bnRpbWUvcHJveHktYWRhcHRlci1kb20uanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9zdmVsdGUtbG9hZGVyLWhvdC9ub2RlX21vZHVsZXMvc3ZlbHRlLWhtci9ydW50aW1lL3Byb3h5LmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlLWxvYWRlci1ob3Qvbm9kZV9tb2R1bGVzL3N2ZWx0ZS1obXIvcnVudGltZS9zdmVsdGUtaG9va3MuanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9zdmVsdGUtbG9hZGVyLWhvdC9ub2RlX21vZHVsZXMvc3ZlbHRlLWhtci9ydW50aW1lL3N2ZWx0ZS1uYXRpdmUvcGF0Y2gtcGFnZS1zaG93LW1vZGFsLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlLWxvYWRlci1ob3Qvbm9kZV9tb2R1bGVzL3N2ZWx0ZS1obXIvcnVudGltZS9zdmVsdGUtbmF0aXZlL3Byb3h5LWFkYXB0ZXItbmF0aXZlLmpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvc3ZlbHRlLW5hdGl2ZS9jb21wb25lbnRzL2luZGV4Lm1qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3N2ZWx0ZS1uYXRpdmUvZG9tL2luZGV4Lm1qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3N2ZWx0ZS1uYXRpdmUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4uL25vZGVfbW9kdWxlcy9zdmVsdGUvaW50ZXJuYWwvaW5kZXgubWpzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvd2VicGFjay9idWlsZGluL2dsb2JhbC5qcyIsIndlYnBhY2s6Ly8vLi4vbm9kZV9tb2R1bGVzL3dlYnBhY2svYnVpbGRpbi9oYXJtb255LW1vZHVsZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBYTtBQUNiLDhDQUE4QyxjQUFjO0FBQzVELFlBQVksbUJBQU8sQ0FBQyxpREFBUTtBQUM1QixzQkFBc0IsbUJBQU8sQ0FBQyw4QkFBOEI7QUFDNUQ7QUFDQTtBQUNBLHVCQUF1QixtQkFBbUI7QUFDMUM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxzQzs7Ozs7Ozs7QUNiYTtBQUNiLDhDQUE4QyxjQUFjO0FBQzVELG1CQUFtQixtQkFBTyxDQUFDLDREQUFjO0FBQ3pDO0FBQ0EsaUM7Ozs7Ozs7QUNKQTtBQUNBO0FBQ0EsdUNBQXVDLFVBQVUsR0FBRyxRQUFRO0FBQzVELHVDQUF1QyxVQUFVLEdBQUcsUUFBUTtBQUM1RCx5Q0FBeUMsVUFBVSxHQUFHLFFBQVE7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLG9EQUFvRCxJQUFJO0FBQ3hELEtBQUs7QUFDTDtBQUNBO0FBQ0EseURBQXlELElBQUk7QUFDN0QsS0FBSztBQUNMO0FBQ0E7QUFDQSxzREFBc0QsY0FBYyxJQUFJLFVBQVU7QUFDbEY7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBOztBQUVBO0FBQ0EsNEJBQTRCLHVCQUFnQjtBQUM1Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0Esb0NBQW9DLFNBQVM7QUFDN0M7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0EsbUNBQW1DLFNBQVM7QUFDNUM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLFFBQVE7QUFDbkQ7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQSw4RUFBOEUsWUFBWTtBQUMxRjs7QUFFQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVFQUF1RSxZQUFZO0FBQ25GO0FBQ0EscUJBQXFCO0FBQ3JCLG9EQUFvRCx5QkFBeUI7QUFDN0U7QUFDQSxpQkFBaUI7QUFDakIsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLHNEQUFzRCxRQUFRO0FBQzlEO0FBQ0EsYUFBYTtBQUNiLGtEQUFrRCx5QkFBeUI7QUFDM0U7QUFDQSxTQUFTO0FBQ1Q7O0FBRUEsSUFBSSxJQUFVO0FBQ2Q7QUFDQSxDQUFDLE1BQU0sRUFFTjs7QUFFRDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EseUVBQXlFLFlBQVk7QUFDckY7QUFDQSxTQUFTO0FBQ1Q7QUFDQSwwREFBMEQsT0FBTyxNQUFNLFFBQVE7QUFDL0U7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxtQ0FBbUMsS0FBSztBQUN4QztBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDO0FBQ3RDO0FBQ0EsS0FBSztBQUNMOzs7Ozs7OztBQzNLQSw4REFBZ0IsbUJBQU8sQ0FBQyxrRUFBd0I7O0FBRWhEO0FBQ0E7QUFDQSw4QkFBOEIsaUVBQStEO0FBQzdGO0FBQ0EsS0FBSztBQUNMOzs7Ozs7Ozs7QUNQQTtBQUNBLHdCQUF3QixtQkFBTyxDQUFDLDhCQUE4QjtBQUM5RCxJQUFJLG1CQUFPLENBQUMseUNBQXlDOztBQUVyRDs7QUFFQTtBQUNBOzs7Ozs7OztBQ1BBLGdFQUFrQixrQ0FBa0MsVUFBVSwwUUFBMFEsRUFBRSxtRUFBbUUsa0VBQWtFLEVBQUUsMERBQTBELEVBQUUsRUFBRSxxRkFBcUYscUVBQXFFLEVBQUUsMERBQTBELEVBQUUsRUFBRSx1SEFBdUgsMERBQTBELEVBQUUsRUFBRSwySkFBMkosMERBQTBELEVBQUUsRUFBRSxxRkFBcUYsa0VBQWtFLEVBQUUsaUVBQWlFLEVBQUUsRUFBRSx1R0FBdUcscUVBQXFFLEVBQUUsaUVBQWlFLEVBQUUsRUFBRSw0REFBNEQsbURBQW1ELGtFQUFrRSxFQUFFLEVBQUUscURBQXFELHFFQUFxRSxFQUFFLEVBQUUsRUFBRSwyREFBMkQsbURBQW1ELHFFQUFxRSxFQUFFLEVBQUUscURBQXFELHFFQUFxRSxFQUFFLEVBQUUsRUFBRSwySkFBMkosOEZBQThGLEVBQUUscUVBQXFFLEVBQUUsRUFBRSwrTEFBK0wsNkZBQTZGLEVBQUUscUVBQXFFLEVBQUUsRUFBRSxxRkFBcUYsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsaUVBQWlFLEVBQUUsRUFBRSx1R0FBdUcsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsaUVBQWlFLEVBQUUsRUFBRSxrRUFBa0UsbURBQW1ELHFFQUFxRSxFQUFFLEVBQUUscURBQXFELHFFQUFxRSxFQUFFLEVBQUUsRUFBRSxpRUFBaUUsbURBQW1ELHFFQUFxRSxFQUFFLEVBQUUscURBQXFELHFFQUFxRSxFQUFFLEVBQUUsRUFBRSwySkFBMkosb0dBQW9HLEVBQUUscUVBQXFFLEVBQUUsRUFBRSwrTEFBK0wsbUdBQW1HLEVBQUUscUVBQXFFLEVBQUUsRUFBRSwwRkFBMEYsMERBQTBELEVBQUUsRUFBRSw0R0FBNEcsMERBQTBELEVBQUUsRUFBRSxnRkFBZ0YsMERBQTBELEVBQUUsa0VBQWtFLEVBQUUsOEVBQThFLEVBQUUsRUFBRSxrR0FBa0csdURBQXVELEVBQUUscUVBQXFFLEVBQUUsOEVBQThFLEVBQUUsRUFBRSxnR0FBZ0csd0RBQXdELEVBQUUsMERBQTBELEVBQUUsRUFBRSxnSEFBZ0gsMERBQTBELEVBQUUsRUFBRSx1RUFBdUUsMERBQTBELEVBQUUsaUZBQWlGLEVBQUUsRUFBRSx5RkFBeUYsMERBQTBELEVBQUUsaUZBQWlGLEVBQUUsRUFBRSxtRUFBbUUsMERBQTBELEVBQUUscUVBQXFFLEVBQUUsRUFBRSxxRkFBcUYsMERBQTBELEVBQUUscUVBQXFFLEVBQUUsRUFBRSxxTEFBcUwsMERBQTBELEVBQUUscUVBQXFFLEVBQUUsRUFBRSwwRUFBMEUsMERBQTBELEVBQUUsa0VBQWtFLEVBQUUsMEVBQTBFLEVBQUUsb0ZBQW9GLEVBQUUsRUFBRSw0RkFBNEYsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsMEVBQTBFLEVBQUUsb0ZBQW9GLEVBQUUsRUFBRSwyRkFBMkYsdURBQXVELEVBQUUsa0VBQWtFLEVBQUUsRUFBRSwyR0FBMkcsMERBQTBELEVBQUUscUVBQXFFLEVBQUUsRUFBRSx1SEFBdUgsMERBQTBELEVBQUUsRUFBRSx1SUFBdUksMERBQTBELEVBQUUsRUFBRSw2SEFBNkgsMERBQTBELEVBQUUsRUFBRSw2SUFBNkksMERBQTBELEVBQUUsRUFBRSxtRkFBbUYsdURBQXVELEVBQUUscUVBQXFFLEVBQUUseUVBQXlFLEVBQUUsRUFBRSxtR0FBbUcsMERBQTBELEVBQUUscUVBQXFFLEVBQUUseUVBQXlFLEVBQUUsRUFBRSxxSEFBcUgsaUZBQWlGLEVBQUUsRUFBRSxxSUFBcUksaUZBQWlGLEVBQUUsRUFBRSxzRUFBc0UsNEVBQTRFLEVBQUUsc0VBQXNFLEVBQUUsbUVBQW1FLEVBQUUseUZBQXlGLEVBQUUsRUFBRSx3RkFBd0YsNEVBQTRFLEVBQUUseUVBQXlFLEVBQUUsbUVBQW1FLEVBQUUseUZBQXlGLEVBQUUsRUFBRSxzRkFBc0YsNEVBQTRFLEVBQUUseUVBQXlFLEVBQUUsbUVBQW1FLEVBQUUseUZBQXlGLEVBQUUsRUFBRSx3RUFBd0Usb0VBQW9FLEVBQUUsK0RBQStELEVBQUUsRUFBRSwwRkFBMEYsb0VBQW9FLEVBQUUsK0RBQStELEVBQUUsRUFBRSxrRkFBa0YsMERBQTBELEVBQUUsRUFBRSxvR0FBb0csdURBQXVELEVBQUUsRUFBRSwrSkFBK0osMERBQTBELEVBQUUsRUFBRSxtTUFBbU0sMERBQTBELEVBQUUsRUFBRSxzRkFBc0YsNERBQTRELEVBQUUsRUFBRSx3R0FBd0csK0RBQStELEVBQUUsRUFBRSxzRkFBc0YsZ0dBQWdHLEVBQUUsaUVBQWlFLEVBQUUsRUFBRSxpSEFBaUgsZ0dBQWdHLEVBQUUsRUFBRSxvTUFBb00sa0ZBQWtGLEVBQUUsRUFBRSwwUEFBMFAsa0ZBQWtGLEVBQUUsRUFBRSwwSEFBMEgscUVBQXFFLEVBQUUsRUFBRSxxSkFBcUosd0VBQXdFLEVBQUUsRUFBRSxpSEFBaUgsb0VBQW9FLEVBQUUsRUFBRSx3SkFBd0oscUVBQXFFLEVBQUUsRUFBRSwwS0FBMEssMERBQTBELEVBQUUsRUFBRSxxTUFBcU0sdURBQXVELEVBQUUsRUFBRSwrS0FBK0ssMERBQTBELEVBQUUsRUFBRSxxT0FBcU8sMERBQTBELEVBQUUsRUFBRSxnSEFBZ0gsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsRUFBRSxtSkFBbUosa0VBQWtFLEVBQUUsRUFBRSwwSUFBMEksa0ZBQWtGLEVBQUUsRUFBRSxzSkFBc0osMERBQTBELEVBQUUsRUFBRSxxTkFBcU4sdURBQXVELEVBQUUscUVBQXFFLEVBQUUsRUFBRSw2VEFBNlQscUVBQXFFLEVBQUUsRUFBRSx5UUFBeVEsa0ZBQWtGLEVBQUUsRUFBRSxpU0FBaVMsMERBQTBELEVBQUUsRUFBRSw0TEFBNEwseUVBQXlFLEVBQUUsMERBQTBELEVBQUUsc0VBQXNFLEVBQUUsaUVBQWlFLEVBQUUsRUFBRSxvUUFBb1EsdURBQXVELEVBQUUsc0VBQXNFLEVBQUUsaUVBQWlFLEVBQUUsRUFBRSw0T0FBNE8saUVBQWlFLEVBQUUsRUFBRSxvVEFBb1QsaUVBQWlFLEVBQUUsRUFBRSxvVUFBb1UsMERBQTBELEVBQUUscUVBQXFFLEVBQUUsRUFBRSw0WUFBNFksMERBQTBELEVBQUUscUVBQXFFLEVBQUUsRUFBRSx1RkFBdUYsaUVBQWlFLEVBQUUsRUFBRSxnR0FBZ0csaUVBQWlFLEVBQUUsRUFBRSw2RUFBNkUscUVBQXFFLEVBQUUsRUFBRSxzRkFBc0YscUVBQXFFLEVBQUUsRUFBRSxzRkFBc0YscUVBQXFFLEVBQUUsRUFBRSwrRkFBK0YscUVBQXFFLEVBQUUsRUFBRSxtRkFBbUYsMERBQTBELEVBQUUsRUFBRSw0RkFBNEYsMERBQTBELEVBQUUsRUFBRSxzRkFBc0YsMERBQTBELEVBQUUsa0VBQWtFLEVBQUUsRUFBRSwrRkFBK0YsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsRUFBRSwyREFBMkQsMERBQTBELEVBQUUsc0VBQXNFLEVBQUUsRUFBRSxvRUFBb0UsdURBQXVELEVBQUUsc0VBQXNFLEVBQUUsRUFBRSwwRUFBMEUsMERBQTBELEVBQUUsa0VBQWtFLEVBQUUsRUFBRSxtRkFBbUYsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsRUFBRSxtRUFBbUUsMERBQTBELEVBQUUsNERBQTRELEVBQUUsRUFBRSw0RUFBNEUsdURBQXVELEVBQUUsK0RBQStELEVBQUUsRUFBRSxxRUFBcUUsb0ZBQW9GLEVBQUUsRUFBRSw4RUFBOEUsb0ZBQW9GLEVBQUUsRUFBRSxxR0FBcUcsdURBQXVELEVBQUUsK0RBQStELEVBQUUsRUFBRSxpRUFBaUUsMERBQTBELEVBQUUsNERBQTRELEVBQUUsRUFBRSx5RUFBeUUsdURBQXVELEVBQUUsK0RBQStELEVBQUUsRUFBRSx5RUFBeUUsMERBQTBELEVBQUUsRUFBRSxpRkFBaUYsMERBQTBELEVBQUUsRUFBRSx1RkFBdUYsK0RBQStELEVBQUUsRUFBRSwwRUFBMEUsMERBQTBELEVBQUUsRUFBRSxrRkFBa0YsMERBQTBELEVBQUUsRUFBRSxxR0FBcUcsMERBQTBELEVBQUUsRUFBRSxnSUFBZ0ksMERBQTBELEVBQUUsRUFBRSx3RkFBd0YsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsRUFBRSxtSEFBbUgsdURBQXVELEVBQUUscUVBQXFFLEVBQUUsRUFBRSxvVkFBb1YsdURBQXVELEVBQUUsRUFBRSxnY0FBZ2MsdURBQXVELEVBQUUsRUFBRSwreUJBQSt5Qix1REFBdUQsRUFBRSxFQUFFLHVnQ0FBdWdDLHVEQUF1RCxFQUFFLEVBQUUsKzRCQUErNEIseUVBQXlFLEVBQUUsRUFBRSwra0NBQStrQyx5RUFBeUUsRUFBRSxFQUFFLGlRQUFpUSxxRUFBcUUsRUFBRSxFQUFFLGlUQUFpVCxxRUFBcUUsRUFBRSxFQUFFLG1EQUFtRCxpRUFBaUUsRUFBRSxFQUFFLDREQUE0RCxpRUFBaUUsRUFBRSxFQUFFLHlEQUF5RCxpRUFBaUUsRUFBRSxFQUFFLGtFQUFrRSxpRUFBaUUsRUFBRSxFQUFFLHdEQUF3RCxpRUFBaUUsRUFBRSxFQUFFLGlFQUFpRSxpRUFBaUUsRUFBRSxFQUFFLG9FQUFvRSwrREFBK0QsRUFBRSwrREFBK0QsRUFBRSxpRUFBaUUsRUFBRSx1RUFBdUUsRUFBRSxxRUFBcUUsRUFBRSw0RUFBNEUsRUFBRSxpRUFBaUUsRUFBRSxpRUFBaUUsRUFBRSxrRUFBa0UsRUFBRSxtRUFBbUUsRUFBRSxzRUFBc0UsRUFBRSxtRUFBbUUsRUFBRSxrRUFBa0UsRUFBRSxpRUFBaUUsRUFBRSxtRUFBbUUsRUFBRSxpRUFBaUUsRUFBRSxnRUFBZ0UsRUFBRSxrRUFBa0UsRUFBRSxpRUFBaUUsRUFBRSw4RUFBOEUsRUFBRSxnRkFBZ0YsRUFBRSwrRUFBK0UsRUFBRSxxRUFBcUUsRUFBRSxxRUFBcUUsRUFBRSxrRUFBa0UsRUFBRSxvRUFBb0UsRUFBRSxvRUFBb0UsRUFBRSxvRUFBb0UsRUFBRSxtRUFBbUUsRUFBRSxpRUFBaUUsRUFBRSw2RUFBNkUsRUFBRSxnRkFBZ0YsRUFBRSxtRUFBbUUsRUFBRSxtRUFBbUUsRUFBRSx1RUFBdUUsRUFBRSx5RUFBeUUsRUFBRSw0RUFBNEUsRUFBRSxzRUFBc0UsRUFBRSx5RUFBeUUsRUFBRSx5RUFBeUUsRUFBRSxvRUFBb0UsRUFBRSxvRUFBb0UsRUFBRSxtRUFBbUUsRUFBRSxrRUFBa0UsRUFBRSwwRUFBMEUsRUFBRSxzRUFBc0UsRUFBRSx5RUFBeUUsRUFBRSw2RUFBNkUsRUFBRSw4RUFBOEUsRUFBRSw4RUFBOEUsRUFBRSxzRUFBc0UsRUFBRSxxRUFBcUUsRUFBRSx1RUFBdUUsRUFBRSwyRUFBMkUsRUFBRSwyRUFBMkUsRUFBRSx3RUFBd0UsRUFBRSx5RUFBeUUsRUFBRSwrRkFBK0YsRUFBRSwyRkFBMkYsRUFBRSw4RkFBOEYsRUFBRSxvR0FBb0csRUFBRSw4RUFBOEUsRUFBRSxvR0FBb0csRUFBRSwrRUFBK0UsRUFBRSxtRkFBbUYsRUFBRSw0RUFBNEUsRUFBRSxnRkFBZ0YsRUFBRSxnRUFBZ0UsRUFBRSxzRUFBc0UsRUFBRSxrRUFBa0UsRUFBRSx3RUFBd0UsRUFBRSxrRUFBa0UsRUFBRSw0RUFBNEUsRUFBRSw2RUFBNkUsRUFBRSw2RUFBNkUsRUFBRSxxRUFBcUUsRUFBRSxvRUFBb0UsRUFBRSxrRUFBa0UsRUFBRSx5RUFBeUUsRUFBRSxtRUFBbUUsRUFBRSx1RUFBdUUsRUFBRSwwRUFBMEUsRUFBRSx1RUFBdUUsRUFBRSx3RUFBd0UsRUFBRSw4RkFBOEYsRUFBRSwwRkFBMEYsRUFBRSw2RkFBNkYsRUFBRSxtR0FBbUcsRUFBRSw2RUFBNkUsRUFBRSxtR0FBbUcsRUFBRSw4RUFBOEUsRUFBRSxrRkFBa0YsRUFBRSwyRUFBMkUsRUFBRSwrRUFBK0UsRUFBRSx3QjtBQUN4Z3VDLElBQUksS0FBVTs7QUFFZDtBQUNBO0FBQ0EsMkJBQTJCLHNJQUFzSTtBQUNqSyxLQUFLO0FBQ0wsQzs7Ozs7Ozs7QUNQQSxnRUFBa0Isa0NBQWtDLFVBQVUsMFFBQTBRLEVBQUUsd0RBQXdELHVEQUF1RCxFQUFFLEVBQUUsMkRBQTJELGtFQUFrRSxFQUFFLEVBQUUsd0RBQXdELHVEQUF1RCxFQUFFLEVBQUUsMkRBQTJELGtFQUFrRSxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsMERBQTBELHFFQUFxRSxFQUFFLEVBQUUsNkRBQTZELDBEQUEwRCxFQUFFLEVBQUUsZ0VBQWdFLHFFQUFxRSxFQUFFLEVBQUUsMkRBQTJELDBEQUEwRCxFQUFFLEVBQUUsOERBQThELHFFQUFxRSxFQUFFLEVBQUUsOERBQThELDhEQUE4RCxFQUFFLEVBQUUsaUVBQWlFLHlFQUF5RSxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsMERBQTBELHFFQUFxRSxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsMERBQTBELHFFQUFxRSxFQUFFLEVBQUUsd0RBQXdELDBEQUEwRCxFQUFFLEVBQUUsMkRBQTJELHFFQUFxRSxFQUFFLEVBQUUseURBQXlELDBEQUEwRCxFQUFFLEVBQUUsNERBQTRELHFFQUFxRSxFQUFFLEVBQUUsNERBQTRELDBEQUEwRCxFQUFFLEVBQUUsK0RBQStELHFFQUFxRSxFQUFFLEVBQUUseURBQXlELDBEQUEwRCxFQUFFLEVBQUUsNERBQTRELHFFQUFxRSxFQUFFLEVBQUUsd0RBQXdELDBEQUEwRCxFQUFFLEVBQUUsMkRBQTJELHFFQUFxRSxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsMERBQTBELHFFQUFxRSxFQUFFLEVBQUUseURBQXlELDBEQUEwRCxFQUFFLEVBQUUsNERBQTRELHFFQUFxRSxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsMERBQTBELHFFQUFxRSxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUseURBQXlELHFFQUFxRSxFQUFFLEVBQUUsd0RBQXdELDBEQUEwRCxFQUFFLEVBQUUsMkRBQTJELHFFQUFxRSxFQUFFLEVBQUUsdURBQXVELHVEQUF1RCxFQUFFLEVBQUUsc0RBQXNELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELHdEQUF3RCxFQUFFLEVBQUUsc0RBQXNELHVEQUF1RCxFQUFFLEVBQUUsb0RBQW9ELHFEQUFxRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsb0RBQW9ELHFEQUFxRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsb0RBQW9ELHFEQUFxRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsb0RBQW9ELHFEQUFxRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsb0RBQW9ELHFEQUFxRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHNEQUFzRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUsb0RBQW9ELHNEQUFzRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDZEQUE2RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUsb0RBQW9ELHNEQUFzRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDZEQUE2RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUsb0RBQW9ELHNEQUFzRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDZEQUE2RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUsb0RBQW9ELHNEQUFzRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDZEQUE2RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUsb0RBQW9ELHNEQUFzRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLEVBQUUsc0RBQXNELDZEQUE2RCxFQUFFLEVBQUUsc0RBQXNELDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDREQUE0RCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsc0RBQXNELDBEQUEwRCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHVEQUF1RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLEVBQUUsdURBQXVELDhEQUE4RCxFQUFFLEVBQUUsdURBQXVELDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDZEQUE2RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsdURBQXVELDJEQUEyRCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUsMERBQTBELDREQUE0RCxFQUFFLEVBQUUsMkRBQTJELDZEQUE2RCxFQUFFLEVBQUUsNERBQTRELDhEQUE4RCxFQUFFLEVBQUUsK0RBQStELHFFQUFxRSxFQUFFLEVBQUUsK0RBQStELHFFQUFxRSxFQUFFLEVBQUUsZ0VBQWdFLHNFQUFzRSxFQUFFLEVBQUUsbUVBQW1FLCtEQUErRCxFQUFFLEVBQUUsaUVBQWlFLDZEQUE2RCxFQUFFLEVBQUUsNERBQTRELDhEQUE4RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUsaUZBQWlGLDREQUE0RCxFQUFFLCtEQUErRCxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsdUlBQXVJLHVEQUF1RCxFQUFFLEVBQUUsMEVBQTBFLDBEQUEwRCxFQUFFLCtEQUErRCxFQUFFLEVBQUUscUdBQXFHLDBEQUEwRCxFQUFFLEVBQUUsbURBQW1ELHlEQUF5RCxFQUFFLEVBQUUsbURBQW1ELHlEQUF5RCxFQUFFLEVBQUUsbURBQW1ELHlEQUF5RCxFQUFFLEVBQUUsbURBQW1ELHlEQUF5RCxFQUFFLEVBQUUsbURBQW1ELHlEQUF5RCxFQUFFLEVBQUUsbURBQW1ELHlEQUF5RCxFQUFFLEVBQUUscURBQXFELHlEQUF5RCxFQUFFLEVBQUUsc0RBQXNELHlEQUF5RCxFQUFFLEVBQUUseURBQXlELHlEQUF5RCxFQUFFLEVBQUUsK0RBQStELHlEQUF5RCxFQUFFLEVBQUUsK0RBQStELHlEQUF5RCxFQUFFLEVBQUUsK0RBQStELHlEQUF5RCxFQUFFLEVBQUUsK0RBQStELHlEQUF5RCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUsa0VBQWtFLHlEQUF5RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsNERBQTRELDREQUE0RCxFQUFFLEVBQUUsMkRBQTJELDhEQUE4RCxFQUFFLEVBQUUsOERBQThELDREQUE0RCxFQUFFLEVBQUUsMERBQTBELGdFQUFnRSxFQUFFLEVBQUUsMERBQTBELGtFQUFrRSxFQUFFLEVBQUUsMkRBQTJELG1FQUFtRSxFQUFFLEVBQUUseURBQXlELG9FQUFvRSxFQUFFLEVBQUUseURBQXlELGtFQUFrRSxFQUFFLEVBQUUsNkRBQTZELDBEQUEwRCxFQUFFLEVBQUUsNERBQTRELDBEQUEwRCxFQUFFLEVBQUUsMkRBQTJELHFFQUFxRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsMERBQTBELHFFQUFxRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsbURBQW1ELHdGQUF3RixFQUFFLEVBQUUsd0RBQXdELDBEQUEwRCxFQUFFLG1FQUFtRSxFQUFFLCtEQUErRCxFQUFFLHlEQUF5RCxFQUFFLEVBQUUsZ0VBQWdFLHVEQUF1RCxFQUFFLEVBQUUsa0VBQWtFLGlFQUFpRSxFQUFFLEVBQUUsb0VBQW9FLDREQUE0RCxFQUFFLEVBQUUsbURBQW1ELHFEQUFxRCxFQUFFLHVEQUF1RCxFQUFFLDBEQUEwRCxFQUFFLCtEQUErRCxFQUFFLCtEQUErRCxFQUFFLEVBQUUsMkRBQTJELDBEQUEwRCxFQUFFLEVBQUUsb0VBQW9FLDBEQUEwRCxFQUFFLEVBQUUscUpBQXFKLHlFQUF5RSxFQUFFLEVBQUUsOEVBQThFLDJEQUEyRCxFQUFFLEVBQUUsaUVBQWlFLHlEQUF5RCxFQUFFLEVBQUUsbUVBQW1FLGdFQUFnRSxFQUFFLHFFQUFxRSxFQUFFLHlEQUF5RCxFQUFFLHNEQUFzRCxFQUFFLDREQUE0RCxFQUFFLHlEQUF5RCxFQUFFLDZEQUE2RCxFQUFFLEVBQUUsbUZBQW1GLHNEQUFzRCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsMkZBQTJGLHdEQUF3RCxFQUFFLEVBQUUscUZBQXFGLHNEQUFzRCxFQUFFLDJEQUEyRCxFQUFFLEVBQUUsNkdBQTZHLHdEQUF3RCxFQUFFLEVBQUUseUlBQXlJLHNEQUFzRCxFQUFFLDREQUE0RCxFQUFFLEVBQUUseUxBQXlMLHdEQUF3RCxFQUFFLEVBQUUsMkZBQTJGLDhEQUE4RCxFQUFFLEVBQUUscUdBQXFHLHVEQUF1RCxFQUFFLEVBQUUsbUZBQW1GLGdFQUFnRSxFQUFFLCtFQUErRSxFQUFFLEVBQUUsaUdBQWlHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsaUhBQWlILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsaUdBQWlHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsaUhBQWlILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsbUdBQW1HLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsbUhBQW1ILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLDBEQUEwRCxFQUFFLEVBQUUscUdBQXFHLDBEQUEwRCxFQUFFLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLEVBQUUscUhBQXFILDBEQUEwRCxFQUFFLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLEVBQUUsaUdBQWlHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsaUhBQWlILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsbUdBQW1HLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsbUhBQW1ILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsaUdBQWlHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsaUhBQWlILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUscUdBQXFHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUscUhBQXFILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUscUdBQXFHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUscUhBQXFILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsaUdBQWlHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsaUhBQWlILHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsK0ZBQStGLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsK0dBQStHLHFFQUFxRSxFQUFFLGlFQUFpRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsK0RBQStELDBEQUEwRCxFQUFFLGtFQUFrRSxFQUFFLEVBQUUsaUZBQWlGLHVEQUF1RCxFQUFFLHFFQUFxRSxFQUFFLEVBQUUsMEZBQTBGLHFEQUFxRCxFQUFFLHNEQUFzRCxFQUFFLEVBQUUsbUVBQW1FLHlEQUF5RCxFQUFFLEVBQUUsbUZBQW1GLHlEQUF5RCxFQUFFLEVBQUUscUdBQXFHLHFFQUFxRSxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsMkZBQTJGLHlEQUF5RCxFQUFFLEVBQUUsNkhBQTZILDBEQUEwRCxFQUFFLEVBQUUsNklBQTZJLDBEQUEwRCxFQUFFLEVBQUUsbUZBQW1GLHdEQUF3RCxFQUFFLEVBQUUscUhBQXFILGlGQUFpRixFQUFFLEVBQUUscUlBQXFJLGlGQUFpRixFQUFFLEVBQUUsc0VBQXNFLGtFQUFrRSxFQUFFLHNFQUFzRSxFQUFFLEVBQUUsd0ZBQXdGLHlEQUF5RCxFQUFFLEVBQUUsc0ZBQXNGLDJEQUEyRCxFQUFFLHlFQUF5RSxFQUFFLEVBQUUsMEhBQTBILHNEQUFzRCxFQUFFLEVBQUUsNEZBQTRGLHlFQUF5RSxFQUFFLHNEQUFzRCxFQUFFLHFEQUFxRCxFQUFFLEVBQUUsOEdBQThHLHNEQUFzRCxFQUFFLGtFQUFrRSxFQUFFLEVBQUUsOEdBQThHLDhEQUE4RCxFQUFFLEVBQUUsOEpBQThKLHVEQUF1RCxFQUFFLHVEQUF1RCxFQUFFLEVBQUUscUpBQXFKLHVEQUF1RCxFQUFFLEVBQUUsK0xBQStMLHNEQUFzRCxFQUFFLEVBQUUsaU5BQWlOLGtFQUFrRSxFQUFFLHVEQUF1RCxFQUFFLEVBQUUsK1FBQStRLHFEQUFxRCxFQUFFLHNEQUFzRCxFQUFFLDREQUE0RCxFQUFFLDREQUE0RCxFQUFFLEVBQUUsMEhBQTBILGtFQUFrRSxFQUFFLEVBQUUsd0pBQXdKLHlEQUF5RCxFQUFFLEVBQUUsZ0xBQWdMLDhEQUE4RCxFQUFFLEVBQUUsMEtBQTBLLG9FQUFvRSxFQUFFLGtFQUFrRSxFQUFFLHNFQUFzRSxFQUFFLEVBQUUsK0tBQStLLHlEQUF5RCxFQUFFLHFEQUFxRCxFQUFFLHdEQUF3RCxFQUFFLDhEQUE4RCxFQUFFLEVBQUUsdUVBQXVFLHNEQUFzRCxFQUFFLEVBQUUsK0RBQStELHlFQUF5RSxFQUFFLEVBQUUsZ0hBQWdILHVEQUF1RCxFQUFFLHVEQUF1RCxFQUFFLGtFQUFrRSxFQUFFLEVBQUUsNEhBQTRILHNEQUFzRCxFQUFFLGtFQUFrRSxFQUFFLEVBQUUsNEhBQTRILHlEQUF5RCxFQUFFLEVBQUUsNEhBQTRILHNEQUFzRCxFQUFFLHFEQUFxRCxFQUFFLDhEQUE4RCxFQUFFLGtFQUFrRSxFQUFFLDREQUE0RCxFQUFFLEVBQUUsa0lBQWtJLHVEQUF1RCxFQUFFLEVBQUUsMk1BQTJNLDJEQUEyRCxFQUFFLDREQUE0RCxFQUFFLG9FQUFvRSxFQUFFLEVBQUUseVFBQXlRLGtFQUFrRSxFQUFFLEVBQUUsc0hBQXNILDREQUE0RCxFQUFFLHNEQUFzRCxFQUFFLGtFQUFrRSxFQUFFLHVEQUF1RCxFQUFFLG1FQUFtRSxFQUFFLEVBQUUsa0lBQWtJLGtFQUFrRSxFQUFFLEVBQUUsK05BQStOLHlEQUF5RCxFQUFFLHFEQUFxRCxFQUFFLEVBQUUsZ0lBQWdJLHFFQUFxRSxFQUFFLEVBQUUsNElBQTRJLDBEQUEwRCxFQUFFLEVBQUUsK0RBQStELDJFQUEyRSxFQUFFLDREQUE0RCxFQUFFLEVBQUUsK0VBQStFLHNGQUFzRixFQUFFLEVBQUUsaUZBQWlGLG9FQUFvRSxFQUFFLEVBQUUsNkdBQTZHLHdEQUF3RCxFQUFFLEVBQUUsNkZBQTZGLDBEQUEwRCxFQUFFLEVBQUUsK0dBQStHLDBEQUEwRCxFQUFFLEVBQUUsK0ZBQStGLHlEQUF5RCxFQUFFLEVBQUUsNkZBQTZGLHdEQUF3RCxFQUFFLHNEQUFzRCxFQUFFLEVBQUUseUhBQXlILDBEQUEwRCxFQUFFLHlEQUF5RCxFQUFFLHNEQUFzRCxFQUFFLHNEQUFzRCxFQUFFLEVBQUUsaUdBQWlHLHNEQUFzRCxFQUFFLG9FQUFvRSxFQUFFLEVBQUUsK0dBQStHLHNEQUFzRCxFQUFFLHFEQUFxRCxFQUFFLEVBQUUscUdBQXFHLHVEQUF1RCxFQUFFLEVBQUUsc01BQXNNLDZEQUE2RCxFQUFFLEVBQUUsd1FBQXdRLDREQUE0RCxFQUFFLGlFQUFpRSxFQUFFLEVBQUUsNExBQTRMLCtEQUErRCxFQUFFLDREQUE0RCxFQUFFLHlFQUF5RSxFQUFFLHlEQUF5RCxFQUFFLDBEQUEwRCxFQUFFLHdEQUF3RCxFQUFFLEVBQUUsbWRBQW1kLDJEQUEyRCxFQUFFLDREQUE0RCxFQUFFLDBEQUEwRCxFQUFFLEVBQUUsb1FBQW9RLDhEQUE4RCxFQUFFLEVBQUUsb1VBQW9VLHVEQUF1RCxFQUFFLEVBQUUsMkVBQTJFLHdEQUF3RCxFQUFFLEVBQUUsd0RBQXdELDJEQUEyRCxFQUFFLEVBQUUsMkZBQTJGLDBEQUEwRCxFQUFFLEVBQUUsNkVBQTZFLDhEQUE4RCxFQUFFLEVBQUUsNEVBQTRFLHFEQUFxRCxFQUFFLHNEQUFzRCxFQUFFLDhEQUE4RCxFQUFFLHVEQUF1RCxFQUFFLEVBQUUscUtBQXFLLHdFQUF3RSxFQUFFLDZFQUE2RSxFQUFFLEVBQUUscU5BQXFOLGtFQUFrRSxFQUFFLEVBQUUsOEdBQThHLGlGQUFpRix3UUFBd1EsRUFBRSxFQUFFLDhHQUE4RyxpRkFBaUYsb21CQUFvbUIsRUFBRSxFQUFFLG9FQUFvRSxzREFBc0QsRUFBRSxpRkFBaUYsNHVCQUE0dUIsRUFBRSxFQUFFLDRFQUE0RSxrRUFBa0UsRUFBRSxFQUFFLHlKQUF5SixrRUFBa0UsRUFBRSwyREFBMkQsRUFBRSxxREFBcUQsRUFBRSxFQUFFLG9MQUFvTCxrRUFBa0UsRUFBRSx5RUFBeUUsRUFBRSxFQUFFLG9GQUFvRiw0REFBNEQsRUFBRSxFQUFFLDJEQUEyRCxpRkFBaUYsb1FBQW9RLEVBQUUsRUFBRSxnRUFBZ0Usc0RBQXNELEVBQUUscURBQXFELEVBQUUsRUFBRSxtRUFBbUUsd0VBQXdFLEVBQUUsRUFBRSxxRUFBcUUsc0RBQXNELEVBQUUseURBQXlELEVBQUUsMERBQTBELEVBQUUsb0VBQW9FLEVBQUUsRUFBRSxvRUFBb0UsaUZBQWlGLDRTQUE0UyxFQUFFLEVBQUUsd0VBQXdFLGlGQUFpRiw0U0FBNFMsRUFBRSxFQUFFLHdFQUF3RSxpRkFBaUYsNG9CQUE0b0IsRUFBRSxFQUFFLDZFQUE2RSxpRkFBaUYsb3hCQUFveEIsRUFBRSxFQUFFLHNLQUFzSywwREFBMEQsRUFBRSxFQUFFLDBFQUEwRSwwREFBMEQsRUFBRSxFQUFFLG1FQUFtRSx3REFBd0QsRUFBRSxFQUFFLHFHQUFxRyx5REFBeUQsRUFBRSwwREFBMEQsRUFBRSxFQUFFLGtRQUFrUSx3REFBd0QsRUFBRSxFQUFFLGlGQUFpRiwwREFBMEQsRUFBRSxFQUFFLDZGQUE2Rix3REFBd0QsRUFBRSxFQUFFLHlIQUF5SCx5REFBeUQsRUFBRSxrRUFBa0UsRUFBRSxtRUFBbUUsRUFBRSw4REFBOEQsRUFBRSxFQUFFLHdGQUF3Rix5REFBeUQsRUFBRSxFQUFFLG9WQUFvVixnRUFBZ0UsRUFBRSx5REFBeUQsRUFBRSx5REFBeUQsRUFBRSxxREFBcUQsRUFBRSx3REFBd0QsRUFBRSx1REFBdUQsRUFBRSwyREFBMkQsRUFBRSxnRUFBZ0UsRUFBRSwrREFBK0QsRUFBRSxFQUFFLHdhQUF3YSx1REFBdUQsRUFBRSxFQUFFLDBHQUEwRyw2REFBNkQsRUFBRSx5REFBeUQsRUFBRSxFQUFFLHFMQUFxTCwyREFBMkQsRUFBRSxFQUFFLHFZQUFxWSwwREFBMEQsRUFBRSxFQUFFLGlRQUFpUSx3REFBd0QsRUFBRSxFQUFFLDBHQUEwRyx1REFBdUQsRUFBRSxFQUFFLHdNQUF3TSx5REFBeUQsRUFBRSxrRUFBa0UsRUFBRSw4REFBOEQsRUFBRSxFQUFFLHlIQUF5SCx3REFBd0QsRUFBRSx1REFBdUQsRUFBRSxFQUFFLDZKQUE2SixzREFBc0QsRUFBRSxrRUFBa0UsRUFBRSxFQUFFLDhJQUE4SSwwREFBMEQsRUFBRSxrRUFBa0UsRUFBRSxFQUFFLDZKQUE2SixtRUFBbUUsRUFBRSxFQUFFLGtMQUFrTCwwREFBMEQsRUFBRSxxREFBcUQsRUFBRSxFQUFFLG1FQUFtRSxrRUFBa0UsRUFBRSwwREFBMEQsRUFBRSxFQUFFLHFGQUFxRixxRUFBcUUsRUFBRSwwREFBMEQsRUFBRSxFQUFFLHVIQUF1SCwwREFBMEQsRUFBRSxFQUFFLDJKQUEySiwwREFBMEQsRUFBRSxFQUFFLHFGQUFxRixrRUFBa0UsRUFBRSxpRUFBaUUsRUFBRSxFQUFFLHVHQUF1RyxxRUFBcUUsRUFBRSxpRUFBaUUsRUFBRSxFQUFFLDREQUE0RCxtREFBbUQsa0VBQWtFLEVBQUUsRUFBRSxxREFBcUQscUVBQXFFLEVBQUUsRUFBRSxFQUFFLDJEQUEyRCxtREFBbUQscUVBQXFFLEVBQUUsRUFBRSxxREFBcUQscUVBQXFFLEVBQUUsRUFBRSxFQUFFLDJKQUEySiw4RkFBOEYsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLCtMQUErTCw2RkFBNkYsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLHFGQUFxRix1REFBdUQsRUFBRSxxRUFBcUUsRUFBRSxpRUFBaUUsRUFBRSxFQUFFLHVHQUF1Ryx1REFBdUQsRUFBRSxxRUFBcUUsRUFBRSxpRUFBaUUsRUFBRSxFQUFFLGtFQUFrRSxtREFBbUQscUVBQXFFLEVBQUUsRUFBRSxxREFBcUQscUVBQXFFLEVBQUUsRUFBRSxFQUFFLGlFQUFpRSxtREFBbUQscUVBQXFFLEVBQUUsRUFBRSxxREFBcUQscUVBQXFFLEVBQUUsRUFBRSxFQUFFLDJKQUEySixvR0FBb0csRUFBRSxxRUFBcUUsRUFBRSxFQUFFLCtMQUErTCxtR0FBbUcsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLDBGQUEwRiwwREFBMEQsRUFBRSxFQUFFLDRHQUE0RywwREFBMEQsRUFBRSxFQUFFLGdGQUFnRiwwREFBMEQsRUFBRSxrRUFBa0UsRUFBRSw4RUFBOEUsRUFBRSxFQUFFLGtHQUFrRyx1REFBdUQsRUFBRSxxRUFBcUUsRUFBRSw4RUFBOEUsRUFBRSxFQUFFLGdHQUFnRyx3REFBd0QsRUFBRSwwREFBMEQsRUFBRSxFQUFFLGdIQUFnSCwwREFBMEQsRUFBRSxFQUFFLHVFQUF1RSwwREFBMEQsRUFBRSxpRkFBaUYsRUFBRSxFQUFFLHlGQUF5RiwwREFBMEQsRUFBRSxpRkFBaUYsRUFBRSxFQUFFLG1FQUFtRSwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLHFGQUFxRiwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLHFMQUFxTCwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLDBFQUEwRSwwREFBMEQsRUFBRSxrRUFBa0UsRUFBRSwwRUFBMEUsRUFBRSxvRkFBb0YsRUFBRSxFQUFFLDRGQUE0Rix1REFBdUQsRUFBRSxxRUFBcUUsRUFBRSwwRUFBMEUsRUFBRSxvRkFBb0YsRUFBRSxFQUFFLDJGQUEyRix1REFBdUQsRUFBRSxrRUFBa0UsRUFBRSxFQUFFLDJHQUEyRywwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLHVIQUF1SCwwREFBMEQsRUFBRSxFQUFFLHVJQUF1SSwwREFBMEQsRUFBRSxFQUFFLDZIQUE2SCwwREFBMEQsRUFBRSxFQUFFLDZJQUE2SSwwREFBMEQsRUFBRSxFQUFFLG1GQUFtRix1REFBdUQsRUFBRSxxRUFBcUUsRUFBRSx5RUFBeUUsRUFBRSxFQUFFLG1HQUFtRywwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSx5RUFBeUUsRUFBRSxFQUFFLHFIQUFxSCxpRkFBaUYsRUFBRSxFQUFFLHFJQUFxSSxpRkFBaUYsRUFBRSxFQUFFLHNFQUFzRSw0RUFBNEUsRUFBRSxzRUFBc0UsRUFBRSxtRUFBbUUsRUFBRSx5RkFBeUYsRUFBRSxFQUFFLHdGQUF3Riw0RUFBNEUsRUFBRSx5RUFBeUUsRUFBRSxtRUFBbUUsRUFBRSx5RkFBeUYsRUFBRSxFQUFFLHNGQUFzRiw0RUFBNEUsRUFBRSx5RUFBeUUsRUFBRSxtRUFBbUUsRUFBRSx5RkFBeUYsRUFBRSxFQUFFLHdFQUF3RSxvRUFBb0UsRUFBRSwrREFBK0QsRUFBRSxFQUFFLDBGQUEwRixvRUFBb0UsRUFBRSwrREFBK0QsRUFBRSxFQUFFLGtGQUFrRiwwREFBMEQsRUFBRSxFQUFFLG9HQUFvRyx1REFBdUQsRUFBRSxFQUFFLCtKQUErSiwwREFBMEQsRUFBRSxFQUFFLG1NQUFtTSwwREFBMEQsRUFBRSxFQUFFLHNGQUFzRiw0REFBNEQsRUFBRSxFQUFFLHdHQUF3RywrREFBK0QsRUFBRSxFQUFFLHNGQUFzRixnR0FBZ0csRUFBRSxpRUFBaUUsRUFBRSxFQUFFLGlIQUFpSCxnR0FBZ0csRUFBRSxFQUFFLG9NQUFvTSxrRkFBa0YsRUFBRSxFQUFFLDBQQUEwUCxrRkFBa0YsRUFBRSxFQUFFLDBIQUEwSCxxRUFBcUUsRUFBRSxFQUFFLHFKQUFxSix3RUFBd0UsRUFBRSxFQUFFLGlIQUFpSCxvRUFBb0UsRUFBRSxFQUFFLHdKQUF3SixxRUFBcUUsRUFBRSxFQUFFLDBLQUEwSywwREFBMEQsRUFBRSxFQUFFLHFNQUFxTSx1REFBdUQsRUFBRSxFQUFFLCtLQUErSywwREFBMEQsRUFBRSxFQUFFLHFPQUFxTywwREFBMEQsRUFBRSxFQUFFLGdIQUFnSCwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLG1KQUFtSixrRUFBa0UsRUFBRSxFQUFFLDBJQUEwSSxrRkFBa0YsRUFBRSxFQUFFLHNKQUFzSiwwREFBMEQsRUFBRSxFQUFFLHFOQUFxTiwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLDZUQUE2VCxxRUFBcUUsRUFBRSxFQUFFLHlRQUF5USxrRkFBa0YsRUFBRSxFQUFFLGlTQUFpUywwREFBMEQsRUFBRSxFQUFFLDRMQUE0TCx5RUFBeUUsRUFBRSwwREFBMEQsRUFBRSxzRUFBc0UsRUFBRSxpRUFBaUUsRUFBRSxFQUFFLG9RQUFvUSx1REFBdUQsRUFBRSxzRUFBc0UsRUFBRSxpRUFBaUUsRUFBRSxFQUFFLDRPQUE0TyxpRUFBaUUsRUFBRSxFQUFFLG9UQUFvVCxpRUFBaUUsRUFBRSxFQUFFLG9VQUFvVSwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLDRZQUE0WSwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLHVGQUF1RixpRUFBaUUsRUFBRSxFQUFFLGdHQUFnRyxpRUFBaUUsRUFBRSxFQUFFLDZFQUE2RSxxRUFBcUUsRUFBRSxFQUFFLHNGQUFzRixxRUFBcUUsRUFBRSxFQUFFLHNGQUFzRixxRUFBcUUsRUFBRSxFQUFFLCtGQUErRixxRUFBcUUsRUFBRSxFQUFFLG1GQUFtRiwwREFBMEQsRUFBRSxFQUFFLDRGQUE0RiwwREFBMEQsRUFBRSxFQUFFLHNGQUFzRiwwREFBMEQsRUFBRSxrRUFBa0UsRUFBRSxFQUFFLCtGQUErRix1REFBdUQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLDJEQUEyRCwwREFBMEQsRUFBRSxzRUFBc0UsRUFBRSxFQUFFLG9FQUFvRSx1REFBdUQsRUFBRSxzRUFBc0UsRUFBRSxFQUFFLDBFQUEwRSwwREFBMEQsRUFBRSxrRUFBa0UsRUFBRSxFQUFFLG1GQUFtRix1REFBdUQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLG1FQUFtRSwwREFBMEQsRUFBRSw0REFBNEQsRUFBRSxFQUFFLDRFQUE0RSx1REFBdUQsRUFBRSwrREFBK0QsRUFBRSxFQUFFLHFFQUFxRSxvRkFBb0YsRUFBRSxFQUFFLDhFQUE4RSxvRkFBb0YsRUFBRSxFQUFFLHFHQUFxRyx1REFBdUQsRUFBRSwrREFBK0QsRUFBRSxFQUFFLGlFQUFpRSwwREFBMEQsRUFBRSw0REFBNEQsRUFBRSxFQUFFLHlFQUF5RSx1REFBdUQsRUFBRSwrREFBK0QsRUFBRSxFQUFFLHlFQUF5RSwwREFBMEQsRUFBRSxFQUFFLGlGQUFpRiwwREFBMEQsRUFBRSxFQUFFLHVGQUF1RiwrREFBK0QsRUFBRSxFQUFFLDBFQUEwRSwwREFBMEQsRUFBRSxFQUFFLGtGQUFrRiwwREFBMEQsRUFBRSxFQUFFLHFHQUFxRywwREFBMEQsRUFBRSxFQUFFLGdJQUFnSSwwREFBMEQsRUFBRSxFQUFFLHdGQUF3RiwwREFBMEQsRUFBRSxrRUFBa0UsRUFBRSxFQUFFLG1IQUFtSCwwREFBMEQsRUFBRSxxRUFBcUUsRUFBRSxFQUFFLG9WQUFvViwwREFBMEQsRUFBRSxFQUFFLGdjQUFnYywwREFBMEQsRUFBRSxFQUFFLCt5QkFBK3lCLDBEQUEwRCxFQUFFLEVBQUUsdWdDQUF1Z0MsMERBQTBELEVBQUUsRUFBRSwrNEJBQSs0Qix5RUFBeUUsRUFBRSxFQUFFLCtrQ0FBK2tDLHlFQUF5RSxFQUFFLEVBQUUsaVFBQWlRLGtFQUFrRSxFQUFFLEVBQUUsaVRBQWlULHFFQUFxRSxFQUFFLHdCO0FBQzdpNUcsSUFBSSxLQUFVOztBQUVkO0FBQ0E7QUFDQSwyQkFBMkIsc0lBQXNJO0FBQ2pLLEtBQUs7QUFDTCxDOzs7Ozs7Ozs7QUNQQTtBQUFBO0FBQUE7QUFBa0Q7O0FBRWxEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRU8saUJBQWlCLHVFQUFZO0FBQ3BDLFFBQVEsc0NBQXNDO0FBQzlDLFFBQVEsWUFBWTs7QUFFcEI7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsRUFBRTs7QUFFRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBLEVBQUU7O0FBRUY7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSx3QkFBd0IsU0FBUyxNQUFNO0FBQ3ZDLENBQUM7Ozs7Ozs7Ozs7QUN0R0Q7QUFBQTtBQUFBO0FBQXFDOztBQUVyQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFTztBQUNQLGlDQUFpQywwQkFBMEI7QUFDM0Q7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7O0FBRUgscUNBQXFDOztBQUVyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHdCQUF3QiwwREFBVzs7QUFFbkM7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQSxZQUFZLHdCQUF3Qjs7QUFFcEM7QUFDQTtBQUNBLEdBQUc7O0FBRUg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQSxHQUFHOztBQUVIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsdUVBQXVFLEdBQUc7QUFDMUU7O0FBRUE7QUFDQTs7Ozs7Ozs7O0FDdkdBO0FBQUE7QUFBQTtBQUFBO0FBQXdDOzs7Ozs7Ozs7QUNBeEM7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxXQUFXLEtBQUs7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLFdBQVcsS0FBSztBQUNoQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsdUJBQXVCLGlCQUFpQjtBQUN4QztBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUJBQWlCLGlCQUFpQjtBQUNsQztBQUNBOztBQUVBO0FBQ0EscUJBQXFCLFVBQVU7QUFDL0I7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZSwyRUFBWTs7Ozs7Ozs7O0FDakkzQjtBQUFBO0FBQUE7QUFBQTtBQUNvQzs7QUFFcEM7O0FBRWU7QUFDZjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsd0RBQVk7QUFDdEM7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLFlBQVk7QUFDN0IsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLG1CQUFtQjtBQUNwQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUJBQWlCLFlBQVk7QUFDN0IsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOzs7Ozs7Ozs7QUNuRkE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFdUQ7O0FBRXZEO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUEsK0JBQStCLG9CQUFvQjs7QUFFbkQsK0NBQStDO0FBQy9DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSxHQUFHO0FBQ0g7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIseUJBQXlCLHVCQUF1QjtBQUNuRTtBQUNBO0FBQ0EsS0FBSztBQUNMLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiLFdBQVc7QUFDWCxtREFBbUQsaUJBQWlCO0FBQ3BFO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYLG9EQUFvRCxVQUFVLElBQUksVUFBVTtBQUM1RTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBLFdBQVcsdUJBQXVCOztBQUVsQztBQUNBO0FBQ0E7QUFDQSx3REFBd0Q7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQSxZQUFZLDRFQUFzQjtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVCxPQUFPO0FBQ1AsS0FBSztBQUNMLGFBQWEsaUJBQWlCO0FBQzlCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ087QUFDUDs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsdUJBQXVCLFVBQVU7O0FBRWpDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWU7QUFDZixhQUFhO0FBQ2I7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQ0FBc0MsVUFBVTtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxHQUFHOztBQUVIO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLHdCQUF3QjtBQUN2RCxjQUFjLHdCQUF3Qjs7QUFFdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQSxnQ0FBZ0MsVUFBVSxJQUFJLDBCQUEwQjtBQUN4RTtBQUNBO0FBQ0E7QUFDQSxLQUFLOztBQUVMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBOztBQUVBLFVBQVU7QUFDVjs7Ozs7Ozs7O0FDeFRBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUt3Qjs7QUFFeEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsb0JBQW9CO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0Isb0JBQW9CO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixPQUFPO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsd0JBQXdCO0FBQ2pDLEdBQUc7QUFDSCxxQ0FBcUMsb0JBQW9CO0FBQ3pELFVBQVU7QUFDVjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLDBCQUEwQjtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsNkJBQTZCLE9BQU8sS0FBSztBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLGNBQWM7QUFDN0I7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTs7QUFFTztBQUNQO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEI7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQSxPQUFPLGlCQUFpQjtBQUN4QjtBQUNBOztBQUVBO0FBQ0E7QUFDQSxNQUFNLDZFQUFxQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLGlCQUFpQjtBQUM5QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsNkVBQXFCO0FBQzNDLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx3QkFBd0IsaUVBQWlCO0FBQ3pDLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7O0FBRUE7QUFDQTs7Ozs7Ozs7O0FDclJBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQytDOztBQUUvQztBQUNBO0FBQ0E7QUFDQTs7QUFFQSxZQUFZLDZEQUFJOztBQUVoQjs7QUFFTztBQUNQO0FBQ0E7QUFDQTs7QUFFQSxFQUFFLDZEQUFJO0FBQ047QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsNENBQTRDLFlBQVksZ0JBQWdCOztBQUV4RTtBQUNBO0FBQ0E7O0FBRU87Ozs7Ozs7OztBQzlEUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFFMEQ7O0FBRVI7O0FBRW9COztBQUV0RSw2RUFBYzs7QUFFZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsMkJBQTJCLGFBQWE7QUFDeEM7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQSx1QkFBdUIsNkJBQTZCLElBQUk7QUFDeEQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMLEdBQUc7QUFDSDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9CQUFvQix3RUFBYztBQUNsQztBQUNBO0FBQ0E7QUFDQTs7QUFFZSxpQ0FBaUMsMERBQWU7QUFDL0Q7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsS0FBSztBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0I7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxXQUFXLG9DQUFvQztBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsYUFBYTtBQUNoQyxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQSxVQUFVLHFCQUFxQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCLDJFQUFZOztBQUVsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYSxhQUFhO0FBQzFCLGFBQWEsa0JBQWtCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLG9CQUFvQixrQkFBa0I7QUFDNUU7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxpQkFBaUIsbUJBQW1CO0FBQ3BDLEtBQUs7QUFDTCxXQUFXLDhDQUE4QztBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLDRCQUE0QixtQkFBbUI7QUFDL0MsV0FBVywyQ0FBMkM7QUFDdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLE1BQU07QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDalZBO0FBQUE7QUFBQTtBQUFxVjs7QUFFclY7O0FBRUEsNENBQTRDLDRCQUE0QjtBQUN4RSwwQ0FBMEMsc0JBQXNCOztBQUVoRTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IsbUVBQVc7O0FBRWpDO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsbUJBQW1CLHdFQUFnQiw0RUFBNEUsd0VBQWdCO0FBQy9IO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHLHFFQUFhO0FBQ2hCO0FBQ0EsR0FBRztBQUNIO0FBQ0EsR0FBRyxzRUFBYztBQUNqQjtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsTUFBTSxhQUFhLFdBQVc7O0FBRTlCO0FBQ0EsNEJBQTRCLDhEQUFNLENBQUMsOERBQU0sR0FBRyxZQUFZLDhFQUFzQjtBQUM5RTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSxXQUFXLDhFQUFzQjtBQUNqQztBQUNBOztBQUVBLDRCQUE0QiwrREFBZTtBQUMzQztBQUNBO0FBQ0EsRUFBRSw0REFBSSwyQ0FBMkMsOERBQWMsSUFBSTtBQUNuRTtBQUNBOztBQUVBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDLHVDQUF1QyxrQkFBa0IsaUNBQWlDO0FBQzFGO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDRCQUE0Qiw4REFBTSxDQUFDLDhEQUFNLEdBQUcsWUFBWSw4RUFBc0I7QUFDOUU7O0FBRUEsV0FBVyw4RUFBc0I7QUFDakM7QUFDQTs7QUFFQSwwQkFBMEIsK0RBQWU7QUFDekM7QUFDQTtBQUNBLEVBQUUsNERBQUksa0NBQWtDLDhEQUFjLEdBQUcsZUFBZTtBQUN4RTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhDQUE4QyxnQ0FBZ0M7O0FBRTlFO0FBQ0E7QUFDQSxDQUFDOztBQUVELHVDQUF1QyxTQUFTO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQixtRUFBVzs7QUFFakM7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxtQkFBbUIsd0VBQWdCLDhFQUE4RSx3RUFBZ0I7QUFDakk7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBLEdBQUcscUVBQWE7QUFDaEI7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHLHNFQUFjO0FBQ2pCO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxpQ0FBaUMsR0FBRyxlQUFlO0FBQ2xHOztBQUVBLGdCQUFnQiw4QkFBOEI7QUFDOUMsb0JBQW9CLDhEQUFNO0FBQzFCOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU0sUUFBUSxPQUFPLFdBQVc7QUFDaEMsTUFBTSxRQUFRO0FBQ2Q7QUFDQSxHQUFHO0FBQ0gsWUFBWTtBQUNaOztBQUVBO0FBQ0E7QUFDQTs7QUFFQSxzQ0FBc0MsMkJBQTJCO0FBQ2pFLENBQUMsaUVBQWlCLFlBQVksNERBQUk7O0FBRWxDO0FBQ0E7QUFDQTtBQUNBLE9BQU8sNkRBQUs7QUFDWixHQUFHLHdFQUFnQjtBQUNuQixHQUFHLHNFQUFjO0FBQ2pCLEdBQUc7QUFDSDtBQUNBLEdBQUcsOERBQU07QUFDVCxHQUFHLDhEQUFNO0FBQ1QsR0FBRyx1RUFBZTtBQUNsQjtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUcsc0VBQWMsYUFBYSx5RUFBaUI7QUFDL0M7QUFDQSxtQ0FBbUMsaUNBQWlDO0FBQ3BFLEtBQUs7QUFDTDs7QUFFQTs7QUFFQTtBQUNBLG1DQUFtQztBQUNuQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxJQUFJLDBFQUFrQjtBQUN0Qjs7QUFFQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0EsR0FBRyxxRUFBYTtBQUNoQjtBQUNBLEdBQUc7QUFDSDtBQUNBLEdBQUcsc0VBQWM7QUFDakI7QUFDQSxHQUFHO0FBQ0g7QUFDQSxrQkFBa0IsOERBQU07QUFDeEIsa0JBQWtCLDhEQUFNO0FBQ3hCLEdBQUcseUVBQWlCO0FBQ3BCO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsTUFBTSxhQUFhLFdBQVc7O0FBRTlCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsNEJBQTRCLDhEQUFNLENBQUMsOERBQU0sR0FBRyxZQUFZLDhFQUFzQjtBQUM5RTtBQUNBOztBQUVBLFdBQVcsOEVBQXNCO0FBQ2pDO0FBQ0E7O0FBRUEsdUJBQXVCLCtEQUFlO0FBQ3RDO0FBQ0E7QUFDQSxFQUFFLDREQUFJLCtDQUErQyw4REFBYyxJQUFJO0FBQ3ZFO0FBQ0E7O0FBRW9COzs7Ozs7Ozs7QUMvUHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTJEO0FBQ0w7QUFDK0I7QUFDQTtBQUNDO0FBQ2pCO0FBQ3FCO0FBQ2pDO0FBQ1c7QUFDc0I7QUFDakI7QUFDekI7QUFDVztBQUNrQjtBQUNTO0FBQzFCOztBQUU1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLDRCQUE0QjtBQUM3QiwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxjQUFjO0FBQ2Q7QUFDQSx1QkFBdUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixzQkFBc0IsR0FBRyxhQUFhO0FBQ3hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsS0FBSyxHQUFHLEtBQUs7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUM7QUFDdkMsK0JBQStCO0FBQy9CO0FBQ0Esc0NBQXNDLEtBQUssR0FBRyxVQUFVLEdBQUcsY0FBYztBQUN6RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsS0FBSyxHQUFHLFVBQVU7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsS0FBSyxHQUFHLFVBQVU7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsaUJBQWlCLFFBQVEsR0FBRyxhQUFhO0FBQ3pDO0FBQ0E7QUFDQSwwQkFBMEI7QUFDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0JBQWtCLHNCQUFzQixHQUFHLGFBQWEsSUFBSSxrQkFBa0I7QUFDOUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsZUFBZTtBQUN0RDtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyxxQkFBcUI7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhEQUE4RCxZQUFZO0FBQzFFO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscURBQXFELEVBQUU7QUFDdkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEJBQTRCLHlFQUFPO0FBQ25DO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxLQUFLO0FBQ3BELG9CQUFvQix5RUFBTztBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0IsMkVBQU07QUFDdEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLHNEQUFzRDtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2RUFBNkU7QUFDN0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsS0FBSyxHQUFHLG9CQUFvQjtBQUM1RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlHQUFpRyx1R0FBZTtBQUNoSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxZQUFZLGtFQUFTO0FBQ3JCO0FBQ0E7QUFDQSxZQUFZLDhEQUFLO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0QsS0FBSyxHQUFHLHVCQUF1QixHQUFHLE1BQU07QUFDMUY7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1RUFBdUUsSUFBSSxNQUFNLGNBQWMsSUFBSSxVQUFVO0FBQzdHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4RkFBOEY7QUFDOUY7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSw0RkFBNEY7QUFDNUY7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwRUFBMEU7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw2Q0FBNkMsVUFBVTtBQUN2RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlDQUFpQyxtR0FBa0IseUNBQXlDLDBDQUEwQztBQUN0STtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxrR0FBaUI7QUFDckQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQyxVQUFVO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0Esa0RBQWtELE1BQU07QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQ0FBaUMsS0FBSyxHQUFHLFNBQVMsR0FBRyxNQUFNO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwyQ0FBMkMsS0FBSyxHQUFHLE1BQU07QUFDekQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsS0FBSyxHQUFHLE1BQU07QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxrRkFBVTtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxvRUFBVztBQUM3QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0Msa0ZBQVU7QUFDNUM7QUFDQTtBQUNBLHVDQUF1QyxvRUFBVztBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVDQUF1Qyw2REFBSTtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxzQkFBc0IsNkRBQUk7QUFDMUI7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsdUJBQXVCLCtEQUFLO0FBQzVCO0FBQ0E7QUFDQTtBQUNBLHlDQUF5QyxNQUFNO0FBQy9DO0FBQ0Esa0NBQWtDLHlCQUF5QixFQUFFO0FBQzdELHNDQUFzQyxnREFBZ0Q7QUFDdEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrQ0FBa0MseURBQXlEO0FBQzNGO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhDQUE4QyxTQUFTO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwwQkFBMEIsc0VBQVE7QUFDbEMsMkJBQTJCLHNFQUFRLDhCQUE4QiwyQkFBMkIsRUFBRTtBQUM5RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0RUFBNEUsV0FBVztBQUN2RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEVBQThFLFdBQVc7QUFDekY7QUFDQSxzREFBc0QsT0FBTztBQUM3RCw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBLDhEQUE4RCxXQUFXO0FBQ3pFO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0ZBQWdGLFdBQVc7QUFDM0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4Q0FBOEMsV0FBVyxjQUFjLFVBQVU7QUFDakYsb0NBQW9DLE9BQU87QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esb0RBQW9ELElBQUk7QUFDeEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHlCQUF5QixvRUFBTztBQUNoQztBQUNBO0FBQ0E7QUFDQSw4R0FBOEcsd0VBQVc7QUFDekgsb0RBQW9ELGFBQWE7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdHQUFnRyx3RUFBVztBQUMzRztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNEZBQTRGLHdFQUFXO0FBQ3ZHO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEZBQThGLHVHQUFjO0FBQzVHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsOEZBQThGLHVHQUFjO0FBQzVHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxrQ0FBa0MsdUZBQWdCO0FBQ2xEO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLHNCQUFzQiw4REFBSTtBQUMxQjtBQUNBOztBQUVBO0FBQ0E7QUFDQSwyQkFBMkIseUVBQVM7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLDBCQUEwQiwyRkFBUTtBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4RkFBOEYsb0dBQVk7QUFDMUcsc0RBQXNELDJCQUEyQjtBQUNqRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDhGQUE4RixvR0FBWTtBQUMxRyx3REFBd0QsMkJBQTJCO0FBQ25GO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxrREFBa0QsbUJBQU8sQ0FBQyxnQ0FBZ0M7QUFDMUYsd0RBQXdELG1CQUFPLENBQUMsZ0NBQWdDO0FBQ2hHLG1EQUFtRCxtQkFBTyxDQUFDLDhCQUE4QjtBQUN6RjtBQUNBO0FBQ0EsNkNBQTZDLG1CQUFPLENBQUMsMkJBQTJCO0FBQ2hGLGtEQUFrRCxtQkFBTyxDQUFDLGlDQUFpQztBQUMzRixzREFBc0QsbUJBQU8sQ0FBQyw2Q0FBNkM7QUFDM0cseURBQXlELG1CQUFPLENBQUMsd0NBQXdDO0FBQ3pHLDhDQUE4QyxtQkFBTyxDQUFDLDRCQUE0QjtBQUNsRiw4Q0FBOEMsbUJBQU8sQ0FBQyw0QkFBNEI7QUFDbEYsbURBQW1ELG1CQUFPLENBQUMsa0NBQWtDO0FBQzdGLGtEQUFrRCxtQkFBTyxDQUFDLHlDQUF5QztBQUNuRyxrREFBa0QsbUJBQU8sQ0FBQyx5Q0FBeUM7QUFDbkcsZ0RBQWdELG1CQUFPLENBQUMsK0JBQStCO0FBQ3ZGLDZDQUE2QyxtQkFBTyxDQUFDLDJCQUEyQjtBQUNoRixrREFBa0QsbUJBQU8sQ0FBQyxpQ0FBaUM7QUFDM0YsbURBQW1ELG1CQUFPLENBQUMsaUNBQWlDO0FBQzVGLGdEQUFnRCxtQkFBTyxDQUFDLDhCQUE4QjtBQUN0RiwwREFBMEQsbUJBQU8sQ0FBQywwQ0FBMEM7QUFDNUc7QUFDQTtBQUNBO0FBQ0E7QUFDQSxrREFBa0QsbUJBQU8sQ0FBQyxpQ0FBaUM7QUFDM0YsaURBQWlELG1CQUFPLENBQUMsZ0NBQWdDO0FBQ3pGLG9EQUFvRCxtQkFBTyxDQUFDLG1DQUFtQyx1QkFBdUIsdUNBQXVDO0FBQzdKLHdEQUF3RCxtQkFBTyxDQUFDLG1DQUFtQztBQUNuRyw4Q0FBOEMsbUJBQU8sQ0FBQyw0QkFBNEI7QUFDbEYsbURBQW1ELG1CQUFPLENBQUMsMENBQTBDO0FBQ3JHLHFEQUFxRCxtQkFBTyxDQUFDLDRDQUE0QztBQUN6Ryw4Q0FBOEMsbUJBQU8sQ0FBQyw0QkFBNEI7QUFDbEYsaURBQWlELG1CQUFPLENBQUMsZ0NBQWdDO0FBQ3pGLGdEQUFnRCxtQkFBTyxDQUFDLCtCQUErQjtBQUN2RixrREFBa0QsbUJBQU8sQ0FBQyxpQ0FBaUM7QUFDM0YsK0NBQStDLG1CQUFPLENBQUMsOEJBQThCO0FBQ3JGLGtEQUFrRCxtQkFBTyxDQUFDLHlDQUF5QztBQUNuRyx1REFBdUQsbUJBQU8sQ0FBQyx3Q0FBd0M7QUFDdkcsNENBQTRDLG1CQUFPLENBQUMsNEJBQTRCO0FBQ2hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsbUJBQU8sQ0FBQyx3REFBd0Q7QUFDcEgsc0RBQXNELG1CQUFPLENBQUMsMERBQTBEO0FBQ3hIOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsS0FBSztBQUNyQztBQUNBO0FBQ0E7QUFDQSxnQ0FBZ0MsR0FBRztBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLCtEQUErRDtBQUMvRDtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsNERBQTRELGNBQWM7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0IseUVBQU87QUFDN0I7QUFDQTtBQUNBLDZCQUE2QiwrREFBSztBQUNsQztBQUNBO0FBQ0Esc0JBQXNCLCtEQUFLO0FBQzNCO0FBQ0Esa0VBQWtFLFVBQVU7QUFDNUU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyw4QkFBOEI7QUFDbkU7QUFDQSxZQUFZO0FBQ1o7QUFDQTtBQUNBLFNBQVMsd0JBQXdCLEVBQUU7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTLHdCQUF3QjtBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHVEQUF1RCxnQkFBZ0IsMkJBQTJCO0FBQ2xHO0FBQ0E7QUFDQSw0QkFBNEI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUyxpQkFBaUIsRUFBRTtBQUM1QjtBQUNBLHdCQUF3Qix5RUFBTztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4REFBOEQ7QUFDOUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUVBQXlFLGFBQWEsWUFBWSxpQkFBaUI7QUFDbkgsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtRUFBbUU7QUFDbkU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esa0NBQWtDO0FBQ2xDLDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUJBQXlCLG1FQUFXO0FBQ3BDO0FBQ0E7QUFDQSw2QkFBNkIsbUVBQVc7QUFDeEM7QUFDQTtBQUNBLDZCQUE2QixtRUFBVztBQUN4QztBQUNBO0FBQ0EsNkJBQTZCLG1FQUFXO0FBQ3hDO0FBQ0E7QUFDQSw2QkFBNkIsbUVBQVc7QUFDeEM7QUFDQTtBQUNBLFFBQVEscUVBQUs7QUFDYixLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRWlkOzs7Ozs7Ozs7O0FDNzNDamQsOENBQWE7O0FBRWIsOENBQThDLGNBQWM7O0FBRTVELGtCQUFrQixtQkFBTyxDQUFDLDhCQUE4QjtBQUN4RCxVQUFVLG1CQUFPLENBQUMsNkNBQU87O0FBRXpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQSw2QkFBNkIsdUJBQXVCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0EsNkJBQTZCO0FBQzdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDO0FBQ3pDO0FBQ0EscUJBQXFCO0FBQ3JCO0FBQ0EsaUJBQWlCLEVBQUU7QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCOztBQUVqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLENBQUM7QUFDRDtBQUNBOzs7Ozs7Ozs7O0FDcEdBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlCO0FBQ2pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRCQUE0QixLQUFLO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkJBQTJCLFNBQVM7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw4QkFBOEIsMEJBQTBCO0FBQ3hELFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsbUJBQW1CLHVCQUF1QjtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLEtBQUs7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixrQkFBa0I7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsbUJBQW1CO0FBQ3RDLG9CQUFvQiw2Q0FBNkM7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsa0JBQWtCO0FBQ3JDO0FBQ0E7QUFDQSwyQkFBMkIsNEJBQTRCO0FBQ3ZEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EseUNBQXlDO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxtQkFBbUIsa0JBQWtCO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiwyQkFBMkI7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQiwyQkFBMkI7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBaUQsb0JBQW9CLFFBQVEsU0FBUyxjQUFjLGFBQWEsa0JBQWtCLHNCQUFzQixhQUFhO0FBQ3RLO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsbUJBQW1CO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEIsbUJBQW1CLFFBQVE7QUFDM0I7QUFDQSxrQ0FBa0MsRUFBRSxjQUFjO0FBQ2xEO0FBQ0Esb0NBQW9DLEVBQUUsY0FBYyxHQUFHO0FBQ3ZELDZCQUE2QixXQUFXLEdBQUcsSUFBSTtBQUMvQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QyxLQUFLLEdBQUcsS0FBSztBQUN6RDtBQUNBO0FBQ0EsOEJBQThCLGVBQWUsVUFBVSxTQUFTLEVBQUUsS0FBSyxHQUFHLFNBQVMsWUFBWSxNQUFNO0FBQ3JHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQSxtREFBbUQsYUFBYSxXQUFXO0FBQzNFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsZ0JBQWdCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtDQUFrQyxVQUFVLGFBQWEsZ0JBQWdCLE1BQU0sY0FBYztBQUM3RjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIsNkJBQTZCO0FBQ3BEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUMsOEJBQThCLEVBQUUsS0FBSztBQUM1RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsaUVBQWlFO0FBQ2hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWUsaUVBQWlFO0FBQ2hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLGlFQUFpRTtBQUNoRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBLGlCQUFpQjtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSwyQkFBMkI7QUFDM0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEscURBQXFELEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsTUFBTSxHQUFHLE1BQU0sR0FBRyxPQUFPLEdBQUcsT0FBTztBQUNyWDtBQUNBO0FBQ0E7QUFDQSx1Q0FBdUM7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EscUNBQXFDO0FBQ3JDLHFDQUFxQztBQUNyQztBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQSxnQkFBZ0I7QUFDaEIsZUFBZTtBQUNmLGVBQWU7QUFDZixjQUFjO0FBQ2QsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG1CQUFtQixrQkFBa0I7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0QkFBNEIsSUFBSTtBQUNoQyw0QkFBNEIsS0FBSztBQUNqQztBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQixPQUFPLEdBQUcsdUJBQXVCLEdBQUcsS0FBSyxHQUFHLE9BQU8sSUFBSTtBQUN6RSx3QkFBd0I7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCLEtBQUs7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQixjQUFjO0FBQ3pDO0FBQ0EsNEJBQTRCO0FBQzVCLG1EQUFtRDtBQUNuRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpQkFBaUI7QUFDakI7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlLEtBQUssRUFBRSwwQkFBMEIsZ0VBQWdFLE1BQU0sR0FBRyxFQUFFO0FBQzNIO0FBQ0E7QUFDQSxnQ0FBZ0MsUUFBUTtBQUN4Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVywrQ0FBK0M7QUFDMUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQkFBK0IsZUFBZTtBQUM5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsZUFBZTtBQUNwRDtBQUNBO0FBQ0E7QUFDQSxxQ0FBcUMsdUJBQXVCO0FBQzVEO0FBQ0E7QUFDQTtBQUNBLHFDQUFxQyxPQUFPO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSwrQ0FBK0Msa0NBQWtDO0FBQ2pGO0FBQ0E7QUFDQSxzREFBc0Qsa0NBQWtDO0FBQ3hGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtEQUFrRCxrQkFBa0I7QUFDcEU7QUFDQSwrQ0FBK0MseUJBQXlCO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBLDBDQUEwQyx3QkFBd0I7QUFDbEU7QUFDQTtBQUNBO0FBQ0EseUNBQXlDLHdCQUF3QjtBQUNqRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esc0NBQXNDLG1CQUFtQjtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSw0REFBNEQ7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFbS9EOzs7Ozs7Ozs7QUMvK0NuL0Q7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSw0Q0FBNEM7O0FBRTVDOzs7Ozs7OztBQ25CQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoidmVuZG9yLmpzIiwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5jb25zdCBob3QgPSByZXF1aXJlKFwiLi4vaG90XCIpO1xuY29uc3QgZmlsZV9zeXN0ZW1fMSA9IHJlcXVpcmUoXCJ0bnMtY29yZS1tb2R1bGVzL2ZpbGUtc3lzdGVtXCIpO1xuZnVuY3Rpb24gaG1yVXBkYXRlKCkge1xuICAgIGNvbnN0IGN1cnJlbnRBcHBGb2xkZXIgPSBmaWxlX3N5c3RlbV8xLmtub3duRm9sZGVycy5jdXJyZW50QXBwKCk7XG4gICAgY29uc3QgbGF0ZXN0SGFzaCA9IF9fd2VicGFja19yZXF1aXJlX19bXCJoXCJdKCk7XG4gICAgcmV0dXJuIGhvdChsYXRlc3RIYXNoLCBmaWxlbmFtZSA9PiB7XG4gICAgICAgIGNvbnN0IGZ1bGxGaWxlUGF0aCA9IGZpbGVfc3lzdGVtXzEucGF0aC5qb2luKGN1cnJlbnRBcHBGb2xkZXIucGF0aCwgZmlsZW5hbWUpO1xuICAgICAgICByZXR1cm4gZmlsZV9zeXN0ZW1fMS5GaWxlLmV4aXN0cyhmdWxsRmlsZVBhdGgpID8gY3VycmVudEFwcEZvbGRlci5nZXRGaWxlKGZpbGVuYW1lKSA6IG51bGw7XG4gICAgfSk7XG59XG5leHBvcnRzLmhtclVwZGF0ZSA9IGhtclVwZGF0ZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWhtci11cGRhdGUuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG52YXIgaG1yX3VwZGF0ZV8xID0gcmVxdWlyZShcIi4vaG1yLXVwZGF0ZVwiKTtcbmV4cG9ydHMuaG1yVXBkYXRlID0gaG1yX3VwZGF0ZV8xLmhtclVwZGF0ZTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImNvbnN0IGhtclByZWZpeCA9ICdITVI6JztcbmNvbnN0IGxvZyA9IHtcbiAgICBpbmZvOiAobWVzc2FnZSkgPT4gY29uc29sZS5pbmZvKGAke2htclByZWZpeH0gJHttZXNzYWdlfWApLFxuICAgIHdhcm46IChtZXNzYWdlKSA9PiBjb25zb2xlLndhcm4oYCR7aG1yUHJlZml4fSAke21lc3NhZ2V9YCksXG4gICAgZXJyb3I6IChtZXNzYWdlKSA9PiBjb25zb2xlLmVycm9yKGAke2htclByZWZpeH0gJHttZXNzYWdlfWApLFxufTtcbmNvbnN0IHJlZnJlc2ggPSAnQXBwbGljYXRpb24gbmVlZHMgdG8gYmUgcmVzdGFydGVkIGluIG9yZGVyIHRvIGFwcGx5IHRoZSBjaGFuZ2VzLic7XG5jb25zdCBob3RPcHRpb25zID0ge1xuICAgIGlnbm9yZVVuYWNjZXB0ZWQ6IGZhbHNlLFxuICAgIGlnbm9yZURlY2xpbmVkOiBmYWxzZSxcbiAgICBpZ25vcmVFcnJvcmVkOiBmYWxzZSxcbiAgICBvblVuYWNjZXB0ZWQoZGF0YSkge1xuICAgICAgICBjb25zdCBjaGFpbiA9IFtdLmNvbmNhdChkYXRhLmNoYWluKTtcbiAgICAgICAgY29uc3QgbGFzdCA9IGNoYWluW2NoYWluLmxlbmd0aCAtIDFdO1xuXG4gICAgICAgIGlmIChsYXN0ID09PSAwKSB7XG4gICAgICAgICAgICBjaGFpbi5wb3AoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGxvZy53YXJuKGBJZ25vcmVkIGFuIHVwZGF0ZSB0byB1bmFjY2VwdGVkIG1vZHVsZTogYCk7XG4gICAgICAgIGNoYWluLmZvckVhY2gobW9kID0+IGxvZy53YXJuKGAgICAgICAgICDinq0gJHttb2R9YCkpO1xuICAgIH0sXG4gICAgb25EZWNsaW5lZChkYXRhKSB7XG4gICAgICAgIGxvZy53YXJuKGBJZ25vcmVkIGFuIHVwZGF0ZSB0byBkZWNsaW5lZCBtb2R1bGU6YCk7XG4gICAgICAgIGRhdGEuY2hhaW4uZm9yRWFjaChtb2QgPT4gbG9nLndhcm4oYCAgICAgICAgIOKerSAke21vZH1gKSk7XG4gICAgfSxcbiAgICBvbkVycm9yZWQoZGF0YSkge1xuICAgICAgICBsb2cud2FybihcbiAgICAgICAgICAgIGBJZ25vcmVkIGFuIGVycm9yIHdoaWxlIHVwZGF0aW5nIG1vZHVsZSAke2RhdGEubW9kdWxlSWR9IDwke2RhdGEudHlwZX0+YFxuICAgICAgICApO1xuICAgICAgICBsb2cud2FybihkYXRhLmVycm9yKTtcbiAgICB9LFxufTtcblxubGV0IG5leHRIYXNoO1xubGV0IGN1cnJlbnRIYXNoO1xuXG5mdW5jdGlvbiB1cFRvRGF0ZSgpIHtcbiAgICByZXR1cm4gbmV4dEhhc2guaW5kZXhPZihfX3dlYnBhY2tfaGFzaF9fKSA+PSAwO1xufVxuXG5mdW5jdGlvbiByZXN1bHQobW9kdWxlcywgYXBwbGllZE1vZHVsZXMpIHtcbiAgICBjb25zdCB1bmFjY2VwdGVkID0gbW9kdWxlcy5maWx0ZXIoXG4gICAgICAgIChtb2R1bGVJZCkgPT4gYXBwbGllZE1vZHVsZXMgJiYgYXBwbGllZE1vZHVsZXMuaW5kZXhPZihtb2R1bGVJZCkgPCAwXG4gICAgKTtcblxuICAgIGlmICh1bmFjY2VwdGVkLmxlbmd0aCA+IDApIHtcbiAgICAgICAgbG9nLndhcm4oJ1RoZSBmb2xsb3dpbmcgbW9kdWxlcyBjb3VsZCBub3QgYmUgdXBkYXRlZDonKTtcblxuICAgICAgICBmb3IgKGNvbnN0IG1vZHVsZUlkIG9mIHVuYWNjZXB0ZWQpIHtcbiAgICAgICAgICAgIGxvZy53YXJuKGAgICAgICAgICAg4qa7ICR7bW9kdWxlSWR9YCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoIShhcHBsaWVkTW9kdWxlcyB8fCBbXSkubGVuZ3RoKSB7XG4gICAgICAgIGxvZy5pbmZvKCdObyBNb2R1bGVzIFVwZGF0ZWQuJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgbG9nLmluZm8oJ1RoZSBmb2xsb3dpbmcgbW9kdWxlcyB3ZXJlIHVwZGF0ZWQ6Jyk7XG5cbiAgICAgICAgZm9yIChjb25zdCBtb2R1bGVJZCBvZiBhcHBsaWVkTW9kdWxlcykge1xuICAgICAgICAgICAgbG9nLmluZm8oYCAgICAgICAgIOKGuyAke21vZHVsZUlkfWApO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbnVtYmVySWRzID0gYXBwbGllZE1vZHVsZXMuZXZlcnkoXG4gICAgICAgICAgICAobW9kdWxlSWQpID0+IHR5cGVvZiBtb2R1bGVJZCA9PT0gJ251bWJlcidcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKG51bWJlcklkcykge1xuICAgICAgICAgICAgbG9nLmluZm8oXG4gICAgICAgICAgICAgICAgJ1BsZWFzZSBjb25zaWRlciB1c2luZyB0aGUgTmFtZWRNb2R1bGVzUGx1Z2luIGZvciBtb2R1bGUgbmFtZXMuJ1xuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZnVuY3Rpb24gY2hlY2sob3B0aW9ucykge1xuICAgIHJldHVybiBtb2R1bGUuaG90XG4gICAgICAgIC5jaGVjaygpXG4gICAgICAgIC50aGVuKChtb2R1bGVzKSA9PiB7XG4gICAgICAgICAgICBpZiAoIW1vZHVsZXMpIHtcbiAgICAgICAgICAgICAgICBsb2cud2FybihcbiAgICAgICAgICAgICAgICAgICAgYENhbm5vdCBmaW5kIHVwZGF0ZS4gJHtyZWZyZXNofWBcbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gbW9kdWxlLmhvdFxuICAgICAgICAgICAgICAgIC5hcHBseShob3RPcHRpb25zKVxuICAgICAgICAgICAgICAgIC50aGVuKChhcHBsaWVkTW9kdWxlcykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgbmV4dENoZWNrO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXVwVG9EYXRlKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5leHRDaGVjayA9IGNoZWNrKG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0KG1vZHVsZXMsIGFwcGxpZWRNb2R1bGVzKTtcblxuICAgICAgICAgICAgICAgICAgICBpZiAodXBUb0RhdGUoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gRG8gbm90IG1vZGlmeSBtZXNzYWdlIC0gQ0xJIGRlcGVuZHMgb24gdGhpcyBleGFjdCBjb250ZW50IHRvIGRldGVybWluZSBobXIgb3BlcmF0aW9uIHN0YXR1cy5cbiAgICAgICAgICAgICAgICAgICAgICAgIGxvZy5pbmZvKGBTdWNjZXNzZnVsbHkgYXBwbGllZCB1cGRhdGUgd2l0aCBobXIgaGFzaCAke2N1cnJlbnRIYXNofS4gQXBwIGlzIHVwIHRvIGRhdGUuYCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV4dENoZWNrIHx8IG51bGw7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzdGF0dXMgPSBtb2R1bGUuaG90LnN0YXR1cygpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoWydhYm9ydCcsICdmYWlsJ10uaW5kZXhPZihzdGF0dXMpID49IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIERvIG5vdCBtb2RpZnkgbWVzc2FnZSAtIENMSSBkZXBlbmRzIG9uIHRoaXMgZXhhY3QgY29udGVudCB0byBkZXRlcm1pbmUgaG1yIG9wZXJhdGlvbiBzdGF0dXMuXG4gICAgICAgICAgICAgICAgICAgICAgICBsb2cuZXJyb3IoYENhbm5vdCBhcHBseSB1cGRhdGUgd2l0aCBobXIgaGFzaCAke2N1cnJlbnRIYXNofS5gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvZy5lcnJvcihlcnIubWVzc2FnZSB8fCBlcnIuc3RhY2spO1xuICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9nLmVycm9yKGBVcGRhdGUgZmFpbGVkOiAke2Vyci5tZXNzYWdlIHx8IGVyci5zdGFja31gKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc3RhdHVzID0gbW9kdWxlLmhvdC5zdGF0dXMoKTtcbiAgICAgICAgICAgIGlmIChbJ2Fib3J0JywgJ2ZhaWwnXS5pbmRleE9mKHN0YXR1cykgPj0gMCkge1xuICAgICAgICAgICAgICAgIGxvZy5lcnJvcihgQ2Fubm90IGNoZWNrIGZvciB1cGRhdGUuICR7cmVmcmVzaH1gKTtcbiAgICAgICAgICAgICAgICBsb2cuZXJyb3IoZXJyLm1lc3NhZ2UgfHwgZXJyLnN0YWNrKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbG9nLmVycm9yKGBVcGRhdGUgY2hlY2sgZmFpbGVkOiAke2Vyci5tZXNzYWdlIHx8IGVyci5zdGFja31gKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG59XG5cbmlmIChtb2R1bGUuaG90KSB7XG4gICAgbG9nLmluZm8oJ0hvdCBNb2R1bGUgUmVwbGFjZW1lbnQgRW5hYmxlZC4gV2FpdGluZyBmb3Igc2lnbmFsLicpO1xufSBlbHNlIHtcbiAgICBsb2cuZXJyb3IoJ0hvdCBNb2R1bGUgUmVwbGFjZW1lbnQgaXMgZGlzYWJsZWQuJyk7XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZShsYXRlc3RIYXNoLCBvcHRpb25zKSB7XG4gICAgbmV4dEhhc2ggPSBsYXRlc3RIYXNoO1xuICAgIGlmICghdXBUb0RhdGUoKSkge1xuICAgICAgICBjb25zdCBzdGF0dXMgPSBtb2R1bGUuaG90LnN0YXR1cygpO1xuXG4gICAgICAgIGlmIChzdGF0dXMgPT09ICdpZGxlJykge1xuICAgICAgICAgICAgLy9EbyBub3QgbW9kaWZ5IG1lc3NhZ2UgLSBDTEkgZGVwZW5kcyBvbiB0aGlzIGV4YWN0IGNvbnRlbnQgdG8gZGV0ZXJtaW5lIGhtciBvcGVyYXRpb24gc3RhdHVzLlxuICAgICAgICAgICAgbG9nLmluZm8oYENoZWNraW5nIGZvciB1cGRhdGVzIHRvIHRoZSBidW5kbGUgd2l0aCBobXIgaGFzaCAke2N1cnJlbnRIYXNofS5gKTtcbiAgICAgICAgICAgIHJldHVybiBjaGVjayhvcHRpb25zKTtcbiAgICAgICAgfSBlbHNlIGlmIChbJ2Fib3J0JywgJ2ZhaWwnXS5pbmRleE9mKHN0YXR1cykgPj0gMCkge1xuICAgICAgICAgICAgbG9nLndhcm4oXG4gICAgICAgICAgICAgICAgYENhbm5vdCBhcHBseSB1cGRhdGUuIEEgcHJldmlvdXMgdXBkYXRlICR7c3RhdHVzfWVkLiAke3JlZnJlc2h9YFxuICAgICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG5cbmZ1bmN0aW9uIGdldE5leHRIYXNoKGhhc2gsIGdldEZpbGVDb250ZW50KSB7XG4gICAgY29uc3QgZmlsZSA9IGdldEZpbGVDb250ZW50KGAke2hhc2h9LmhvdC11cGRhdGUuanNvbmApO1xuICAgIGlmICghZmlsZSkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGhhc2gpO1xuICAgIH1cblxuICAgIHJldHVybiBmaWxlLnJlYWRUZXh0KCkudGhlbihob3RVcGRhdGVDb250ZW50ID0+IHtcbiAgICAgICAgaWYgKGhvdFVwZGF0ZUNvbnRlbnQpIHtcbiAgICAgICAgICAgIGNvbnN0IG1hbmlmZXN0ID0gSlNPTi5wYXJzZShob3RVcGRhdGVDb250ZW50KTtcbiAgICAgICAgICAgIGNvbnN0IG5ld0hhc2ggPSBtYW5pZmVzdC5oO1xuICAgICAgICAgICAgcmV0dXJuIGdldE5leHRIYXNoKG5ld0hhc2gsIGdldEZpbGVDb250ZW50KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoaGFzaCk7XG4gICAgICAgIH1cbiAgICB9KS5jYXRjaChlcnJvciA9PiBQcm9taXNlLnJlamVjdChlcnJvcikpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIGNoZWNrU3RhdGUoaW5pdGlhbEhhc2gsIGdldEZpbGVDb250ZW50KSB7XG4gICAgY3VycmVudEhhc2ggPSBpbml0aWFsSGFzaDtcbiAgICByZXR1cm4gZ2V0TmV4dEhhc2goaW5pdGlhbEhhc2gsIGdldEZpbGVDb250ZW50KS50aGVuKG5leHRIYXNoID0+IHtcbiAgICAgICAgaWYgKG5leHRIYXNoICE9IGluaXRpYWxIYXNoKSB7XG4gICAgICAgICAgICByZXR1cm4gdXBkYXRlKG5leHRIYXNoLCB7fSk7XG4gICAgICAgIH1cbiAgICB9KVxufVxuIiwiY29uc3QgbG9hZENzcyA9IHJlcXVpcmUoXCIuL2xvYWQtYXBwbGljYXRpb24tY3NzXCIpO1xuXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uKCkge1xuICAgIGxvYWRDc3MoZnVuY3Rpb24oKSB7XG4gICAgICAgIGNvbnN0IGFwcENzc0NvbnRleHQgPSByZXF1aXJlLmNvbnRleHQoXCJ+L1wiLCBmYWxzZSwgL15cXC5cXC9hcHBcXC4oY3NzfHNjc3N8bGVzc3xzYXNzKSQvKTtcbiAgICAgICAgZ2xvYmFsLnJlZ2lzdGVyV2VicGFja01vZHVsZXMoYXBwQ3NzQ29udGV4dCk7XG4gICAgfSk7XG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChsb2FkTW9kdWxlRm4pIHtcbiAgICBjb25zdCBhcHBsaWNhdGlvbiA9IHJlcXVpcmUoXCJ0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uXCIpO1xuICAgIHJlcXVpcmUoXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3N0eWxpbmcvc3R5bGUtc2NvcGVcIik7XG5cbiAgICBsb2FkTW9kdWxlRm4oKTtcblxuICAgIGFwcGxpY2F0aW9uLmxvYWRBcHBDc3MoKTtcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0ge1widHlwZVwiOlwic3R5bGVzaGVldFwiLFwic3R5bGVzaGVldFwiOntcInJ1bGVzXCI6W3tcInR5cGVcIjpcImNvbW1lbnRcIixcImNvbW1lbnRcIjpcIiFcXG4gKiBOYXRpdmVTY3JpcHQgVGhlbWUgdjIuMC4yNCAoaHR0cHM6Ly9uYXRpdmVzY3JpcHQub3JnKVxcbiAqIENvcHlyaWdodCAyMDE2LTIwMTYgVGhlIFRoZW1lIEF1dGhvcnNcXG4gKiBDb3B5cmlnaHQgMjAxNi0yMDE5IFByb2dyZXNzIFNvZnR3YXJlXFxuICogTGljZW5zZWQgdW5kZXIgQXBhY2hlIDIuMCAoaHR0cHM6Ly9naXRodWIuY29tL05hdGl2ZVNjcmlwdC90aGVtZS9ibG9iL21hc3Rlci9MSUNFTlNFKVxcbiBcIn0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQnV0dG9uXCIsXCIubnQtYnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDQzNjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b25cIixcIi5ucy1kYXJrIC5udC1idXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZjZmVmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbjphY3RpdmVcIixcIkJ1dHRvbi4tYWN0aXZlXCIsXCIubnQtYnV0dG9uOmFjdGl2ZVwiLFwiLm50LWJ1dHRvbi4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMDA0MzYzXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgQnV0dG9uOmFjdGl2ZVwiLFwiLm5zLWRhcmsgQnV0dG9uLi1hY3RpdmVcIixcIi5ucy1kYXJrIC5udC1idXR0b246YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYnV0dG9uLi1hY3RpdmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmY2ZlZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJCdXR0b24uLW91dGxpbmVcIixcIi5udC1idXR0b24uLW91dGxpbmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLW91dGxpbmVcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLW91dGxpbmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiM5NmRkZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcIi1oaWdodGxpZ2h0LWxpZ2h0XCIsXCJrZXlmcmFtZXNcIjpbe1widHlwZVwiOlwia2V5ZnJhbWVcIixcInZhbHVlc1wiOltcIjAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMTAwJVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZjJmMmYyXCJ9XX1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcIi1oaWdodGxpZ2h0LWRhcmtcIixcImtleWZyYW1lc1wiOlt7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMCVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcImtleWZyYW1lXCIsXCJ2YWx1ZXNcIjpbXCIxMDAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMyMzIzMjNcIn1dfV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbi4tb3V0bGluZTphY3RpdmVcIixcIkJ1dHRvbi4tb3V0bGluZS4tYWN0aXZlXCIsXCIubnQtYnV0dG9uLi1vdXRsaW5lOmFjdGl2ZVwiLFwiLm50LWJ1dHRvbi4tb3V0bGluZS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYW5pbWF0aW9uXCIsXCJ2YWx1ZVwiOlwiLWhpZ2h0bGlnaHQtbGlnaHQgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmMmYyZjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLW91dGxpbmU6YWN0aXZlXCIsXCIubnMtZGFyayBCdXR0b24uLW91dGxpbmUuLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWJ1dHRvbi4tb3V0bGluZTphY3RpdmVcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLW91dGxpbmUuLWFjdGl2ZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImFuaW1hdGlvblwiLFwidmFsdWVcIjpcIi1oaWdodGxpZ2h0LWRhcmsgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMyMzIzMjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJCdXR0b24uLXByaW1hcnlcIixcIi5udC1idXR0b24uLXByaW1hcnlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLXByaW1hcnlcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLXByaW1hcnlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcImFjY2VudC1oaWdodGxpZ2h0LWxpZ2h0XCIsXCJrZXlmcmFtZXNcIjpbe1widHlwZVwiOlwia2V5ZnJhbWVcIixcInZhbHVlc1wiOltcIjAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMTAwJVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMDBhYWZjXCJ9XX1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcImFjY2VudC1oaWdodGxpZ2h0LWRhcmtcIixcImtleWZyYW1lc1wiOlt7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMCVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcImtleWZyYW1lXCIsXCJ2YWx1ZXNcIjpbXCIxMDAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGFhZmNcIn1dfV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbi4tcHJpbWFyeTphY3RpdmVcIixcIkJ1dHRvbi4tcHJpbWFyeS4tYWN0aXZlXCIsXCIubnQtYnV0dG9uLi1wcmltYXJ5OmFjdGl2ZVwiLFwiLm50LWJ1dHRvbi4tcHJpbWFyeS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYW5pbWF0aW9uXCIsXCJ2YWx1ZVwiOlwiYWNjZW50LWhpZ2h0bGlnaHQtbGlnaHQgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGFhZmNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLXByaW1hcnk6YWN0aXZlXCIsXCIubnMtZGFyayBCdXR0b24uLXByaW1hcnkuLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWJ1dHRvbi4tcHJpbWFyeTphY3RpdmVcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLXByaW1hcnkuLWFjdGl2ZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImFuaW1hdGlvblwiLFwidmFsdWVcIjpcImFjY2VudC1oaWdodGxpZ2h0LWRhcmsgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGFhZmNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJBY3Rpdml0eUluZGljYXRvclwiLFwiLm50LWFjdGl2aXR5LWluZGljYXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIEFjdGl2aXR5SW5kaWNhdG9yXCIsXCIubnMtZGFyayAubnQtYWN0aXZpdHktaW5kaWNhdG9yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiU2VnbWVudGVkQmFyXCIsXCIubnQtc2VnbWVudGVkLWJhclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwic2VsZWN0ZWQtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBTZWdtZW50ZWRCYXJcIixcIi5ucy1kYXJrIC5udC1zZWdtZW50ZWQtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZWxlY3RlZC1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1pb3MgU2VnbWVudGVkQmFyXCIsXCIubnMtaW9zIC5udC1zZWdtZW50ZWQtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMCAxNVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLWlvcyBTZWdtZW50ZWRCYXJcIixcIi5ucy1kYXJrLm5zLWlvcyAubnQtc2VnbWVudGVkLWJhclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlByb2dyZXNzXCIsXCIubnQtcHJvZ3Jlc3NcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFByb2dyZXNzXCIsXCIubnMtZGFyayAubnQtcHJvZ3Jlc3NcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlNsaWRlclwiLFwiLm50LXNsaWRlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgU2xpZGVyXCIsXCIubnMtZGFyayAubnQtc2xpZGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJTbGlkZXJbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWFuZHJvaWQgU2xpZGVyW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5udC1zbGlkZXJbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWFuZHJvaWQgLm50LXNsaWRlcltpc0VuYWJsZWQ9ZmFsc2VdXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZTBlMGUwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNlMGUwZTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJTZWFyY2hCYXJcIixcIi5udC1zZWFyY2gtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LWZpZWxkLWhpbnQtY29sb3JcIixcInZhbHVlXCI6XCIjNzM3MzczXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1maWVsZC1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBTZWFyY2hCYXJcIixcIi5ucy1kYXJrIC5udC1zZWFyY2gtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LWZpZWxkLWhpbnQtY29sb3JcIixcInZhbHVlXCI6XCIjYjNiM2IzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1maWVsZC1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtYW5kcm9pZCBTd2l0Y2hcIixcIi5ucy1hbmRyb2lkIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNjY2NcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2NjY1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLWFuZHJvaWQgU3dpdGNoXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiM2MzYzNjNcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzYzNjM2M1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIFN3aXRjaFtjaGVja2VkPXRydWVdXCIsXCIubnMtYW5kcm9pZCAubnQtc3dpdGNoW2NoZWNrZWQ9dHJ1ZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1hbmRyb2lkIFN3aXRjaFtjaGVja2VkPXRydWVdXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1zd2l0Y2hbY2hlY2tlZD10cnVlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtYW5kcm9pZCAubnQtc3dpdGNoW2lzRW5hYmxlZD1mYWxzZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNlNmU2ZTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1hbmRyb2lkIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1zd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzRhNGE0YVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1pb3MgU3dpdGNoXCIsXCIubnMtaW9zIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm9mZi1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2U2ZTZlNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLWlvcyBTd2l0Y2hcIixcIi5ucy1kYXJrLm5zLWlvcyAubnQtc3dpdGNoXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJvZmYtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiM0YTRhNGFcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtaW9zIC5udC1zd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LDE4OCwyNTUsLjQpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtaW9zIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LXN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuNClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJUYWJWaWV3XCIsXCIubnQtdGFiLXZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZWxlY3RlZC10YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiNhYmQ1ZTlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJhbmRyb2lkLXNlbGVjdGVkLXRhYi1oaWdobGlnaHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgVGFiVmlld1wiLFwiLm5zLWRhcmsgLm50LXRhYi12aWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwic2VsZWN0ZWQtdGFiLXRleHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGFiLWJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGFiLXRleHQtY29sb3JcIixcInZhbHVlXCI6XCIjYWJkNWU5XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYW5kcm9pZC1zZWxlY3RlZC10YWItaGlnaGxpZ2h0LWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYlZpZXcubnMtZGFya1wiLFwiLm50LXRhYi12aWV3Lm5zLWRhcmtcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZWxlY3RlZC10YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiNhYmQ1ZTlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJhbmRyb2lkLXNlbGVjdGVkLXRhYi1oaWdobGlnaHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGFiU3RyaXBcIixcIi5udC10YWItc3RyaXBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJoaWdobGlnaHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZFwiLFwidmFsdWVcIjpcIiNmMmYyZjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBUYWJTdHJpcFwiLFwiLm5zLWRhcmsgLm50LXRhYi1zdHJpcFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhpZ2hsaWdodC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiIzNhM2EzYVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYlN0cmlwSXRlbVwiLFwiLm50LXRhYi1zdHJpcF9faXRlbVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFRhYlN0cmlwSXRlbVwiLFwiLm5zLWRhcmsgLm50LXRhYi1zdHJpcF9faXRlbVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYlN0cmlwSXRlbTphY3RpdmVcIixcIlRhYlN0cmlwSXRlbTphY3RpdmUgTGFiZWxcIixcIi5udC10YWItc3RyaXBfX2l0ZW06YWN0aXZlXCIsXCIubnQtdGFiLXN0cmlwX19pdGVtOmFjdGl2ZSBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFRhYlN0cmlwSXRlbTphY3RpdmVcIixcIi5ucy1kYXJrIFRhYlN0cmlwSXRlbTphY3RpdmUgTGFiZWxcIixcIi5ucy1kYXJrIC5udC10YWItc3RyaXBfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyayAubnQtdGFiLXN0cmlwX19pdGVtOmFjdGl2ZSBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYkNvbnRlbnRJdGVtXCIsXCIubnQtdGFiLWNvbnRlbnRfX2l0ZW1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFRhYkNvbnRlbnRJdGVtXCIsXCIubnMtZGFyayAubnQtdGFiLWNvbnRlbnRfX2l0ZW1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3XCIsXCJSYWRMaXN0Vmlld1wiLFwiLm50LWxpc3Qtdmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIml0ZW0tc2VsZWN0ZWQtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuMTUpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwic2VwYXJhdG9yLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2NjY1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIExpc3RWaWV3XCIsXCIubnMtZGFyayBSYWRMaXN0Vmlld1wiLFwiLm5zLWRhcmsgLm50LWxpc3Qtdmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIml0ZW0tc2VsZWN0ZWQtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuMTUpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXc+Ki5hY3RpdmVcIixcIkxpc3RWaWV3Pio6aGlnaGxpZ2h0ZWRcIixcIlJhZExpc3RWaWV3PiouYWN0aXZlXCIsXCJSYWRMaXN0Vmlldz4qOmhpZ2hsaWdodGVkXCIsXCIubnQtbGlzdC12aWV3PiouYWN0aXZlXCIsXCIubnQtbGlzdC12aWV3Pio6aGlnaGxpZ2h0ZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xNSlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBMaXN0Vmlldz4qLmFjdGl2ZVwiLFwiLm5zLWRhcmsgTGlzdFZpZXc+KjpoaWdobGlnaHRlZFwiLFwiLm5zLWRhcmsgUmFkTGlzdFZpZXc+Ki5hY3RpdmVcIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3Pio6aGlnaGxpZ2h0ZWRcIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXc+Ki5hY3RpdmVcIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXc+KjpoaWdobGlnaHRlZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LDE4OCwyNTUsLjE1KVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3IC4tc2VwYXJhdG9yXCIsXCJSYWRMaXN0VmlldyAuLXNlcGFyYXRvclwiLFwiLm50LWxpc3QtdmlldyAuLXNlcGFyYXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1ib3R0b20tY29sb3JcIixcInZhbHVlXCI6XCIjY2NjXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgTGlzdFZpZXcgLi1zZXBhcmF0b3JcIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3IC4tc2VwYXJhdG9yXCIsXCIubnMtZGFyayAubnQtbGlzdC12aWV3IC4tc2VwYXJhdG9yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWJvdHRvbS1jb2xvclwiLFwidmFsdWVcIjpcIiM2MzYzNjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBMaXN0Vmlld1wiLFwiLm5zLWRhcmsgUmFkTGlzdFZpZXdcIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZXBhcmF0b3ItY29sb3JcIixcInZhbHVlXCI6XCIjNjM2MzYzXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlXCIsXCJSYWRMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGVcIixcIi5udC1saXN0LXZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNkNTAwMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIixcIlJhZExpc3RWaWV3IC5udC1saXN0LXZpZXdfX2RlbGV0ZT5MYWJlbFwiLFwiLm50LWxpc3QtdmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3IC5udC1saXN0LXZpZXdfX2RlbGV0ZT5MYWJlbFwiLFwiLm5zLWRhcmsgLm50LWxpc3QtdmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJMaXN0VmlldyBOVEljb25cIixcIkxpc3RWaWV3IC5udC1pY29uXCIsXCJSYWRMaXN0VmlldyBOVEljb25cIixcIlJhZExpc3RWaWV3IC5udC1pY29uXCIsXCIubnQtbGlzdC12aWV3IE5USWNvblwiLFwiLm50LWxpc3QtdmlldyAubnQtaWNvblwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwNjY5OFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIExpc3RWaWV3IE5USWNvblwiLFwiLm5zLWRhcmsgTGlzdFZpZXcgLm50LWljb25cIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3IE5USWNvblwiLFwiLm5zLWRhcmsgUmFkTGlzdFZpZXcgLm50LWljb25cIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXcgTlRJY29uXCIsXCIubnMtZGFyayAubnQtbGlzdC12aWV3IC5udC1pY29uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19oZWFkZXJcIixcIi5udC1kcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMyNDQ0ZmVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRTaWRlRHJhd2VyPipcIixcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9fY29udGVudFwiLFwiLm50LWRyYXdlcj4qXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2NvbnRlbnRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtLi1zZWxlY3RlZFwiLFwiLm50LWRyYXdlciAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuMTUpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkIExhYmVsXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWQgTGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBSYWRTaWRlRHJhd2VyIC5udC1kcmF3ZXJfX2hlYWRlclwiLFwiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2hlYWRlclwiLFwiLm5zLWRhcmsgLm50LWRyYXdlciAubnQtZHJhd2VyX19oZWFkZXJcIixcIi5udC1kcmF3ZXIubnMtZGFyayAubnQtZHJhd2VyX19oZWFkZXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwM2M4NFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFJhZFNpZGVEcmF3ZXI+KlwiLFwiLm5zLWRhcmsgUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19jb250ZW50XCIsXCJSYWRTaWRlRHJhd2VyLm5zLWRhcms+KlwiLFwiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2NvbnRlbnRcIixcIi5ucy1kYXJrIC5udC1kcmF3ZXI+KlwiLFwiLm5zLWRhcmsgLm50LWRyYXdlciAubnQtZHJhd2VyX19jb250ZW50XCIsXCIubnQtZHJhd2VyLm5zLWRhcms+KlwiLFwiLm50LWRyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2NvbnRlbnRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtLi1zZWxlY3RlZFwiLFwiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWRcIixcIi5ucy1kYXJrIC5udC1kcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtLi1zZWxlY3RlZFwiLFwiLm50LWRyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xNSlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBSYWRTaWRlRHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWQgTGFiZWxcIixcIlJhZFNpZGVEcmF3ZXIubnMtZGFyayAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkIExhYmVsXCIsXCIubnMtZGFyayAubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWQgTGFiZWxcIixcIi5udC1kcmF3ZXIubnMtZGFyayAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkIExhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjOTZkZGZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGV4dFZpZXdcIixcIlRleHRGaWVsZFwiLFwiUGlja2VyRmllbGRcIixcIkRhdGVQaWNrZXJGaWVsZFwiLFwiVGltZVBpY2tlckZpZWxkXCIsXCJEYXRlVGltZVBpY2tlckZpZWxkc1wiLFwiRGF0YUZvcm1FZGl0b3JDb3JlXCIsXCJSYWRBdXRvQ29tcGxldGVUZXh0Vmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJ0cmFuc3BhcmVudFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBsYWNlaG9sZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzczNzM3M1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNjN2M3YzdcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBUZXh0Vmlld1wiLFwiLm5zLWRhcmsgVGV4dEZpZWxkXCIsXCIubnMtZGFyayBQaWNrZXJGaWVsZFwiLFwiLm5zLWRhcmsgRGF0ZVBpY2tlckZpZWxkXCIsXCIubnMtZGFyayBUaW1lUGlja2VyRmllbGRcIixcIi5ucy1kYXJrIERhdGVUaW1lUGlja2VyRmllbGRzXCIsXCIubnMtZGFyayBEYXRhRm9ybUVkaXRvckNvcmVcIixcIi5ucy1kYXJrIFJhZEF1dG9Db21wbGV0ZVRleHRWaWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGxhY2Vob2xkZXItY29sb3JcIixcInZhbHVlXCI6XCIjYjNiM2IzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZhZmFmYVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRleHRWaWV3OmZvY3VzXCIsXCJUZXh0RmllbGQ6Zm9jdXNcIixcIlBpY2tlckZpZWxkOmZvY3VzXCIsXCJEYXRlUGlja2VyRmllbGQ6Zm9jdXNcIixcIlRpbWVQaWNrZXJGaWVsZDpmb2N1c1wiLFwiRGF0ZVRpbWVQaWNrZXJGaWVsZHM6Zm9jdXNcIixcIkRhdGFGb3JtRWRpdG9yQ29yZTpmb2N1c1wiLFwiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXc6Zm9jdXNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjMDA4OGM5XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgVGV4dFZpZXc6Zm9jdXNcIixcIi5ucy1kYXJrIFRleHRGaWVsZDpmb2N1c1wiLFwiLm5zLWRhcmsgUGlja2VyRmllbGQ6Zm9jdXNcIixcIi5ucy1kYXJrIERhdGVQaWNrZXJGaWVsZDpmb2N1c1wiLFwiLm5zLWRhcmsgVGltZVBpY2tlckZpZWxkOmZvY3VzXCIsXCIubnMtZGFyayBEYXRlVGltZVBpY2tlckZpZWxkczpmb2N1c1wiLFwiLm5zLWRhcmsgRGF0YUZvcm1FZGl0b3JDb3JlOmZvY3VzXCIsXCIubnMtZGFyayBSYWRBdXRvQ29tcGxldGVUZXh0Vmlldzpmb2N1c1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiM5NmRkZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJUZXh0Vmlld1tpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJUZXh0RmllbGRbaXNFbmFibGVkPWZhbHNlXVwiLFwiUGlja2VyRmllbGRbaXNFbmFibGVkPWZhbHNlXVwiLFwiRGF0ZVBpY2tlckZpZWxkW2lzRW5hYmxlZD1mYWxzZV1cIixcIlRpbWVQaWNrZXJGaWVsZFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJEYXRlVGltZVBpY2tlckZpZWxkc1tpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJEYXRhRm9ybUVkaXRvckNvcmVbaXNFbmFibGVkPWZhbHNlXVwiLFwiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXdbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2UwZTBlMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZjJmMmYyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgVGV4dFZpZXdbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWRhcmsgVGV4dEZpZWxkW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5ucy1kYXJrIFBpY2tlckZpZWxkW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5ucy1kYXJrIERhdGVQaWNrZXJGaWVsZFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtZGFyayBUaW1lUGlja2VyRmllbGRbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWRhcmsgRGF0ZVRpbWVQaWNrZXJGaWVsZHNbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWRhcmsgRGF0YUZvcm1FZGl0b3JDb3JlW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5ucy1kYXJrIFJhZEF1dG9Db21wbGV0ZVRleHRWaWV3W2lzRW5hYmxlZD1mYWxzZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNlMGUwZTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzNkM2QzZFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlByb3BlcnR5RWRpdG9yOmZvY3VzIERhdGFGb3JtRWRpdG9yQ29yZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBQcm9wZXJ0eUVkaXRvcjpmb2N1cyBEYXRhRm9ybUVkaXRvckNvcmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjOTZkZGZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgVG9rZW5cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzk2ZGRmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFJhZEF1dG9Db21wbGV0ZVRleHRWaWV3IFRva2VuXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRBdXRvQ29tcGxldGVUZXh0VmlldyBUb2tlbjpzZWxlY3RlZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjNjNjZGZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgVG9rZW46c2VsZWN0ZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwYWFmY1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZEF1dG9Db21wbGV0ZVRleHRWaWV3IENsZWFyQnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgQ2xlYXJCdXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRBdXRvQ29tcGxldGVUZXh0VmlldyBTdWdnZXN0aW9uVmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgU3VnZ2VzdGlvblZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZERhdGFGb3JtXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGxhY2Vob2xkZXItY29sb3JcIixcInZhbHVlXCI6XCIjNzM3MzczXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkRGF0YUZvcm1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwbGFjZWhvbGRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNiM2IzYjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWREYXRhRm9ybSBQcm9wZXJ0eUVkaXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkRGF0YUZvcm0gUHJvcGVydHlFZGl0b3JcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlBpY2tlclBhZ2UgTGlzdFZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFBpY2tlclBhZ2UgTGlzdFZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlBpY2tlclBhZ2UgTGlzdFZpZXc+KlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1ib3R0b20tY29sb3JcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LDE4OCwyNTUsLjQpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUGlja2VyUGFnZSBMaXN0Vmlldz4qXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWJvdHRvbS1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuNClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJQaWNrZXJQYWdlLm5zLWRhcmsgTGlzdFZpZXdcIixcIi5ucy1kYXJrIFN1Z2dlc3Rpb25WaWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZFwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZGF0ZS10aW1lLXBpY2tlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmRcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmRhdGUtdGltZS1waWNrZXIubnMtZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmRcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmRhdGUtdGltZS1waWNrZXItYnV0dG9uc1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwNDM2M1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5kYXRlLXRpbWUtcGlja2VyLWJ1dHRvbnMubnMtZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZjZmVmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLmRhdGUtdGltZS1waWNrZXItYnV0dG9uLWNhbmNlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmRcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmRhdGUtdGltZS1waWNrZXItc3Bpbm5lcnNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDY1OTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZGF0ZS10aW1lLXBpY2tlci1zcGlubmVycy5ucy1kYXJrXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjYzllZWZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiRGF0YUZvcm1FZGl0b3JMYWJlbFwiLFwiTlRJbnB1dD5MYWJlbFwiLFwiLm50LWlucHV0PkxhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMDA2NTk2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgRGF0YUZvcm1FZGl0b3JMYWJlbFwiLFwiLm5zLWRhcmsgTlRJbnB1dD5MYWJlbFwiLFwiLm5zLWRhcmsgLm50LWlucHV0PkxhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjYzllZWZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyXCIsXCJOVEFjdGlvbkJhclwiLFwiLm50LWFjdGlvbi1iYXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzNkNWFmZVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIEFjdGlvbkJhclwiLFwiLm5zLWRhcmsgTlRBY3Rpb25CYXJcIixcIi5ucy1kYXJrIC5udC1hY3Rpb24tYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzNzQ1OTdcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJBY3Rpb25CYXIgTlRJY29uXCIsXCJBY3Rpb25CYXIgTGFiZWxcIixcIkFjdGlvbkJhciBCdXR0b25cIixcIkFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiLFwiTlRBY3Rpb25CYXIgTlRJY29uXCIsXCJOVEFjdGlvbkJhciBMYWJlbFwiLFwiTlRBY3Rpb25CYXIgQnV0dG9uXCIsXCJOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiLFwiLm50LWFjdGlvbi1iYXIgTlRJY29uXCIsXCIubnQtYWN0aW9uLWJhciBMYWJlbFwiLFwiLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnQtYWN0aW9uLWJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIEFjdGlvbkJhciBOVEljb25cIixcIi5ucy1kYXJrIEFjdGlvbkJhciBMYWJlbFwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBOVEljb25cIixcIi5ucy1kYXJrIE5UQWN0aW9uQmFyIExhYmVsXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1kYXJrIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBOVEljb25cIixcIi5ucy1kYXJrIC5udC1hY3Rpb24tYmFyIExhYmVsXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBCdXR0b25cIixcIi5ucy1kYXJrIC5udC1hY3Rpb24tYmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyIE5USWNvbjphY3RpdmVcIixcIkFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiQWN0aW9uQmFyIExhYmVsOmFjdGl2ZVwiLFwiQWN0aW9uQmFyIExhYmVsLi1hY3RpdmVcIixcIkFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCJBY3Rpb25CYXIgQnV0dG9uLi1hY3RpdmVcIixcIkFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbTphY3RpdmVcIixcIkFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCJOVEFjdGlvbkJhciBOVEljb246YWN0aXZlXCIsXCJOVEFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCJOVEFjdGlvbkJhciBMYWJlbC4tYWN0aXZlXCIsXCJOVEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCJOVEFjdGlvbkJhciBCdXR0b24uLWFjdGl2ZVwiLFwiTlRBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCJOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBOVEljb246YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm50LWFjdGlvbi1iYXIgTGFiZWw6YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBMYWJlbC4tYWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBCdXR0b246YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBCdXR0b24uLWFjdGl2ZVwiLFwiLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgQWN0aW9uQmFyIE5USWNvbjphY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIExhYmVsOmFjdGl2ZVwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIExhYmVsLi1hY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtZGFyayBBY3Rpb25CYXIgQnV0dG9uLi1hY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbTphY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBOVEljb246YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBMYWJlbC4tYWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBCdXR0b24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgTlRBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBOVEljb246YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWFjdGlvbi1iYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBMYWJlbC4tYWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBCdXR0b24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWlvcyBBY3Rpb25CYXIgTlRJY29uXCIsXCIubnMtaW9zIEFjdGlvbkJhciBOVEljb246YWN0aXZlXCIsXCIubnMtaW9zIEFjdGlvbkJhciBMYWJlbFwiLFwiLm5zLWlvcyBBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtaW9zIEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1pb3MgQWN0aW9uQmFyIEJ1dHRvbjphY3RpdmVcIixcIi5ucy1pb3MgQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtaW9zIEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbTphY3RpdmVcIixcIi5ucy1pb3MgTlRBY3Rpb25CYXIgTlRJY29uXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIE5USWNvbjphY3RpdmVcIixcIi5ucy1pb3MgTlRBY3Rpb25CYXIgTGFiZWxcIixcIi5ucy1pb3MgTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWlvcyBOVEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtOmFjdGl2ZVwiLFwiLm5zLWlvcyAubnQtYWN0aW9uLWJhciBOVEljb25cIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWlvcyAubnQtYWN0aW9uLWJhciBMYWJlbFwiLFwiLm5zLWlvcyAubnQtYWN0aW9uLWJhciBMYWJlbDphY3RpdmVcIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtaW9zIC5udC1hY3Rpb24tYmFyIEJ1dHRvbjphY3RpdmVcIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW1cIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInRyYW5zcGFyZW50XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtaW9zIEFjdGlvbkJhciBOVEljb25cIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIEFjdGlvbkJhciBMYWJlbFwiLFwiLm5zLWRhcmsubnMtaW9zIEFjdGlvbkJhciBMYWJlbDphY3RpdmVcIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1pb3MgQWN0aW9uQmFyIEJ1dHRvbjphY3RpdmVcIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW1cIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgTlRJY29uXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIE5UQWN0aW9uQmFyIExhYmVsXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgQnV0dG9uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTlRJY29uXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIC5udC1hY3Rpb24tYmFyIExhYmVsXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgQnV0dG9uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIC5udC1hY3Rpb24tYmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInRyYW5zcGFyZW50XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWFuZHJvaWQgQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgQWN0aW9uQmFyIC5udC1idXR0b25cIixcIi5ucy1hbmRyb2lkIE5UQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgTlRBY3Rpb25CYXIgLm50LWJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtYW5kcm9pZCAubnQtYWN0aW9uLWJhciAubnQtYnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzZDVhZmVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1hbmRyb2lkIEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1kYXJrLm5zLWFuZHJvaWQgQWN0aW9uQmFyIC5udC1idXR0b25cIixcIi5ucy1kYXJrLm5zLWFuZHJvaWQgTlRBY3Rpb25CYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIE5UQWN0aW9uQmFyIC5udC1idXR0b25cIixcIi5ucy1kYXJrLm5zLWFuZHJvaWQgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1hY3Rpb24tYmFyIC5udC1idXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzM3NDU5N1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5oclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNkOWQ5ZDlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayAuaHJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjNGQ0ZDRkXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmhyLWxpZ2h0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzk2ZGRmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIC5oci1saWdodFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNmY2ZlZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuaHItZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayAuaHItZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiM5NmRkZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtcm9vdFwiLFwiLm5zLW1vZGFsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1ibGFja1wiLFwidmFsdWVcIjpcIiMwMDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLXdoaXRlXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29sb3ItZ3JleVwiLFwidmFsdWVcIjpcIiNlMGUwZTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLWdyZXktbGlnaHRcIixcInZhbHVlXCI6XCIjYmFiYWJhXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1jaGFyY29hbFwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLXRyYW5zcGFyZW50XCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLWFxdWFcIixcInZhbHVlXCI6XCIjMDBjYWFiXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1ibHVlXCIsXCJ2YWx1ZVwiOlwiIzNkNWFmZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29sb3ItYnJvd25cIixcInZhbHVlXCI6XCIjNzk1NTQ4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1mb3Jlc3RcIixcInZhbHVlXCI6XCIjMDA2OTY4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1ncmV5LWRhcmtcIixcInZhbHVlXCI6XCIjNWM2ODdjXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1wdXJwbGVcIixcInZhbHVlXCI6XCIjODEzMGZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1sZW1vblwiLFwidmFsdWVcIjpcIiNmZmVhMDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbG9yLWxpbWVcIixcInZhbHVlXCI6XCIjYWVlNDA2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1vcmFuZ2VcIixcInZhbHVlXCI6XCIjZjU3YzAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb2xvci1ydWJ5XCIsXCJ2YWx1ZVwiOlwiI2ZmMTc0NFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29sb3Itc2t5XCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29sb3ItZXJyb3JcIixcInZhbHVlXCI6XCIjZDUwMDAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb25zdC1mb250LXNpemVcIixcInZhbHVlXCI6XCIxNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYmFja2dyb3VuZC1hbHQtMTBcIixcInZhbHVlXCI6XCIjYzBlYmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb25zdC1idG4tY29sb3Itc2Vjb25kYXJ5XCIsXCJ2YWx1ZVwiOlwiIzAxYTBlY1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYnRuLWNvbG9yLWRpc2FibGVkXCIsXCJ2YWx1ZVwiOlwiI2E0YTRhNFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYnRuLWZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjE4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb25zdC1idG4tbWluLXdpZHRoXCIsXCJ2YWx1ZVwiOlwiNjRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWJ0bi1oZWlnaHRcIixcInZhbHVlXCI6XCI1MlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYnRuLXBhZGRpbmcteFwiLFwidmFsdWVcIjpcIjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWJ0bi1wYWRkaW5nLXlcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb25zdC1idG4tbWFyZ2luLXhcIixcInZhbHVlXCI6XCIxNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYnRuLW1hcmdpbi15XCIsXCJ2YWx1ZVwiOlwiOFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYnRuLXJhZGl1c1wiLFwidmFsdWVcIjpcIjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWhlYWRpbmdzLW1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCI0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1jb25zdC1oZWFkaW5ncy1mb250LXdlaWdodFwiLFwidmFsdWVcIjpcIm5vcm1hbFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYm9yZGVyLXdpZHRoXCIsXCJ2YWx1ZVwiOlwiMVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcIlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tY29uc3QtYm9yZGVyLXJhZGl1cy1zbVwiLFwidmFsdWVcIjpcIjRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWJvcmRlci1yYWRpdXMtbGdcIixcInZhbHVlXCI6XCI1MCVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWJvcmRlci1yYWRpdXMtcm91bmRlZFwiLFwidmFsdWVcIjpcIjVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWljb24tZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWljb24tZm9udC1zaXplLWxnXCIsXCJ2YWx1ZVwiOlwiMjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWNvbnN0LWRpc2FibGVkLW9wYWNpdHlcIixcInZhbHVlXCI6XCIwLjVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWxpZ2h0LXByaW1hcnlcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1iYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYWNjZW50XCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYWItY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1hYi1iYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiIzNkNWFmZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYnRuLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYmFja2dyb3VuZC1hbHQtNVwiLFwidmFsdWVcIjpcIiNmMmYyZjJcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWxpZ2h0LWJhY2tncm91bmQtYWx0LTEwXCIsXCJ2YWx1ZVwiOlwiI2U2ZTZlNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYmFja2dyb3VuZC1hbHQtMjBcIixcInZhbHVlXCI6XCIjY2NjY2NjXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1zZWNvbmRhcnlcIixcInZhbHVlXCI6XCIjNzM3MzczXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1kaXNhYmxlZFwiLFwidmFsdWVcIjpcIiNhY2U0ZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWxpZ2h0LXRleHQtY29sb3JcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1oZWFkaW5ncy1jb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWxpZ2h0LXRhYi10ZXh0LWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2FiZDVlOVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYWNjZW50LWRhcmtcIixcInZhbHVlXCI6XCIjMDA4OGM5XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1hY2NlbnQtbGlnaHRcIixcInZhbHVlXCI6XCIjOTZkZGZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1hY2NlbnQtdHJhbnNwYXJlbnRcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LCAxODgsIDI1NSwgMC44KVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtcHJpbWFyeS1hY2NlbnRcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LCAxODgsIDI1NSwgMC40KVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYmFja2dyb3VuZC1hY2NlbnRcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LCAxODgsIDI1NSwgMC4xKVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYmFja2dyb3VuZC1kYXJrLWFjY2VudFwiLFwidmFsdWVcIjpcInJnYmEoNDgsIDE4OCwgMjU1LCAwLjE1KVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtaXRlbS1hY3RpdmUtY29sb3JcIixcInZhbHVlXCI6XCIjNjc2NzY3XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1pdGVtLWFjdGl2ZS1iYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwgMTg4LCAyNTUsIDAuMTUpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1hYi1iYWNrZ3JvdW5kLWRhcmtcIixcInZhbHVlXCI6XCIjMjQ0NGZlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1saWdodC1pdGVtLWFjdGl2ZS1pY29uLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzY3Njc2N1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYnRuLWNvbG9yLWludmVyc2VcIixcInZhbHVlXCI6XCJ3aGl0ZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tbGlnaHQtYnRuLWNvbG9yLXNlY29uZGFyeVwiLFwidmFsdWVcIjpcIiMwZDBkMGRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstcHJpbWFyeVwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstYmFja2dyb3VuZFwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstYWNjZW50XCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZGFyay1ib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWJ0bi1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstYmFja2dyb3VuZC1hbHQtNVwiLFwidmFsdWVcIjpcIiMzZDNkM2RcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstYmFja2dyb3VuZC1hbHQtMTBcIixcInZhbHVlXCI6XCIjNGE0YTRhXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWJhY2tncm91bmQtYWx0LTIwXCIsXCJ2YWx1ZVwiOlwiIzYzNjM2M1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZGFyay1zZWNvbmRhcnlcIixcInZhbHVlXCI6XCIjYjNiM2IzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWRpc2FibGVkXCIsXCJ2YWx1ZVwiOlwiIzMwNjg4M1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZGFyay1hYi1jb2xvclwiLFwidmFsdWVcIjpcIndoaXRlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWFiLWJhY2tncm91bmRcIixcInZhbHVlXCI6XCIjMzc0NTk3XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLXRleHQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWhlYWRpbmdzLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZGFyay10YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiNhYmQ1ZTlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstYWNjZW50LWRhcmtcIixcInZhbHVlXCI6XCIjOTZkZGZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWFjY2VudC1saWdodFwiLFwidmFsdWVcIjpcIiNmY2ZlZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstYWNjZW50LXRyYW5zcGFyZW50XCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwgMTg4LCAyNTUsIDAuOClcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstcHJpbWFyeS1hY2NlbnRcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LCAxODgsIDI1NSwgMC40KVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZGFyay1iYWNrZ3JvdW5kLWFjY2VudFwiLFwidmFsdWVcIjpcInJnYmEoNDgsIDE4OCwgMjU1LCAwLjEpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWJhY2tncm91bmQtZGFyay1hY2NlbnRcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LCAxODgsIDI1NSwgMC4xNSlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstaXRlbS1hY3RpdmUtY29sb3JcIixcInZhbHVlXCI6XCIjYzFjMWMxXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWl0ZW0tYWN0aXZlLWJhY2tncm91bmRcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LCAxODgsIDI1NSwgMC4xNSlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCItLWRhcmstYWItYmFja2dyb3VuZC1kYXJrXCIsXCJ2YWx1ZVwiOlwiIzMwM2M4NFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZGFyay1pdGVtLWFjdGl2ZS1pY29uLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2MxYzFjMVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIi0tZGFyay1idG4tY29sb3ItaW52ZXJzZVwiLFwidmFsdWVcIjpcIndoaXRlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiLS1kYXJrLWJ0bi1jb2xvci1zZWNvbmRhcnlcIixcInZhbHVlXCI6XCIjZTZlNmU2XCJ9XX1dLFwicGFyc2luZ0Vycm9yc1wiOltdfX07OyBcbmlmIChtb2R1bGUuaG90ICYmIGdsb2JhbC5faXNNb2R1bGVMb2FkZWRGb3JVSSAmJiBnbG9iYWwuX2lzTW9kdWxlTG9hZGVkRm9yVUkoXCIvVXNlcnMvc3RldmVoYW5sb24vY29kaW5nL2phdmFzY3JpcHQvU1ZFTFRFX05BVElWRS90b2RvYXBwL25vZGVfbW9kdWxlcy9uYXRpdmVzY3JpcHQtdGhlbWUtY29yZS9jc3MvYmx1ZS5jc3NcIikgKSB7XG4gICAgXG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoKTtcbiAgICBtb2R1bGUuaG90LmRpc3Bvc2UoKCkgPT4ge1xuICAgICAgICBnbG9iYWwuaG1yUmVmcmVzaCh7IHR5cGU6IFwic3R5bGVcIiwgcGF0aDogXCIvVXNlcnMvc3RldmVoYW5sb24vY29kaW5nL2phdmFzY3JpcHQvU1ZFTFRFX05BVElWRS90b2RvYXBwL25vZGVfbW9kdWxlcy9uYXRpdmVzY3JpcHQtdGhlbWUtY29yZS9jc3MvYmx1ZS5jc3NcIiB9KTtcbiAgICB9KTtcbn0gIiwibW9kdWxlLmV4cG9ydHMgPSB7XCJ0eXBlXCI6XCJzdHlsZXNoZWV0XCIsXCJzdHlsZXNoZWV0XCI6e1wicnVsZXNcIjpbe1widHlwZVwiOlwiY29tbWVudFwiLFwiY29tbWVudFwiOlwiIVxcbiAqIE5hdGl2ZVNjcmlwdCBUaGVtZSB2Mi4wLjI0IChodHRwczovL25hdGl2ZXNjcmlwdC5vcmcpXFxuICogQ29weXJpZ2h0IDIwMTYtMjAxNiBUaGUgVGhlbWUgQXV0aG9yc1xcbiAqIENvcHlyaWdodCAyMDE2LTIwMTkgUHJvZ3Jlc3MgU29mdHdhcmVcXG4gKiBMaWNlbnNlZCB1bmRlciBBcGFjaGUgMi4wIChodHRwczovL2dpdGh1Yi5jb20vTmF0aXZlU2NyaXB0L3RoZW1lL2Jsb2IvbWFzdGVyL0xJQ0VOU0UpXFxuIFwifSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1ibGFja1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLWJsYWNrXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy13aGl0ZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLXdoaXRlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1ncmV5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZTBlMGUwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYmctZ3JleVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZTBlMGUwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtZ3JleS1saWdodFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2JhYmFiYVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLWdyZXktbGlnaHRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2JhYmFiYVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWNoYXJjb2FsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYmctY2hhcmNvYWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLXRyYW5zcGFyZW50XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCJ0cmFuc3BhcmVudFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLXRyYW5zcGFyZW50XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInRyYW5zcGFyZW50XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYXF1YVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwY2FhYlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLWFxdWFcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwY2FhYlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJsdWVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzZDVhZmVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1iZy1ibHVlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzZDVhZmVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1icm93blwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzc5NTU0OFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLWJyb3duXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiM3OTU1NDhcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1mb3Jlc3RcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDY5NjhcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1iZy1mb3Jlc3RcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwNjk2OFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWdyZXktZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzVjNjg3Y1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLWdyZXktZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjNWM2ODdjXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtcHVycGxlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjODEzMGZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYmctcHVycGxlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiM4MTMwZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1sZW1vblwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZWEwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLWxlbW9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmVhMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1saW1lXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjYWVlNDA2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYmctbGltZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjYWVlNDA2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtb3JhbmdlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZjU3YzAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYmctb3JhbmdlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmNTdjMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1ydWJ5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmYxNzQ0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYmctcnVieVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmYxNzQ0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtc2t5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmMtYmctc2t5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYy1lcnJvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2Q1MDAwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5jLWJnLWVycm9yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNkNTAwMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudy1mdWxsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCIxMDAlXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnctMTAwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCIxMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuaC1mdWxsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaGVpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTAwJVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5oLTEwMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhlaWdodFwiLFwidmFsdWVcIjpcIjEwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC0wXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi0wXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS0wXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC0yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi0yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIyXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS0yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjJcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLTRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCI0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC00XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLTRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCI0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi00XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLTRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LTRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCI0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCI0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS00XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC01XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi01XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCI1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS01XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLThcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC04XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjhcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLThcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi04XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjhcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLThcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjhcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LThcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCI4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS04XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjhcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLTEwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS10LTEwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjEwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tci0xMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1yaWdodFwiLFwidmFsdWVcIjpcIjEwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi0xMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIxMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLWwtMTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjEwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teC0xMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1yaWdodFwiLFwidmFsdWVcIjpcIjEwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIxMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXktMTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tdG9wXCIsXCJ2YWx1ZVwiOlwiMTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS0xMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjEyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC0xMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCIxMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXItMTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIxMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLWItMTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMTJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLTEyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIxMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXgtMTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIxMlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMTJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS15LTEyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjEyXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjEyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIxNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXQtMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tdG9wXCIsXCJ2YWx1ZVwiOlwiMTVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLTE1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1iLTE1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjE1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tbC0xNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMTVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LTE1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjE1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS0xNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCIxNVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIxNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS10LTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjE2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tci0xNlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1yaWdodFwiLFwidmFsdWVcIjpcIjE2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi0xNlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIxNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLWwtMTZcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjE2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teC0xNlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1yaWdodFwiLFwidmFsdWVcIjpcIjE2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIxNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXktMTZcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tdG9wXCIsXCJ2YWx1ZVwiOlwiMTZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCIyMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXItMjBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIyMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLWItMjBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLTIwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIyMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXgtMjBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIyMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS15LTIwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tMjRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXQtMjRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tdG9wXCIsXCJ2YWx1ZVwiOlwiMjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLTI0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1iLTI0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjI0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tbC0yNFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LTI0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMjRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjI0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS0yNFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCIyNFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLTI1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS10LTI1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tci0yNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1yaWdodFwiLFwidmFsdWVcIjpcIjI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tYi0yNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIyNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLWwtMjVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teC0yNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1yaWdodFwiLFwidmFsdWVcIjpcIjI1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIyNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXktMjVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tdG9wXCIsXCJ2YWx1ZVwiOlwiMjVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS0yOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tdC0yOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCIyOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXItMjhcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIyOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLWItMjhcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMjhcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1sLTI4XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWxlZnRcIixcInZhbHVlXCI6XCIyOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXgtMjhcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tcmlnaHRcIixcInZhbHVlXCI6XCIyOFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMjhcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS15LTI4XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXRvcFwiLFwidmFsdWVcIjpcIjI4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tMzBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXQtMzBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tdG9wXCIsXCJ2YWx1ZVwiOlwiMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1yLTMwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS1iLTMwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0tbC0zMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS14LTMwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm0teS0zMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCIzMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi0wXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC0wXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi0yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC0yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIyXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLTRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtNFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItNFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCI0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi00XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCI0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC00XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtNFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCI0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktNFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiNFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi01XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC01XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCI1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiNVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLThcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi04XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC04XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCI4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiOFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLTEwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjEwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtdC0xMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1yLTEwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1yaWdodFwiLFwidmFsdWVcIjpcIjEwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi0xMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1sLTEwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC14LTEwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1yaWdodFwiLFwidmFsdWVcIjpcIjEwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC15LTEwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy10b3BcIixcInZhbHVlXCI6XCIxMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC0xMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCIxMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtMTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXRvcFwiLFwidmFsdWVcIjpcIjEyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtci0xMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIxMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLWItMTJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWJvdHRvbVwiLFwidmFsdWVcIjpcIjEyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC0xMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctbGVmdFwiLFwidmFsdWVcIjpcIjEyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAteC0xMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIxMlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctbGVmdFwiLFwidmFsdWVcIjpcIjEyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAteS0xMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMTJcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWJvdHRvbVwiLFwidmFsdWVcIjpcIjEyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMTVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC10LTE1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy10b3BcIixcInZhbHVlXCI6XCIxNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1iLTE1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIxNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLWwtMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWxlZnRcIixcInZhbHVlXCI6XCIxNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWxlZnRcIixcInZhbHVlXCI6XCIxNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXRvcFwiLFwidmFsdWVcIjpcIjE1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIxNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjE2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtdC0xNlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1yLTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1yaWdodFwiLFwidmFsdWVcIjpcIjE2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi0xNlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1sLTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC14LTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1yaWdodFwiLFwidmFsdWVcIjpcIjE2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC15LTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy10b3BcIixcInZhbHVlXCI6XCIxNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCIyMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtMjBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXRvcFwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtci0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIyMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLWItMjBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWJvdHRvbVwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctbGVmdFwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAteC0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIyMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctbGVmdFwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAteS0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWJvdHRvbVwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtMjRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC10LTI0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy10b3BcIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItMjRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1iLTI0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLWwtMjRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWxlZnRcIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtMjRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMjRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWxlZnRcIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktMjRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXRvcFwiLFwidmFsdWVcIjpcIjI0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLTI1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtdC0yNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1yLTI1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1yaWdodFwiLFwidmFsdWVcIjpcIjI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtYi0yNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1sLTI1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC14LTI1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1yaWdodFwiLFwidmFsdWVcIjpcIjI1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC15LTI1XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy10b3BcIixcInZhbHVlXCI6XCIyNVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC0yOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCIyOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXQtMjhcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXRvcFwiLFwidmFsdWVcIjpcIjI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtci0yOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIyOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLWItMjhcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWJvdHRvbVwiLFwidmFsdWVcIjpcIjI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtbC0yOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctbGVmdFwiLFwidmFsdWVcIjpcIjI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAteC0yOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctcmlnaHRcIixcInZhbHVlXCI6XCIyOFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctbGVmdFwiLFwidmFsdWVcIjpcIjI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAteS0yOFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMjhcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWJvdHRvbVwiLFwidmFsdWVcIjpcIjI4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnAtMzBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC10LTMwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy10b3BcIixcInZhbHVlXCI6XCIzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXItMzBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucC1iLTMwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLWwtMzBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWxlZnRcIixcInZhbHVlXCI6XCIzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXgtMzBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLWxlZnRcIixcInZhbHVlXCI6XCIzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5wLXktMzBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nLXRvcFwiLFwidmFsdWVcIjpcIjMwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1ib3R0b21cIixcInZhbHVlXCI6XCIzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50ZXh0LWxlZnRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LWFsaWduXCIsXCJ2YWx1ZVwiOlwibGVmdFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50ZXh0LXJpZ2h0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1hbGlnblwiLFwidmFsdWVcIjpcInJpZ2h0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnRleHQtY2VudGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50ZXh0LWxvd2VyY2FzZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInRleHQtdHJhbnNmb3JtXCIsXCJ2YWx1ZVwiOlwibG93ZXJjYXNlXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnRleHQtdXBwZXJjYXNlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC10cmFuc2Zvcm1cIixcInZhbHVlXCI6XCJ1cHBlcmNhc2VcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudGV4dC1jYXBpdGFsaXplXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC10cmFuc2Zvcm1cIixcInZhbHVlXCI6XCJjYXBpdGFsaXplXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmZvbnQtd2VpZ2h0LW5vcm1hbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtd2VpZ2h0XCIsXCJ2YWx1ZVwiOlwibm9ybWFsXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmZvbnQtd2VpZ2h0LWJvbGRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXdlaWdodFwiLFwidmFsdWVcIjpcImJvbGRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZm9udC1pdGFsaWNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXN0eWxlXCIsXCJ2YWx1ZVwiOlwiaXRhbGljXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnQtMTBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50LTEyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMThcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudC0xNFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnQtMTVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIyMVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50LTE2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudC0xN1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjIzXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnQtMThcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50LTE5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudC0yMFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjI2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnQtMjVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIzMVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50LTMwXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMzZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudC0zNlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjQyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmgxXCIsXCIuaDJcIixcIi5oM1wiLFwiLmg0XCIsXCIuaDVcIixcIi5oNlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCI0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCJub3JtYWxcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayAuaDFcIixcIi5ucy1kYXJrIC5oMlwiLFwiLm5zLWRhcmsgLmgzXCIsXCIubnMtZGFyayAuaDRcIixcIi5ucy1kYXJrIC5oNVwiLFwiLm5zLWRhcmsgLmg2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmJvZHlcIixcIi5ib2R5MlwiLFwiLmZvb3Rub3RlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjNzM3MzczXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCJub3JtYWxcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayAuYm9keVwiLFwiLm5zLWRhcmsgLmJvZHkyXCIsXCIubnMtZGFyayAuZm9vdG5vdGVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNiM2IzYjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuaDFcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIzMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5oMlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjIyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmgzXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuaDRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5oNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjExXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmg2XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYm9keVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjE0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmJvZHkyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTdcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZm9vdG5vdGVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxM1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIC5oMVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjM0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWFuZHJvaWQgLmgyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtYW5kcm9pZCAuaDNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIC5oNVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjExXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC13ZWlnaHRcIixcInZhbHVlXCI6XCJib2xkXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWFuZHJvaWQgLmJvZHkyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXdlaWdodFwiLFwidmFsdWVcIjpcIjUwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5pbWctcm91bmRlZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1yYWRpdXNcIixcInZhbHVlXCI6XCI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmltZy1jaXJjbGVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItcmFkaXVzXCIsXCJ2YWx1ZVwiOlwiNTAlXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmltZy10aHVtYm5haWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItcmFkaXVzXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5pbnZpc2libGVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ2aXNpYmlsaXR5XCIsXCJ2YWx1ZVwiOlwiY29sbGFwc2VcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucHVsbC1sZWZ0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaG9yaXpvbnRhbC1hbGlnblwiLFwidmFsdWVcIjpcImxlZnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIucHVsbC1yaWdodFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhvcml6b250YWwtYWxpZ25cIixcInZhbHVlXCI6XCJyaWdodFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5tLXgtYXV0b1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhvcml6b250YWwtYWxpZ25cIixcInZhbHVlXCI6XCJjZW50ZXJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubS15LWF1dG9cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ2ZXJ0aWNhbC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi50ZXh0LXByaW1hcnlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIudGV4dC1kYW5nZXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNkNTAwMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuYmctcHJpbWFyeVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmJnLWRhbmdlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZDUwMDAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmZhXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1mYW1pbHlcIixcInZhbHVlXCI6XCJGb250QXdlc29tZSxmb250YXdlc29tZS13ZWJmb250XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLXJvb3RcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LWZhbWlseVwiLFwidmFsdWVcIjpcInNhbnMtc2VyaWZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXdlaWdodFwiLFwidmFsdWVcIjpcIm5vcm1hbFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjE2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtcm9vdFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi4taGlkZGVuXCIsXCIuaGlkZGVuXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidmlzaWJpbGl0eVwiLFwidmFsdWVcIjpcImNvbGxhcHNlZFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi4tcm91bmRlZFwiLFwiLnJvdW5kZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItcmFkaXVzXCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5oclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhlaWdodFwiLFwidmFsdWVcIjpcIjFcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ3aWR0aFwiLFwidmFsdWVcIjpcIjEwMCVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCI5IDAgMTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItd2lkdGhcIixcInZhbHVlXCI6XCIwIDAgMVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1zdHlsZVwiLFwidmFsdWVcIjpcInNvbGlkXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLnRleHQtbXV0ZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNhY2U0ZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayAudGV4dC1tdXRlZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwNjg4M1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxhYmVsPipcIixcIkxhYmVsPio+KlwiLFwiQnV0dG9uPipcIixcIkJ1dHRvbj4qPipcIixcIlRleHRGaWVsZD4qXCIsXCJUZXh0RmllbGQ+Kj4qXCIsXCJUZXh0Vmlldz4qXCIsXCJUZXh0Vmlldz4qPipcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJJbWFnZVwiLFwiTGlzdFZpZXdcIixcIlJhZExpc3RWaWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWluLWhlaWdodFwiLFwidmFsdWVcIjpcIjEwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIk5USWNvblwiLFwiLm50LWljb25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvblwiLFwiLm50LWJ1dHRvblwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInRleHQtdHJhbnNmb3JtXCIsXCJ2YWx1ZVwiOlwibm9uZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcInRyYW5zcGFyZW50XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWluLXdpZHRoXCIsXCJ2YWx1ZVwiOlwiNjRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJoZWlnaHRcIixcInZhbHVlXCI6XCI1MlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCIwIDAgMCAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMThcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCI4IDE2IDggMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIEJ1dHRvblwiLFwiLm5zLWlvcyAubnQtYnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaGVpZ2h0XCIsXCJ2YWx1ZVwiOlwiNDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItd2lkdGhcIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWFuZHJvaWQgQnV0dG9uXCIsXCIubnMtYW5kcm9pZCAubnQtYnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiNCAxMlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbi4tb3V0bGluZVwiLFwiLm50LWJ1dHRvbi4tb3V0bGluZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhlaWdodFwiLFwidmFsdWVcIjpcIjQwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXdpZHRoXCIsXCJ2YWx1ZVwiOlwiMVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIEJ1dHRvbi4tb3V0bGluZVwiLFwiLm5zLWFuZHJvaWQgLm50LWJ1dHRvbi4tb3V0bGluZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjggMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJCdXR0b24uLXJvdW5kZWQtc21cIixcIkJ1dHRvbi4tcm91bmRlZC1sZ1wiLFwiLm50LWJ1dHRvbi4tcm91bmRlZC1zbVwiLFwiLm50LWJ1dHRvbi4tcm91bmRlZC1sZ1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhlaWdodFwiLFwidmFsdWVcIjpcIjQwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcIjRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtYW5kcm9pZCBCdXR0b24uLXJvdW5kZWQtc21cIixcIi5ucy1hbmRyb2lkIEJ1dHRvbi4tcm91bmRlZC1sZ1wiLFwiLm5zLWFuZHJvaWQgLm50LWJ1dHRvbi4tcm91bmRlZC1zbVwiLFwiLm5zLWFuZHJvaWQgLm50LWJ1dHRvbi4tcm91bmRlZC1sZ1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjggMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJCdXR0b24uLXJvdW5kZWQtbGdcIixcIi5udC1idXR0b24uLXJvdW5kZWQtbGdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItcmFkaXVzXCIsXCJ2YWx1ZVwiOlwiNTAlXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQnV0dG9uW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5udC1idXR0b25baXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm9wYWNpdHlcIixcInZhbHVlXCI6XCIuNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbi4tc2ltcGxlXCIsXCIubnQtYnV0dG9uLi1zaW1wbGVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJhbmRyb2lkLWVsZXZhdGlvblwiLFwidmFsdWVcIjpcIjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJhbmRyb2lkLWR5bmFtaWMtZWxldmF0aW9uLW9mZnNldFwiLFwidmFsdWVcIjpcIjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtcm9vdCBCdXR0b24uLWFxdWFcIixcIi5ucy1yb290IC5udC1idXR0b24uLWFxdWFcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwY2FhYlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGNhYWJcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZGZmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1yb290IEJ1dHRvbi4tYXF1YVwiLFwiLm5zLWRhcmsubnMtcm9vdCAubnQtYnV0dG9uLi1hcXVhXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGNhYWJcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjMDBjYWFiXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmRmZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLXJvb3QgQnV0dG9uLi1ibHVlXCIsXCIubnMtcm9vdCAubnQtYnV0dG9uLi1ibHVlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzZDVhZmVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjM2Q1YWZlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtcm9vdCBCdXR0b24uLWJsdWVcIixcIi5ucy1kYXJrLm5zLXJvb3QgLm50LWJ1dHRvbi4tYmx1ZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjM2Q1YWZlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzNkNWFmZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1yb290IEJ1dHRvbi4tYnJvd25cIixcIi5ucy1yb290IC5udC1idXR0b24uLWJyb3duXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiM3OTU1NDhcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjNzk1NTQ4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmJmOWY4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtcm9vdCBCdXR0b24uLWJyb3duXCIsXCIubnMtZGFyay5ucy1yb290IC5udC1idXR0b24uLWJyb3duXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiM3OTU1NDhcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjNzk1NTQ4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmJmOWY4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLXJvb3QgQnV0dG9uLi1mb3Jlc3RcIixcIi5ucy1yb290IC5udC1idXR0b24uLWZvcmVzdFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzljZmZmZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMDA2OTY4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwNjk2OFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLXJvb3QgQnV0dG9uLi1mb3Jlc3RcIixcIi5ucy1kYXJrLm5zLXJvb3QgLm50LWJ1dHRvbi4tZm9yZXN0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjOWNmZmZlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDY5NjhcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjMDA2OTY4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLXJvb3QgQnV0dG9uLi1ncmV5XCIsXCIubnMtcm9vdCAubnQtYnV0dG9uLi1ncmV5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiM1YzY4N2NcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjNWM2ODdjXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtcm9vdCBCdXR0b24uLWdyZXlcIixcIi5ucy1kYXJrLm5zLXJvb3QgLm50LWJ1dHRvbi4tZ3JleVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjNWM2ODdjXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzVjNjg3Y1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1yb290IEJ1dHRvbi4tbGVtb25cIixcIi5ucy1yb290IC5udC1idXR0b24uLWxlbW9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmVhMDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjZmZlYTAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMDAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtcm9vdCBCdXR0b24uLWxlbW9uXCIsXCIubnMtZGFyay5ucy1yb290IC5udC1idXR0b24uLWxlbW9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmVhMDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjZmZlYTAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMDAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLXJvb3QgQnV0dG9uLi1saW1lXCIsXCIubnMtcm9vdCAubnQtYnV0dG9uLi1saW1lXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNhZWU0MDZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjYWVlNDA2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMDAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtcm9vdCBCdXR0b24uLWxpbWVcIixcIi5ucy1kYXJrLm5zLXJvb3QgLm50LWJ1dHRvbi4tbGltZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjYWVlNDA2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2FlZTQwNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1yb290IEJ1dHRvbi4tb3JhbmdlXCIsXCIubnMtcm9vdCAubnQtYnV0dG9uLi1vcmFuZ2VcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2Y1N2MwMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNmNTdjMDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1yb290IEJ1dHRvbi4tb3JhbmdlXCIsXCIubnMtZGFyay5ucy1yb290IC5udC1idXR0b24uLW9yYW5nZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZjU3YzAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2Y1N2MwMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1yb290IEJ1dHRvbi4tcHVycGxlXCIsXCIubnMtcm9vdCAubnQtYnV0dG9uLi1wdXJwbGVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzgxMzBmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiM4MTMwZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1yb290IEJ1dHRvbi4tcHVycGxlXCIsXCIubnMtZGFyay5ucy1yb290IC5udC1idXR0b24uLXB1cnBsZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjODEzMGZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzgxMzBmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1yb290IEJ1dHRvbi4tcnVieVwiLFwiLm5zLXJvb3QgLm50LWJ1dHRvbi4tcnVieVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmYxNzQ0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmMTc0NFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLXJvb3QgQnV0dG9uLi1ydWJ5XCIsXCIubnMtZGFyay5ucy1yb290IC5udC1idXR0b24uLXJ1YnlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmMTc0NFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNmZjE3NDRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtcm9vdCBCdXR0b24uLXNreVwiLFwiLm5zLXJvb3QgLm50LWJ1dHRvbi4tc2t5XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtcm9vdCBCdXR0b24uLXNreVwiLFwiLm5zLWRhcmsubnMtcm9vdCAubnQtYnV0dG9uLi1za3lcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJQYWdlXCIsXCIubnQtcGFnZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUGFnZVwiLFwiLm5zLWRhcmsgLm50LXBhZ2VcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkFjdGl2aXR5SW5kaWNhdG9yXCIsXCIubnQtYWN0aXZpdHktaW5kaWNhdG9yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCIzMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhlaWdodFwiLFwidmFsdWVcIjpcIjMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiU2xpZGVyXCIsXCIubnQtc2xpZGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMjAgMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIFNsaWRlclwiLFwiLm5zLWlvcyAubnQtc2xpZGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMTAgMTVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJTbGlkZXJbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm50LXNsaWRlcltpc0VuYWJsZWQ9ZmFsc2VdXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNlMGUwZTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNlMGUwZTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtYW5kcm9pZCBTd2l0Y2hcIixcIi5ucy1hbmRyb2lkIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIxNCAxNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtYW5kcm9pZCAubnQtc3dpdGNoW2lzRW5hYmxlZD1mYWxzZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNlNmU2ZTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1hbmRyb2lkIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1zd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzRhNGE0YVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1pb3MgU3dpdGNoXCIsXCIubnMtaW9zIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCI4IDE1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWlvcyBTd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWlvcyAubnQtc3dpdGNoW2lzRW5hYmxlZD1mYWxzZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC40KVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLWlvcyBTd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWRhcmsubnMtaW9zIC5udC1zd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LDE4OCwyNTUsLjQpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGFiVmlld1wiLFwiLm50LXRhYi12aWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGFiLXRleHQtZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMThcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LXRyYW5zZm9ybVwiLFwidmFsdWVcIjpcImNhcGl0YWxpemVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJCb3R0b21OYXZpZ2F0aW9uXCIsXCIubnQtYm90dG9tLW5hdmlnYXRpb25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3XCIsXCJSYWRMaXN0Vmlld1wiLFwiLm50LWxpc3Qtdmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1pbi1oZWlnaHRcIixcInZhbHVlXCI6XCIxMDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJMaXN0VmlldyBTdGFja0xheW91dFwiLFwiUmFkTGlzdFZpZXcgU3RhY2tMYXlvdXRcIixcIi5udC1saXN0LXZpZXcgU3RhY2tMYXlvdXRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3PipcIixcIlJhZExpc3RWaWV3PipcIixcIi5udC1saXN0LXZpZXc+KlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJ0cmFuc3BhcmVudFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCI4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3PiogTGFiZWxcIixcIlJhZExpc3RWaWV3PiogTGFiZWxcIixcIi5udC1saXN0LXZpZXc+KiBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCI1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidmVydGljYWwtYWxpZ25cIixcInZhbHVlXCI6XCJjZW50ZXJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJMaXN0Vmlldz4qIEltYWdlXCIsXCJSYWRMaXN0Vmlldz4qIEltYWdlXCIsXCIubnQtbGlzdC12aWV3PiogSW1hZ2VcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzdHJldGNoXCIsXCJ2YWx1ZVwiOlwiYXNwZWN0Rml0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXcuLXNpbmdsZS1jb2wtY2FyZHMgSW1hZ2VcIixcIlJhZExpc3RWaWV3Li1zaW5nbGUtY29sLWNhcmRzIEltYWdlXCIsXCIubnQtbGlzdC12aWV3Li1zaW5nbGUtY29sLWNhcmRzIEltYWdlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCIxMDAlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaGVpZ2h0XCIsXCJ2YWx1ZVwiOlwiMjAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXcuLXR3by1jb2wtY2FyZHMgSW1hZ2VcIixcIlJhZExpc3RWaWV3Li10d28tY29sLWNhcmRzIEltYWdlXCIsXCIubnQtbGlzdC12aWV3Li10d28tY29sLWNhcmRzIEltYWdlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaGVpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWlvcyBMaXN0Vmlldy4tdHdvLWNvbC1jYXJkcz5TdGFja0xheW91dFwiLFwiLm5zLWlvcyBSYWRMaXN0Vmlldy4tdHdvLWNvbC1jYXJkcz5TdGFja0xheW91dFwiLFwiLm5zLWlvcyAubnQtbGlzdC12aWV3Li10d28tY29sLWNhcmRzPlN0YWNrTGF5b3V0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCI1MCVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIExpc3RWaWV3Li10d28tY29sLWNhcmRzPlN0YWNrTGF5b3V0IEltYWdlXCIsXCIubnMtaW9zIFJhZExpc3RWaWV3Li10d28tY29sLWNhcmRzPlN0YWNrTGF5b3V0IEltYWdlXCIsXCIubnMtaW9zIC5udC1saXN0LXZpZXcuLXR3by1jb2wtY2FyZHM+U3RhY2tMYXlvdXQgSW1hZ2VcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJob3Jpem9udGFsLWFsaWduXCIsXCJ2YWx1ZVwiOlwibGVmdFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIndpZHRoXCIsXCJ2YWx1ZVwiOlwiMTAwJVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3Li10d28tbGluZXMtaW1hZ2UgSW1hZ2VcIixcIkxpc3RWaWV3Li1zaW5nbGUtbGluZS1pbWFnZSBJbWFnZVwiLFwiUmFkTGlzdFZpZXcuLXR3by1saW5lcy1pbWFnZSBJbWFnZVwiLFwiUmFkTGlzdFZpZXcuLXNpbmdsZS1saW5lLWltYWdlIEltYWdlXCIsXCIubnQtbGlzdC12aWV3Li10d28tbGluZXMtaW1hZ2UgSW1hZ2VcIixcIi5udC1saXN0LXZpZXcuLXNpbmdsZS1saW5lLWltYWdlIEltYWdlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCI2MFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhlaWdodFwiLFwidmFsdWVcIjpcIjYwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tYm90dG9tXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3IC4tc2VwYXJhdG9yXCIsXCJSYWRMaXN0VmlldyAuLXNlcGFyYXRvclwiLFwiLm50LWxpc3QtdmlldyAuLXNlcGFyYXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1ib3R0b20td2lkdGhcIixcInZhbHVlXCI6XCIxXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlXCIsXCJSYWRMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGVcIixcIi5udC1saXN0LXZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjAgMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIExpc3RWaWV3IC5udC1saXN0LXZpZXdfX2RlbGV0ZVwiLFwiLm5zLWlvcyBSYWRMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGVcIixcIi5ucy1pb3MgLm50LWxpc3QtdmlldyAubnQtbGlzdC12aWV3X19kZWxldGVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMCAxMCAwIDI1XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlPkxhYmVsXCIsXCJSYWRMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIixcIi5udC1saXN0LXZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlPkxhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaG9yaXpvbnRhbC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInZlcnRpY2FsLWFsaWduXCIsXCJ2YWx1ZVwiOlwiY2VudGVyXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC10cmFuc2Zvcm1cIixcInZhbHVlXCI6XCJjYXBpdGFsaXplXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXcgTlRJY29uXCIsXCJMaXN0VmlldyAubnQtaWNvblwiLFwiUmFkTGlzdFZpZXcgTlRJY29uXCIsXCJSYWRMaXN0VmlldyAubnQtaWNvblwiLFwiLm50LWxpc3QtdmlldyBOVEljb25cIixcIi5udC1saXN0LXZpZXcgLm50LWljb25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIyMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIndpZHRoXCIsXCJ2YWx1ZVwiOlwiNTZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJoZWlnaHRcIixcInZhbHVlXCI6XCIxMDAlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZExpc3RWaWV3PlN0YWNrTGF5b3V0XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRMaXN0Vmlldz4qPipcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRTaWRlRHJhd2VyIC5udC1kcmF3ZXJfX2hlYWRlclwiLFwiLm50LWRyYXdlciAubnQtZHJhd2VyX19oZWFkZXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJoZWlnaHRcIixcInZhbHVlXCI6XCIxNDhcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ3aWR0aFwiLFwidmFsdWVcIjpcIjEwMCVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ2ZXJ0aWNhbC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyIExhYmVsXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2hlYWRlciBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidmVydGljYWwtYWxpZ25cIixcInZhbHVlXCI6XCJjZW50ZXJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRTaWRlRHJhd2VyIC5udC1kcmF3ZXJfX2hlYWRlcj5MYWJlbFwiLFwiLm50LWRyYXdlciAubnQtZHJhd2VyX19oZWFkZXI+TGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyLWltYWdlXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2hlYWRlci1pbWFnZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhlaWdodFwiLFwidmFsdWVcIjpcIjc0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCI3NFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1yYWRpdXNcIixcInZhbHVlXCI6XCI1MCVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ2ZXJ0aWNhbC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19oZWFkZXItZm9vdG5vdGVcIixcIi5udC1kcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyLWZvb3Rub3RlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwib3BhY2l0eVwiLFwidmFsdWVcIjpcIi41XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19oZWFkZXI+TGFiZWxcIixcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyLWltYWdlXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2hlYWRlcj5MYWJlbFwiLFwiLm50LWRyYXdlciAubnQtZHJhd2VyX19oZWFkZXItaW1hZ2VcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW4tbGVmdFwiLFwidmFsdWVcIjpcIjE1XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLXJpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJob3Jpem9udGFsLWFsaWduXCIsXCJ2YWx1ZVwiOlwiY2VudGVyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19oZWFkZXIuLWxlZnQ+TGFiZWxcIixcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyLi1sZWZ0IC5udC1kcmF3ZXJfX2hlYWRlci1pbWFnZVwiLFwiLm50LWRyYXdlciAubnQtZHJhd2VyX19oZWFkZXIuLWxlZnQ+TGFiZWxcIixcIi5udC1kcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyLi1sZWZ0IC5udC1kcmF3ZXJfX2hlYWRlci1pbWFnZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhvcml6b250YWwtYWxpZ25cIixcInZhbHVlXCI6XCJsZWZ0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19saXN0LWl0ZW1cIixcIi5udC1kcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy1sZWZ0XCIsXCJ2YWx1ZVwiOlwiMTVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJoZWlnaHRcIixcInZhbHVlXCI6XCI0OFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhvcml6b250YWwtYWxpZ25cIixcInZhbHVlXCI6XCJsZWZ0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCIxMDAlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwib3JpZW50YXRpb25cIixcInZhbHVlXCI6XCJob3Jpem9udGFsXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19saXN0LWl0ZW0gTGFiZWxcIixcIi5udC1kcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtIExhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidmVydGljYWwtYWxpZ25cIixcInZhbHVlXCI6XCJjZW50ZXJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRTaWRlRHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbSBOVEljb25cIixcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtIC5udC1pY29uXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbSBOVEljb25cIixcIi5udC1kcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtIC5udC1pY29uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ3aWR0aFwiLFwidmFsdWVcIjpcIjMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2hlYWRlclwiLFwiLm50LWRyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2hlYWRlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMjMyMzIzXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2hlYWRlciBMYWJlbFwiLFwiLm50LWRyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2hlYWRlciBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2Q0ZDRkNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkZvcm1cIixcIi5udC1mb3JtXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1mYW1pbHlcIixcInZhbHVlXCI6XCJcXFwiUm9ib3RvIFJlZ3VsYXJcXFwiXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjE2IDAgMTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIEZvcm1cIixcIi5ucy1pb3MgLm50LWZvcm1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LWZhbWlseVwiLFwidmFsdWVcIjpcIlxcXCJTRiBVSSBUZXh0IFJlZ3VsYXJcXFwiLHN5c3RlbVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkZvcm0gLi1jZW50ZXJcIixcIi5udC1mb3JtIC4tY2VudGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaG9yaXpvbnRhbC1hbGlnblwiLFwidmFsdWVcIjpcImNlbnRlclwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkZvcm0gLm50LWZvcm1fX29yLXNlcGFyYXRvclwiLFwiLm50LWZvcm0gLm50LWZvcm1fX29yLXNlcGFyYXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjIwIDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJGb3JtIC5udC1mb3JtX19saW5rXCIsXCIubnQtZm9ybSAubnQtZm9ybV9fbGlua1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIEZvcm0gLm50LWZvcm1fX2xpbmtcIixcIi5ucy1kYXJrIC5udC1mb3JtIC5udC1mb3JtX19saW5rXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiRm9ybSAubnQtZm9ybV9fdGl0bGVcIixcIi5udC1mb3JtIC5udC1mb3JtX190aXRsZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjE4XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiRm9ybSAubnQtZm9ybV9fbG9nb1wiLFwiLm50LWZvcm0gLm50LWZvcm1fX2xvZ29cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIyMCAwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCI1MCVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJGb3JtIC5udC1mb3JtX192YWxpZGF0aW9uLW1lc3NhZ2VcIixcIi5udC1mb3JtIC5udC1mb3JtX192YWxpZGF0aW9uLW1lc3NhZ2VcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNkNTAwMDBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIxIDAgMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaGVpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJGb3JtIC5udC1mb3JtX19mb290ZXJcIixcIi5udC1mb3JtIC5udC1mb3JtX19mb290ZXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhvcml6b250YWwtYWxpZ25cIixcInZhbHVlXCI6XCJjZW50ZXJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJGb3JtIC5udC1mb3JtX19mb290ZXIgQnV0dG9uXCIsXCIubnQtZm9ybSAubnQtZm9ybV9fZm9vdGVyIEJ1dHRvblwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIndpZHRoXCIsXCJ2YWx1ZVwiOlwiNTAlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiNVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkZvcm1baXNFbmFibGVkPWZhbHNlXSAqXCIsXCIubnQtZm9ybVtpc0VuYWJsZWQ9ZmFsc2VdICpcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJvcGFjaXR5XCIsXCJ2YWx1ZVwiOlwiLjVcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJUZXh0Vmlldy5uZy12YWxpZFwiLFwiVGV4dEZpZWxkLm5nLXZhbGlkXCIsXCJQaWNrZXJGaWVsZC5uZy12YWxpZFwiLFwiRGF0ZVBpY2tlckZpZWxkLm5nLXZhbGlkXCIsXCJUaW1lUGlja2VyRmllbGQubmctdmFsaWRcIixcIlJhZEF1dG9Db21wbGV0ZVRleHRWaWV3Lm5nLXZhbGlkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luLWJvdHRvbVwiLFwidmFsdWVcIjpcIjIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGV4dFZpZXcubmctaW52YWxpZC5uZy1kaXJ0eVwiLFwiVGV4dEZpZWxkLm5nLWludmFsaWQubmctZGlydHlcIixcIlBpY2tlckZpZWxkLm5nLWludmFsaWQubmctZGlydHlcIixcIkRhdGVQaWNrZXJGaWVsZC5uZy1pbnZhbGlkLm5nLWRpcnR5XCIsXCJUaW1lUGlja2VyRmllbGQubmctaW52YWxpZC5uZy1kaXJ0eVwiLFwiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcubmctaW52YWxpZC5uZy1kaXJ0eVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1ib3R0b21cIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2Q1MDAwMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRleHRWaWV3XCIsXCJUZXh0RmllbGRcIixcIlBpY2tlckZpZWxkXCIsXCJEYXRlUGlja2VyRmllbGRcIixcIlRpbWVQaWNrZXJGaWVsZFwiLFwiRGF0ZVRpbWVQaWNrZXJGaWVsZHNcIixcIkRhdGFGb3JtRWRpdG9yQ29yZVwiLFwiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItd2lkdGhcIixcInZhbHVlXCI6XCIwIDAgMVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1yYWRpdXNcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInRyYW5zcGFyZW50XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiOCAwIDRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCI1IDE2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGV4dFZpZXcuLXJvdW5kZWRcIixcIlRleHRWaWV3Li1ib3JkZXJcIixcIlRleHRGaWVsZC4tcm91bmRlZFwiLFwiVGV4dEZpZWxkLi1ib3JkZXJcIixcIlBpY2tlckZpZWxkLi1yb3VuZGVkXCIsXCJQaWNrZXJGaWVsZC4tYm9yZGVyXCIsXCJEYXRlUGlja2VyRmllbGQuLXJvdW5kZWRcIixcIkRhdGVQaWNrZXJGaWVsZC4tYm9yZGVyXCIsXCJUaW1lUGlja2VyRmllbGQuLXJvdW5kZWRcIixcIlRpbWVQaWNrZXJGaWVsZC4tYm9yZGVyXCIsXCJEYXRlVGltZVBpY2tlckZpZWxkcy4tcm91bmRlZFwiLFwiRGF0ZVRpbWVQaWNrZXJGaWVsZHMuLWJvcmRlclwiLFwiRGF0YUZvcm1FZGl0b3JDb3JlLi1yb3VuZGVkXCIsXCJEYXRhRm9ybUVkaXRvckNvcmUuLWJvcmRlclwiLFwiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcuLXJvdW5kZWRcIixcIlJhZEF1dG9Db21wbGV0ZVRleHRWaWV3Li1ib3JkZXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItd2lkdGhcIixcInZhbHVlXCI6XCIxXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcIjVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMTIgMTRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJUZXh0Vmlldy4tcm91bmRlZFwiLFwiVGV4dEZpZWxkLi1yb3VuZGVkXCIsXCJQaWNrZXJGaWVsZC4tcm91bmRlZFwiLFwiRGF0ZVBpY2tlckZpZWxkLi1yb3VuZGVkXCIsXCJUaW1lUGlja2VyRmllbGQuLXJvdW5kZWRcIixcIkRhdGVUaW1lUGlja2VyRmllbGRzLi1yb3VuZGVkXCIsXCJEYXRhRm9ybUVkaXRvckNvcmUuLXJvdW5kZWRcIixcIlJhZEF1dG9Db21wbGV0ZVRleHRWaWV3Li1yb3VuZGVkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcIjUwJVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRleHRWaWV3W2lzRW5hYmxlZD1mYWxzZV1cIixcIlRleHRGaWVsZFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJQaWNrZXJGaWVsZFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJEYXRlUGlja2VyRmllbGRbaXNFbmFibGVkPWZhbHNlXVwiLFwiVGltZVBpY2tlckZpZWxkW2lzRW5hYmxlZD1mYWxzZV1cIixcIkRhdGVUaW1lUGlja2VyRmllbGRzW2lzRW5hYmxlZD1mYWxzZV1cIixcIkRhdGFGb3JtRWRpdG9yQ29yZVtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJSYWRBdXRvQ29tcGxldGVUZXh0Vmlld1tpc0VuYWJsZWQ9ZmFsc2VdXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwib3BhY2l0eVwiLFwidmFsdWVcIjpcIi41XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGFiZWxcIixcIkRhdGFGb3JtRWRpdG9yTGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMiAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGV4dFZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtaW4taGVpZ2h0XCIsXCJ2YWx1ZVwiOlwiMTAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXdbZGlzcGxheU1vZGU9VG9rZW5zXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCI0IDAgOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZEF1dG9Db21wbGV0ZVRleHRWaWV3IFRva2VuXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLXJhZGl1c1wiLFwidmFsdWVcIjpcIjUwJVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIFRva2VuQ2xlYXJCdXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ3aWR0aFwiLFwidmFsdWVcIjpcIjE4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaGVpZ2h0XCIsXCJ2YWx1ZVwiOlwiMThcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItcmFkaXVzXCIsXCJ2YWx1ZVwiOlwiNTAlXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwib3BhY2l0eVwiLFwidmFsdWVcIjpcIi42XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUGlja2VyRmllbGRcIixcIkRhdGVQaWNrZXJGaWVsZFwiLFwiVGltZVBpY2tlckZpZWxkXCIsXCJEYXRlVGltZVBpY2tlckZpZWxkc1wiLFwiRGF0YUZvcm1FZGl0b3JDb3JlXCIsXCJSYWRBdXRvQ29tcGxldGVUZXh0Vmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtcmVwZWF0XCIsXCJ2YWx1ZVwiOlwibm8tcmVwZWF0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1wb3NpdGlvblwiLFwidmFsdWVcIjpcInJpZ2h0IGNlbnRlclwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1pb3MgUGlja2VyRmllbGRcIixcIi5ucy1pb3MgRGF0ZVBpY2tlckZpZWxkXCIsXCIubnMtaW9zIFRpbWVQaWNrZXJGaWVsZFwiLFwiLm5zLWlvcyBEYXRlVGltZVBpY2tlckZpZWxkc1wiLFwiLm5zLWlvcyBEYXRhRm9ybUVkaXRvckNvcmVcIixcIi5ucy1pb3MgUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLXNpemVcIixcInZhbHVlXCI6XCIyOCAxNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlByb3BlcnR5RWRpdG9yW3R5cGU9RGF0ZV0gRGF0YUZvcm1FZGl0b3JDb3JlXCIsXCJEYXRlUGlja2VyRmllbGRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWltYWdlXCIsXCJ2YWx1ZVwiOlwidXJsKFxcXCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUZRQUFBQXdCQU1BQUFCOUlFQytBQUFBRDFCTVZFVkhjRXdBQUFBQUFBQUFBQUFBQUFEVHJBai9BQUFBQkhSU1RsTUF3QkFnVTVEQ1F3QUFBRmRKUkVGVVNNZGpZQ0FWdUxpNG9ESG9wNVJKeEFVRE9DcGdWY3JvZ2dVSVlGWEtnazJwTXc2bENoaHVkWEhBb1pTQlZrclJ3MjZFS2NVQzZLdDBOQW9Ha1ZJV2FGU05LaDI1U2dkN1FVUkNaVVJDRlVjTEFBQzJJMmhFRUNCWVBnQUFBQUJKUlU1RXJrSmdnZz09XFxcIilcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJQcm9wZXJ0eUVkaXRvclt0eXBlPVRpbWVdIERhdGFGb3JtRWRpdG9yQ29yZVwiLFwiVGltZVBpY2tlckZpZWxkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1pbWFnZVwiLFwidmFsdWVcIjpcInVybChcXFwiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFGUUFBQUF3QkFNQUFBQjlJRUMrQUFBQUxWQk1WRVZIY0V3QUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUN0dGw2bkFBQUFEblJTVGxNQVlPQkF3Q0FRMEZDQWNQQ3dvRVp3ZGhzQUFBRTJTVVJCVkVqSFkyQVlMSUIxVGQyN2Q4OVBCUkJXeVFoVUNBTFBCUWlxMUhzSEJZOElxR1gxZS9mdXlXUmpZMHNRamQ4TjNlL2VLU2FBR0d4Qzc5N3R3R3M5VUNXTURWU0x6d2x5Nzk0bXdOaHM5OTQ5eEsyU0E4VWdvQlVOT0pWR281b2o5MjRyVHFWK0VFUDUzc0dNZllMYlUyOFprSlV5M01QcE1hWjNhcWhLazk0cDRQUy9BS3BTUnB4aFVQZUlBVlVwZzk1ekhKRUtNd09oVk80ZDlzamxldmNNWFduZXV3VllsZks4YzBCWHl2THVBSTRBbUlDdWxQTmRBVmFsZk84TTBKVnl2SHRBckZKbXFpcUZBQ29wYlNCV0tUc3NzQkFBVjJEQm93QUJjRVVCUEdJUkFGZkVzbUltT1Z6SkJaNElFUUJYSW9RbmJhUWM5SkJBaG9FRDNCa0dsZzNoQUhjMmhHVnVoTlluMUNneVNDaUlTQ2plU0NrMFNTaUtJUVg4REdQalRzSUZQQW5WQmltVkVTbFYzSUFCQUtEa3o1akhJY1RvQUFBQUFFbEZUa1N1UW1DQ1xcXCIpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiRGF0ZVRpbWVQaWNrZXJGaWVsZHNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtaW1hZ2VcIixcInZhbHVlXCI6XCJ1cmwoXFxcImRhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBS2dBQUFBd0JBTUFBQUIzVUN5cEFBQUFMVkJNVkVWSGNFd0FBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFDdHRsNm5BQUFBRG5SU1RsTUFRR0Rnd0JBZzBGQ0FjUEN3b005SWUra0FBQUdjU1VSQlZFakg1WmUvVHNNd0VNWkQycFFXVlJVWnUwVmlqeEFTYThVVFZKWFlVWFlXbmlEcWlsaGdZK1FCbUJFak13OVJ0VFFsVTc5bklDUnlyRGp4eFlrZHFZaHZpWWU3WDg3LzdzNldsUXFBTURDZ1B3RjE1aWdwV2hBT2c5Y1FpRDhEQ3RwSGhhN2s5bmFZbWNRZUFaMVVRYi9sekJtejJYb1VkRkZhVTJ5a2MwOFdLM3B5M2Vudk55Q2dWZ1BvQTNDUkxyaHpCcnliZ2RvSms0MFRxa2RDeFJNbWcvclk1d2ZEV2VITEJIUllDQzRKZTJrQWVsdU16Y2ViQWVnOEM1UzUySWowb1RiMlJaZVZiS3NhUUh1NExMcGM0N3pCamRwSTl0NHJRbTNaL2plQWhsdHhjck5ZRnpwZ2NYR29qMEJ6VFUrd0UxMXU4S0lKSGJPTXlGMzYrTkNFOXZBb3Vvd2syNjhPbmVCVWRCbGliUjU2ZFBEUVRBY01YYmFCWnRackNmU1lIU211RWU0MG9lTnlPNkJ5K0dsb2ZrMjVWSzRwRFIyVUU1MUtRcUdoZWVyamtxYytaYWd2Vmc4aVNTdERXVG5KUlpRVFpTZ3JmTG1VQ2w4TmxKVm8vaE9WRWwwSGJkVk0xRUZidFQxMTBFNGF0RzVheVVaTnJ6STBiYytmWGZlK3JqMnYwRTd6SWRISms2ZVR4NW5sdUNVRjFqL1JEeFFRUHczaTlOK3pBQUFBQUVsRlRrU3VRbUNDXFxcIilcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIERhdGVUaW1lUGlja2VyRmllbGRzXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1zaXplXCIsXCJ2YWx1ZVwiOlwiNTYgMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJEYXRlVGltZVBpY2tlckZpZWxkcyAuaW5wdXRcIixcIkRhdGVUaW1lUGlja2VyRmllbGRzIERhdGVQaWNrZXJGaWVsZFwiLFwiRGF0ZVRpbWVQaWNrZXJGaWVsZHMgVGltZVBpY2tlckZpZWxkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1pbWFnZVwiLFwidmFsdWVcIjpcIm5vbmVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItd2lkdGhcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIERhdGVUaW1lUGlja2VyRmllbGRzIC5pbnB1dFwiLFwiLm5zLWRhcmsgRGF0ZVRpbWVQaWNrZXJGaWVsZHMgRGF0ZVBpY2tlckZpZWxkXCIsXCIubnMtZGFyayBEYXRlVGltZVBpY2tlckZpZWxkcyBUaW1lUGlja2VyRmllbGRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWltYWdlXCIsXCJ2YWx1ZVwiOlwibm9uZVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJ0cmFuc3BhcmVudFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkRhdGVUaW1lUGlja2VyRmllbGRzIFRpbWVQaWNrZXJGaWVsZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi1sZWZ0XCIsXCJ2YWx1ZVwiOlwiLTMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUGlja2VyRmllbGRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWltYWdlXCIsXCJ2YWx1ZVwiOlwidXJsKFxcXCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUZRQUFBQXdCQU1BQUFCOUlFQytBQUFBR0ZCTVZFVkhjRXdBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFCb0F0VExBQUFBQjNSU1RsTUFvUEF3MEJBZ0NFSlU0d0FBQUVwSlJFRlVTTWRqWUJnRmd3VXdDaEN0Vkx5UWFFUEx5NGsxTnFtOG5GaGptZFdKTjlabzFOZ2haaXdKU29sM3dLaWhBMm9vQ1prN2hQajB4K3BPZEVIRUVFSjg4VFlLQmdvQUFBQzVKUmc0OXJJV0FBQUFBRWxGVGtTdVFtQ0NcXFwiKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlBpY2tlclBhZ2UuaW5wdXRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJQaWNrZXJQYWdlIExpc3RWaWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwic2VwYXJhdG9yLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJQaWNrZXJQYWdlIExpc3RWaWV3PipcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJoZWlnaHRcIixcInZhbHVlXCI6XCI0OFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpbi10b3BcIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjEwIDEyXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWJvdHRvbS13aWR0aFwiLFwidmFsdWVcIjpcIjFweFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFBpY2tlckZpZWxkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1pbWFnZVwiLFwidmFsdWVcIjpcInVybChcXFwiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFGUUFBQUF3QkFNQUFBQjlJRUMrQUFBQUJHZEJUVUVBQUxHUEMveGhCUUFBQUFGelVrZENBSzdPSE9rQUFBQVlVRXhVUlVkd1RQLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8veDFMVmI0QUFBQUhkRkpPVXdDZzhERFFFQ0FJUWxUakFBQUFTa2xFUVZSSXgyTmdHQVdEQlRBS0VLMVV2SkJvUTh2TGlUVTJxYnljV0dPWjFZazMxbWpVMkNGbUxBbEtpWGZBcUtFRGFpZ0ptVHVFK1BUSDZrNTBRY1FRUW56eE5nb0dDZ0FBQUxrbEdEajJzaFlBQUFBQVNVVk9SSzVDWUlJPVxcXCIpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgRGF0ZVBpY2tlckZpZWxkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1pbWFnZVwiLFwidmFsdWVcIjpcInVybChcXFwiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFGUUFBQUF3QkFNQUFBQjlJRUMrQUFBQUJHZEJUVUVBQUxHUEMveGhCUUFBQUFGelVrZENBSzdPSE9rQUFBQVBVRXhVUlVkd1RQLy8vLy8vLy8vLy8vLy8veFBnTVJvQUFBQUVkRkpPVXdEQUVDQlRrTUpEQUFBQVYwbEVRVlJJeDJOZ0lCVzR1TGlnTWVpbmxFbkVCUU00S21CVnl1aUNCUWhnVmNxQ1Rha3pEcVVLR0c1MWNjQ2hsSUZXU3RIRGJvUXB4UUxvcTNRMENnYVJVaFpvVkkwcUhibEtCM3RCUkVKbFJFSVZSd3NBQUxZamFFUVFJRmcrQUFBQUFFbEZUa1N1UW1DQ1xcXCIpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgVGltZVBpY2tlckZpZWxkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1pbWFnZVwiLFwidmFsdWVcIjpcInVybChcXFwiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFGUUFBQUF3QkFNQUFBQjlJRUMrQUFBQUJHZEJUVUVBQUxHUEMveGhCUUFBQUFGelVrZENBSzdPSE9rQUFBQXRVRXhVUlVkd1RQLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLzgxZTNRSUFBQUFPZEZKT1V3Qmc0RURBSUJEUVVIRHdzS0NBNGlzdkpBQUFBVFpKUkVGVVNNZGpZQmdzZ0hWMjNidDN6M2NHRUZiSkNGUUlBczhGQ0tyVWV3Y0Zqd2lvWmZWNzkrN0paV05qV3hDTjN3MWQ3OTRwSm9BWWJFTHYzcTNBYXoxUUpZd05WSXZQQ1hMdjNpVEEyR3puM2ozRXJaSUR4U0NnRlEwNGxVYWhtaVAzYmlsT3BYNFFRL25ld1l4OWd0dFRieGlRbFRLY3cra3hwbmRxcUVxVDNpbmc5TDhBcWxKR25HRlE5NGdCVlNtRDNuTWNrUW96QTZGVTdoMzJ5T1Y4OXd4ZGFkNjdDVmlWY3I5elFGZks4bTREamdDNGdLNlU5MTBCVnFWODd3elFsWEs4ZTBDc1VtYXFLb1VBS2lsdElGWXBPeXl3RUFCWFlNR2pBQUZ3UlFFOFloRUFWOFN5WWlZNVhNa0ZuZ2dSQUZjaWhDZHRwQnowa0VDR2dRUGNHUWFXRGVFQWR6YUVaVzZFMWlmVUtESklLSWhJS041SUtUUkpLSW9oQmZ3TlkrTmV3Z1U4Q2RVR0taVVJLVlhjZ0FFQXExTFBtRjFxRGV3QUFBQUFTVVZPUks1Q1lJST1cXFwiKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIERhdGVUaW1lUGlja2VyRmllbGRzXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1pbWFnZVwiLFwidmFsdWVcIjpcInVybChcXFwiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFLZ0FBQUF3QkFNQUFBQjNVQ3lwQUFBQUJHZEJUVUVBQUxHUEMveGhCUUFBQUFGelVrZENBSzdPSE9rQUFBQXRVRXhVUlVkd1RQLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLzgxZTNRSUFBQUFPZEZKT1V3QkFZT0RBRUNEUVVIRHdzS0NBYXhNaTFnQUFBWnhKUkVGVVNNZmxsODlLdzBBUXhtUGExRXBwTVE5UUNIZ1BJbmd0UGtFcGVKZWNQZmtFb1dkQjhPNWRQSHIxSllyZVBMWTJOWmZ5UFlNeFliTmtrNTFzc2h1bytGMnloNWxmWnYvTnpGcFdLZ0RDd0lEK0JOU1pvNlJvUVRnTW5rSWdmZ3NvYUI4VnVwTGIyMkZtRW5zRWRGSUYvWll6Wjh4bTYxSFFSV2xOc1pIT1BWbXM2TU4xcDcvZmdJQmFEYUQzd0VXNjRNNFo4R0lHYWlkTU5rNm9IZ2tWVDVnTTZtT2ZId3huaFM4VDBHRWh1Q1RzcFFIb2JURTJIODhHb1BNc1VPWmlJOUtIMnRnWFhWYXlyV29BN2VHeTZIS044d1kzYWlQWmU2OEl0V1g3M3dBYWJzWEp6V0pkNklERnhhRStBczAxUGNGT2RMbkJveVoweERJaWQrbmpWUlBhdzd2b01wWnN2enAwZ2xQUlpZaTFlZWpSd1VNekhUQjAyUWFhV2E4bDBHTjJwTGpHdU5PRWpzcnRnTXJocDZINU5lVlN1YVkwZEZCT2RDb0poWWJtcVk5TG52cVVvYjVZUFlna3JReGw1U1FYVVU2VW9henc1VklxZkRWUVZxTDVUMVJLZEIyMFZUTlJCMjNWOXRSQk8yblF1bWtsR3pXOXl0QzBQZjkwM1llNjlyeENPODJIUkNkUG5rNGVaNWJqbGhSWS8wUS9IbjQvRGZYU25jWUFBQUFBU1VWT1JLNUNZSUk9XFxcIilcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBEYXRlUGlja2VyRmllbGRcIixcIi5ucy1kYXJrIFRpbWVQaWNrZXJGaWVsZFwiLFwiLm5zLWRhcmsgRGF0ZVRpbWVQaWNrZXJGaWVsZHNcIixcIi5ucy1kYXJrIFJhZEF1dG9Db21wbGV0ZVRleHRWaWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY2xhc3NcIixcInZhbHVlXCI6XCJucy1kYXJrXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkRGF0YUZvcm0gUHJvcGVydHlFZGl0b3JcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiNSAwIDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJOVElucHV0XCIsXCIubnQtaW5wdXRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIxMCAwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiRGF0YUZvcm1FZGl0b3JMYWJlbFwiLFwiTlRJbnB1dD5MYWJlbFwiLFwiLm50LWlucHV0PkxhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMTZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNiYWJhYmFcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJEYXRhRm9ybUVkaXRvckxhYmVsXCIsXCJOVElucHV0PkxhYmVsXCIsXCJOVElucHV0PlRleHRWaWV3XCIsXCI+VGV4dEZpZWxkXCIsXCI+UGlja2VyRmllbGRcIixcIj5EYXRlUGlja2VyRmllbGRcIixcIj5UaW1lUGlja2VyRmllbGRcIixcIj5EYXRlVGltZVBpY2tlckZpZWxkc1wiLFwiPlJhZEF1dG9Db21wbGV0ZVRleHRWaWV3XCIsXCIubnQtaW5wdXQ+TGFiZWxcIixcIi5udC1pbnB1dD5UZXh0Vmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjAgMTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJOVElucHV0Li1zaWRlc1wiLFwiLm50LWlucHV0Li1zaWRlc1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm1hcmdpblwiLFwidmFsdWVcIjpcIjAgMCAxMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIk5USW5wdXQuLXNpZGVzPkxhYmVsXCIsXCIubnQtaW5wdXQuLXNpZGVzPkxhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiNSAxNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIk5USW5wdXQ+TlRJY29uXCIsXCJOVElucHV0Pi5udC1pY29uXCIsXCIubnQtaW5wdXQ+TlRJY29uXCIsXCIubnQtaW5wdXQ+Lm50LWljb25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIyMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInZlcnRpY2FsLWFsaWduXCIsXCJ2YWx1ZVwiOlwiY2VudGVyXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaG9yaXpvbnRhbC1hbGlnblwiLFwidmFsdWVcIjpcInJpZ2h0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiLTE1IDEwIDAgMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkFjdGlvbkJhclwiLFwiTlRBY3Rpb25CYXJcIixcIi5udC1hY3Rpb24tYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiZm9udC1zaXplXCIsXCJ2YWx1ZVwiOlwiMThcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJBY3Rpb25CYXIgTlRJY29uXCIsXCJBY3Rpb25CYXIgTGFiZWxcIixcIkFjdGlvbkJhciBCdXR0b25cIixcIkFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiLFwiTlRBY3Rpb25CYXIgTlRJY29uXCIsXCJOVEFjdGlvbkJhciBMYWJlbFwiLFwiTlRBY3Rpb25CYXIgQnV0dG9uXCIsXCJOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiLFwiLm50LWFjdGlvbi1iYXIgTlRJY29uXCIsXCIubnQtYWN0aW9uLWJhciBMYWJlbFwiLFwiLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnQtYWN0aW9uLWJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImFuZHJvaWQtZWxldmF0aW9uXCIsXCJ2YWx1ZVwiOlwiMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjE2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZ1wiLFwidmFsdWVcIjpcIjEyIDNcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWluLXdpZHRoXCIsXCJ2YWx1ZVwiOlwiMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIndpZHRoXCIsXCJ2YWx1ZVwiOlwiYXV0b1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci13aWR0aFwiLFwidmFsdWVcIjpcIjBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LXRyYW5zZm9ybVwiLFwidmFsdWVcIjpcIm5vbmVcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXdlaWdodFwiLFwidmFsdWVcIjpcIm5vcm1hbFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkFjdGlvbkJhciBOVEljb246YWN0aXZlXCIsXCJBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCJBY3Rpb25CYXIgQnV0dG9uOmFjdGl2ZVwiLFwiQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtOmFjdGl2ZVwiLFwiTlRBY3Rpb25CYXIgTlRJY29uOmFjdGl2ZVwiLFwiTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCJOVEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCJOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbTphY3RpdmVcIixcIi5udC1hY3Rpb24tYmFyIE5USWNvbjphY3RpdmVcIixcIi5udC1hY3Rpb24tYmFyIExhYmVsOmFjdGl2ZVwiLFwiLm50LWFjdGlvbi1iYXIgQnV0dG9uOmFjdGl2ZVwiLFwiLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwib3BhY2l0eVwiLFwidmFsdWVcIjpcIi43XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyPkxhYmVsXCIsXCJOVEFjdGlvbkJhcj5MYWJlbFwiLFwiLm50LWFjdGlvbi1iYXI+TGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXdlaWdodFwiLFwidmFsdWVcIjpcImJvbGRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJmb250LXNpemVcIixcInZhbHVlXCI6XCIxOFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1zdGF0dXNiYXItdHJhbnNwYXJlbnQgUGFnZT5BY3Rpb25CYXJcIixcIi5ucy1zdGF0dXNiYXItdHJhbnNwYXJlbnQgUGFnZT5OVEFjdGlvbkJhclwiLFwiLm5zLXN0YXR1c2Jhci10cmFuc3BhcmVudCBQYWdlPi5udC1hY3Rpb24tYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGFkZGluZy10b3BcIixcInZhbHVlXCI6XCIyNFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkX18xOS5ucy1zdGF0dXNiYXItdHJhbnNwYXJlbnQgUGFnZT5BY3Rpb25CYXJcIixcIi5ucy1tb2RhbC5ucy1zdGF0dXNiYXItdHJhbnNwYXJlbnQgUGFnZT5BY3Rpb25CYXJcIixcIi5ucy1hbmRyb2lkX18xOS5ucy1zdGF0dXNiYXItdHJhbnNwYXJlbnQgUGFnZT5OVEFjdGlvbkJhclwiLFwiLm5zLW1vZGFsLm5zLXN0YXR1c2Jhci10cmFuc3BhcmVudCBQYWdlPk5UQWN0aW9uQmFyXCIsXCIubnMtYW5kcm9pZF9fMTkubnMtc3RhdHVzYmFyLXRyYW5zcGFyZW50IFBhZ2U+Lm50LWFjdGlvbi1iYXJcIixcIi5ucy1tb2RhbC5ucy1zdGF0dXNiYXItdHJhbnNwYXJlbnQgUGFnZT4ubnQtYWN0aW9uLWJhclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmctdG9wXCIsXCJ2YWx1ZVwiOlwiMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1hbmRyb2lkIEFjdGlvbkJhciAubnQtYnV0dG9uXCIsXCIubnMtYW5kcm9pZCBOVEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1hbmRyb2lkIE5UQWN0aW9uQmFyIC5udC1idXR0b25cIixcIi5ucy1hbmRyb2lkIC5udC1hY3Rpb24tYmFyIEJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgLm50LWFjdGlvbi1iYXIgLm50LWJ1dHRvblwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBhZGRpbmdcIixcInZhbHVlXCI6XCIwIDZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJBY3Rpb25CYXI+TGFiZWxcIixcIk5UQWN0aW9uQmFyPkxhYmVsXCIsXCIubnQtYWN0aW9uLWJhcj5MYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIndpZHRoXCIsXCJ2YWx1ZVwiOlwiMTAwJVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkFjdGlvbkJhcj5MYWJlbFwiLFwiQWN0aW9uQmFyPkdyaWRMYXlvdXQgTGFiZWxcIixcIk5UQWN0aW9uQmFyPkxhYmVsXCIsXCJOVEFjdGlvbkJhcj5HcmlkTGF5b3V0IExhYmVsXCIsXCIubnQtYWN0aW9uLWJhcj5MYWJlbFwiLFwiLm50LWFjdGlvbi1iYXI+R3JpZExheW91dCBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImZvbnQtc2l6ZVwiLFwidmFsdWVcIjpcIjE4XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidmVydGljYWwtYWxpZ25cIixcInZhbHVlXCI6XCJjZW50ZXJcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LWFsaWduXCIsXCJ2YWx1ZVwiOlwiY2VudGVyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyPkdyaWRMYXlvdXRcIixcIk5UQWN0aW9uQmFyPkdyaWRMYXlvdXRcIixcIi5udC1hY3Rpb24tYmFyPkdyaWRMYXlvdXRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMCA0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwid2lkdGhcIixcInZhbHVlXCI6XCIxMDAlXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyPkdyaWRMYXlvdXQ+U3RhY2tMYXlvdXRcIixcIk5UQWN0aW9uQmFyPkdyaWRMYXlvdXQ+U3RhY2tMYXlvdXRcIixcIi5udC1hY3Rpb24tYmFyPkdyaWRMYXlvdXQ+U3RhY2tMYXlvdXRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhvcml6b250YWwtYWxpZ25cIixcInZhbHVlXCI6XCJsZWZ0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyPkdyaWRMYXlvdXQgQnV0dG9uXCIsXCJOVEFjdGlvbkJhcj5HcmlkTGF5b3V0IEJ1dHRvblwiLFwiLm50LWFjdGlvbi1iYXI+R3JpZExheW91dCBCdXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMTIgMTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJob3Jpem9udGFsLWFsaWduXCIsXCJ2YWx1ZVwiOlwibGVmdFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkFjdGlvbkJhcj5HcmlkTGF5b3V0IFtjb2w9XFxcIjJcXFwiXVwiLFwiTlRBY3Rpb25CYXI+R3JpZExheW91dCBbY29sPVxcXCIyXFxcIl1cIixcIi5udC1hY3Rpb24tYmFyPkdyaWRMYXlvdXQgW2NvbD1cXFwiMlxcXCJdXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiaG9yaXpvbnRhbC1hbGlnblwiLFwidmFsdWVcIjpcInJpZ2h0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWFuZHJvaWQgQWN0aW9uQmFyPkdyaWRMYXlvdXQgQnV0dG9uXCIsXCIubnMtYW5kcm9pZCBOVEFjdGlvbkJhcj5HcmlkTGF5b3V0IEJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgLm50LWFjdGlvbi1iYXI+R3JpZExheW91dCBCdXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwYWRkaW5nXCIsXCJ2YWx1ZVwiOlwiMTIgMTZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJtYXJnaW5cIixcInZhbHVlXCI6XCIwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQnV0dG9uXCIsXCIubnQtYnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDQzNjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b25cIixcIi5ucy1kYXJrIC5udC1idXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZjZmVmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbjphY3RpdmVcIixcIkJ1dHRvbi4tYWN0aXZlXCIsXCIubnQtYnV0dG9uOmFjdGl2ZVwiLFwiLm50LWJ1dHRvbi4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMDA0MzYzXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgQnV0dG9uOmFjdGl2ZVwiLFwiLm5zLWRhcmsgQnV0dG9uLi1hY3RpdmVcIixcIi5ucy1kYXJrIC5udC1idXR0b246YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYnV0dG9uLi1hY3RpdmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmY2ZlZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJCdXR0b24uLW91dGxpbmVcIixcIi5udC1idXR0b24uLW91dGxpbmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLW91dGxpbmVcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLW91dGxpbmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiM5NmRkZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcIi1oaWdodGxpZ2h0LWxpZ2h0XCIsXCJrZXlmcmFtZXNcIjpbe1widHlwZVwiOlwia2V5ZnJhbWVcIixcInZhbHVlc1wiOltcIjAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMTAwJVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZjJmMmYyXCJ9XX1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcIi1oaWdodGxpZ2h0LWRhcmtcIixcImtleWZyYW1lc1wiOlt7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMCVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcImtleWZyYW1lXCIsXCJ2YWx1ZXNcIjpbXCIxMDAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMyMzIzMjNcIn1dfV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbi4tb3V0bGluZTphY3RpdmVcIixcIkJ1dHRvbi4tb3V0bGluZS4tYWN0aXZlXCIsXCIubnQtYnV0dG9uLi1vdXRsaW5lOmFjdGl2ZVwiLFwiLm50LWJ1dHRvbi4tb3V0bGluZS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYW5pbWF0aW9uXCIsXCJ2YWx1ZVwiOlwiLWhpZ2h0bGlnaHQtbGlnaHQgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmMmYyZjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLW91dGxpbmU6YWN0aXZlXCIsXCIubnMtZGFyayBCdXR0b24uLW91dGxpbmUuLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWJ1dHRvbi4tb3V0bGluZTphY3RpdmVcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLW91dGxpbmUuLWFjdGl2ZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImFuaW1hdGlvblwiLFwidmFsdWVcIjpcIi1oaWdodGxpZ2h0LWRhcmsgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMyMzIzMjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJCdXR0b24uLXByaW1hcnlcIixcIi5udC1idXR0b24uLXByaW1hcnlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLXByaW1hcnlcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLXByaW1hcnlcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcImFjY2VudC1oaWdodGxpZ2h0LWxpZ2h0XCIsXCJrZXlmcmFtZXNcIjpbe1widHlwZVwiOlwia2V5ZnJhbWVcIixcInZhbHVlc1wiOltcIjAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMTAwJVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMDBhYWZjXCJ9XX1dfSx7XCJ0eXBlXCI6XCJrZXlmcmFtZXNcIixcIm5hbWVcIjpcImFjY2VudC1oaWdodGxpZ2h0LWRhcmtcIixcImtleWZyYW1lc1wiOlt7XCJ0eXBlXCI6XCJrZXlmcmFtZVwiLFwidmFsdWVzXCI6W1wiMCVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcImtleWZyYW1lXCIsXCJ2YWx1ZXNcIjpbXCIxMDAlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGFhZmNcIn1dfV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkJ1dHRvbi4tcHJpbWFyeTphY3RpdmVcIixcIkJ1dHRvbi4tcHJpbWFyeS4tYWN0aXZlXCIsXCIubnQtYnV0dG9uLi1wcmltYXJ5OmFjdGl2ZVwiLFwiLm50LWJ1dHRvbi4tcHJpbWFyeS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYW5pbWF0aW9uXCIsXCJ2YWx1ZVwiOlwiYWNjZW50LWhpZ2h0bGlnaHQtbGlnaHQgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGFhZmNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBCdXR0b24uLXByaW1hcnk6YWN0aXZlXCIsXCIubnMtZGFyayBCdXR0b24uLXByaW1hcnkuLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWJ1dHRvbi4tcHJpbWFyeTphY3RpdmVcIixcIi5ucy1kYXJrIC5udC1idXR0b24uLXByaW1hcnkuLWFjdGl2ZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImFuaW1hdGlvblwiLFwidmFsdWVcIjpcImFjY2VudC1oaWdodGxpZ2h0LWRhcmsgLjNzIGVhc2Utb3V0IGZvcndhcmRzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMGFhZmNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJBY3Rpdml0eUluZGljYXRvclwiLFwiLm50LWFjdGl2aXR5LWluZGljYXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIEFjdGl2aXR5SW5kaWNhdG9yXCIsXCIubnMtZGFyayAubnQtYWN0aXZpdHktaW5kaWNhdG9yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiU2VnbWVudGVkQmFyXCIsXCIubnQtc2VnbWVudGVkLWJhclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwic2VsZWN0ZWQtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBTZWdtZW50ZWRCYXJcIixcIi5ucy1kYXJrIC5udC1zZWdtZW50ZWQtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZWxlY3RlZC1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1pb3MgU2VnbWVudGVkQmFyXCIsXCIubnMtaW9zIC5udC1zZWdtZW50ZWQtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwibWFyZ2luXCIsXCJ2YWx1ZVwiOlwiMCAxNVwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLWlvcyBTZWdtZW50ZWRCYXJcIixcIi5ucy1kYXJrLm5zLWlvcyAubnQtc2VnbWVudGVkLWJhclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlByb2dyZXNzXCIsXCIubnQtcHJvZ3Jlc3NcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFByb2dyZXNzXCIsXCIubnMtZGFyayAubnQtcHJvZ3Jlc3NcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xKVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlNsaWRlclwiLFwiLm50LXNsaWRlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgU2xpZGVyXCIsXCIubnMtZGFyayAubnQtc2xpZGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJTbGlkZXJbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWFuZHJvaWQgU2xpZGVyW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5udC1zbGlkZXJbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWFuZHJvaWQgLm50LXNsaWRlcltpc0VuYWJsZWQ9ZmFsc2VdXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZTBlMGUwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNlMGUwZTBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJTZWFyY2hCYXJcIixcIi5udC1zZWFyY2gtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LWZpZWxkLWhpbnQtY29sb3JcIixcInZhbHVlXCI6XCIjNzM3MzczXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1maWVsZC1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBTZWFyY2hCYXJcIixcIi5ucy1kYXJrIC5udC1zZWFyY2gtYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0ZXh0LWZpZWxkLWhpbnQtY29sb3JcIixcInZhbHVlXCI6XCIjYjNiM2IzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGV4dC1maWVsZC1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwidHJhbnNwYXJlbnRcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtYW5kcm9pZCBTd2l0Y2hcIixcIi5ucy1hbmRyb2lkIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNjY2NcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2NjY1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLWFuZHJvaWQgU3dpdGNoXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiM2MzYzNjNcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzYzNjM2M1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIFN3aXRjaFtjaGVja2VkPXRydWVdXCIsXCIubnMtYW5kcm9pZCAubnQtc3dpdGNoW2NoZWNrZWQ9dHJ1ZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1hbmRyb2lkIFN3aXRjaFtjaGVja2VkPXRydWVdXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1zd2l0Y2hbY2hlY2tlZD10cnVlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1hbmRyb2lkIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtYW5kcm9pZCAubnQtc3dpdGNoW2lzRW5hYmxlZD1mYWxzZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNlNmU2ZTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1hbmRyb2lkIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1zd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzRhNGE0YVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1pb3MgU3dpdGNoXCIsXCIubnMtaW9zIC5udC1zd2l0Y2hcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIm9mZi1iYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2U2ZTZlNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLm5zLWlvcyBTd2l0Y2hcIixcIi5ucy1kYXJrLm5zLWlvcyAubnQtc3dpdGNoXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJvZmYtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiM0YTRhNGFcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtaW9zIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtaW9zIC5udC1zd2l0Y2hbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LDE4OCwyNTUsLjQpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtaW9zIFN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LXN3aXRjaFtpc0VuYWJsZWQ9ZmFsc2VdXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuNClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJUYWJWaWV3XCIsXCIubnQtdGFiLXZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZWxlY3RlZC10YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiNhYmQ1ZTlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJhbmRyb2lkLXNlbGVjdGVkLXRhYi1oaWdobGlnaHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgVGFiVmlld1wiLFwiLm5zLWRhcmsgLm50LXRhYi12aWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwic2VsZWN0ZWQtdGFiLXRleHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGFiLWJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwidGFiLXRleHQtY29sb3JcIixcInZhbHVlXCI6XCIjYWJkNWU5XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYW5kcm9pZC1zZWxlY3RlZC10YWItaGlnaGxpZ2h0LWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYlZpZXcubnMtZGFya1wiLFwiLm50LXRhYi12aWV3Lm5zLWRhcmtcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZWxlY3RlZC10YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJ0YWItdGV4dC1jb2xvclwiLFwidmFsdWVcIjpcIiNhYmQ1ZTlcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJhbmRyb2lkLXNlbGVjdGVkLXRhYi1oaWdobGlnaHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGFiU3RyaXBcIixcIi5udC10YWItc3RyaXBcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJoaWdobGlnaHQtY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZFwiLFwidmFsdWVcIjpcIiNmMmYyZjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBUYWJTdHJpcFwiLFwiLm5zLWRhcmsgLm50LXRhYi1zdHJpcFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImhpZ2hsaWdodC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiIzNhM2EzYVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYlN0cmlwSXRlbVwiLFwiLm50LXRhYi1zdHJpcF9faXRlbVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFRhYlN0cmlwSXRlbVwiLFwiLm5zLWRhcmsgLm50LXRhYi1zdHJpcF9faXRlbVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYlN0cmlwSXRlbTphY3RpdmVcIixcIlRhYlN0cmlwSXRlbTphY3RpdmUgTGFiZWxcIixcIi5udC10YWItc3RyaXBfX2l0ZW06YWN0aXZlXCIsXCIubnQtdGFiLXN0cmlwX19pdGVtOmFjdGl2ZSBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFRhYlN0cmlwSXRlbTphY3RpdmVcIixcIi5ucy1kYXJrIFRhYlN0cmlwSXRlbTphY3RpdmUgTGFiZWxcIixcIi5ucy1kYXJrIC5udC10YWItc3RyaXBfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyayAubnQtdGFiLXN0cmlwX19pdGVtOmFjdGl2ZSBMYWJlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwYmNmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRhYkNvbnRlbnRJdGVtXCIsXCIubnQtdGFiLWNvbnRlbnRfX2l0ZW1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFRhYkNvbnRlbnRJdGVtXCIsXCIubnMtZGFyayAubnQtdGFiLWNvbnRlbnRfX2l0ZW1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3XCIsXCJSYWRMaXN0Vmlld1wiLFwiLm50LWxpc3Qtdmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIml0ZW0tc2VsZWN0ZWQtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuMTUpXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwic2VwYXJhdG9yLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2NjY1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIExpc3RWaWV3XCIsXCIubnMtZGFyayBSYWRMaXN0Vmlld1wiLFwiLm5zLWRhcmsgLm50LWxpc3Qtdmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcIml0ZW0tc2VsZWN0ZWQtYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuMTUpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXc+Ki5hY3RpdmVcIixcIkxpc3RWaWV3Pio6aGlnaGxpZ2h0ZWRcIixcIlJhZExpc3RWaWV3PiouYWN0aXZlXCIsXCJSYWRMaXN0Vmlldz4qOmhpZ2hsaWdodGVkXCIsXCIubnQtbGlzdC12aWV3PiouYWN0aXZlXCIsXCIubnQtbGlzdC12aWV3Pio6aGlnaGxpZ2h0ZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xNSlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBMaXN0Vmlldz4qLmFjdGl2ZVwiLFwiLm5zLWRhcmsgTGlzdFZpZXc+KjpoaWdobGlnaHRlZFwiLFwiLm5zLWRhcmsgUmFkTGlzdFZpZXc+Ki5hY3RpdmVcIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3Pio6aGlnaGxpZ2h0ZWRcIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXc+Ki5hY3RpdmVcIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXc+KjpoaWdobGlnaHRlZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LDE4OCwyNTUsLjE1KVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIkxpc3RWaWV3IC4tc2VwYXJhdG9yXCIsXCJSYWRMaXN0VmlldyAuLXNlcGFyYXRvclwiLFwiLm50LWxpc3QtdmlldyAuLXNlcGFyYXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1ib3R0b20tY29sb3JcIixcInZhbHVlXCI6XCIjY2NjXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgTGlzdFZpZXcgLi1zZXBhcmF0b3JcIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3IC4tc2VwYXJhdG9yXCIsXCIubnMtZGFyayAubnQtbGlzdC12aWV3IC4tc2VwYXJhdG9yXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWJvdHRvbS1jb2xvclwiLFwidmFsdWVcIjpcIiM2MzYzNjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBMaXN0Vmlld1wiLFwiLm5zLWRhcmsgUmFkTGlzdFZpZXdcIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJzZXBhcmF0b3ItY29sb3JcIixcInZhbHVlXCI6XCIjNjM2MzYzXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiTGlzdFZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlXCIsXCJSYWRMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGVcIixcIi5udC1saXN0LXZpZXcgLm50LWxpc3Qtdmlld19fZGVsZXRlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNkNTAwMDBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIixcIlJhZExpc3RWaWV3IC5udC1saXN0LXZpZXdfX2RlbGV0ZT5MYWJlbFwiLFwiLm50LWxpc3QtdmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBMaXN0VmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3IC5udC1saXN0LXZpZXdfX2RlbGV0ZT5MYWJlbFwiLFwiLm5zLWRhcmsgLm50LWxpc3QtdmlldyAubnQtbGlzdC12aWV3X19kZWxldGU+TGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJMaXN0VmlldyBOVEljb25cIixcIkxpc3RWaWV3IC5udC1pY29uXCIsXCJSYWRMaXN0VmlldyBOVEljb25cIixcIlJhZExpc3RWaWV3IC5udC1pY29uXCIsXCIubnQtbGlzdC12aWV3IE5USWNvblwiLFwiLm50LWxpc3QtdmlldyAubnQtaWNvblwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwNjY5OFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIExpc3RWaWV3IE5USWNvblwiLFwiLm5zLWRhcmsgTGlzdFZpZXcgLm50LWljb25cIixcIi5ucy1kYXJrIFJhZExpc3RWaWV3IE5USWNvblwiLFwiLm5zLWRhcmsgUmFkTGlzdFZpZXcgLm50LWljb25cIixcIi5ucy1kYXJrIC5udC1saXN0LXZpZXcgTlRJY29uXCIsXCIubnMtZGFyayAubnQtbGlzdC12aWV3IC5udC1pY29uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19oZWFkZXJcIixcIi5udC1kcmF3ZXIgLm50LWRyYXdlcl9faGVhZGVyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmMmYyZjJcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRTaWRlRHJhd2VyPipcIixcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9fY29udGVudFwiLFwiLm50LWRyYXdlcj4qXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2NvbnRlbnRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtLi1zZWxlY3RlZFwiLFwiLm50LWRyYXdlciAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuMTUpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkIExhYmVsXCIsXCIubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWQgTGFiZWxcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBSYWRTaWRlRHJhd2VyIC5udC1kcmF3ZXJfX2hlYWRlclwiLFwiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2hlYWRlclwiLFwiLm5zLWRhcmsgLm50LWRyYXdlciAubnQtZHJhd2VyX19oZWFkZXJcIixcIi5udC1kcmF3ZXIubnMtZGFyayAubnQtZHJhd2VyX19oZWFkZXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNkNGQ0ZDRcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzIzMjMyM1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFJhZFNpZGVEcmF3ZXI+KlwiLFwiLm5zLWRhcmsgUmFkU2lkZURyYXdlciAubnQtZHJhd2VyX19jb250ZW50XCIsXCJSYWRTaWRlRHJhd2VyLm5zLWRhcms+KlwiLFwiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2NvbnRlbnRcIixcIi5ucy1kYXJrIC5udC1kcmF3ZXI+KlwiLFwiLm5zLWRhcmsgLm50LWRyYXdlciAubnQtZHJhd2VyX19jb250ZW50XCIsXCIubnQtZHJhd2VyLm5zLWRhcms+KlwiLFwiLm50LWRyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2NvbnRlbnRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFJhZFNpZGVEcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtLi1zZWxlY3RlZFwiLFwiUmFkU2lkZURyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWRcIixcIi5ucy1kYXJrIC5udC1kcmF3ZXIgLm50LWRyYXdlcl9fbGlzdC1pdGVtLi1zZWxlY3RlZFwiLFwiLm50LWRyYXdlci5ucy1kYXJrIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwicmdiYSg0OCwxODgsMjU1LC4xNSlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBSYWRTaWRlRHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWQgTGFiZWxcIixcIlJhZFNpZGVEcmF3ZXIubnMtZGFyayAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkIExhYmVsXCIsXCIubnMtZGFyayAubnQtZHJhd2VyIC5udC1kcmF3ZXJfX2xpc3QtaXRlbS4tc2VsZWN0ZWQgTGFiZWxcIixcIi5udC1kcmF3ZXIubnMtZGFyayAubnQtZHJhd2VyX19saXN0LWl0ZW0uLXNlbGVjdGVkIExhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjOTZkZGZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiVGV4dFZpZXdcIixcIlRleHRGaWVsZFwiLFwiUGlja2VyRmllbGRcIixcIkRhdGVQaWNrZXJGaWVsZFwiLFwiVGltZVBpY2tlckZpZWxkXCIsXCJEYXRlVGltZVBpY2tlckZpZWxkc1wiLFwiRGF0YUZvcm1FZGl0b3JDb3JlXCIsXCJSYWRBdXRvQ29tcGxldGVUZXh0Vmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCJ0cmFuc3BhcmVudFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcInBsYWNlaG9sZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzczNzM3M1wifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNjN2M3YzdcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBUZXh0Vmlld1wiLFwiLm5zLWRhcmsgVGV4dEZpZWxkXCIsXCIubnMtZGFyayBQaWNrZXJGaWVsZFwiLFwiLm5zLWRhcmsgRGF0ZVBpY2tlckZpZWxkXCIsXCIubnMtZGFyayBUaW1lUGlja2VyRmllbGRcIixcIi5ucy1kYXJrIERhdGVUaW1lUGlja2VyRmllbGRzXCIsXCIubnMtZGFyayBEYXRhRm9ybUVkaXRvckNvcmVcIixcIi5ucy1kYXJrIFJhZEF1dG9Db21wbGV0ZVRleHRWaWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGxhY2Vob2xkZXItY29sb3JcIixcInZhbHVlXCI6XCIjYjNiM2IzXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZhZmFmYVwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlRleHRWaWV3OmZvY3VzXCIsXCJUZXh0RmllbGQ6Zm9jdXNcIixcIlBpY2tlckZpZWxkOmZvY3VzXCIsXCJEYXRlUGlja2VyRmllbGQ6Zm9jdXNcIixcIlRpbWVQaWNrZXJGaWVsZDpmb2N1c1wiLFwiRGF0ZVRpbWVQaWNrZXJGaWVsZHM6Zm9jdXNcIixcIkRhdGFGb3JtRWRpdG9yQ29yZTpmb2N1c1wiLFwiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXc6Zm9jdXNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjMDA4OGM5XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgVGV4dFZpZXc6Zm9jdXNcIixcIi5ucy1kYXJrIFRleHRGaWVsZDpmb2N1c1wiLFwiLm5zLWRhcmsgUGlja2VyRmllbGQ6Zm9jdXNcIixcIi5ucy1kYXJrIERhdGVQaWNrZXJGaWVsZDpmb2N1c1wiLFwiLm5zLWRhcmsgVGltZVBpY2tlckZpZWxkOmZvY3VzXCIsXCIubnMtZGFyayBEYXRlVGltZVBpY2tlckZpZWxkczpmb2N1c1wiLFwiLm5zLWRhcmsgRGF0YUZvcm1FZGl0b3JDb3JlOmZvY3VzXCIsXCIubnMtZGFyayBSYWRBdXRvQ29tcGxldGVUZXh0Vmlldzpmb2N1c1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiM5NmRkZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJUZXh0Vmlld1tpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJUZXh0RmllbGRbaXNFbmFibGVkPWZhbHNlXVwiLFwiUGlja2VyRmllbGRbaXNFbmFibGVkPWZhbHNlXVwiLFwiRGF0ZVBpY2tlckZpZWxkW2lzRW5hYmxlZD1mYWxzZV1cIixcIlRpbWVQaWNrZXJGaWVsZFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJEYXRlVGltZVBpY2tlckZpZWxkc1tpc0VuYWJsZWQ9ZmFsc2VdXCIsXCJEYXRhRm9ybUVkaXRvckNvcmVbaXNFbmFibGVkPWZhbHNlXVwiLFwiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXdbaXNFbmFibGVkPWZhbHNlXVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2UwZTBlMFwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZjJmMmYyXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgVGV4dFZpZXdbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWRhcmsgVGV4dEZpZWxkW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5ucy1kYXJrIFBpY2tlckZpZWxkW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5ucy1kYXJrIERhdGVQaWNrZXJGaWVsZFtpc0VuYWJsZWQ9ZmFsc2VdXCIsXCIubnMtZGFyayBUaW1lUGlja2VyRmllbGRbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWRhcmsgRGF0ZVRpbWVQaWNrZXJGaWVsZHNbaXNFbmFibGVkPWZhbHNlXVwiLFwiLm5zLWRhcmsgRGF0YUZvcm1FZGl0b3JDb3JlW2lzRW5hYmxlZD1mYWxzZV1cIixcIi5ucy1kYXJrIFJhZEF1dG9Db21wbGV0ZVRleHRWaWV3W2lzRW5hYmxlZD1mYWxzZV1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNlMGUwZTBcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzNkM2QzZFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlByb3BlcnR5RWRpdG9yOmZvY3VzIERhdGFGb3JtRWRpdG9yQ29yZVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyayBQcm9wZXJ0eUVkaXRvcjpmb2N1cyBEYXRhRm9ybUVkaXRvckNvcmVcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJib3JkZXItY29sb3JcIixcInZhbHVlXCI6XCIjOTZkZGZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgVG9rZW5cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzk2ZGRmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFJhZEF1dG9Db21wbGV0ZVRleHRWaWV3IFRva2VuXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMwMDg4YzlcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRBdXRvQ29tcGxldGVUZXh0VmlldyBUb2tlbjpzZWxlY3RlZFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjNjNjZGZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgVG9rZW46c2VsZWN0ZWRcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwYWFmY1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZEF1dG9Db21wbGV0ZVRleHRWaWV3IENsZWFyQnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMzBiY2ZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgQ2xlYXJCdXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMzMGJjZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWRBdXRvQ29tcGxldGVUZXh0VmlldyBTdWdnZXN0aW9uVmlld1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkQXV0b0NvbXBsZXRlVGV4dFZpZXcgU3VnZ2VzdGlvblZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlJhZERhdGFGb3JtXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwicGxhY2Vob2xkZXItY29sb3JcIixcInZhbHVlXCI6XCIjNzM3MzczXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkRGF0YUZvcm1cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJwbGFjZWhvbGRlci1jb2xvclwiLFwidmFsdWVcIjpcIiNiM2IzYjNcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJSYWREYXRhRm9ybSBQcm9wZXJ0eUVkaXRvclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmQtY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUmFkRGF0YUZvcm0gUHJvcGVydHlFZGl0b3JcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlBpY2tlclBhZ2UgTGlzdFZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIFBpY2tlclBhZ2UgTGlzdFZpZXdcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIlBpY2tlclBhZ2UgTGlzdFZpZXc+KlwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJvcmRlci1ib3R0b20tY29sb3JcIixcInZhbHVlXCI6XCJyZ2JhKDQ4LDE4OCwyNTUsLjQpXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgUGlja2VyUGFnZSBMaXN0Vmlldz4qXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYm9yZGVyLWJvdHRvbS1jb2xvclwiLFwidmFsdWVcIjpcInJnYmEoNDgsMTg4LDI1NSwuNClcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJQaWNrZXJQYWdlLm5zLWRhcmsgTGlzdFZpZXdcIixcIi5ucy1kYXJrIFN1Z2dlc3Rpb25WaWV3XCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZmZmXCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZFwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZGF0ZS10aW1lLXBpY2tlclwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmRcIixcInZhbHVlXCI6XCIjZmZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmRhdGUtdGltZS1waWNrZXIubnMtZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifSx7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmRcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmRhdGUtdGltZS1waWNrZXItYnV0dG9uc1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzAwNDM2M1wifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5kYXRlLXRpbWUtcGlja2VyLWJ1dHRvbnMubnMtZGFya1wiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZjZmVmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrLmRhdGUtdGltZS1waWNrZXItYnV0dG9uLWNhbmNlbFwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImJhY2tncm91bmRcIixcInZhbHVlXCI6XCIjMzAzMDMwXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLmRhdGUtdGltZS1waWNrZXItc3Bpbm5lcnNcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMwMDY1OTZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIuZGF0ZS10aW1lLXBpY2tlci1zcGlubmVycy5ucy1kYXJrXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjYzllZWZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiRGF0YUZvcm1FZGl0b3JMYWJlbFwiLFwiTlRJbnB1dD5MYWJlbFwiLFwiLm50LWlucHV0PkxhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMDA2NTk2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgRGF0YUZvcm1FZGl0b3JMYWJlbFwiLFwiLm5zLWRhcmsgTlRJbnB1dD5MYWJlbFwiLFwiLm5zLWRhcmsgLm50LWlucHV0PkxhYmVsXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjYzllZWZmXCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyXCIsXCJOVEFjdGlvbkJhclwiLFwiLm50LWFjdGlvbi1iYXJcIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJjb2xvclwiLFwidmFsdWVcIjpcIiMyNjI2MjZcIn0se1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiI2ZmZlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIEFjdGlvbkJhclwiLFwiLm5zLWRhcmsgTlRBY3Rpb25CYXJcIixcIi5ucy1kYXJrIC5udC1hY3Rpb24tYmFyXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZDRkNGQ0XCJ9LHtcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiMzMDMwMzBcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCJBY3Rpb25CYXIgTlRJY29uXCIsXCJBY3Rpb25CYXIgTGFiZWxcIixcIkFjdGlvbkJhciBCdXR0b25cIixcIkFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiLFwiTlRBY3Rpb25CYXIgTlRJY29uXCIsXCJOVEFjdGlvbkJhciBMYWJlbFwiLFwiTlRBY3Rpb25CYXIgQnV0dG9uXCIsXCJOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiLFwiLm50LWFjdGlvbi1iYXIgTlRJY29uXCIsXCIubnQtYWN0aW9uLWJhciBMYWJlbFwiLFwiLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnQtYWN0aW9uLWJhciAubnQtYWN0aW9uLWJhcl9faXRlbVwiXSxcImRlY2xhcmF0aW9uc1wiOlt7XCJ0eXBlXCI6XCJkZWNsYXJhdGlvblwiLFwicHJvcGVydHlcIjpcImNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzI2MjYyNlwifV19LHtcInR5cGVcIjpcInJ1bGVcIixcInNlbGVjdG9yc1wiOltcIi5ucy1kYXJrIEFjdGlvbkJhciBOVEljb25cIixcIi5ucy1kYXJrIEFjdGlvbkJhciBMYWJlbFwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBOVEljb25cIixcIi5ucy1kYXJrIE5UQWN0aW9uQmFyIExhYmVsXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1kYXJrIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBOVEljb25cIixcIi5ucy1kYXJrIC5udC1hY3Rpb24tYmFyIExhYmVsXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBCdXR0b25cIixcIi5ucy1kYXJrIC5udC1hY3Rpb24tYmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZDRkNGQ0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiQWN0aW9uQmFyIE5USWNvbjphY3RpdmVcIixcIkFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiQWN0aW9uQmFyIExhYmVsOmFjdGl2ZVwiLFwiQWN0aW9uQmFyIExhYmVsLi1hY3RpdmVcIixcIkFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCJBY3Rpb25CYXIgQnV0dG9uLi1hY3RpdmVcIixcIkFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbTphY3RpdmVcIixcIkFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCJOVEFjdGlvbkJhciBOVEljb246YWN0aXZlXCIsXCJOVEFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCJOVEFjdGlvbkJhciBMYWJlbC4tYWN0aXZlXCIsXCJOVEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCJOVEFjdGlvbkJhciBCdXR0b24uLWFjdGl2ZVwiLFwiTlRBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCJOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBOVEljb246YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm50LWFjdGlvbi1iYXIgTGFiZWw6YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBMYWJlbC4tYWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBCdXR0b246YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciBCdXR0b24uLWFjdGl2ZVwiLFwiLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnQtYWN0aW9uLWJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjMjYyNjI2XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsgQWN0aW9uQmFyIE5USWNvbjphY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIExhYmVsOmFjdGl2ZVwiLFwiLm5zLWRhcmsgQWN0aW9uQmFyIExhYmVsLi1hY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtZGFyayBBY3Rpb25CYXIgQnV0dG9uLi1hY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbTphY3RpdmVcIixcIi5ucy1kYXJrIEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBOVEljb246YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBMYWJlbC4tYWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciBCdXR0b24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgTlRBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyayBOVEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBOVEljb246YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBOVEljb24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWFjdGlvbi1iYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBMYWJlbC4tYWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciBCdXR0b24uLWFjdGl2ZVwiLFwiLm5zLWRhcmsgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyayAubnQtYWN0aW9uLWJhciAubnQtYWN0aW9uLWJhcl9faXRlbS4tYWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiY29sb3JcIixcInZhbHVlXCI6XCIjZDRkNGQ0XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWlvcyBBY3Rpb25CYXIgTlRJY29uXCIsXCIubnMtaW9zIEFjdGlvbkJhciBOVEljb246YWN0aXZlXCIsXCIubnMtaW9zIEFjdGlvbkJhciBMYWJlbFwiLFwiLm5zLWlvcyBBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtaW9zIEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1pb3MgQWN0aW9uQmFyIEJ1dHRvbjphY3RpdmVcIixcIi5ucy1pb3MgQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtaW9zIEFjdGlvbkJhciAubnQtYWN0aW9uLWJhcl9faXRlbTphY3RpdmVcIixcIi5ucy1pb3MgTlRBY3Rpb25CYXIgTlRJY29uXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIE5USWNvbjphY3RpdmVcIixcIi5ucy1pb3MgTlRBY3Rpb25CYXIgTGFiZWxcIixcIi5ucy1pb3MgTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWlvcyBOVEFjdGlvbkJhciBCdXR0b246YWN0aXZlXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtaW9zIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtOmFjdGl2ZVwiLFwiLm5zLWlvcyAubnQtYWN0aW9uLWJhciBOVEljb25cIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWlvcyAubnQtYWN0aW9uLWJhciBMYWJlbFwiLFwiLm5zLWlvcyAubnQtYWN0aW9uLWJhciBMYWJlbDphY3RpdmVcIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtaW9zIC5udC1hY3Rpb24tYmFyIEJ1dHRvbjphY3RpdmVcIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW1cIixcIi5ucy1pb3MgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInRyYW5zcGFyZW50XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWRhcmsubnMtaW9zIEFjdGlvbkJhciBOVEljb25cIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIEFjdGlvbkJhciBMYWJlbFwiLFwiLm5zLWRhcmsubnMtaW9zIEFjdGlvbkJhciBMYWJlbDphY3RpdmVcIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1pb3MgQWN0aW9uQmFyIEJ1dHRvbjphY3RpdmVcIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW1cIixcIi5ucy1kYXJrLm5zLWlvcyBBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgTlRJY29uXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIE5UQWN0aW9uQmFyIExhYmVsXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgQnV0dG9uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIE5UQWN0aW9uQmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyay5ucy1pb3MgTlRBY3Rpb25CYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTlRJY29uXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTlRJY29uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIC5udC1hY3Rpb24tYmFyIExhYmVsXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgTGFiZWw6YWN0aXZlXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgQnV0dG9uOmFjdGl2ZVwiLFwiLm5zLWRhcmsubnMtaW9zIC5udC1hY3Rpb24tYmFyIC5udC1hY3Rpb24tYmFyX19pdGVtXCIsXCIubnMtZGFyay5ucy1pb3MgLm50LWFjdGlvbi1iYXIgLm50LWFjdGlvbi1iYXJfX2l0ZW06YWN0aXZlXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcInRyYW5zcGFyZW50XCJ9XX0se1widHlwZVwiOlwicnVsZVwiLFwic2VsZWN0b3JzXCI6W1wiLm5zLWFuZHJvaWQgQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgQWN0aW9uQmFyIC5udC1idXR0b25cIixcIi5ucy1hbmRyb2lkIE5UQWN0aW9uQmFyIEJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgTlRBY3Rpb25CYXIgLm50LWJ1dHRvblwiLFwiLm5zLWFuZHJvaWQgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtYW5kcm9pZCAubnQtYWN0aW9uLWJhciAubnQtYnV0dG9uXCJdLFwiZGVjbGFyYXRpb25zXCI6W3tcInR5cGVcIjpcImRlY2xhcmF0aW9uXCIsXCJwcm9wZXJ0eVwiOlwiYmFja2dyb3VuZC1jb2xvclwiLFwidmFsdWVcIjpcIiNmZmZcIn1dfSx7XCJ0eXBlXCI6XCJydWxlXCIsXCJzZWxlY3RvcnNcIjpbXCIubnMtZGFyay5ucy1hbmRyb2lkIEFjdGlvbkJhciBCdXR0b25cIixcIi5ucy1kYXJrLm5zLWFuZHJvaWQgQWN0aW9uQmFyIC5udC1idXR0b25cIixcIi5ucy1kYXJrLm5zLWFuZHJvaWQgTlRBY3Rpb25CYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIE5UQWN0aW9uQmFyIC5udC1idXR0b25cIixcIi5ucy1kYXJrLm5zLWFuZHJvaWQgLm50LWFjdGlvbi1iYXIgQnV0dG9uXCIsXCIubnMtZGFyay5ucy1hbmRyb2lkIC5udC1hY3Rpb24tYmFyIC5udC1idXR0b25cIl0sXCJkZWNsYXJhdGlvbnNcIjpbe1widHlwZVwiOlwiZGVjbGFyYXRpb25cIixcInByb3BlcnR5XCI6XCJiYWNrZ3JvdW5kLWNvbG9yXCIsXCJ2YWx1ZVwiOlwiIzMwMzAzMFwifV19XSxcInBhcnNpbmdFcnJvcnNcIjpbXX19OzsgXG5pZiAobW9kdWxlLmhvdCAmJiBnbG9iYWwuX2lzTW9kdWxlTG9hZGVkRm9yVUkgJiYgZ2xvYmFsLl9pc01vZHVsZUxvYWRlZEZvclVJKFwiL1VzZXJzL3N0ZXZlaGFubG9uL2NvZGluZy9qYXZhc2NyaXB0L1NWRUxURV9OQVRJVkUvdG9kb2FwcC9ub2RlX21vZHVsZXMvbmF0aXZlc2NyaXB0LXRoZW1lLWNvcmUvY3NzL2NvcmUuY3NzXCIpICkge1xuICAgIFxuICAgIG1vZHVsZS5ob3QuYWNjZXB0KCk7XG4gICAgbW9kdWxlLmhvdC5kaXNwb3NlKCgpID0+IHtcbiAgICAgICAgZ2xvYmFsLmhtclJlZnJlc2goeyB0eXBlOiBcInN0eWxlXCIsIHBhdGg6IFwiL1VzZXJzL3N0ZXZlaGFubG9uL2NvZGluZy9qYXZhc2NyaXB0L1NWRUxURV9OQVRJVkUvdG9kb2FwcC9ub2RlX21vZHVsZXMvbmF0aXZlc2NyaXB0LXRoZW1lLWNvcmUvY3NzL2NvcmUuY3NzXCIgfSk7XG4gICAgfSk7XG59ICIsImltcG9ydCB7IG1ha2VBcHBseUhtciB9IGZyb20gJ3N2ZWx0ZS1obXIvcnVudGltZSc7XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bmRlZlxuY29uc3QgZyA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gd2luZG93IDogZ2xvYmFsO1xuXG5jb25zdCBnbG9iYWxLZXkgPVxuXHR0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJ1xuXHRcdD8gU3ltYm9sKCdTVkVMVEVfTE9BREVSX0hPVCcpXG5cdFx0OiAnX19TVkVMVEVfTE9BREVSX0hPVCc7XG5cbmlmICghZ1tnbG9iYWxLZXldKSB7XG5cdC8vIGRvIHVwZGF0aW5nIHJlZnMgY291bnRpbmcgdG8ga25vdyB3aGVuIGEgZnVsbCB1cGRhdGUgaGFzIGJlZW4gYXBwbGllZFxuXHRsZXQgdXBkYXRpbmdDb3VudCA9IDA7XG5cblx0Y29uc3Qgbm90aWZ5U3RhcnQgPSAoKSA9PiB7XG5cdFx0dXBkYXRpbmdDb3VudCsrO1xuXHR9O1xuXG5cdGNvbnN0IG5vdGlmeUVycm9yID0gcmVsb2FkID0+IGVyciA9PiB7XG5cdFx0Y29uc3QgZXJyU3RyaW5nID0gKGVyciAmJiBlcnIuc3RhY2spIHx8IGVycjtcblx0XHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29uc29sZVxuXHRcdGNvbnNvbGUuZXJyb3IoXG5cdFx0XHQnW0hNUl0gRmFpbGVkIHRvIGFjY2VwdCB1cGRhdGUgKG5vbGx1cCBjb21wYXQgbW9kZSknLFxuXHRcdFx0ZXJyU3RyaW5nXG5cdFx0KTtcblx0XHRyZWxvYWQoKTtcblx0XHRub3RpZnlFbmQoKTtcblx0fTtcblxuXHRjb25zdCBub3RpZnlFbmQgPSAoKSA9PiB7XG5cdFx0dXBkYXRpbmdDb3VudC0tO1xuXHRcdGlmICh1cGRhdGluZ0NvdW50ID09PSAwKSB7XG5cdFx0XHQvLyBOT1RFIHRoaXMgbWVzc2FnZSBpcyBpbXBvcnRhbnQgZm9yIHRpbWluZyBpbiB0ZXN0c1xuXHRcdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcblx0XHRcdGNvbnNvbGUubG9nKCdbSE1SOlN2ZWx0ZV0gVXAgdG8gZGF0ZScpO1xuXHRcdH1cblx0fTtcblxuXHRnW2dsb2JhbEtleV0gPSB7XG5cdFx0aG90U3RhdGVzOiB7fSxcblx0XHRub3RpZnlTdGFydCxcblx0XHRub3RpZnlFcnJvcixcblx0XHRub3RpZnlFbmQsXG5cdH07XG59XG5cbmNvbnN0IHJ1bkFjY2VwdEhhbmRsZXJzID0gYWNjZXB0SGFuZGxlcnMgPT4ge1xuXHRjb25zdCBxdWV1ZSA9IFsuLi5hY2NlcHRIYW5kbGVyc107XG5cdGNvbnN0IG5leHQgPSAoKSA9PiB7XG5cdFx0Y29uc3QgY3VyID0gcXVldWUuc2hpZnQoKTtcblx0XHRpZiAoY3VyKSB7XG5cdFx0XHRyZXR1cm4gY3VyKG51bGwpLnRoZW4obmV4dCk7XG5cdFx0fSBlbHNlIHtcblx0XHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUobnVsbCk7XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gbmV4dCgpO1xufTtcblxuZXhwb3J0IGNvbnN0IGFwcGx5SG1yID0gbWFrZUFwcGx5SG1yKGFyZ3MgPT4ge1xuXHRjb25zdCB7IG5vdGlmeVN0YXJ0LCBub3RpZnlFcnJvciwgbm90aWZ5RW5kIH0gPSBnW2dsb2JhbEtleV07XG5cdGNvbnN0IHsgbSwgcmVsb2FkIH0gPSBhcmdzO1xuXG5cdGxldCBhY2NlcHRIYW5kbGVycyA9IChtLmhvdC5kYXRhICYmIG0uaG90LmRhdGEuYWNjZXB0SGFuZGxlcnMpIHx8IFtdO1xuXHRsZXQgbmV4dEFjY2VwdEhhbmRsZXJzID0gW107XG5cblx0bS5ob3QuZGlzcG9zZShkYXRhID0+IHtcblx0XHRkYXRhLmFjY2VwdEhhbmRsZXJzID0gbmV4dEFjY2VwdEhhbmRsZXJzO1xuXHR9KTtcblxuXHRjb25zdCBkaXNwb3NlID0gKC4uLmFyZ3MpID0+IG0uaG90LmRpc3Bvc2UoLi4uYXJncyk7XG5cblx0Y29uc3QgYWNjZXB0ID0gaGFuZGxlciA9PiB7XG5cdFx0aWYgKG5leHRBY2NlcHRIYW5kbGVycy5sZW5ndGggPT09IDApIHtcblx0XHRcdG0uaG90LmFjY2VwdCgpO1xuXHRcdH1cblx0XHRuZXh0QWNjZXB0SGFuZGxlcnMucHVzaChoYW5kbGVyKTtcblx0fTtcblxuXHRjb25zdCBjaGVjayA9IHN0YXR1cyA9PiB7XG5cdFx0aWYgKHN0YXR1cyA9PT0gJ3JlYWR5Jykge1xuXHRcdFx0bm90aWZ5U3RhcnQoKTtcblx0XHR9IGVsc2UgaWYgKHN0YXR1cyA9PT0gJ2lkbGUnKSB7XG5cdFx0XHRydW5BY2NlcHRIYW5kbGVycyhhY2NlcHRIYW5kbGVycylcblx0XHRcdFx0LnRoZW4obm90aWZ5RW5kKVxuXHRcdFx0XHQuY2F0Y2gobm90aWZ5RXJyb3IocmVsb2FkKSk7XG5cdFx0fVxuXHR9O1xuXG5cdG0uaG90LmFkZFN0YXR1c0hhbmRsZXIoY2hlY2spO1xuXG5cdG0uaG90LmRpc3Bvc2UoKCkgPT4ge1xuXHRcdG0uaG90LnJlbW92ZVN0YXR1c0hhbmRsZXIoY2hlY2spO1xuXHR9KTtcblxuXHRjb25zdCBob3QgPSB7XG5cdFx0ZGF0YTogbS5ob3QuZGF0YSxcblx0XHRkaXNwb3NlLFxuXHRcdGFjY2VwdCxcblx0fTtcblxuXHRyZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgYXJncywgeyBob3QgfSk7XG59KTtcbiIsImltcG9ydCB7IGNyZWF0ZVByb3h5IH0gZnJvbSAnLi9wcm94eSdcblxuY29uc3QgbG9nUHJlZml4ID0gJ1tITVI6U3ZlbHRlXSdcblxuY29uc3QgZGVmYXVsdEhvdE9wdGlvbnMgPSB7XG4gIC8vIGRvbid0IHByZXNlcnZlIGxvY2FsIHN0YXRlXG4gIG5vUHJlc2VydmVTdGF0ZTogZmFsc2UsXG4gIC8vIGRvbid0IHJlbG9hZCBvbiBmYXRhbCBlcnJvclxuICBub1JlbG9hZDogZmFsc2UsXG4gIC8vIHRyeSB0byByZWNvdmVyIGFmdGVyIHJ1bnRpbWUgZXJyb3JzIGR1cmluZyBjb21wb25lbnQgaW5pdFxuICBvcHRpbWlzdGljOiBmYWxzZSxcbn1cblxuY29uc3QgcmVnaXN0cnkgPSBuZXcgTWFwKClcblxuY29uc3QgbG9nID0gKC4uLmFyZ3MpID0+IGNvbnNvbGUubG9nKGxvZ1ByZWZpeCwgLi4uYXJncylcblxuY29uc3QgZG9tUmVsb2FkID0gKCkgPT4ge1xuICBpZiAoXG4gICAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICB3aW5kb3cubG9jYXRpb24gJiZcbiAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkXG4gICkge1xuICAgIGxvZygnUmVsb2FkJylcbiAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKClcbiAgfSBlbHNlIHtcbiAgICBsb2coJ0Z1bGwgcmVsb2FkIHJlcXVpcmVkJylcbiAgfVxufVxuXG5jb25zdCBkZWZhdWx0QXJncyA9IHtcbiAgcmVsb2FkOiBkb21SZWxvYWQsXG59XG5cbmV4cG9ydCBjb25zdCBtYWtlQXBwbHlIbXIgPSB0cmFuc2Zvcm1BcmdzID0+IGFyZ3MgPT4ge1xuICBjb25zdCBhbGxBcmdzID0gdHJhbnNmb3JtQXJncyh7IC4uLmRlZmF1bHRBcmdzLCAuLi5hcmdzIH0pXG4gIHJldHVybiBhcHBseUhtcihhbGxBcmdzKVxufVxuXG5mdW5jdGlvbiBhcHBseUhtcihhcmdzKSB7XG4gIGNvbnN0IHtcbiAgICBpZCxcbiAgICByZWxvYWQgPSBkb21SZWxvYWQsXG4gICAgLy8gbm9ybWFsaXplZCBob3QgQVBJIChtdXN0IGNvbmZvcm0gdG8gcm9sbHVwLXBsdWdpbi1ob3QpXG4gICAgaG90LFxuICAgIGhvdE9wdGlvbnM6IGhvdE9wdGlvbnNBcmcsXG4gICAgQ29tcG9uZW50LFxuICAgIGNvbXBpbGVEYXRhLFxuICAgIFByb3h5QWRhcHRlcixcbiAgfSA9IGFyZ3NcblxuICBjb25zdCBob3RPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgZGVmYXVsdEhvdE9wdGlvbnMsIGhvdE9wdGlvbnNBcmcpXG5cbiAgLy8gbWV0YSBpbmZvIGZyb20gY29tcGlsYXRpb24gKHZhcnMsIHRoaW5ncyB0aGF0IGNvdWxkIGJlIGluc3BlY3RlZCBpbiBBU1QuLi4pXG4gIC8vIGNhbiBiZSB1c2VkIHRvIGhlbHAgdGhlIHByb3h5IGJldHRlciBlbXVsYXRlIHRoZSBwcm94aWVkIGNvbXBvbmVudCAoYW5kXG4gIC8vIGJldHRlciBtb2NrIHN2ZWx0ZSBob29rcywgaW4gdGhlIHdhaXQgZm9yIG9mZmljaWFsIHN1cHBvcnQpXG4gIGlmIChjb21waWxlRGF0YSkge1xuICAgIC8vIE5PVEUgd2UncmUgbWFraW5nIENvbXBvbmVudCBjYXJyeSB0aGUgbG9hZCB0byBtaW5pbWl6ZSBkaWZmIHdpdGggYmFzZSBicmFuY2hcbiAgICBDb21wb25lbnQuJGNvbXBpbGUgPSBjb21waWxlRGF0YVxuICB9XG5cbiAgY29uc3QgZXhpc3RpbmcgPSBob3QuZGF0YSAmJiBob3QuZGF0YS5yZWNvcmRcbiAgY29uc3QgciA9IGV4aXN0aW5nIHx8IGNyZWF0ZVByb3h5KFByb3h5QWRhcHRlciwgaWQsIENvbXBvbmVudCwgaG90T3B0aW9ucylcblxuICBpZiAoci5oYXNGYXRhbEVycm9yKCkpIHtcbiAgICBpZiAoaG90T3B0aW9ucyAmJiBob3RPcHRpb25zLm5vUmVsb2FkKSB7XG4gICAgICBsb2coJ0Z1bGwgcmVsb2FkIHJlcXVpcmVkJylcbiAgICB9IGVsc2Uge1xuICAgICAgcmVsb2FkKClcbiAgICB9XG4gIH1cblxuICByLnVwZGF0ZSh7IENvbXBvbmVudCwgaG90T3B0aW9ucyB9KVxuXG4gIGhvdC5kaXNwb3NlKGRhdGEgPT4ge1xuICAgIGRhdGEucmVjb3JkID0gclxuICB9KVxuXG4gIGhvdC5hY2NlcHQoYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHIucmVsb2FkKClcbiAgICBpZiAoci5oYXNGYXRhbEVycm9yKCkpIHtcbiAgICAgIGlmIChob3RPcHRpb25zICYmIGhvdE9wdGlvbnMubm9SZWxvYWQpIHtcbiAgICAgICAgbG9nKCdGdWxsIHJlbG9hZCByZXF1aXJlZCcpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZWxvYWQoKVxuICAgICAgfVxuICAgIH1cbiAgfSlcblxuICAvLyB3ZWxsLCBlbmRnYW1lLi4uIHdlIHdvbid0IGJlIGFibGUgdG8gcmVuZGVyIG5leHQgdXBkYXRlcywgZXZlbiBzdWNjZXNzZnVsLFxuICAvLyBpZiB3ZSBkb24ndCBoYXZlIHByb3hpZXMgaW4gc3ZlbHRlJ3MgdHJlZVxuICAvL1xuICAvLyBzaW5jZSB3ZSB3b24ndCByZXR1cm4gdGhlIHByb3h5IGFuZCB0aGUgYXBwIHdpbGwgZXhwZWN0IGEgc3ZlbHRlIGNvbXBvbmVudCxcbiAgLy8gaXQncyBnb25uYSBjcmFzaC4uLiBzbyBpdCdzIGJlc3QgdG8gcmVwb3J0IHRoZSByZWFsIGNhdXNlXG4gIC8vXG4gIC8vIGZ1bGwgcmVsb2FkIHJlcXVpcmVkXG4gIC8vXG4gIGNvbnN0IHByb3h5T2sgPSByICYmIHIucHJveHlcbiAgaWYgKCFwcm94eU9rKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gY3JlYXRlIEhNUiBwcm94eSBmb3IgU3ZlbHRlIGNvbXBvbmVudCAke2lkfWApXG4gIH1cblxuICByZXR1cm4gci5wcm94eVxufVxuIiwiZXhwb3J0IHsgbWFrZUFwcGx5SG1yIH0gZnJvbSAnLi9ob3QtYXBpJ1xuIiwiY29uc3QgcmVtb3ZlRWxlbWVudCA9IGVsID0+IGVsICYmIGVsLnBhcmVudE5vZGUgJiYgZWwucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChlbClcblxuY29uc3QgRXJyb3JPdmVybGF5ID0gKCkgPT4ge1xuICBsZXQgZXJyb3JzID0gW11cbiAgbGV0IGNvbXBpbGVFcnJvciA9IG51bGxcblxuICBjb25zdCBlcnJvcnNUaXRsZSA9ICdGYWlsZWQgdG8gaW5pdCBjb21wb25lbnQnXG4gIGNvbnN0IGNvbXBpbGVFcnJvclRpdGxlID0gJ0ZhaWxlZCB0byBjb21waWxlJ1xuXG4gIGNvbnN0IHN0eWxlID0ge1xuICAgIHNlY3Rpb246IGBcbiAgICAgIHBvc2l0aW9uOiBmaXhlZDtcbiAgICAgIHRvcDogMDtcbiAgICAgIGJvdHRvbTogMDtcbiAgICAgIGxlZnQ6IDA7XG4gICAgICByaWdodDogMDtcbiAgICAgIHBhZGRpbmc6IDMycHg7XG4gICAgICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIC44NSk7XG4gICAgICBmb250LWZhbWlseTogTWVubG8sIENvbnNvbGFzLCBtb25vc3BhY2U7XG4gICAgICBmb250LXNpemU6IGxhcmdlO1xuICAgICAgY29sb3I6IHJnYigyMzIsIDIzMiwgMjMyKTtcbiAgICAgIG92ZXJmbG93OiBhdXRvO1xuICAgIGAsXG4gICAgaDE6IGBcbiAgICAgIG1hcmdpbi10b3A6IDA7XG4gICAgICBjb2xvcjogI0UzNjA0OTtcbiAgICAgIGZvbnQtc2l6ZTogbGFyZ2U7XG4gICAgICBmb250LXdlaWdodDogbm9ybWFsO1xuICAgIGAsXG4gICAgaDI6IGBcbiAgICAgIG1hcmdpbjogMzJweCAwIDA7XG4gICAgICBmb250LXNpemU6IGxhcmdlO1xuICAgICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgICBgLFxuICAgIHByZTogYGAsXG4gIH1cblxuICBjb25zdCBjcmVhdGVPdmVybGF5ID0gKCkgPT4ge1xuICAgIGNvbnN0IGgxID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaDEnKVxuICAgIGgxLnN0eWxlID0gc3R5bGUuaDFcbiAgICBjb25zdCBzZWN0aW9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2VjdGlvbicpXG4gICAgc2VjdGlvbi5hcHBlbmRDaGlsZChoMSlcbiAgICBzZWN0aW9uLnN0eWxlID0gc3R5bGUuc2VjdGlvblxuICAgIGNvbnN0IGJvZHkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgIHNlY3Rpb24uYXBwZW5kQ2hpbGQoYm9keSlcbiAgICByZXR1cm4geyBoMSwgZWw6IHNlY3Rpb24sIGJvZHkgfVxuICB9XG5cbiAgY29uc3Qgc2V0VGl0bGUgPSB0aXRsZSA9PiB7XG4gICAgb3ZlcmxheS5oMS50ZXh0Q29udGVudCA9IHRpdGxlXG4gIH1cblxuICBjb25zdCBzaG93ID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgZWwgfSA9IG92ZXJsYXlcbiAgICBpZiAoIWVsLnBhcmVudE5vZGUpIHtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGRvY3VtZW50LmJvZHlcbiAgICAgIHRhcmdldC5hcHBlbmRDaGlsZChvdmVybGF5LmVsKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhpZGUgPSAoKSA9PiB7XG4gICAgY29uc3QgeyBlbCB9ID0gb3ZlcmxheVxuICAgIGlmIChlbC5wYXJlbnROb2RlKSB7XG4gICAgICBvdmVybGF5LmVsLnJlbW92ZSgpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgdXBkYXRlID0gKCkgPT4ge1xuICAgIGlmIChjb21waWxlRXJyb3IpIHtcbiAgICAgIG92ZXJsYXkuYm9keS5pbm5lckhUTUwgPSAnJ1xuICAgICAgc2V0VGl0bGUoY29tcGlsZUVycm9yVGl0bGUpXG4gICAgICBjb25zdCBlcnJvckVsID0gcmVuZGVyRXJyb3IoY29tcGlsZUVycm9yKVxuICAgICAgb3ZlcmxheS5ib2R5LmFwcGVuZENoaWxkKGVycm9yRWwpXG4gICAgICBzaG93KClcbiAgICB9IGVsc2UgaWYgKGVycm9ycy5sZW5ndGggPiAwKSB7XG4gICAgICBvdmVybGF5LmJvZHkuaW5uZXJIVE1MID0gJydcbiAgICAgIHNldFRpdGxlKGVycm9yc1RpdGxlKVxuICAgICAgZXJyb3JzLmZvckVhY2goKHsgdGl0bGUsIG1lc3NhZ2UgfSkgPT4ge1xuICAgICAgICBjb25zdCBlcnJvckVsID0gcmVuZGVyRXJyb3IobWVzc2FnZSwgdGl0bGUpXG4gICAgICAgIG92ZXJsYXkuYm9keS5hcHBlbmRDaGlsZChlcnJvckVsKVxuICAgICAgfSlcbiAgICAgIHNob3coKVxuICAgIH0gZWxzZSB7XG4gICAgICBoaWRlKClcbiAgICB9XG4gIH1cblxuICBjb25zdCByZW5kZXJFcnJvciA9IChtZXNzYWdlLCB0aXRsZSkgPT4ge1xuICAgIGNvbnN0IGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgaWYgKHRpdGxlKSB7XG4gICAgICBjb25zdCBoMiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2gyJylcbiAgICAgIGgyLnRleHRDb250ZW50ID0gdGl0bGVcbiAgICAgIGgyLnN0eWxlID0gc3R5bGUuaDJcbiAgICAgIGRpdi5hcHBlbmRDaGlsZChoMilcbiAgICB9XG4gICAgY29uc3QgcHJlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgncHJlJylcbiAgICBwcmUudGV4dENvbnRlbnQgPSBtZXNzYWdlXG4gICAgZGl2LmFwcGVuZENoaWxkKHByZSlcbiAgICByZXR1cm4gZGl2XG4gIH1cblxuICBjb25zdCBhZGRFcnJvciA9IChlcnJvciwgdGl0bGUpID0+IHtcbiAgICBjb25zdCBtZXNzYWdlID0gKGVycm9yICYmIGVycm9yLnN0YWNrKSB8fCBlcnJvclxuICAgIGVycm9ycy5wdXNoKHsgdGl0bGUsIG1lc3NhZ2UgfSlcbiAgICB1cGRhdGUoKVxuICB9XG5cbiAgY29uc3QgY2xlYXJFcnJvcnMgPSAoKSA9PiB7XG4gICAgZXJyb3JzLmZvckVhY2goKHsgZWxlbWVudCB9KSA9PiB7XG4gICAgICByZW1vdmVFbGVtZW50KGVsZW1lbnQpXG4gICAgfSlcbiAgICBlcnJvcnMgPSBbXVxuICAgIHVwZGF0ZSgpXG4gIH1cblxuICBjb25zdCBzZXRDb21waWxlRXJyb3IgPSBtZXNzYWdlID0+IHtcbiAgICBjb21waWxlRXJyb3IgPSBtZXNzYWdlXG4gICAgdXBkYXRlKClcbiAgfVxuXG4gIGNvbnN0IG92ZXJsYXkgPSBjcmVhdGVPdmVybGF5KClcblxuICByZXR1cm4ge1xuICAgIGFkZEVycm9yLFxuICAgIGNsZWFyRXJyb3JzLFxuICAgIHNldENvbXBpbGVFcnJvcixcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBFcnJvck92ZXJsYXlcbiIsIi8qIGdsb2JhbCBkb2N1bWVudCAqL1xuaW1wb3J0IEVycm9yT3ZlcmxheSBmcm9tICcuL292ZXJsYXknXG5cbmNvbnN0IHJlbW92ZUVsZW1lbnQgPSBlbCA9PiBlbCAmJiBlbC5wYXJlbnROb2RlICYmIGVsLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQoZWwpXG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFByb3h5QWRhcHRlckRvbSB7XG4gIGNvbnN0cnVjdG9yKGluc3RhbmNlKSB7XG4gICAgdGhpcy5pbnN0YW5jZSA9IGluc3RhbmNlXG4gICAgdGhpcy5pbnNlcnRpb25Qb2ludCA9IG51bGxcblxuICAgIHRoaXMuYWZ0ZXJNb3VudCA9IHRoaXMuYWZ0ZXJNb3VudC5iaW5kKHRoaXMpXG4gICAgdGhpcy5yZXJlbmRlciA9IHRoaXMucmVyZW5kZXIuYmluZCh0aGlzKVxuICB9XG5cbiAgLy8gTk9URSBvdmVybGF5IGlzIG9ubHkgY3JlYXRlZCBiZWZvcmUgYmVpbmcgYWN0dWFsbHkgc2hvd24gdG8gaGVscCB0ZXN0XG4gIC8vIHJ1bm5lciAoaXQgd29uJ3QgaGF2ZSB0byBhY2NvdW50IGZvciBlcnJvciBvdmVybGF5IHdoZW4gcnVubmluZyBhc3NlcnRpb25zXG4gIC8vIGFib3V0IHRoZSBjb250ZW50cyBvZiB0aGUgcmVuZGVyZWQgcGFnZSlcbiAgc3RhdGljIGdldEVycm9yT3ZlcmxheShub0NyZWF0ZSA9IGZhbHNlKSB7XG4gICAgaWYgKCFub0NyZWF0ZSAmJiAhdGhpcy5lcnJvck92ZXJsYXkpIHtcbiAgICAgIHRoaXMuZXJyb3JPdmVybGF5ID0gRXJyb3JPdmVybGF5KClcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZXJyb3JPdmVybGF5XG4gIH1cblxuICBzdGF0aWMgcmVuZGVyQ29tcGlsZUVycm9yKG1lc3NhZ2UpIHtcbiAgICBjb25zdCBub0NyZWF0ZSA9ICFtZXNzYWdlXG4gICAgY29uc3Qgb3ZlcmxheSA9IHRoaXMuZ2V0RXJyb3JPdmVybGF5KG5vQ3JlYXRlKVxuICAgIGlmICghb3ZlcmxheSkgcmV0dXJuXG4gICAgb3ZlcmxheS5zZXRDb21waWxlRXJyb3IobWVzc2FnZSlcbiAgfVxuXG4gIGRpc3Bvc2UoKSB7XG4gICAgLy8gQ29tcG9uZW50IGlzIGJlaW5nIGRlc3Ryb3llZCwgZGV0YWNoaW5nIGlzIG5vdCBvcHRpb25hbCBpbiBTdmVsdGUzJ3NcbiAgICAvLyBjb21wb25lbnQgQVBJLCBzbyB3ZSBjYW4gZGlzcG9zZSBvZiB0aGUgaW5zZXJ0aW9uIHBvaW50IGluIGV2ZXJ5IGNhc2UuXG4gICAgaWYgKHRoaXMuaW5zZXJ0aW9uUG9pbnQpIHtcbiAgICAgIHJlbW92ZUVsZW1lbnQodGhpcy5pbnNlcnRpb25Qb2ludClcbiAgICAgIHRoaXMuaW5zZXJ0aW9uUG9pbnQgPSBudWxsXG4gICAgfVxuICAgIHRoaXMuY2xlYXJFcnJvcigpXG4gIH1cblxuICAvLyBOT1RFIGFmdGVyTW91bnQgQ0FOIGJlIGNhbGxlZCBtdWx0aXBsZSB0aW1lcyAoZS5nLiBrZXllZCBsaXN0KVxuICBhZnRlck1vdW50KHRhcmdldCwgYW5jaG9yKSB7XG4gICAgY29uc3Qge1xuICAgICAgaW5zdGFuY2U6IHsgZGVidWdOYW1lIH0sXG4gICAgfSA9IHRoaXNcbiAgICBpZiAoIXRoaXMuaW5zZXJ0aW9uUG9pbnQpIHtcbiAgICAgIHRoaXMuaW5zZXJ0aW9uUG9pbnQgPSBkb2N1bWVudC5jcmVhdGVDb21tZW50KGRlYnVnTmFtZSlcbiAgICB9XG4gICAgdGFyZ2V0Lmluc2VydEJlZm9yZSh0aGlzLmluc2VydGlvblBvaW50LCBhbmNob3IpXG4gIH1cblxuICByZXJlbmRlcigpIHtcbiAgICB0aGlzLmNsZWFyRXJyb3IoKVxuICAgIGNvbnN0IHtcbiAgICAgIGluc3RhbmNlOiB7IHJlZnJlc2hDb21wb25lbnQgfSxcbiAgICAgIGluc2VydGlvblBvaW50LFxuICAgIH0gPSB0aGlzXG4gICAgaWYgKCFpbnNlcnRpb25Qb2ludCkge1xuICAgICAgY29uc3QgZXJyID0gbmV3IEVycm9yKCdDYW5ub3QgcmVyZW5kZXI6IE1pc3NpbmcgaW5zZXJ0aW9uIHBvaW50JylcbiAgICAgIGVyci5obXJGYXRhbCA9IHRydWVcbiAgICAgIHJldHVybiBlcnJcbiAgICB9XG4gICAgcmVmcmVzaENvbXBvbmVudChpbnNlcnRpb25Qb2ludC5wYXJlbnROb2RlLCBpbnNlcnRpb25Qb2ludClcbiAgfVxuXG4gIHJlbmRlckVycm9yKGVycikge1xuICAgIGNvbnN0IHtcbiAgICAgIGluc3RhbmNlOiB7IGRlYnVnTmFtZSB9LFxuICAgIH0gPSB0aGlzXG4gICAgY29uc3QgdGl0bGUgPSBkZWJ1Z05hbWUgfHwgZXJyLm1vZHVsZU5hbWUgfHwgJ0Vycm9yJ1xuICAgIHRoaXMuY29uc3RydWN0b3IuZ2V0RXJyb3JPdmVybGF5KCkuYWRkRXJyb3IoZXJyLCB0aXRsZSlcbiAgfVxuXG4gIGNsZWFyRXJyb3IoKSB7XG4gICAgY29uc3Qgb3ZlcmxheSA9IHRoaXMuY29uc3RydWN0b3IuZ2V0RXJyb3JPdmVybGF5KHRydWUpXG4gICAgaWYgKCFvdmVybGF5KSByZXR1cm5cbiAgICBvdmVybGF5LmNsZWFyRXJyb3JzKClcbiAgfVxufVxuXG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgd2luZG93Ll9fU1ZFTFRFX0hNUl9BREFQVEVSID0gUHJveHlBZGFwdGVyRG9tXG59XG4iLCIvKipcbiAqIFRoZSBITVIgcHJveHkgaXMgYSBjb21wb25lbnQtbGlrZSBvYmplY3Qgd2hvc2UgdGFzayBpcyB0byBzaXQgaW4gdGhlXG4gKiBjb21wb25lbnQgdHJlZSBpbiBwbGFjZSBvZiB0aGUgcHJveGllZCBjb21wb25lbnQsIGFuZCByZXJlbmRlciBlYWNoXG4gKiBzdWNjZXNzaXZlIHZlcnNpb25zIG9mIHNhaWQgY29tcG9uZW50LlxuICovXG5cbmltcG9ydCB7IGNyZWF0ZVByb3hpZWRDb21wb25lbnQgfSBmcm9tICcuL3N2ZWx0ZS1ob29rcydcblxuY29uc3QgaGFuZGxlZE1ldGhvZHMgPSBbJ2NvbnN0cnVjdG9yJywgJyRkZXN0cm95J11cbmNvbnN0IGZvcndhcmRlZE1ldGhvZHMgPSBbJyRzZXQnLCAnJG9uJ11cblxuY29uc3Qgbm9vcCA9ICgpID0+IHt9XG5cbmNvbnN0IGxvZ0Vycm9yID0gKC4uLmFyZ3MpID0+IGNvbnNvbGUuZXJyb3IoJ1tITVJdW1N2ZWx0ZV0nLCAuLi5hcmdzKVxuXG5jb25zdCBwb3NpeGlmeSA9IGZpbGUgPT4gZmlsZS5yZXBsYWNlKC9bL1xcXFxdL2csICcvJylcblxuY29uc3QgZ2V0QmFzZU5hbWUgPSBpZCA9PlxuICBpZFxuICAgIC5zcGxpdCgnLycpXG4gICAgLnBvcCgpXG4gICAgLnNwbGl0KCcuJylcbiAgICAuc2xpY2UoMCwgLTEpXG4gICAgLmpvaW4oJy4nKVxuXG5jb25zdCBjYXBpdGFsaXplID0gc3RyID0+IHN0clswXS50b1VwcGVyQ2FzZSgpICsgc3RyLnNsaWNlKDEpXG5cbmNvbnN0IGdldEZyaWVuZGx5TmFtZSA9IGlkID0+IGNhcGl0YWxpemUoZ2V0QmFzZU5hbWUocG9zaXhpZnkoaWQpKSlcblxuY29uc3QgZ2V0RGVidWdOYW1lID0gaWQgPT4gYDwke2dldEZyaWVuZGx5TmFtZShpZCl9PmBcblxuY29uc3QgcmVsYXlDYWxscyA9IChnZXRUYXJnZXQsIG5hbWVzLCBkZXN0ID0ge30pID0+IHtcbiAgZm9yIChjb25zdCBrZXkgb2YgbmFtZXMpIHtcbiAgICBkZXN0W2tleV0gPSBmdW5jdGlvbiguLi5hcmdzKSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoKVxuICAgICAgaWYgKCF0YXJnZXQpIHtcbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgICByZXR1cm4gdGFyZ2V0W2tleV0gJiYgdGFyZ2V0W2tleV0uY2FsbCh0aGlzLCAuLi5hcmdzKVxuICAgIH1cbiAgfVxuICByZXR1cm4gZGVzdFxufVxuXG5jb25zdCBjb3B5Q29tcG9uZW50TWV0aG9kcyA9IChwcm94eSwgY21wLCBkZWJ1Z05hbWUpID0+IHtcbiAgLy9wcm94eSBjdXN0b20gbWV0aG9kc1xuICBjb25zdCBtZXRob2RzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoT2JqZWN0LmdldFByb3RvdHlwZU9mKGNtcCkpXG4gIG1ldGhvZHMuZm9yRWFjaChtZXRob2QgPT4ge1xuICAgIGlmIChcbiAgICAgICFoYW5kbGVkTWV0aG9kcy5pbmNsdWRlcyhtZXRob2QpICYmXG4gICAgICAhZm9yd2FyZGVkTWV0aG9kcy5pbmNsdWRlcyhtZXRob2QpXG4gICAgKSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkocHJveHksIG1ldGhvZCwge1xuICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIGdldCgpIHtcbiAgICAgICAgICByZXR1cm4gY21wW21ldGhvZF1cbiAgICAgICAgfSxcbiAgICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgICAgLy8gd2UncmUgY2hhbmluZyBpdCBvbiB0aGUgcmVhbCBjb21wb25lbnQgZmlyc3QgdG8gc2VlIHdoYXQgaXRcbiAgICAgICAgICAvLyBnaXZlcy4uLiBpZiBpdCB0aHJvd3MgYW4gZXJyb3IsIHdlIHdhbnQgdG8gdGhyb3cgdGhlIHNhbWUgZXJyb3IgaW5cbiAgICAgICAgICAvLyBvcmRlciB0byBtb3N0IGNsb3NlbHkgZm9sbG93IG5vbi1obXIgYmVoYXZpb3VyLlxuICAgICAgICAgIGNtcFttZXRob2RdID0gdmFsdWVcbiAgICAgICAgICAvLyB3aG8ga25vd3M/IG1heWJlIHRoZSB2YWx1ZSBoYXMgYmVlbiB0cmFuc2Zvcm1lZCBzb21laG93XG4gICAgICAgICAgcHJveHlbbWV0aG9kXSA9IGNtcFttZXRob2RdXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuICB9KVxufVxuXG4vLyBldmVyeXRoaW5nIGluIHRoZSBjb25zdHJ1Y3RvciFcbi8vXG4vLyBzbyB3ZSBkb24ndCBwb2x1dGUgdGhlIGNvbXBvbmVudCBjbGFzcyB3aXRoIG5ldyBtZW1iZXJzXG4vL1xuLy8gc3BlY2lmaWNpdHkgJiBjb25mb3JtYW5jZSB3aXRoIFN2ZWx0ZSBjb21wb25lbnQgY29uc3RydWN0b3IgaXMgYWNoaWV2ZWRcbi8vIGluIHRoZSBcImNvbXBvbmVudCBsZXZlbFwiIChhcyBvcHBvc2VkIFwiaW5zdGFuY2UgbGV2ZWxcIikgY3JlYXRlUmVjb3JkXG4vL1xuY2xhc3MgUHJveHlDb21wb25lbnQge1xuICBjb25zdHJ1Y3RvcihcbiAgICB7XG4gICAgICBBZGFwdGVyLFxuICAgICAgaWQsXG4gICAgICBkZWJ1Z05hbWUsXG4gICAgICBjdXJyZW50LCAvLyB7IENvbXBvbmVudCwgaG90T3B0aW9uczogeyBub1ByZXNlcnZlU3RhdGUsIC4uLiB9IH1cbiAgICAgIHJlZ2lzdGVyLFxuICAgICAgcmVwb3J0RXJyb3IsXG4gICAgfSxcbiAgICBvcHRpb25zIC8vIHsgdGFyZ2V0LCBhbmNob3IsIC4uLiB9XG4gICkge1xuICAgIGxldCBjbXBcbiAgICBsZXQgZGlzcG9zZWQgPSBmYWxzZVxuICAgIGxldCBsYXN0RXJyb3IgPSBudWxsXG5cbiAgICBjb25zdCBkZXN0cm95Q29tcG9uZW50ID0gKCkgPT4ge1xuICAgICAgLy8gZGVzdHJveUNvbXBvbmVudCBpcyB0b2xlcmFudCAoZG9uJ3QgY3Jhc2ggb24gbm8gY21wKSBiZWNhdXNlIGl0XG4gICAgICAvLyBpcyBwb3NzaWJsZSB0aGF0IHJlbG9hZC9yZXJlbmRlciBpcyBjYWxsZWQgYWZ0ZXIgYSBwcmV2aW91c1xuICAgICAgLy8gY3JlYXRlQ29tcG9uZW50IGhhcyBmYWlsZWQgKGhlbmNlIHdlIGhhdmUgYSBwcm94eSwgYnV0IG5vIGNtcClcbiAgICAgIGlmIChjbXApIHtcbiAgICAgICAgY21wLiRkZXN0cm95KClcbiAgICAgICAgY21wID0gbnVsbFxuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IHJlZnJlc2hDb21wb25lbnQgPSAodGFyZ2V0LCBhbmNob3IsIGNvbnNlcnZhdGl2ZURlc3Ryb3kpID0+IHtcbiAgICAgIGlmIChsYXN0RXJyb3IpIHtcbiAgICAgICAgbGFzdEVycm9yID0gbnVsbFxuICAgICAgICBhZGFwdGVyLnJlcmVuZGVyKClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgaWYgKGNvbnNlcnZhdGl2ZURlc3Ryb3kpIHtcbiAgICAgICAgICAgIGNtcCA9IGNtcC4kcmVwbGFjZShjdXJyZW50LkNvbXBvbmVudCwge1xuICAgICAgICAgICAgICB0YXJnZXQsXG4gICAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgICAgY29uc2VydmF0aXZlOiB0cnVlLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY21wID0gY21wLiRyZXBsYWNlKGN1cnJlbnQuQ29tcG9uZW50LCB7IHRhcmdldCwgYW5jaG9yIH0pXG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBjb25zdCBlcnJTdHJpbmcgPSBTdHJpbmcoKGVyciAmJiBlcnIuc3RhY2spIHx8IGVycilcbiAgICAgICAgICBzZXRFcnJvcihlcnIsIHRhcmdldCwgYW5jaG9yKVxuICAgICAgICAgIGlmICghY3VycmVudC5ob3RPcHRpb25zLm9wdGltaXN0aWMgfHwgKGVyciAmJiBlcnIuaG1yRmF0YWwpKSB7XG4gICAgICAgICAgICB0aHJvdyBlcnJcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgbG9nRXJyb3IoYEVycm9yIGR1cmluZyBjb21wb25lbnQgaW5pdCAke2RlYnVnTmFtZX06ICR7ZXJyU3RyaW5nfWApXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gVE9ETyBuZWVkIHRvIHVzZSBjbXAuJHJlcGxhY2VcbiAgICBjb25zdCBzZXRFcnJvciA9IChlcnIsIHRhcmdldCwgYW5jaG9yKSA9PiB7XG4gICAgICBsYXN0RXJyb3IgPSBlcnJcbiAgICAgIGFkYXB0ZXIucmVuZGVyRXJyb3IoZXJyKVxuICAgIH1cblxuICAgIGNvbnN0IGluc3RhbmNlID0ge1xuICAgICAgaG90T3B0aW9uczogY3VycmVudC5ob3RPcHRpb25zLFxuICAgICAgcHJveHk6IHRoaXMsXG4gICAgICBpZCxcbiAgICAgIGRlYnVnTmFtZSxcbiAgICAgIHJlZnJlc2hDb21wb25lbnQsXG4gICAgfVxuXG4gICAgY29uc3QgYWRhcHRlciA9IG5ldyBBZGFwdGVyKGluc3RhbmNlKVxuXG4gICAgY29uc3QgeyBhZnRlck1vdW50LCByZXJlbmRlciB9ID0gYWRhcHRlclxuXG4gICAgLy8gJGRlc3Ryb3kgaXMgbm90IGNhbGxlZCB3aGVuIGEgY2hpbGQgY29tcG9uZW50IGlzIGRpc3Bvc2VkLCBzbyB3ZVxuICAgIC8vIG5lZWQgdG8gaG9vayBmcm9tIGZyYWdtZW50LlxuICAgIGNvbnN0IG9uRGVzdHJveSA9ICgpID0+IHtcbiAgICAgIC8vIE5PVEUgZG8gTk9UIGNhbGwgJGRlc3Ryb3kgb24gdGhlIGNtcCBmcm9tIGhlcmU7IHRoZSBjbXAgaXMgYWxyZWFkeVxuICAgICAgLy8gICBkZWFkLCB0aGlzIHdvdWxkIG5vdCB3b3JrXG4gICAgICBpZiAoIWRpc3Bvc2VkKSB7XG4gICAgICAgIGRpc3Bvc2VkID0gdHJ1ZVxuICAgICAgICBhZGFwdGVyLmRpc3Bvc2UoKVxuICAgICAgICB1bnJlZ2lzdGVyKClcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyAtLS0tIHJlZ2lzdGVyIHByb3h5IGluc3RhbmNlIC0tLS1cblxuICAgIGNvbnN0IHVucmVnaXN0ZXIgPSByZWdpc3RlcihyZXJlbmRlcilcblxuICAgIC8vIC0tLS0gYXVnbWVudGVkIG1ldGhvZHMgLS0tLVxuXG4gICAgdGhpcy4kZGVzdHJveSA9ICgpID0+IHtcbiAgICAgIGRlc3Ryb3lDb21wb25lbnQoKVxuICAgICAgb25EZXN0cm95KClcbiAgICB9XG5cbiAgICAvLyAtLS0tIGZvcndhcmRlZCBtZXRob2RzIC0tLS1cblxuICAgIGNvbnN0IGdldENvbXBvbmVudCA9ICgpID0+IGNtcFxuXG4gICAgcmVsYXlDYWxscyhnZXRDb21wb25lbnQsIGZvcndhcmRlZE1ldGhvZHMsIHRoaXMpXG5cbiAgICAvLyAtLS0tIGNyZWF0ZSAmIG1vdW50IHRhcmdldCBjb21wb25lbnQgaW5zdGFuY2UgLS0tXG5cbiAgICB0cnkge1xuICAgICAgY21wID0gY3JlYXRlUHJveGllZENvbXBvbmVudChjdXJyZW50LkNvbXBvbmVudCwgb3B0aW9ucywge1xuICAgICAgICBub1ByZXNlcnZlU3RhdGU6IGN1cnJlbnQuaG90T3B0aW9ucy5ub1ByZXNlcnZlU3RhdGUsXG4gICAgICAgIG9uRGVzdHJveSxcbiAgICAgICAgb25Nb3VudDogYWZ0ZXJNb3VudCxcbiAgICAgICAgb25JbnN0YW5jZTogY29tcCA9PiB7XG4gICAgICAgICAgLy8gV0FSTklORyB0aGUgcHJveHkgTVVTVCB1c2UgdGhlIHNhbWUgJCQgb2JqZWN0IGFzIGl0cyBjb21wb25lbnRcbiAgICAgICAgICAvLyBpbnN0YW5jZSwgYmVjYXVzZSBhIGxvdCBvZiB3aXJpbmcgaGFwcGVucyBkdXJpbmcgY29tcG9uZW50XG4gICAgICAgICAgLy8gaW5pdGlhbGlzYXRpb24uLi4gbG90cyBvZiByZWZlcmVuY2VzIHRvICQkIGFuZCAkJC5mcmFnbWVudCBoYXZlXG4gICAgICAgICAgLy8gYWxyZWFkeSBiZWVuIGRpc3RyaWJ1dGVkIGFyb3VuZCB3aGVuIHRoZSBjb21wb25lbnQgY29uc3RydWN0b3JcbiAgICAgICAgICAvLyByZXR1cm5zLCBiZWZvcmUgd2UgaGF2ZSBhIGNoYW5jZSB0byB3cmFwIHRoZW0gKGFuZCBzbyB3ZSBjYW4ndFxuICAgICAgICAgIC8vIHdyYXAgdGhlbSBubyBtb3JlLCBiZWNhdXNlIGV4aXN0aW5nIHJlZmVyZW5jZXMgd291bGQgYmVjb21lXG4gICAgICAgICAgLy8gaW52YWxpZClcbiAgICAgICAgICB0aGlzLiQkID0gY29tcC4kJFxuICAgICAgICAgIGNvcHlDb21wb25lbnRNZXRob2RzKHRoaXMsIGNvbXAsIGRlYnVnTmFtZSlcbiAgICAgICAgfSxcbiAgICAgIH0pXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCB7IHRhcmdldCwgYW5jaG9yIH0gPSBvcHRpb25zXG4gICAgICBzZXRFcnJvcihlcnIsIHRhcmdldCwgYW5jaG9yKVxuICAgICAgdGhyb3cgZXJyXG4gICAgfVxuICB9XG59XG5cbmNvbnN0IGNvcHlTdGF0aWNzID0gKGNvbXBvbmVudCwgcHJveHkpID0+IHtcbiAgLy9mb3J3YXJkIHN0YXRpYyBwcm9wZXJ0aWVzIGFuZCBtZXRob2RzXG4gIGZvciAobGV0IGtleSBpbiBjb21wb25lbnQpIHtcbiAgICBwcm94eVtrZXldID0gY29tcG9uZW50W2tleV1cbiAgfVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBITVIgcHJveHkgYW5kIGl0cyBhc3NvY2lhdGVkIGByZWxvYWRgIGZ1bmN0aW9uIHRoYXQgcHVzaGVzIGEgbmV3XG4gKiB2ZXJzaW9uIHRvIGFsbCBleGlzdGluZyBpbnN0YW5jZXMgb2YgdGhlIGNvbXBvbmVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVByb3h5KEFkYXB0ZXIsIGlkLCBDb21wb25lbnQsIGhvdE9wdGlvbnMpIHtcbiAgbGV0IGZhdGFsRXJyb3IgPSBmYWxzZVxuXG4gIGNvbnN0IGRlYnVnTmFtZSA9IGdldERlYnVnTmFtZShpZClcbiAgY29uc3QgaW5zdGFuY2VzID0gW11cblxuICAvLyBjdXJyZW50IG9iamVjdCB3aWxsIGJlIHVwZGF0ZWQsIHByb3h5IGluc3RhbmNlcyB3aWxsIGtlZXAgYSByZWZcbiAgY29uc3QgY3VycmVudCA9IHtcbiAgICBDb21wb25lbnQsXG4gICAgaG90T3B0aW9ucyxcbiAgfVxuXG4gIGNvbnN0IG5hbWUgPSBgUHJveHkke2RlYnVnTmFtZX1gXG5cbiAgLy8gdGhpcyB0cmljayBnaXZlcyB0aGUgZHluYW1pYyBuYW1lIFByb3h5PENvbXBvbmVudD4gdG8gdGhlIGNvbmNyZXRlXG4gIC8vIHByb3h5IGNsYXNzLi4uIHVuZm9ydHVuYXRlbHksIHRoaXMgZG9lc24ndCBzaG93cyBpbiBkZXYgdG9vbHMsIGJ1dFxuICAvLyBpdCBzdGlsbHMgYWxsb3cgdG8gaW5zcGVjdCBjbXAuY29uc3RydWN0b3IubmFtZSB0byBjb25maXJtIGFuIGluc3RhbmNlXG4gIC8vIGlzIGEgcHJveHlcbiAgY29uc3QgcHJveHkgPSB7XG4gICAgW25hbWVdOiBjbGFzcyBleHRlbmRzIFByb3h5Q29tcG9uZW50IHtcbiAgICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBzdXBlcihcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgQWRhcHRlcixcbiAgICAgICAgICAgICAgaWQsXG4gICAgICAgICAgICAgIGRlYnVnTmFtZSxcbiAgICAgICAgICAgICAgY3VycmVudCxcbiAgICAgICAgICAgICAgcmVnaXN0ZXI6IHJlcmVuZGVyID0+IHtcbiAgICAgICAgICAgICAgICBpbnN0YW5jZXMucHVzaChyZXJlbmRlcilcbiAgICAgICAgICAgICAgICBjb25zdCB1bnJlZ2lzdGVyID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgaSA9IGluc3RhbmNlcy5pbmRleE9mKHJlcmVuZGVyKVxuICAgICAgICAgICAgICAgICAgaW5zdGFuY2VzLnNwbGljZShpLCAxKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdW5yZWdpc3RlclxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9wdGlvbnNcbiAgICAgICAgICApXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgIC8vIElmIHdlIGZhaWwgdG8gY3JlYXRlIGEgcHJveHkgaW5zdGFuY2UsIGFueSBpbnN0YW5jZSwgdGhhdCBtZWFuc1xuICAgICAgICAgIC8vIHRoYXQgd2Ugd29uJ3QgYmUgYWJsZSB0byBmaXggdGhpcyBpbnN0YW5jZSB3aGVuIGl0IGlzIHVwZGF0ZWQuXG4gICAgICAgICAgLy8gUmVjb3ZlcmluZyB0byBub3JtYWwgc3RhdGUgd2lsbCBiZSBpbXBvc3NpYmxlLiBITVIncyBkZWFkLlxuICAgICAgICAgIC8vXG4gICAgICAgICAgLy8gRmF0YWwgZXJyb3Igd2lsbCB0cmlnZ2VyIGEgZnVsbCByZWxvYWQgb24gbmV4dCB1cGRhdGUgKHJlbG9hZGluZ1xuICAgICAgICAgIC8vIHJpZ2h0IG5vdyBpcyBraW5kYSBwb2ludGxlc3Mgc2luY2UgYnVnZ3kgY29kZSBzdGlsbCBleGlzdHMpLlxuICAgICAgICAgIC8vXG4gICAgICAgICAgZmF0YWxFcnJvciA9IHRydWVcbiAgICAgICAgICBsb2dFcnJvcihcbiAgICAgICAgICAgIGBVbnJlY292ZXJhYmxlIGVycm9yIGluICR7ZGVidWdOYW1lfTogbmV4dCB1cGRhdGUgd2lsbCB0cmlnZ2VyIGZ1bGwgcmVsb2FkYFxuICAgICAgICAgIClcbiAgICAgICAgICB0aHJvdyBlcnJcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gIH1bbmFtZV1cblxuICAvLyBpbml0aWFsaXplIHN0YXRpYyBtZW1iZXJzXG4gIGNvcHlTdGF0aWNzKGN1cnJlbnQuQ29tcG9uZW50LCBwcm94eSlcblxuICBjb25zdCB1cGRhdGUgPSBuZXdTdGF0ZSA9PiBPYmplY3QuYXNzaWduKGN1cnJlbnQsIG5ld1N0YXRlKVxuXG4gIC8vIHJlbG9hZCBhbGwgZXhpc3RpbmcgaW5zdGFuY2VzIG9mIHRoaXMgY29tcG9uZW50XG4gIGNvbnN0IHJlbG9hZCA9ICgpID0+IHtcbiAgICAvLyB1cGRhdGUgY3VycmVudCByZWZlcmVuY2VzXG4gICAgLy8gT2JqZWN0LmFzc2lnbihjdXJyZW50LCB7IENvbXBvbmVudCwgaG90T3B0aW9ucyB9KVxuICAgIC8vIGNvbnN0IHsgQ29tcG9uZW50LCBob3RPcHRpb25zIH0gPSBjdXJyZW50XG5cbiAgICAvLyBjb3B5IHN0YXRpY3MgYmVmb3JlIGRvaW5nIGFueXRoaW5nIGJlY2F1c2UgYSBzdGF0aWMgcHJvcC9tZXRob2RcbiAgICAvLyBjb3VsZCBiZSB1c2VkIHNvbWV3aGVyZSBpbiB0aGUgY3JlYXRlL3JlbmRlciBjYWxsXG4gICAgLy8gVE9ETyBkZWxldGUgcHJvcHMvbWV0aG9kcyBwcmV2aW91c2x5IGFkZGVkIGFuZCBvZiB3aGljaCB2YWx1ZSBoYXNcbiAgICAvLyBub3QgY2hhbmdlZCBzaW5jZVxuICAgIGNvcHlTdGF0aWNzKGN1cnJlbnQuQ29tcG9uZW50LCBwcm94eSlcblxuICAgIGNvbnN0IGVycm9ycyA9IFtdXG5cbiAgICBpbnN0YW5jZXMuZm9yRWFjaChyZXJlbmRlciA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICByZXJlbmRlcigpXG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgbG9nRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byByZXJlbmRlciAke2RlYnVnTmFtZX06ICR7KGVyciAmJiBlcnIuc3RhY2spIHx8IGVycn1gXG4gICAgICAgIClcbiAgICAgICAgZXJyb3JzLnB1c2goZXJyKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICBpZiAoZXJyb3JzLmxlbmd0aCA+IDApIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIHJldHVybiB0cnVlXG4gIH1cblxuICBjb25zdCBoYXNGYXRhbEVycm9yID0gKCkgPT4gZmF0YWxFcnJvclxuXG4gIHJldHVybiB7IGlkLCBwcm94eSwgdXBkYXRlLCByZWxvYWQsIGhhc0ZhdGFsRXJyb3IgfVxufVxuIiwiLyoqXG4gKiBFbXVsYXRlcyBmb3J0aGNvbWluZyBITVIgaG9va3MgaW4gU3ZlbHRlLlxuICpcbiAqIEFsbCByZWZlcmVuY2VzIHRvIHByaXZhdGUgY29tcG9uZW50IHN0YXRlICgkJCkgYXJlIG5vdyBpc29sYXRlZCBpbiB0aGlzXG4gKiBtb2R1bGUuXG4gKi9cbmltcG9ydCB7XG4gIGN1cnJlbnRfY29tcG9uZW50LFxuICBnZXRfY3VycmVudF9jb21wb25lbnQsXG4gIHNldF9jdXJyZW50X2NvbXBvbmVudCxcbn0gZnJvbSAnc3ZlbHRlL2ludGVybmFsJ1xuXG4vLyBOT1RFIGV4Y2x1ZGVzIHN0b3JlIHN1YnNjcmlwdGlvbnMgYmVjYXVzZSBpdCBjYXVzZXMgY3Jhc2hlcyAoYW5kIGFsc29cbi8vIHByb2JhYmx5IG5vdCBpbnRlbnRlZCB0byByZXN0b3JlIHN0b3JlcyBzdGF0ZSAtLSBzdG9yZXMgbGl2ZXMgb3V0c2lkZSBvZlxuLy8gdGhlIEhNUidkIGNvbXBvbmVudCBub3JtYWxseSlcbmNvbnN0IGlzV3JpdGFibGUgPSB2ID0+ICF2Lm1vZHVsZSAmJiB2LndyaXRhYmxlICYmIHYubmFtZS5zdWJzdHIoMCwgMSkgIT09ICckJ1xuXG5jb25zdCBpc1Byb3AgPSB2ID0+IGlzV3JpdGFibGUodikgJiYgdi5leHBvcnRfbmFtZSAhPSBudWxsXG5cbi8vIENvcmUgJGNhcHR1cmVfc3RhdGUgc2hvdWxkIGJlIGFibGUgdG8gY2FwdHVyZSBlaXRoZXIgb25seSBwcm9wcyBvciB0aGUgd2hvbGVcbi8vIGxvY2FsIHN0YXRlIChpLmUuIGFueSBgbGV0YCB2YWx1ZSkuIFRoZSBiZXN0IGJlaGF2aW91ciByZWdhcmRpbmcgSE1SIHZhcmllc1xuLy8gYmV0d2VlbiBwcm9qZWN0cywgYW5kIGV2ZW4gc2l0dWF0aW9ucyBvZiB3aGF0IHlvdSdyZSBjdXJyZW50bHkgd29ya2luZyBvbi4uLlxuLy8gSXQncyBiZXR0ZXIgdG8gbGVhdmUgaXQgYXMgYW4gb3B0aW9uIHRvIHRoZSBlbmQgdXNlci5cbmNvbnN0ICRjYXB0dXJlX3N0YXRlID0gKGNtcCwgeyBjYXB0dXJlTG9jYWxTdGF0ZSB9KSA9PiB7XG4gIGNvbnN0IGNvbXBpbGVEYXRhID0gY21wLmNvbnN0cnVjdG9yLiRjb21waWxlXG4gIC8vIGFjdHVhbCAkY2FwdHVyZV9zdGF0ZSBpcyB0aGUgb25seSB0aGluZyB0aGF0IHdvcmtzIGluIDMuMTYrIChjb3JyZWN0XG4gIC8vIGxvY2FsIHN0YXRlIGJlaGF2aW91ciB3aWxsIGJlIG1hZGUgcG9zc2libGUgd2hlbiAjMzgyMiBpcyBtZXJnZWQpXG4gIGlmIChjbXAuJGNhcHR1cmVfc3RhdGUpIHtcbiAgICAvLyBOT1RFIHRoZSBjYXB0dXJlTG9jYWxTdGF0ZSBvcHRpb24gaXMgZmFudGFzeSBmb3Igbm93XG4gICAgcmV0dXJuIGNtcC4kY2FwdHVyZV9zdGF0ZSh7IGNhcHR1cmVMb2NhbFN0YXRlIH0pXG4gIH1cbiAgaWYgKGNvbXBpbGVEYXRhICYmIGNvbXBpbGVEYXRhLnZhcnMpIHtcbiAgICBjb25zdCBzdGF0ZSA9IHt9XG4gICAgY29uc3QgZmlsdGVyID0gY2FwdHVyZUxvY2FsU3RhdGUgPyBpc1dyaXRhYmxlIDogaXNQcm9wXG4gICAgY29uc3QgdmFycyA9IGNvbXBpbGVEYXRhLnZhcnMuZmlsdGVyKGZpbHRlcilcbiAgICBjb25zdCBjdHggPSBjbXAuJCQuY3R4XG4gICAgZm9yIChjb25zdCB7IG5hbWUgfSBvZiB2YXJzKSB7XG4gICAgICBzdGF0ZVtuYW1lXSA9IGN0eFtuYW1lXVxuICAgIH1cbiAgICByZXR1cm4gc3RhdGVcbiAgfVxuICAvLyBlbHNlIG5vdGhpbmcsIHN0YXRlIHdvbid0IGJlIHVzZWQgZm9yIHJlc3RvcmUuLi5cbn1cblxuY29uc3QgY2FwdHVyZVN0YXRlID0gKGNtcCwgY2FwdHVyZUxvY2FsU3RhdGUgPSB0cnVlKSA9PiB7XG4gIC8vIHNhbml0eSBjaGVjazogcHJvcHBlciBiZWhhdmlvdXIgaGVyZSBpcyB0byBjcmFzaCBub2lzaWx5IHNvIHRoYXRcbiAgLy8gdXNlciBrbm93cyB0aGF0IHRoZXkncmUgbG9va2luZyBhdCBzb21ldGhpbmcgYnJva2VuXG4gIGlmICghY21wKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdNaXNzaW5nIGNvbXBvbmVudCcpXG4gIH1cbiAgaWYgKCFjbXAuJCQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgY29tcG9uZW50JylcbiAgfVxuICBjb25zdCB7XG4gICAgJCQ6IHsgY2FsbGJhY2tzLCBib3VuZCwgY3R4IH0sXG4gIH0gPSBjbXBcbiAgY29uc3Qgc3RhdGUgPSAkY2FwdHVyZV9zdGF0ZShjbXAsIHsgY2FwdHVyZUxvY2FsU3RhdGUgfSlcbiAgcmV0dXJuIHsgY3R4LCBjYWxsYmFja3MsIGJvdW5kLCBzdGF0ZSB9XG59XG5cbi8vIHJlc3RvcmVTdGF0ZVxuLy9cbi8vIEl0IGlzIHRvbyBsYXRlIHRvIHJlc3RvcmUgY29udGV4dCBhdCB0aGlzIHBvaW50IGJlY2F1c2UgY29tcG9uZW50IGluc3RhbmNlXG4vLyBmdW5jdGlvbiBoYXMgYWxyZWFkeSBiZWVuIGNhbGxlZCAoYW5kIHNvIGNvbnRleHQgaGFzIGFscmVhZHkgYmVlbiByZWFkKS5cbi8vIEluc3RlYWQsIHdlIHJlbHkgb24gc2V0dGluZyBjdXJyZW50X2NvbXBvbmVudCB0byB0aGUgc2FtZSB2YWx1ZSBpdCBoYXMgd2hlblxuLy8gdGhlIGNvbXBvbmVudCB3YXMgZmlyc3QgcmVuZGVyZWQgLS0gd2hpY2ggZml4IHN1cHBvcnQgZm9yIGNvbnRleHQsIGFuZCBpc1xuLy8gYWxzbyBnZW5lcmFsbHkgbW9yZSByZXNwZWN0ZnVsIG9mIG5vcm1hbCBvcGVyYXRpb24uXG4vL1xuY29uc3QgcmVzdG9yZVN0YXRlID0gKGNtcCwgcmVzdG9yZSkgPT4ge1xuICBpZiAoIXJlc3RvcmUpIHtcbiAgICByZXR1cm5cbiAgfVxuICBjb25zdCB7IGNhbGxiYWNrcywgYm91bmQsIHN0YXRlIH0gPSByZXN0b3JlXG4gIGlmIChjYWxsYmFja3MpIHtcbiAgICBjbXAuJCQuY2FsbGJhY2tzID0gY2FsbGJhY2tzXG4gIH1cbiAgaWYgKGJvdW5kKSB7XG4gICAgY21wLiQkLmJvdW5kID0gYm91bmRcbiAgfVxuICBpZiAoc3RhdGUgJiYgY21wLiRpbmplY3Rfc3RhdGUpIHtcbiAgICBjbXAuJGluamVjdF9zdGF0ZShzdGF0ZSlcbiAgfVxuICAvLyBwcm9wcywgcHJvcHMuJCRzbG90cyBhcmUgcmVzdG9yZWQgYXQgY29tcG9uZW50IGNyZWF0aW9uICh3b3Jrc1xuICAvLyBiZXR0ZXIgLS0gd2VsbCwgYXQgYWxsIGFjdHVhbGx5KVxufVxuXG5jb25zdCBmaWx0ZXJQcm9wcyA9IChwcm9wcywgeyB2YXJzIH0gPSB7fSkgPT4ge1xuICBpZiAoIXZhcnMpIHtcbiAgICByZXR1cm4gcHJvcHNcbiAgfVxuICBjb25zdCByZXN1bHQgPSB7fVxuICB2YXJzXG4gICAgLmZpbHRlcih2ID0+ICEhdi5leHBvcnRfbmFtZSlcbiAgICAuZm9yRWFjaCgoeyBleHBvcnRfbmFtZSB9KSA9PiB7XG4gICAgICByZXN1bHRbZXhwb3J0X25hbWVdID0gcHJvcHNbZXhwb3J0X25hbWVdXG4gICAgfSlcbiAgT2JqZWN0LmtleXMocHJvcHMpXG4gICAgLmZpbHRlcihuYW1lID0+IG5hbWUuc3Vic3RyKDAsIDIpID09PSAnJCQnKVxuICAgIC5mb3JFYWNoKGtleSA9PiB7XG4gICAgICByZXN1bHRba2V5XSA9IHByb3BzW2tleV1cbiAgICB9KVxuICByZXR1cm4gcmVzdWx0XG59XG5cbmV4cG9ydCBjb25zdCBjcmVhdGVQcm94aWVkQ29tcG9uZW50ID0gKFxuICBDb21wb25lbnQsXG4gIGluaXRpYWxPcHRpb25zLFxuICB7IG5vUHJlc2VydmVTdGF0ZSwgb25JbnN0YW5jZSwgb25Nb3VudCwgb25EZXN0cm95IH1cbikgPT4ge1xuICBsZXQgY21wXG4gIGxldCBsYXN0XG4gIGxldCBwYXJlbnRDb21wb25lbnRcbiAgbGV0IGNvbXBpbGVEYXRhXG4gIGxldCBvcHRpb25zID0gaW5pdGlhbE9wdGlvbnNcblxuICBjb25zdCBpc0N1cnJlbnQgPSBfY21wID0+IGNtcCA9PT0gX2NtcFxuXG4gIGNvbnN0IHJlc3RvcmVPcHRpb25zID0gcmVzdG9yZSA9PiB7XG4gICAgY29uc3QgY3R4ID0gcmVzdG9yZSAmJiByZXN0b3JlLmN0eFxuICAgIGlmIChjdHgpIHtcbiAgICAgIC8vIGlmICRpbmplY3Rfc3RhdGUgaXMgYXZhaWxhYmxlIChyZXN0b3JlLnN0YXRlKSwgdGhlbiBpdCB3aWxsIGJlIHVzZWQgdG9cbiAgICAgIC8vIHJlc3RvcmUgcHJvcCB2YWx1ZXMsIGFmdGVyIHRoZSBjb21wb25lbnQgaGFzIGJlZW4gcmVjcmVhdGVkIHdpdGggdGhlXG4gICAgICAvLyBpbml0aWFsIHByb3BzIHBhc3NlZCBkdXJpbmcgY29tcG9uZW50IGNyZWF0aW9uLlxuICAgICAgLy9cbiAgICAgIC8vIE5PVEUgb3JpZ2luYWwgcHJvcHMgY29udGFpbiBzbG90czogY3R4LnByb3BzLiQkc2xvdHNcbiAgICAgIC8vXG4gICAgICAvLyBOT1RFIG1heWJlIGNvbXBpbGUgZGF0YSBzaG91bGQgYmUgdGhlIHByZWZlcnJlZCBzdHJhdGVneSBiZWNhdXNlIGl0XG4gICAgICAvLyBhdm9pZHMgY3JlYXRpbmcgdGhlIGNvbXBvbmVudCB3aXRoIG91dGRhdGVkIHByb3AgdmFsdWVzLCBhbmQgbWF5YmUgaXRcbiAgICAgIC8vIGNhbiBpbXBhY3QgdHJhbnNpdGlvbnMgb3Igc3VjaC4gT24gdGhlIG90aGVyIGhhbmQsIGl0IHNlZW1zIHNvbWVob3dcbiAgICAgIC8vIG1vcmUgcmVwcmVzZW50YXRpdmUgb2YgdGhlIG5vcm1hbCAoaS5lLiBub24gSE1SKSBjb21wb25lbnQgYmVoYXZpb3VyLFxuICAgICAgLy8gdG8gYmUgY3JlYXRlZCB3aXRoIHRoZSBpbml0aWFsIHByb3BzIGFuZCB0aGVuIHRyYW5zaXRpb25uZWQgdG8gdGhlXG4gICAgICAvLyBjdXJyZW50IHZhbHVlLlxuICAgICAgaWYgKCFyZXN0b3JlLnN0YXRlKSB7XG4gICAgICAgIGNvbnN0IHByb3BzID0gZmlsdGVyUHJvcHMoY3R4LCBjb21waWxlRGF0YSlcbiAgICAgICAgcmV0dXJuIHsgcHJvcHMgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGFzc2lnbk9wdGlvbnMgPSAodGFyZ2V0LCBhbmNob3IsIHJlc3RvcmUpID0+XG4gICAgKG9wdGlvbnMgPSBPYmplY3QuYXNzaWduKFxuICAgICAge30sXG4gICAgICBpbml0aWFsT3B0aW9ucyxcbiAgICAgIHsgdGFyZ2V0LCBhbmNob3IgfSxcbiAgICAgIHJlc3RvcmVPcHRpb25zKHJlc3RvcmUpXG4gICAgKSlcblxuICBjb25zdCBpbnN0cnVtZW50ID0gdGFyZ2V0Q21wID0+IHtcbiAgICBjb25zdCBjcmVhdGVDb21wb25lbnQgPSAoQ29tcG9uZW50LCByZXN0b3JlLCBwcmV2aW91c0NtcCkgPT4ge1xuICAgICAgc2V0X2N1cnJlbnRfY29tcG9uZW50KHBhcmVudENvbXBvbmVudCB8fCBwcmV2aW91c0NtcClcbiAgICAgIGNvbnN0IGNvbXAgPSBuZXcgQ29tcG9uZW50KG9wdGlvbnMpXG4gICAgICByZXN0b3JlU3RhdGUoY29tcCwgcmVzdG9yZSlcbiAgICAgIGluc3RydW1lbnQoY29tcClcbiAgICAgIHJldHVybiBjb21wXG4gICAgfVxuXG4gICAgLy8gYGNvbnNlcnZhdGl2ZTogdHJ1ZWAgbWVhbnMgd2Ugd2FudCB0byBiZSBzdXJlIHRoYXQgdGhlIG5ldyBjb21wb25lbnQgaGFzXG4gICAgLy8gYWN0dWFsbHkgYmVlbiBzdWNjZXNzZnVseSBjcmVhdGVkIGJlZm9yZSBkZXN0cm95aW5nIHRoZSBvbGQgaW5zdGFuY2UuXG4gICAgLy8gVGhpcyBjb3VsZCBiZSB1c2VmdWwgZm9yIHByZXZlbnRpbmcgcnVudGltZSBlcnJvcnMgaW4gY29tcG9uZW50IGluaXQgdG9cbiAgICAvLyBicmluZyBkb3duIHRoZSB3aG9sZSBITVIuIFVuZm9ydHVuYXRlbHkgdGhlIGltcGxlbWVudGF0aW9uIGJlbGxvdyBpc1xuICAgIC8vIGJyb2tlbiAoRklYTUUpLCBidXQgdGhhdCByZW1haW5zIGFuIGludGVyZXN0aW5nIHRhcmdldCBmb3Igd2hlbiBITVIgaG9va3NcbiAgICAvLyB3aWxsIGFjdHVhbGx5IGxhbmQgaW4gU3ZlbHRlIGl0c2VsZi5cbiAgICAvL1xuICAgIC8vIFRoZSBnb2FsIHdvdWxkIGJlIHRvIHJlbmRlciBhbiBlcnJvciBpbnBsYWNlIGluIGNhc2Ugb2YgZXJyb3IsIHRvIGF2b2lkXG4gICAgLy8gbG9zaW5nIHRoZSBuYXZpZ2F0aW9uIHN0YWNrIChlc3BlY2lhbGx5IGFubm95aW5nIGluIG5hdGl2ZSwgdGhhdCBpcyBub3RcbiAgICAvLyBiYXNlZCBvbiBVUkwgbmF2aWdhdGlvbiwgc28gd2UgbG9zZSB0aGUgY3VycmVudCBwYWdlIG9uIGVhY2ggZXJyb3IpLlxuICAgIC8vXG4gICAgdGFyZ2V0Q21wLiRyZXBsYWNlID0gKFxuICAgICAgQ29tcG9uZW50LFxuICAgICAgeyB0YXJnZXQgPSBvcHRpb25zLnRhcmdldCwgYW5jaG9yID0gb3B0aW9ucy5hbmNob3IsIGNvbnNlcnZhdGl2ZSA9IGZhbHNlIH1cbiAgICApID0+IHtcbiAgICAgIGNvbXBpbGVEYXRhID0gQ29tcG9uZW50LiRjb21waWxlXG4gICAgICBjb25zdCByZXN0b3JlID0gY2FwdHVyZVN0YXRlKHRhcmdldENtcCwgIW5vUHJlc2VydmVTdGF0ZSlcbiAgICAgIGFzc2lnbk9wdGlvbnModGFyZ2V0LCBhbmNob3IsIHJlc3RvcmUpXG4gICAgICBjb25zdCBwcmV2aW91cyA9IGNtcFxuICAgICAgaWYgKGNvbnNlcnZhdGl2ZSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IG5leHQgPSBjcmVhdGVDb21wb25lbnQoQ29tcG9uZW50LCByZXN0b3JlLCBwcmV2aW91cylcbiAgICAgICAgICAvLyBwcmV2ZW50cyBvbl9kZXN0cm95IGZyb20gZmlyaW5nIG9uIG5vbi1maW5hbCBjbXAgaW5zdGFuY2VcbiAgICAgICAgICBjbXAgPSBudWxsXG4gICAgICAgICAgcHJldmlvdXMuJGRlc3Ryb3koKVxuICAgICAgICAgIGNtcCA9IG5leHRcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgY21wID0gcHJldmlvdXNcbiAgICAgICAgICB0aHJvdyBlcnJcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gcHJldmVudHMgb25fZGVzdHJveSBmcm9tIGZpcmluZyBvbiBub24tZmluYWwgY21wIGluc3RhbmNlXG4gICAgICAgIGNtcCA9IG51bGxcbiAgICAgICAgaWYgKHByZXZpb3VzKSB7XG4gICAgICAgICAgLy8gcHJldmlvdXMgY2FuIGJlIG51bGwgaWYgbGFzdCBjb25zdHJ1Y3RvciBoYXMgY3Jhc2hlZFxuICAgICAgICAgIHByZXZpb3VzLiRkZXN0cm95KClcbiAgICAgICAgfVxuICAgICAgICBjbXAgPSBjcmVhdGVDb21wb25lbnQoQ29tcG9uZW50LCByZXN0b3JlLCBsYXN0KVxuICAgICAgICBsYXN0ID0gY21wXG4gICAgICB9XG4gICAgICByZXR1cm4gY21wXG4gICAgfVxuXG4gICAgLy8gTk9URSBvbk1vdW50IG11c3QgcHJvdmlkZSB0YXJnZXQgJiBhbmNob3IgKGZvciB1cyB0byBiZSBhYmxlIHRvIGRldGVybWluYXRlXG4gICAgLy8gXHRcdFx0YWN0dWFsIERPTSBpbnNlcnRpb24gcG9pbnQpXG4gICAgLy9cbiAgICAvLyBcdFx0XHRBbmQgYWxzbywgdG8gc3VwcG9ydCBrZXllZCBsaXN0LCBpdCBuZWVkcyB0byBiZSBjYWxsZWQgZWFjaCB0aW1lIHRoZVxuICAgIC8vIFx0XHRcdGNvbXBvbmVudCBpcyBtb3ZlZCAoc2FtZSBhcyAkJC5mcmFnbWVudC5tKVxuICAgIGlmIChvbk1vdW50KSB7XG4gICAgICBjb25zdCBtID0gdGFyZ2V0Q21wLiQkLmZyYWdtZW50Lm1cbiAgICAgIHRhcmdldENtcC4kJC5mcmFnbWVudC5tID0gKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gbSguLi5hcmdzKVxuICAgICAgICBvbk1vdW50KC4uLmFyZ3MpXG4gICAgICAgIHJldHVybiByZXN1bHRcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBOT1RFIG9uRGVzdHJveSBtdXN0IGJlIGNhbGxlZCBldmVuIGlmIHRoZSBjYWxsIGRvZXNuJ3QgcGFzcyB0aHJvdWdoIHRoZVxuICAgIC8vICAgICAgY29tcG9uZW50J3MgJGRlc3Ryb3kgbWV0aG9kICh0aGF0IHdlIGNhbiBob29rIG9udG8gYnkgb3Vyc2VsdmVzLCBzaW5jZVxuICAgIC8vICAgICAgaXQncyBwdWJsaWMgQVBJKSAtLSB0aGlzIGhhcHBlbnMgYSBsb3QgaW4gc3ZlbHRlJ3MgaW50ZXJuYWxzLCB0aGF0XG4gICAgLy8gICAgICBtYW5pcHVsYXRlcyBjbXAuJCQuZnJhZ21lbnQgZGlyZWN0bHksIG9mdGVuIGJpbmRpbmcgdG8gZnJhZ21lbnQuZCxcbiAgICAvLyAgICAgIGZvciBleGFtcGxlXG4gICAgaWYgKG9uRGVzdHJveSkge1xuICAgICAgdGFyZ2V0Q21wLiQkLm9uX2Rlc3Ryb3kucHVzaCgoKSA9PiB7XG4gICAgICAgIGlmIChpc0N1cnJlbnQodGFyZ2V0Q21wKSkge1xuICAgICAgICAgIG9uRGVzdHJveSgpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuXG4gICAgaWYgKG9uSW5zdGFuY2UpIHtcbiAgICAgIG9uSW5zdGFuY2UodGFyZ2V0Q21wKVxuICAgIH1cblxuICAgIC8vIFN2ZWx0ZSAzIGNyZWF0ZXMgYW5kIG1vdW50IGNvbXBvbmVudHMgZnJvbSB0aGVpciBjb25zdHJ1Y3RvciBpZlxuICAgIC8vIG9wdGlvbnMudGFyZ2V0IGlzIHByZXNlbnQuXG4gICAgLy9cbiAgICAvLyBUaGlzIG1lYW5zIHRoYXQgYXQgdGhpcyBwb2ludCwgdGhlIGNvbXBvbmVudCdzIGBmcmFnbWVudC5jYCBhbmQsXG4gICAgLy8gbW9zdCBub3RhYmx5LCBgZnJhZ21lbnQubWAgd2lsbCBhbHJlYWR5IGhhdmUgYmVlbiBjYWxsZWQgX2Zyb20gaW5zaWRlXG4gICAgLy8gY3JlYXRlQ29tcG9uZW50Xy4gVGhhdCBpczogYmVmb3JlIHdlIGhhdmUgYSBjaGFuY2UgdG8gaG9vayBvbiBpdC5cbiAgICAvL1xuICAgIC8vIFByb3h5J3MgY29uc3RydWN0b3JcbiAgICAvLyAgIC0+IGNyZWF0ZUNvbXBvbmVudFxuICAgIC8vICAgICAtPiBjb21wb25lbnQgY29uc3RydWN0b3JcbiAgICAvLyAgICAgICAtPiBjb21wb25lbnQuJCQuZnJhZ21lbnQuYyguLi4pIChvciBsLCBpZiBoeWRyYXRlOnRydWUpXG4gICAgLy8gICAgICAgLT4gY29tcG9uZW50LiQkLmZyYWdtZW50Lm0oLi4uKVxuICAgIC8vXG4gICAgLy8gICAtPiB5b3UgYXJlIGhlcmUgPC1cbiAgICAvL1xuICAgIGlmIChvbk1vdW50KSB7XG4gICAgICBjb25zdCB7IHRhcmdldCwgYW5jaG9yIH0gPSBvcHRpb25zXG4gICAgICBpZiAodGFyZ2V0KSB7XG4gICAgICAgIG9uTW91bnQodGFyZ2V0LCBhbmNob3IpXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gTk9URSByZWx5aW5nIG9uIGR5bmFtaWMgYmluZGluZ3MgKGN1cnJlbnRfY29tcG9uZW50KSBtYWtlcyB1cyBkZXBlbmRlbnQgb25cbiAgLy8gYnVuZGxlciBjb25maWcgKGFuZCBhcHBhcmVudGx5IGl0IGRvZXMgbm90IHdvcmsgaW4gZGVtby1zdmVsdGUtbm9sbHVwKVxuICB0cnkge1xuICAgIC8vIHVuZm9ydHVuYXRlbHksIHVubGlrZSBjdXJyZW50X2NvbXBvbmVudCwgZ2V0X2N1cnJlbnRfY29tcG9uZW50KCkgY2FuXG4gICAgLy8gY3Jhc2ggaW4gdGhlIG5vcm1hbCBwYXRoICh3aGVuIHRoZXJlIGlzIHJlYWxseSBubyBwYXJlbnQpXG4gICAgcGFyZW50Q29tcG9uZW50ID0gZ2V0X2N1cnJlbnRfY29tcG9uZW50KClcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgLy8gLi4uIHNvIHdlIG5lZWQgdG8gY29uc2lkZXIgdGhhdCB0aGlzIGVycm9yIG1lYW5zIHRoYXQgdGhlcmUgaXMgbm8gcGFyZW50XG4gICAgLy9cbiAgICAvLyB0aGF0IG1ha2VzIHVzIHRpZ2h0bHkgY291cGxlZCB0byB0aGUgZXJyb3IgbWVzc2FnZSBidXQsIGF0IGxlYXN0LCB3ZVxuICAgIC8vIHdvbid0IG11dGUgYW4gdW5leHBlY3RlZCBlcnJvciwgd2hpY2ggaXMgcXVpdGUgYSBob3JyaWJsZSB0aGluZyB0byBkb1xuICAgIGlmIChlcnIubWVzc2FnZSA9PT0gJ0Z1bmN0aW9uIGNhbGxlZCBvdXRzaWRlIGNvbXBvbmVudCBpbml0aWFsaXphdGlvbicpIHtcbiAgICAgIC8vIHdobyBrbm93cy4uLlxuICAgICAgcGFyZW50Q29tcG9uZW50ID0gY3VycmVudF9jb21wb25lbnRcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgZXJyXG4gICAgfVxuICB9XG5cbiAgY21wID0gbmV3IENvbXBvbmVudChvcHRpb25zKVxuXG4gIGluc3RydW1lbnQoY21wKVxuXG4gIHJldHVybiBjbXBcbn1cbiIsIi8qIGdsb2JhbCBTeW1ib2wgKi9cblxuLy8gVGhpcyBtb2R1bGUgbW9ua2V5IHBhdGNoZXMgUGFnZSNzaG93TW9kYWwgaW4gb3JkZXIgdG8gYmUgYWJsZSB0b1xuLy8gYWNjZXNzIGZyb20gdGhlIEhNUiBwcm94eSBkYXRhIHBhc3NlZCB0byBgc2hvd01vZGFsYCBpbiBzdmVsdGUtbmF0aXZlLlxuLy9cbi8vIERhdGEgYXJlIHN0b3JlZCBpbiBhIG9wYXF1ZSBwcm9wIGFjY2Vzc2libGUgd2l0aCBgZ2V0TW9kYWxEYXRhYC5cbi8vXG4vLyBJdCBhbHNvIHN3aXRjaGVzIHRoZSBgY2xvc2VDYWxsYmFja2Agb3B0aW9uIHdpdGggYSBjdXN0b20gYnJld2VkIG9uZVxuLy8gaW4gb3JkZXIgdG8gZ2l2ZSB0aGUgcHJveHkgY29udHJvbCBvdmVyIHdoZW4gaXRzIG93biBpbnN0YW5jZSB3aWxsIGJlXG4vLyBkZXN0cm95ZWQuXG4vL1xuLy8gT2J2aW91c2x5IHRoaXMgbWV0aG9kIHN1ZmZlciBmcm9tIGV4dHJlbWUgY291cGxpbmcgd2l0aCB0aGUgdGFyZ2V0IGNvZGVcbi8vIGluIHN2ZWx0ZS1uYXRpdmUuIFNvIGl0IHdvdWxkIGJlIHdpc2UgdG8gcmVjaGVjayBjb21wYXRpYmlsaXR5IG9uIFNOXG4vLyB2ZXJzaW9uIHVwZ3JhZGVzLlxuLy9cbi8vIFJlbGV2YW50IGNvZGUgaXMgdGhlcmUgKGxhc3QgY2hlY2tlZCB2ZXJzaW9uKTpcbi8vXG4vLyBodHRwczovL2dpdGh1Yi5jb20vaGFsZm5lbHNvbi9zdmVsdGUtbmF0aXZlL2Jsb2IvNDhmZGM5N2QyZWI0ZDM5NThjZmNiNGZmNmNmNTc1NWEyMjA4MjllYi9zcmMvZG9tL25hdmlnYXRpb24udHMjTDEzMlxuLy9cblxuLy8gRklYTUUgc2hvdWxkIHdlIG92ZXJyaWRlIFZpZXdCYXNlI3Nob3dNb2RhbCBpbnN0ZWFkP1xuaW1wb3J0IHsgUGFnZSB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvcGFnZSdcblxuY29uc3QgcHJvcCA9XG4gIHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnXG4gICAgPyBTeW1ib2woJ2htcl9zdmVsdGVfbmF0aXZlX21vZGFsJylcbiAgICA6ICdfX19ITVJfU1ZFTFRFX05BVElWRV9NT0RBTF9fXydcblxuY29uc3Qgc3VwID0gUGFnZS5wcm90b3R5cGUuc2hvd01vZGFsXG5cbmxldCBwYXRjaGVkID0gZmFsc2VcblxuZXhwb3J0IGNvbnN0IHBhdGNoU2hvd01vZGFsID0gKCkgPT4ge1xuICAvLyBndWFyZDogYWxyZWFkeSBwYXRjaGVkXG4gIGlmIChwYXRjaGVkKSByZXR1cm5cbiAgcGF0Y2hlZCA9IHRydWVcblxuICBQYWdlLnByb3RvdHlwZS5zaG93TW9kYWwgPSBmdW5jdGlvbihtb2RhbFZpZXcsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBtb2RhbERhdGEgPSB7XG4gICAgICBvcmlnaW5hbE9wdGlvbnM6IG9wdGlvbnMsXG4gICAgICBjbG9zZUNhbGxiYWNrOiBvcHRpb25zLmNsb3NlQ2FsbGJhY2ssXG4gICAgfVxuXG4gICAgbW9kYWxWaWV3W3Byb3BdID0gbW9kYWxEYXRhXG5cbiAgICAvLyBQcm94aWVzIHRvIGEgZnVuY3Rpb24gdGhhdCBjYW4gYmUgc3dhcHBlZCBvbiB0aGUgZmx5IGJ5IEhNUiBwcm94eS5cbiAgICAvL1xuICAgIC8vIFRoZSBkZWZhdWx0IGlzIHN0aWxsIHRvIGNhbGwgdGhlIG9yaWdpbmFsIGNsb3NlQ2FsbGJhY2sgZnJvbSBzdmVsdGVcbiAgICAvLyBuYXZ0aXZlLCB3aGljaCB3aWxsIGRlc3Ryb3kgdGhlIG1vZGFsIHZpZXcgJiBjb21wb25lbnQuIFRoaXMgd2F5LCBpZlxuICAgIC8vIG5vIEhNUiBoYXBwZW5zIG9uIHRoZSBtb2RhbCBjb250ZW50LCBub3JtYWwgYmVoYXZpb3VyIGlzIHByZXNlcnZlZFxuICAgIC8vIHdpdGhvdXQgdGhlIHByb3h5IGhhdmluZyBhbnkgd29yayB0byBkby5cbiAgICAvL1xuICAgIGNvbnN0IGNsb3NlQ2FsbGJhY2sgPSAoLi4uYXJncykgPT4ge1xuICAgICAgcmV0dXJuIG1vZGFsRGF0YS5jbG9zZUNhbGxiYWNrKC4uLmFyZ3MpXG4gICAgfVxuXG4gICAgY29uc3QgdGFtcGVyZWRPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucywgeyBjbG9zZUNhbGxiYWNrIH0pXG5cbiAgICByZXR1cm4gc3VwLmNhbGwodGhpcywgbW9kYWxWaWV3LCB0YW1wZXJlZE9wdGlvbnMpXG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGdldE1vZGFsRGF0YSA9IG1vZGFsVmlldyA9PiBtb2RhbFZpZXdbcHJvcF1cbiIsIi8qIGdsb2JhbCBkb2N1bWVudCAqL1xuXG5pbXBvcnQgeyBOYXZpZ2F0aW9uVHlwZSB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvZnJhbWUnXG5cbmltcG9ydCBQcm94eUFkYXB0ZXJEb20gZnJvbSAnLi4vcHJveHktYWRhcHRlci1kb20nXG5cbmltcG9ydCB7IHBhdGNoU2hvd01vZGFsLCBnZXRNb2RhbERhdGEgfSBmcm9tICcuL3BhdGNoLXBhZ2Utc2hvdy1tb2RhbCdcblxucGF0Y2hTaG93TW9kYWwoKVxuXG4vLyBTdmVsdGUgTmF0aXZlIHN1cHBvcnRcbi8vID09PT09PT09PT09PT09PT09PT09PVxuLy9cbi8vIFJlcmVuZGVyaW5nIFN2ZWx0ZSBOYXRpdmUgcGFnZSBwcm92ZXMgY2hhbGxlbmdpbmcuLi5cbi8vXG4vLyBJbiBOYXRpdmVTY3JpcHQsIHBhZ2VzIGFyZSB0aGUgdG9wIGxldmVsIGNvbXBvbmVudC4gVGhleSBhcmUgbm9ybWFsbHlcbi8vIGludHJvZHVjZWQgaW50byBOYXRpdmVTY3JpcHQncyBydW50aW1lIGJ5IGl0cyBgbmF2aWdhdGVgIGZ1bmN0aW9uLiBUaGlzXG4vLyBpcyBob3cgU3ZlbHRlIE5hdGl2ZXMgaGFuZGxlcyBpdDogaXQgcmVuZGVycyB0aGUgUGFnZSBjb21wb25lbnQgdG8gYVxuLy8gZHVtbXkgZnJhZ21lbnQsIGFuZCBcIm5hdmlnYXRlXCIgdG8gdGhlIHBhZ2UgZWxlbWVudCB0aHVzIGNyZWF0ZWQuXG4vL1xuLy8gQXMgbG9uZyBhcyBtb2RpZmljYXRpb25zIG9ubHkgaW1wYWN0IGNoaWxkIGNvbXBvbmVudHMgb2YgdGhlIHBhZ2UsIHRoZW5cbi8vIHdlIGNhbiBrZWVwIHRoZSBleGlzdGluZyBwYWdlIGFuZCByZXBsYWNlIGl0cyBjb250ZW50IGZvciBITVIuXG4vL1xuLy8gSG93ZXZlciwgaWYgdGhlIHBhZ2UgY29tcG9uZW50IGl0c2VsZiBpcyBtb2RpZmllZCAoaW5jbHVkaW5nIGl0cyBzeXN0ZW1cbi8vIHRpdGxlIGJhciksIHRoaW5ncyBnZXQgaGFpcnkuLi5cbi8vXG4vLyBBcHBhcmVudGx5LCB0aGUgc29sZSB3YXkgb2YgaW50cm9kdWNpbmcgYSBuZXcgcGFnZSBpbiBhIE5TIGFwcGxpY2F0aW9uIGlzXG4vLyB0byBuYXZpZ2F0ZSB0byBpdCAobm8gd2F5IHRvIGp1c3QgcmVwbGFjZSBpdCBpbiBpdHMgcGFyZW50IFwiZWxlbWVudFwiLCBmb3Jcbi8vIGV4YW1wbGUpLiBUaGlzIGlzIGhvdyBpdCBpcyBkb25lIGluIE5TJ3Mgb3duIFwiY29yZVwiIEhNUi5cbi8vXG4vLyBOT1RFIFRoZSBsYXN0IHBhcmFncmFwaCBoYXMgbm90IHJlYWxseSBiZWVuIGNvbmZpcm1lZCB3aXRoIE5TNi5cbi8vXG4vLyBVbmZvcnR1bmF0ZWx5IHRoZSBBUEkgdGhleSdyZSB1c2luZyB0byBkbyB0aGF0IGlzIG5vdCBwdWJsaWMuLi4gSXRzIHZhcmlvdXNcbi8vIHBhcnRzIHJlbWFpbiBleHBvc2VkIHRob3VnaCAoYnV0IGRvY3VtZW50ZWQgYXMgcHJpdmF0ZSksIHNvIHRoaXMgZXhwbG9yYXRvcnlcbi8vIHdvcmsgbm93IHJlbGllcyBvbiBpdC4gSXQgbWlnaHQgYmUgZnJhZ2lsZS4uLlxuLy9cbi8vIFRoZSBwcm9ibGVtIGlzIHRoYXQgdGhlcmUgaXMgbm8gcHVibGljIEFQSSB0aGF0IGNhbiBuYXZpZ2F0ZSB0byBhIHBhZ2UgYW5kXG4vLyByZXBsYWNlIChsaWtlIGxvY2F0aW9uLnJlcGxhY2UpIHRoZSBjdXJyZW50IGhpc3RvcnkgZW50cnkuIEFjdHVhbGx5IHRoZXJlXG4vLyBpcyBhbiBhY3RpdmUgaXNzdWUgYXQgTlMgYXNraW5nIGZvciB0aGF0LiBJbmNpZGVudGFsbHksIG1lbWJlcnMgb2Zcbi8vIE5hdGl2ZVNjcmlwdC1WdWUgaGF2ZSBjb21tZW50ZWQgb24gdGhlIGlzc3VlIHRvIHdlaWdodCBpbiBmb3IgaXQgLS0gdGhleVxuLy8gcHJvYmFibHkgZmFjZSBzb21lIHNpbWlsYXIgY2hhbGxlbmdlLlxuLy9cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9OYXRpdmVTY3JpcHQvTmF0aXZlU2NyaXB0L2lzc3Vlcy82MjgzXG5cbmNvbnN0IGdldE5hdlRyYW5zaXRpb24gPSAoeyB0cmFuc2l0aW9uIH0pID0+IHtcbiAgaWYgKHR5cGVvZiB0cmFuc2l0aW9uID09PSAnc3RyaW5nJykge1xuICAgIHRyYW5zaXRpb24gPSB7IG5hbWU6IHRyYW5zaXRpb24gfVxuICB9XG4gIHJldHVybiB0cmFuc2l0aW9uID8geyBhbmltYXRlZDogdHJ1ZSwgdHJhbnNpdGlvbiB9IDogeyBhbmltYXRlZDogZmFsc2UgfVxufVxuXG4vLyBjb3BpZWQgZnJvbSBUTlMgRnJhbWVCYXNlLnJlcGxhY2VQYWdlXG4vL1xuLy8gaXQgaXMgbm90IHB1YmxpYyBidXQgdGhlcmUgaXMgYSBjb21tZW50IGluIHRoZXJlIGluZGljYXRpbmcgaXQgaXMgZm9yXG4vLyBITVIgKHByb2JhYmx5IHRoZWlyIG93biBjb3JlIEhNUiB0aG91Z2gpXG4vL1xuLy8gTk9URSB0aGlzIFwid29ya2VkXCIgaW4gVE5TIDUsIGJ1dCBub3QgYW55bW9yZSBpbiBUTlMgNjogdXBkYXRlZCB2ZXJzaW9uIGJlbGxvd1xuLy9cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bnVzZWQtdmFyc1xuY29uc3QgcmVwbGFjZVBhZ2VfdG5zNSA9IChmcmFtZSwgbmV3UGFnZUVsZW1lbnQsIGhvdE9wdGlvbnMpID0+IHtcbiAgY29uc3QgY3VycmVudEJhY2tzdGFja0VudHJ5ID0gZnJhbWUuX2N1cnJlbnRFbnRyeVxuICBmcmFtZS5uYXZpZ2F0aW9uVHlwZSA9IDJcbiAgZnJhbWUucGVyZm9ybU5hdmlnYXRpb24oe1xuICAgIGlzQmFja05hdmlnYXRpb246IGZhbHNlLFxuICAgIGVudHJ5OiB7XG4gICAgICByZXNvbHZlZFBhZ2U6IG5ld1BhZ2VFbGVtZW50Lm5hdGl2ZVZpZXcsXG4gICAgICAvL1xuICAgICAgLy8gZW50cnk6IGN1cnJlbnRCYWNrc3RhY2tFbnRyeS5lbnRyeSxcbiAgICAgIGVudHJ5OiBPYmplY3QuYXNzaWduKFxuICAgICAgICBjdXJyZW50QmFja3N0YWNrRW50cnkuZW50cnksXG4gICAgICAgIGdldE5hdlRyYW5zaXRpb24oaG90T3B0aW9ucylcbiAgICAgICksXG4gICAgICBuYXZEZXB0aDogY3VycmVudEJhY2tzdGFja0VudHJ5Lm5hdkRlcHRoLFxuICAgICAgZnJhZ21lbnRUYWc6IGN1cnJlbnRCYWNrc3RhY2tFbnRyeS5mcmFnbWVudFRhZyxcbiAgICAgIGZyYW1lSWQ6IGN1cnJlbnRCYWNrc3RhY2tFbnRyeS5mcmFtZUlkLFxuICAgIH0sXG4gIH0pXG59XG5cbi8vIFVwZGF0ZWQgZm9yIFROUyB2NlxuLy9cbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9OYXRpdmVTY3JpcHQvTmF0aXZlU2NyaXB0L2Jsb2IvNi4xLjEvdG5zLWNvcmUtbW9kdWxlcy91aS9mcmFtZS9mcmFtZS1jb21tb24udHMjTDY1NlxuY29uc3QgcmVwbGFjZVBhZ2UgPSAoZnJhbWUsIG5ld1BhZ2VFbGVtZW50KSA9PiB7XG4gIGNvbnN0IGN1cnJlbnRCYWNrc3RhY2tFbnRyeSA9IGZyYW1lLl9jdXJyZW50RW50cnlcbiAgY29uc3QgbmV3UGFnZSA9IG5ld1BhZ2VFbGVtZW50Lm5hdGl2ZVZpZXdcbiAgY29uc3QgbmV3QmFja3N0YWNrRW50cnkgPSB7XG4gICAgZW50cnk6IGN1cnJlbnRCYWNrc3RhY2tFbnRyeS5lbnRyeSxcbiAgICByZXNvbHZlZFBhZ2U6IG5ld1BhZ2UsXG4gICAgbmF2RGVwdGg6IGN1cnJlbnRCYWNrc3RhY2tFbnRyeS5uYXZEZXB0aCxcbiAgICBmcmFnbWVudFRhZzogY3VycmVudEJhY2tzdGFja0VudHJ5LmZyYWdtZW50VGFnLFxuICAgIGZyYW1lSWQ6IGN1cnJlbnRCYWNrc3RhY2tFbnRyeS5mcmFtZUlkLFxuICB9XG4gIGNvbnN0IG5hdmlnYXRpb25Db250ZXh0ID0ge1xuICAgIGVudHJ5OiBuZXdCYWNrc3RhY2tFbnRyeSxcbiAgICBpc0JhY2tOYXZpZ2F0aW9uOiBmYWxzZSxcbiAgICBuYXZpZ2F0aW9uVHlwZTogTmF2aWdhdGlvblR5cGUucmVwbGFjZSxcbiAgfVxuICBmcmFtZS5fbmF2aWdhdGlvblF1ZXVlLnB1c2gobmF2aWdhdGlvbkNvbnRleHQpXG4gIGZyYW1lLl9wcm9jZXNzTmV4dE5hdmlnYXRpb25FbnRyeSgpXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFByb3h5QWRhcHRlck5hdGl2ZSBleHRlbmRzIFByb3h5QWRhcHRlckRvbSB7XG4gIGNvbnN0cnVjdG9yKGluc3RhbmNlKSB7XG4gICAgc3VwZXIoaW5zdGFuY2UpXG5cbiAgICB0aGlzLm5hdGl2ZVBhZ2VFbGVtZW50ID0gbnVsbFxuICAgIHRoaXMub3JpZ2luYWxOYXRpdmVWaWV3ID0gbnVsbFxuICAgIHRoaXMubmF2aWdhdGVkRnJvbUhhbmRsZXIgPSBudWxsXG5cbiAgICB0aGlzLnJlbGF5TmF0aXZlTmF2aWdhdGVkRnJvbSA9IHRoaXMucmVsYXlOYXRpdmVOYXZpZ2F0ZWRGcm9tLmJpbmQodGhpcylcbiAgfVxuXG4gIGRpc3Bvc2UoKSB7XG4gICAgc3VwZXIuZGlzcG9zZSgpXG4gICAgdGhpcy5yZWxlYXNlTmF0aXZlUGFnZUVsZW1lbnQoKVxuICB9XG5cbiAgcmVsZWFzZU5hdGl2ZVBhZ2VFbGVtZW50KCkge1xuICAgIGlmICh0aGlzLm5hdGl2ZVBhZ2VFbGVtZW50KSB7XG4gICAgICAvLyBuYXRpdmUgY2xlYW5pbmcgd2lsbCBoYXBwZW4gd2hlbiBuYXZpZ2F0aW5nIGJhY2sgZnJvbSB0aGUgcGFnZVxuICAgICAgdGhpcy5uYXRpdmVQYWdlRWxlbWVudCA9IG51bGxcbiAgICB9XG4gIH1cblxuICAvLyBzdmVsdGUtbmF0aXZlIHVzZXMgbmF2aWdhdGVGcm9tIGV2ZW50ICsgZS5pc0JhY2tOYXZpZ2F0aW9uIHRvIGtub3dcbiAgLy8gd2hlbiB0byAkZGVzdHJveSB0aGUgY29tcG9uZW50IC0tIGJ1dCB3ZSBkb24ndCB3YW50IG91ciBwcm94eSBpbnN0YW5jZVxuICAvLyBkZXN0cm95ZWQgd2hlbiB3ZSByZW5hdmlnYXRlIHRvIHRoZSBzYW1lIHBhZ2UgZm9yIG5hdmlnYXRpb24gcHVycG9zZXMhXG4gIGludGVyY2VwdFBhZ2VOYXZpZ2F0aW9uKHBhZ2VFbGVtZW50KSB7XG4gICAgY29uc3Qgb3JpZ2luYWxOYXRpdmVWaWV3ID0gcGFnZUVsZW1lbnQubmF0aXZlVmlld1xuICAgIGNvbnN0IHsgb24gfSA9IG9yaWdpbmFsTmF0aXZlVmlld1xuICAgIGNvbnN0IG93bk9uID0gb3JpZ2luYWxOYXRpdmVWaWV3Lmhhc093blByb3BlcnR5KCdvbicpXG4gICAgLy8gdHJpY2tzIHN2ZWx0ZS1uYXRpdmUgaW50byBnaXZpbmcgdXMgaXRzIGhhbmRsZXJcbiAgICBvcmlnaW5hbE5hdGl2ZVZpZXcub24gPSBmdW5jdGlvbih0eXBlLCBoYW5kbGVyLCAuLi5yZXN0KSB7XG4gICAgICBpZiAodHlwZSA9PT0gJ25hdmlnYXRlZEZyb20nKSB7XG4gICAgICAgIHRoaXMubmF2aWdhdGVkRnJvbUhhbmRsZXIgPSBoYW5kbGVyXG4gICAgICAgIGlmIChvd25Pbikge1xuICAgICAgICAgIG9yaWdpbmFsTmF0aXZlVmlldy5vbiA9IG9uXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGVsZXRlIG9yaWdpbmFsTmF0aXZlVmlldy5vblxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgJ1VuZXhwZWN0ZWQgY2FsbDogaGFzIHVuZGVybHlpbmcgc3ZlbHRlLW5hdGl2ZSBjb2RlIGNoYW5nZWQ/J1xuICAgICAgICApXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgYWZ0ZXJNb3VudCh0YXJnZXQsIGFuY2hvcikge1xuICAgIC8vIG5hdGl2ZVBhZ2VFbGVtZW50IG5lZWRzIHRvIGJlIHVwZGF0ZWQgZWFjaCB0aW1lIChvbmx5IGZvciBwYWdlXG4gICAgLy8gY29tcG9uZW50cywgbmF0aXZlIGNvbXBvbmVudCB0aGF0IGFyZSBub3QgcGFnZXMgZm9sbG93IG5vcm1hbCBmbG93KVxuICAgIC8vXG4gICAgLy8gREVCVUcgcXVpZCBvZiBjb21wb25lbnRzIHRoYXQgYXJlIGluaXRpYWxseSBhIHBhZ2UsIGJ1dCB0aGVuIGhhdmUgdGhlXG4gICAgLy8gPHBhZ2U+IHRhZyByZW1vdmVkIHdoaWxlIHJ1bm5pbmc/IG9yIHRoZSBvcHBvc2l0ZT9cbiAgICAvL1xuICAgIC8vIGluc2VydGlvblBvaW50IG5lZWRzIHRvIGJlIHVwZGF0ZWQgX29ubHkgd2hlbiB0aGUgdGFyZ2V0IGNoYW5nZXNfIC0tXG4gICAgLy8gaS5lLiB3aGVuIHRoZSBjb21wb25lbnQgaXMgbW91bnQsIGkuZS4gKGluIHN2ZWx0ZTMpIHdoZW4gdGhlIGNvbXBvbmVudFxuICAgIC8vIGlzIF9jcmVhdGVkXywgYW5kIHN2ZWx0ZTMgZG9lc24ndCBhbGxvdyBpdCB0byBtb3ZlIGFmdGVyd2FyZCAtLSB0aGF0XG4gICAgLy8gaXMsIGluc2VydGlvblBvaW50IG9ubHkgbmVlZHMgdG8gYmUgY3JlYXRlZCBvbmNlIHdoZW4gdGhlIGNvbXBvbmVudCBpc1xuICAgIC8vIGZpcnN0IG1vdW50ZWQuXG4gICAgLy9cbiAgICAvLyBERUJVRyBpcyBpdCByZWFsbHkgdHJ1ZSB0aGF0IGNvbXBvbmVudHMnIGVsZW1lbnRzIGNhbm5vdCBtb3ZlIGluIHRoZVxuICAgIC8vIERPTT8gd2hhdCBhYm91dCBrZXllZCBsaXN0P1xuICAgIC8vXG4gICAgY29uc3QgaXNOYXRpdmVQYWdlID0gdGFyZ2V0LnRhZ05hbWUgPT09ICdmcmFnbWVudCdcbiAgICBpZiAoaXNOYXRpdmVQYWdlKSB7XG4gICAgICBjb25zdCBuYXRpdmVQYWdlRWxlbWVudCA9IHRhcmdldC5maXJzdENoaWxkXG4gICAgICB0aGlzLmludGVyY2VwdFBhZ2VOYXZpZ2F0aW9uKG5hdGl2ZVBhZ2VFbGVtZW50KVxuICAgICAgdGhpcy5uYXRpdmVQYWdlRWxlbWVudCA9IG5hdGl2ZVBhZ2VFbGVtZW50XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIHRyeSB0byBwcm90ZWN0IGFnYWluc3QgY29tcG9uZW50cyBjaGFuZ2luZyBmcm9tIHBhZ2UgdG8gbm8tcGFnZVxuICAgICAgLy8gb3IgdmljZSB2ZXJzYSAtLSBzZWUgREVCVUcgMSBhYm92ZS4gTk9UIFRFU1RFRCBzbyBwcm9sbHkgbm90IHdvcmtpbmdcbiAgICAgIHRoaXMubmF0aXZlUGFnZUVsZW1lbnQgPSBudWxsXG4gICAgICBzdXBlci5hZnRlck1vdW50KHRhcmdldCwgYW5jaG9yKVxuICAgIH1cbiAgfVxuXG4gIHJlcmVuZGVyKCkge1xuICAgIGNvbnN0IHsgbmF0aXZlUGFnZUVsZW1lbnQgfSA9IHRoaXNcbiAgICBpZiAobmF0aXZlUGFnZUVsZW1lbnQpIHtcbiAgICAgIHRoaXMucmVyZW5kZXJOYXRpdmUoKVxuICAgIH0gZWxzZSB7XG4gICAgICBzdXBlci5yZXJlbmRlcigpXG4gICAgfVxuICB9XG5cbiAgcmVyZW5kZXJOYXRpdmUoKSB7XG4gICAgY29uc3QgeyBuYXRpdmVQYWdlRWxlbWVudDogb2xkUGFnZUVsZW1lbnQgfSA9IHRoaXNcbiAgICBjb25zdCBuYXRpdmVWaWV3ID0gb2xkUGFnZUVsZW1lbnQubmF0aXZlVmlld1xuICAgIGNvbnN0IGZyYW1lID0gbmF0aXZlVmlldy5mcmFtZVxuICAgIGlmIChmcmFtZSkge1xuICAgICAgcmV0dXJuIHRoaXMucmVyZW5kZXJQYWdlKGZyYW1lLCBuYXRpdmVWaWV3KVxuICAgIH1cbiAgICBjb25zdCBtb2RhbFBhcmVudCA9IG5hdGl2ZVZpZXcuX21vZGFsUGFyZW50IC8vIEZJWE1FIHByaXZhdGUgQVBJXG4gICAgaWYgKG1vZGFsUGFyZW50KSB7XG4gICAgICByZXR1cm4gdGhpcy5yZXJlbmRlck1vZGFsKG1vZGFsUGFyZW50LCBuYXRpdmVWaWV3KVxuICAgIH1cbiAgICAvLyB3dGY/IGhvcGVmdWxseSBhIHJhY2UgY29uZGl0aW9uIHdpdGggYSBkZXN0cm95ZWQgY29tcG9uZW50LCBzb1xuICAgIC8vIHdlIGhhdmUgbm90aGluZyBtb3JlIHRvIGRvIGhlcmVcbiAgICAvL1xuICAgIC8vIGZvciBvbmNlLCBpdCBoYXBwZW5zIHdoZW4gaG90IHJlbG9hZGluZyBkZXYgZGVwcywgbGlrZSB0aGlzIGZpbGVcbiAgICAvL1xuICB9XG5cbiAgcmVyZW5kZXJQYWdlKGZyYW1lLCBwcmV2aW91c1BhZ2VWaWV3KSB7XG4gICAgY29uc3QgaXNDdXJyZW50UGFnZSA9IGZyYW1lLmN1cnJlbnRQYWdlID09PSBwcmV2aW91c1BhZ2VWaWV3XG4gICAgaWYgKGlzQ3VycmVudFBhZ2UpIHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgaW5zdGFuY2U6IHsgaG90T3B0aW9ucyB9LFxuICAgICAgfSA9IHRoaXNcbiAgICAgIGNvbnN0IG5ld1BhZ2VFbGVtZW50ID0gdGhpcy5jcmVhdGVQYWdlKClcbiAgICAgIGlmICghbmV3UGFnZUVsZW1lbnQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGYWlsZWQgdG8gY3JlYXRlIHVwZGF0ZWQgcGFnZScpXG4gICAgICB9XG4gICAgICBjb25zdCBpc0ZpcnN0UGFnZSA9ICFmcmFtZS5jYW5Hb0JhY2soKVxuXG4gICAgICBpZiAoaXNGaXJzdFBhZ2UpIHtcbiAgICAgICAgLy8gTk9URSBub3Qgc28gc3VyZSBvZiBiZWxsb3cgd2l0aCB0aGUgbmV3IE5TNiBtZXRob2QgZm9yIHJlcGxhY2VcbiAgICAgICAgLy8gXG4gICAgICAgIC8vIFRoZSBcInJlcGxhY2VQYWdlXCIgc3RyYXRlZ3kgZG9lcyBub3Qgd29yayBvbiB0aGUgZmlyc3QgcGFnZVxuICAgICAgICAvLyBvZiB0aGUgc3RhY2suXG4gICAgICAgIC8vXG4gICAgICAgIC8vIFJlc3VsdGluZyBidWc6XG4gICAgICAgIC8vIC0gbGF1bmNoXG4gICAgICAgIC8vIC0gY2hhbmdlIGZpcnN0IHBhZ2UgPT4gSE1SXG4gICAgICAgIC8vIC0gbmF2aWdhdGUgdG8gb3RoZXIgcGFnZVxuICAgICAgICAvLyAtIGJhY2tcbiAgICAgICAgLy8gICA9PiBhY3R1YWw6IGJhY2sgdG8gT1NcbiAgICAgICAgLy8gICA9PiBleHBlY3RlZDogYmFjayB0byBwYWdlIDFcbiAgICAgICAgLy9cbiAgICAgICAgLy8gRm9ydHVuYXRlbHksIHdlIGNhbiBvdmVyd3JpdGUgaGlzdG9yeSBpbiB0aGlzIGNhc2UuXG4gICAgICAgIC8vXG4gICAgICAgIGNvbnN0IG5hdGl2ZVZpZXcgPSBuZXdQYWdlRWxlbWVudC5uYXRpdmVWaWV3XG4gICAgICAgIGZyYW1lLm5hdmlnYXRlKFxuICAgICAgICAgIE9iamVjdC5hc3NpZ24oXG4gICAgICAgICAgICB7fSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgY3JlYXRlOiAoKSA9PiBuYXRpdmVWaWV3LFxuICAgICAgICAgICAgICBjbGVhckhpc3Rvcnk6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0TmF2VHJhbnNpdGlvbihob3RPcHRpb25zKVxuICAgICAgICAgIClcbiAgICAgICAgKVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVwbGFjZVBhZ2UoZnJhbWUsIG5ld1BhZ2VFbGVtZW50LCBob3RPcHRpb25zKVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBiYWNrRW50cnkgPSBmcmFtZS5iYWNrU3RhY2suZmluZChcbiAgICAgICAgKHsgcmVzb2x2ZWRQYWdlOiBwYWdlIH0pID0+IHBhZ2UgPT09IHByZXZpb3VzUGFnZVZpZXdcbiAgICAgIClcbiAgICAgIGlmICghYmFja0VudHJ5KSB7XG4gICAgICAgIC8vIHdlbGwuLi4gbG9va3MgbGlrZSB3ZSBkaWRuJ3QgbWFrZSBpdCB0byBoaXN0b3J5IGFmdGVyIGFsbFxuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICAgIC8vIHJlcGxhY2UgZXhpc3RpbmcgbmF0aXZlVmlld1xuICAgICAgY29uc3QgbmV3UGFnZUVsZW1lbnQgPSB0aGlzLmNyZWF0ZVBhZ2UoKVxuICAgICAgaWYgKG5ld1BhZ2VFbGVtZW50KSB7XG4gICAgICAgIGJhY2tFbnRyeS5yZXNvbHZlZFBhZ2UgPSBuZXdQYWdlRWxlbWVudC5uYXRpdmVWaWV3XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBjcmVhdGUgdXBkYXRlZCBwYWdlJylcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBtb2RhbFBhcmVudCBpcyB0aGUgcGFnZSBvbiB3aGljaCBzaG93TW9kYWwoLi4uKSB3YXMgY2FsbGVkXG4gIC8vIG9sZFBhZ2VFbGVtZW50IGlzIHRoZSBtb2RhbCBjb250ZW50LCB0aGF0IHdlJ3JlIGFjdHVhbGx5IHRyeWluZyB0byByZWxvYWRcbiAgcmVyZW5kZXJNb2RhbChtb2RhbFBhcmVudCwgbW9kYWxWaWV3KSB7XG4gICAgY29uc3QgbW9kYWxEYXRhID0gZ2V0TW9kYWxEYXRhKG1vZGFsVmlldylcblxuICAgIG1vZGFsRGF0YS5jbG9zZUNhbGxiYWNrID0gKCkgPT4ge1xuICAgICAgY29uc3QgbmF0aXZlUGFnZUVsZW1lbnQgPSB0aGlzLmNyZWF0ZVBhZ2UoKVxuICAgICAgaWYgKCFuYXRpdmVQYWdlRWxlbWVudCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBjcmVhdGVkIHVwZGF0ZWQgbW9kYWwgcGFnZScpXG4gICAgICB9XG4gICAgICBjb25zdCB7IG5hdGl2ZVZpZXcgfSA9IG5hdGl2ZVBhZ2VFbGVtZW50XG4gICAgICBjb25zdCB7IG9yaWdpbmFsT3B0aW9ucyB9ID0gbW9kYWxEYXRhXG4gICAgICAvLyBPcHRpb25zIHdpbGwgZ2V0IG1vbmtleSBwYXRjaGVkIGFnYWluLCB0aGUgb25seSB3b3JrIGxlZnQgZm9yIHVzXG4gICAgICAvLyBpcyB0byB0cnkgdG8gcmVkdWNlIHZpc3VhbCBkaXN0dXJiYW5jZXMuXG4gICAgICAvL1xuICAgICAgLy8gRklYTUUgRXZlbiB0aGF0IHByb3ZlcyB0b28gbXVjaCB1bmZvcnR1bmF0ZWx5Li4uIEFwcGFyZW50bHkgVE5TXG4gICAgICAvLyBkb2VzIG5vdCByZXNwZWN0IHRoZSBgYW5pbWF0ZWRgIG9wdGlvbiBpbiB0aGlzIGNvbnRleHQ6XG4gICAgICAvLyBodHRwczovL2RvY3MubmF0aXZlc2NyaXB0Lm9yZy9hcGktcmVmZXJlbmNlL2ludGVyZmFjZXMvX3VpX2NvcmVfdmlld19iYXNlXy5zaG93bW9kYWxvcHRpb25zI2FuaW1hdGVkXG4gICAgICAvL1xuICAgICAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9yaWdpbmFsT3B0aW9ucywgeyBhbmltYXRlZDogZmFsc2UgfSlcbiAgICAgIG1vZGFsUGFyZW50LnNob3dNb2RhbChuYXRpdmVWaWV3LCBvcHRpb25zKVxuICAgIH1cblxuICAgIG1vZGFsVmlldy5jbG9zZU1vZGFsKClcbiAgfVxuXG4gIGNyZWF0ZVBhZ2UoKSB7XG4gICAgY29uc3Qge1xuICAgICAgaW5zdGFuY2U6IHsgcmVmcmVzaENvbXBvbmVudCB9LFxuICAgIH0gPSB0aGlzXG4gICAgY29uc3QgeyBuYXRpdmVQYWdlRWxlbWVudCwgcmVsYXlOYXRpdmVOYXZpZ2F0ZWRGcm9tIH0gPSB0aGlzXG4gICAgY29uc3Qgb2xkTmF0aXZlVmlldyA9IG5hdGl2ZVBhZ2VFbGVtZW50Lm5hdGl2ZVZpZXdcbiAgICAvLyByZXJlbmRlclxuICAgIGNvbnN0IHRhcmdldCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ZyYWdtZW50JylcbiAgICAvLyBub3QgdXNpbmcgY29uc2VydmF0aXZlIGZvciBub3csIHNpbmNlIHRoZXJlJ3Mgbm90aGluZyBpbiBwbGFjZSBoZXJlIHRvXG4gICAgLy8gbGV2ZXJhZ2UgaXQgKHlldD8pIC0tIGFuZCBpdCBtaWdodCBiZSBlYXNpZXIgdG8gbWlzcyBicmVha2FnZXMgaW4gbmF0aXZlXG4gICAgLy8gb25seSBjb2RlIHBhdGhzXG4gICAgcmVmcmVzaENvbXBvbmVudCh0YXJnZXQsIG51bGwpXG4gICAgLy8gdGhpcy5uYXRpdmVQYWdlRWxlbWVudCBpcyB1cGRhdGVkIGluIGFmdGVyTW91bnQsIHRyaWdnZXJlZCBieSBwcm94eSAvIGhvb2tzXG4gICAgY29uc3QgbmV3UGFnZUVsZW1lbnQgPSB0aGlzLm5hdGl2ZVBhZ2VFbGVtZW50XG4gICAgLy8gdXBkYXRlIGV2ZW50IHByb3h5XG4gICAgb2xkTmF0aXZlVmlldy5vZmYoJ25hdmlnYXRlZEZyb20nLCByZWxheU5hdGl2ZU5hdmlnYXRlZEZyb20pXG4gICAgbmF0aXZlUGFnZUVsZW1lbnQubmF0aXZlVmlldy5vbignbmF2aWdhdGVkRnJvbScsIHJlbGF5TmF0aXZlTmF2aWdhdGVkRnJvbSlcbiAgICByZXR1cm4gbmV3UGFnZUVsZW1lbnRcbiAgfVxuXG4gIHJlbGF5TmF0aXZlTmF2aWdhdGVkRnJvbSh7IGlzQmFja05hdmlnYXRpb24gfSkge1xuICAgIGNvbnN0IHsgb3JpZ2luYWxOYXRpdmVWaWV3LCBuYXZpZ2F0ZWRGcm9tSGFuZGxlciB9ID0gdGhpc1xuICAgIGlmICghaXNCYWNrTmF2aWdhdGlvbikge1xuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGlmIChvcmlnaW5hbE5hdGl2ZVZpZXcpIHtcbiAgICAgIGNvbnN0IHsgb2ZmIH0gPSBvcmlnaW5hbE5hdGl2ZVZpZXdcbiAgICAgIGNvbnN0IG93bk9mZiA9IG9yaWdpbmFsTmF0aXZlVmlldy5oYXNPd25Qcm9wZXJ0eSgnb2ZmJylcbiAgICAgIG9yaWdpbmFsTmF0aXZlVmlldy5vZmYgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5uYXZpZ2F0ZWRGcm9tSGFuZGxlciA9IG51bGxcbiAgICAgICAgaWYgKG93bk9mZikge1xuICAgICAgICAgIG9yaWdpbmFsTmF0aXZlVmlldy5vZmYgPSBvZmZcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBkZWxldGUgb3JpZ2luYWxOYXRpdmVWaWV3Lm9mZlxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChuYXZpZ2F0ZWRGcm9tSGFuZGxlcikge1xuICAgICAgcmV0dXJuIG5hdmlnYXRlZEZyb21IYW5kbGVyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cylcbiAgICB9XG4gIH1cblxuICByZW5kZXJFcnJvcihlcnIsIHRhcmdldCwgYW5jaG9yKSB7XG4gICAgLy8gVE9ETyBmYWxsYmFjayBvbiBUTlMgZXJyb3IgaGFuZGxlciBmb3Igbm93Li4uIGF0IGxlYXN0IG91ciBlcnJvclxuICAgIC8vIGlzIG1vcmUgaW5mb3JtYXRpdmVcbiAgICB0aHJvdyBlcnJcbiAgfVxufVxuIiwiaW1wb3J0IHsgU3ZlbHRlQ29tcG9uZW50LCBpbml0LCBzYWZlX25vdF9lcXVhbCwgY3JlYXRlX3Nsb3QsIGdldF9zbG90X2NvbnRleHQsIGdldF9zbG90X2NoYW5nZXMsIHRyYW5zaXRpb25faW4sIHRyYW5zaXRpb25fb3V0LCBhc3NpZ24sIGV4Y2x1ZGVfaW50ZXJuYWxfcHJvcHMsIGJpbmRpbmdfY2FsbGJhY2tzLCBiaW5kLCBzcGFjZSwgY3JlYXRlX2NvbXBvbmVudCwgc2V0X2F0dHJpYnV0ZXMsIGluc2VydCwgbW91bnRfY29tcG9uZW50LCBnZXRfc3ByZWFkX3VwZGF0ZSwgYWRkX2ZsdXNoX2NhbGxiYWNrLCBkZXRhY2gsIGRlc3Ryb3lfY29tcG9uZW50IH0gZnJvbSAnc3ZlbHRlL2ludGVybmFsJztcblxuLyogc3JjXFxjb21wb25lbnRzXFxTbG90Q29tcG9uZW50LnN2ZWx0ZSBnZW5lcmF0ZWQgYnkgU3ZlbHRlIHYzLjE2LjQgKi9cblxuY29uc3QgZ2V0X2RlZmF1bHRfc2xvdF9jaGFuZ2VzID0gZGlydHkgPT4gKHsgcHJvcHM6IGRpcnR5WzBdICYgLypwKi8gMSB9KTtcbmNvbnN0IGdldF9kZWZhdWx0X3Nsb3RfY29udGV4dCA9IGN0eCA9PiAoeyBwcm9wczogLypwKi8gY3R4WzBdIH0pO1xuXG5mdW5jdGlvbiBjcmVhdGVfZnJhZ21lbnQoY3R4KSB7XG5cdGxldCBjdXJyZW50O1xuXHRjb25zdCBkZWZhdWx0X3Nsb3RfdGVtcGxhdGUgPSAvKiQkc2xvdHMqLyBjdHhbM10uZGVmYXVsdDtcblx0Y29uc3QgZGVmYXVsdF9zbG90ID0gY3JlYXRlX3Nsb3QoZGVmYXVsdF9zbG90X3RlbXBsYXRlLCBjdHgsIC8qJCRzY29wZSovIGN0eFsyXSwgZ2V0X2RlZmF1bHRfc2xvdF9jb250ZXh0KTtcblxuXHRyZXR1cm4ge1xuXHRcdGMoKSB7XG5cdFx0XHRpZiAoZGVmYXVsdF9zbG90KSBkZWZhdWx0X3Nsb3QuYygpO1xuXHRcdH0sXG5cdFx0bSh0YXJnZXQsIGFuY2hvcikge1xuXHRcdFx0aWYgKGRlZmF1bHRfc2xvdCkge1xuXHRcdFx0XHRkZWZhdWx0X3Nsb3QubSh0YXJnZXQsIGFuY2hvcik7XG5cdFx0XHR9XG5cblx0XHRcdGN1cnJlbnQgPSB0cnVlO1xuXHRcdH0sXG5cdFx0cChjdHgsIGRpcnR5KSB7XG5cdFx0XHRpZiAoZGVmYXVsdF9zbG90ICYmIGRlZmF1bHRfc2xvdC5wICYmIGRpcnR5WzBdICYgLyokJHNjb3BlLCBwKi8gNSkge1xuXHRcdFx0XHRkZWZhdWx0X3Nsb3QucChnZXRfc2xvdF9jb250ZXh0KGRlZmF1bHRfc2xvdF90ZW1wbGF0ZSwgY3R4LCAvKiQkc2NvcGUqLyBjdHhbMl0sIGdldF9kZWZhdWx0X3Nsb3RfY29udGV4dCksIGdldF9zbG90X2NoYW5nZXMoZGVmYXVsdF9zbG90X3RlbXBsYXRlLCAvKiQkc2NvcGUqLyBjdHhbMl0sIGRpcnR5LCBnZXRfZGVmYXVsdF9zbG90X2NoYW5nZXMpKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdGkobG9jYWwpIHtcblx0XHRcdGlmIChjdXJyZW50KSByZXR1cm47XG5cdFx0XHR0cmFuc2l0aW9uX2luKGRlZmF1bHRfc2xvdCwgbG9jYWwpO1xuXHRcdFx0Y3VycmVudCA9IHRydWU7XG5cdFx0fSxcblx0XHRvKGxvY2FsKSB7XG5cdFx0XHR0cmFuc2l0aW9uX291dChkZWZhdWx0X3Nsb3QsIGxvY2FsKTtcblx0XHRcdGN1cnJlbnQgPSBmYWxzZTtcblx0XHR9LFxuXHRcdGQoZGV0YWNoaW5nKSB7XG5cdFx0XHRpZiAoZGVmYXVsdF9zbG90KSBkZWZhdWx0X3Nsb3QuZChkZXRhY2hpbmcpO1xuXHRcdH1cblx0fTtcbn1cblxuZnVuY3Rpb24gaW5zdGFuY2UoJCRzZWxmLCAkJHByb3BzLCAkJGludmFsaWRhdGUpIHtcblx0bGV0IHsgJCRzbG90cyA9IHt9LCAkJHNjb3BlIH0gPSAkJHByb3BzO1xuXG5cdCQkc2VsZi4kc2V0ID0gJCRuZXdfcHJvcHMgPT4ge1xuXHRcdCQkaW52YWxpZGF0ZSgxLCAkJHByb3BzID0gYXNzaWduKGFzc2lnbih7fSwgJCRwcm9wcyksIGV4Y2x1ZGVfaW50ZXJuYWxfcHJvcHMoJCRuZXdfcHJvcHMpKSk7XG5cdFx0aWYgKFwiJCRzY29wZVwiIGluICQkbmV3X3Byb3BzKSAkJGludmFsaWRhdGUoMiwgJCRzY29wZSA9ICQkbmV3X3Byb3BzLiQkc2NvcGUpO1xuXHR9O1xuXG5cdGxldCBwO1xuXG5cdCQkc2VsZi4kJC51cGRhdGUgPSAoKSA9PiB7XG5cdFx0ICQkaW52YWxpZGF0ZSgwLCBwID0gJCRwcm9wcyk7XG5cdH07XG5cblx0JCRwcm9wcyA9IGV4Y2x1ZGVfaW50ZXJuYWxfcHJvcHMoJCRwcm9wcyk7XG5cdHJldHVybiBbcCwgJCRwcm9wcywgJCRzY29wZSwgJCRzbG90c107XG59XG5cbmNsYXNzIFNsb3RDb21wb25lbnQgZXh0ZW5kcyBTdmVsdGVDb21wb25lbnQge1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHRpbml0KHRoaXMsIG9wdGlvbnMsIGluc3RhbmNlLCBjcmVhdGVfZnJhZ21lbnQsIHNhZmVfbm90X2VxdWFsLCB7fSk7XG5cdH1cbn1cblxuLyogc3JjXFxjb21wb25lbnRzXFxBc0NvbXBvbmVudC5zdmVsdGUgZ2VuZXJhdGVkIGJ5IFN2ZWx0ZSB2My4xNi40ICovXG5cbmZ1bmN0aW9uIGluc3RhbmNlJDEoJCRzZWxmLCAkJHByb3BzLCAkJGludmFsaWRhdGUpIHtcblx0bGV0IHNsb3RzID0gJCRwcm9wcy4kJHNsb3RzO1xuXHRsZXQgc2NvcGUgPSAkJHByb3BzLiQkc2NvcGU7XG5cblx0Y29uc3QgY29tcG9uZW50ID0gY2xhc3MgZXh0ZW5kcyBTbG90Q29tcG9uZW50IHtcblx0XHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0XHRsZXQgbmV3X29wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zKTtcblx0XHRcdG5ld19vcHRpb25zLnByb3BzID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucy5wcm9wcywgeyAkJHNsb3RzOiBzbG90cywgJCRzY29wZTogc2NvcGUgfSk7XG5cdFx0XHRzdXBlcihuZXdfb3B0aW9ucyk7XG5cdFx0fVxuXHR9O1xuXG5cdCQkc2VsZi4kc2V0ID0gJCRuZXdfcHJvcHMgPT4ge1xuXHRcdCQkaW52YWxpZGF0ZSgzLCAkJHByb3BzID0gYXNzaWduKGFzc2lnbih7fSwgJCRwcm9wcyksIGV4Y2x1ZGVfaW50ZXJuYWxfcHJvcHMoJCRuZXdfcHJvcHMpKSk7XG5cdH07XG5cblx0JCRwcm9wcyA9IGV4Y2x1ZGVfaW50ZXJuYWxfcHJvcHMoJCRwcm9wcyk7XG5cdHJldHVybiBbY29tcG9uZW50XTtcbn1cblxuY2xhc3MgQXNDb21wb25lbnQgZXh0ZW5kcyBTdmVsdGVDb21wb25lbnQge1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHRpbml0KHRoaXMsIG9wdGlvbnMsIGluc3RhbmNlJDEsIG51bGwsIHNhZmVfbm90X2VxdWFsLCB7IGNvbXBvbmVudDogMCB9KTtcblx0fVxuXG5cdGdldCBjb21wb25lbnQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuJCQuY3R4WzBdO1xuXHR9XG59XG5cbi8qIHNyY1xcY29tcG9uZW50c1xcVGVtcGxhdGUuc3ZlbHRlIGdlbmVyYXRlZCBieSBTdmVsdGUgdjMuMTYuNCAqL1xuY29uc3QgZ2V0X2RlZmF1bHRfc2xvdF9jaGFuZ2VzJDEgPSBkaXJ0eSA9PiAoeyBpdGVtOiBkaXJ0eVswXSAmIC8qcHJvcHMqLyAzMiB9KTtcblxuY29uc3QgZ2V0X2RlZmF1bHRfc2xvdF9jb250ZXh0JDEgPSBjdHggPT4gKHtcblx0aXRlbTogLypwcm9wcyovIGN0eFs1XSA/IC8qcHJvcHMqLyBjdHhbNV0uaXRlbSA6IG51bGxcbn0pO1xuXG4vLyAoMjowKSA8QXNDb21wb25lbnQgYmluZDpjb21wb25lbnQ9XCJ7dGVtcGxhdGV9XCIgbGV0OnByb3BzPlxuZnVuY3Rpb24gY3JlYXRlX2RlZmF1bHRfc2xvdChjdHgpIHtcblx0bGV0IGN1cnJlbnQ7XG5cdGNvbnN0IGRlZmF1bHRfc2xvdF90ZW1wbGF0ZSA9IC8qJCRzbG90cyovIGN0eFsyXS5kZWZhdWx0O1xuXHRjb25zdCBkZWZhdWx0X3Nsb3QgPSBjcmVhdGVfc2xvdChkZWZhdWx0X3Nsb3RfdGVtcGxhdGUsIGN0eCwgLyokJHNjb3BlKi8gY3R4WzRdLCBnZXRfZGVmYXVsdF9zbG90X2NvbnRleHQkMSk7XG5cblx0cmV0dXJuIHtcblx0XHRjKCkge1xuXHRcdFx0aWYgKGRlZmF1bHRfc2xvdCkgZGVmYXVsdF9zbG90LmMoKTtcblx0XHR9LFxuXHRcdG0odGFyZ2V0LCBhbmNob3IpIHtcblx0XHRcdGlmIChkZWZhdWx0X3Nsb3QpIHtcblx0XHRcdFx0ZGVmYXVsdF9zbG90Lm0odGFyZ2V0LCBhbmNob3IpO1xuXHRcdFx0fVxuXG5cdFx0XHRjdXJyZW50ID0gdHJ1ZTtcblx0XHR9LFxuXHRcdHAoY3R4LCBkaXJ0eSkge1xuXHRcdFx0aWYgKGRlZmF1bHRfc2xvdCAmJiBkZWZhdWx0X3Nsb3QucCAmJiBkaXJ0eVswXSAmIC8qJCRzY29wZSwgcHJvcHMqLyA0OCkge1xuXHRcdFx0XHRkZWZhdWx0X3Nsb3QucChnZXRfc2xvdF9jb250ZXh0KGRlZmF1bHRfc2xvdF90ZW1wbGF0ZSwgY3R4LCAvKiQkc2NvcGUqLyBjdHhbNF0sIGdldF9kZWZhdWx0X3Nsb3RfY29udGV4dCQxKSwgZ2V0X3Nsb3RfY2hhbmdlcyhkZWZhdWx0X3Nsb3RfdGVtcGxhdGUsIC8qJCRzY29wZSovIGN0eFs0XSwgZGlydHksIGdldF9kZWZhdWx0X3Nsb3RfY2hhbmdlcyQxKSk7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRpKGxvY2FsKSB7XG5cdFx0XHRpZiAoY3VycmVudCkgcmV0dXJuO1xuXHRcdFx0dHJhbnNpdGlvbl9pbihkZWZhdWx0X3Nsb3QsIGxvY2FsKTtcblx0XHRcdGN1cnJlbnQgPSB0cnVlO1xuXHRcdH0sXG5cdFx0byhsb2NhbCkge1xuXHRcdFx0dHJhbnNpdGlvbl9vdXQoZGVmYXVsdF9zbG90LCBsb2NhbCk7XG5cdFx0XHRjdXJyZW50ID0gZmFsc2U7XG5cdFx0fSxcblx0XHRkKGRldGFjaGluZykge1xuXHRcdFx0aWYgKGRlZmF1bHRfc2xvdCkgZGVmYXVsdF9zbG90LmQoZGV0YWNoaW5nKTtcblx0XHR9XG5cdH07XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZV9mcmFnbWVudCQxKGN0eCkge1xuXHRsZXQgdGVtcGxhdGVfMTtcblx0bGV0IHQ7XG5cdGxldCB1cGRhdGluZ19jb21wb25lbnQ7XG5cdGxldCBjdXJyZW50O1xuXHRsZXQgdGVtcGxhdGVfMV9sZXZlbHMgPSBbLyokJHByb3BzKi8gY3R4WzFdLCB7IGNvbXBvbmVudDogLyp0ZW1wbGF0ZSovIGN0eFswXSB9LCB7IHhtbG5zOiBcInRuc1wiIH1dO1xuXHRsZXQgdGVtcGxhdGVfMV9kYXRhID0ge307XG5cblx0Zm9yIChsZXQgaSA9IDA7IGkgPCB0ZW1wbGF0ZV8xX2xldmVscy5sZW5ndGg7IGkgKz0gMSkge1xuXHRcdHRlbXBsYXRlXzFfZGF0YSA9IGFzc2lnbih0ZW1wbGF0ZV8xX2RhdGEsIHRlbXBsYXRlXzFfbGV2ZWxzW2ldKTtcblx0fVxuXG5cdGZ1bmN0aW9uIGFzY29tcG9uZW50X2NvbXBvbmVudF9iaW5kaW5nKHZhbHVlKSB7XG5cdFx0Lyphc2NvbXBvbmVudF9jb21wb25lbnRfYmluZGluZyovIGN0eFszXS5jYWxsKG51bGwsIHZhbHVlKTtcblx0fVxuXG5cdGxldCBhc2NvbXBvbmVudF9wcm9wcyA9IHtcblx0XHQkJHNsb3RzOiB7XG5cdFx0XHRkZWZhdWx0OiBbXG5cdFx0XHRcdGNyZWF0ZV9kZWZhdWx0X3Nsb3QsXG5cdFx0XHRcdCh7IHByb3BzIH0pID0+ICh7IDU6IHByb3BzIH0pLFxuXHRcdFx0XHQoeyBwcm9wcyB9KSA9PiBbcHJvcHMgPyAzMiA6IDBdXG5cdFx0XHRdXG5cdFx0fSxcblx0XHQkJHNjb3BlOiB7IGN0eCB9XG5cdH07XG5cblx0aWYgKC8qdGVtcGxhdGUqLyBjdHhbMF0gIT09IHZvaWQgMCkge1xuXHRcdGFzY29tcG9uZW50X3Byb3BzLmNvbXBvbmVudCA9IC8qdGVtcGxhdGUqLyBjdHhbMF07XG5cdH1cblxuXHRjb25zdCBhc2NvbXBvbmVudCA9IG5ldyBBc0NvbXBvbmVudCh7IHByb3BzOiBhc2NvbXBvbmVudF9wcm9wcyB9KTtcblx0YmluZGluZ19jYWxsYmFja3MucHVzaCgoKSA9PiBiaW5kKGFzY29tcG9uZW50LCBcImNvbXBvbmVudFwiLCBhc2NvbXBvbmVudF9jb21wb25lbnRfYmluZGluZykpO1xuXG5cdHJldHVybiB7XG5cdFx0YygpIHtcblx0XHRcdHRlbXBsYXRlXzEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoXCJ0bnNcIiwgXCJ0ZW1wbGF0ZVwiKTtcblx0XHRcdHQgPSBzcGFjZSgpO1xuXHRcdFx0Y3JlYXRlX2NvbXBvbmVudChhc2NvbXBvbmVudC4kJC5mcmFnbWVudCk7XG5cdFx0XHRzZXRfYXR0cmlidXRlcyh0ZW1wbGF0ZV8xLCB0ZW1wbGF0ZV8xX2RhdGEpO1xuXHRcdH0sXG5cdFx0bSh0YXJnZXQsIGFuY2hvcikge1xuXHRcdFx0aW5zZXJ0KHRhcmdldCwgdGVtcGxhdGVfMSwgYW5jaG9yKTtcblx0XHRcdGluc2VydCh0YXJnZXQsIHQsIGFuY2hvcik7XG5cdFx0XHRtb3VudF9jb21wb25lbnQoYXNjb21wb25lbnQsIHRhcmdldCwgYW5jaG9yKTtcblx0XHRcdGN1cnJlbnQgPSB0cnVlO1xuXHRcdH0sXG5cdFx0cChjdHgsIGRpcnR5KSB7XG5cdFx0XHRzZXRfYXR0cmlidXRlcyh0ZW1wbGF0ZV8xLCBnZXRfc3ByZWFkX3VwZGF0ZSh0ZW1wbGF0ZV8xX2xldmVscywgW1xuXHRcdFx0XHRkaXJ0eVswXSAmIC8qJCRwcm9wcyovIDIgJiYgLyokJHByb3BzKi8gY3R4WzFdLFxuXHRcdFx0XHRkaXJ0eVswXSAmIC8qdGVtcGxhdGUqLyAxICYmICh7IGNvbXBvbmVudDogLyp0ZW1wbGF0ZSovIGN0eFswXSB9KSxcblx0XHRcdFx0eyB4bWxuczogXCJ0bnNcIiB9XG5cdFx0XHRdKSk7XG5cblx0XHRcdGNvbnN0IGFzY29tcG9uZW50X2NoYW5nZXMgPSB7fTtcblxuXHRcdFx0aWYgKGRpcnR5WzBdICYgLyokJHNjb3BlLCBwcm9wcyovIDQ4KSB7XG5cdFx0XHRcdGFzY29tcG9uZW50X2NoYW5nZXMuJCRzY29wZSA9IHsgZGlydHksIGN0eCB9O1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAoIXVwZGF0aW5nX2NvbXBvbmVudCAmJiBkaXJ0eVswXSAmIC8qdGVtcGxhdGUqLyAxKSB7XG5cdFx0XHRcdHVwZGF0aW5nX2NvbXBvbmVudCA9IHRydWU7XG5cdFx0XHRcdGFzY29tcG9uZW50X2NoYW5nZXMuY29tcG9uZW50ID0gLyp0ZW1wbGF0ZSovIGN0eFswXTtcblx0XHRcdFx0YWRkX2ZsdXNoX2NhbGxiYWNrKCgpID0+IHVwZGF0aW5nX2NvbXBvbmVudCA9IGZhbHNlKTtcblx0XHRcdH1cblxuXHRcdFx0YXNjb21wb25lbnQuJHNldChhc2NvbXBvbmVudF9jaGFuZ2VzKTtcblx0XHR9LFxuXHRcdGkobG9jYWwpIHtcblx0XHRcdGlmIChjdXJyZW50KSByZXR1cm47XG5cdFx0XHR0cmFuc2l0aW9uX2luKGFzY29tcG9uZW50LiQkLmZyYWdtZW50LCBsb2NhbCk7XG5cdFx0XHRjdXJyZW50ID0gdHJ1ZTtcblx0XHR9LFxuXHRcdG8obG9jYWwpIHtcblx0XHRcdHRyYW5zaXRpb25fb3V0KGFzY29tcG9uZW50LiQkLmZyYWdtZW50LCBsb2NhbCk7XG5cdFx0XHRjdXJyZW50ID0gZmFsc2U7XG5cdFx0fSxcblx0XHRkKGRldGFjaGluZykge1xuXHRcdFx0aWYgKGRldGFjaGluZykgZGV0YWNoKHRlbXBsYXRlXzEpO1xuXHRcdFx0aWYgKGRldGFjaGluZykgZGV0YWNoKHQpO1xuXHRcdFx0ZGVzdHJveV9jb21wb25lbnQoYXNjb21wb25lbnQsIGRldGFjaGluZyk7XG5cdFx0fVxuXHR9O1xufVxuXG5mdW5jdGlvbiBpbnN0YW5jZSQyKCQkc2VsZiwgJCRwcm9wcywgJCRpbnZhbGlkYXRlKSB7XG5cdGxldCB0ZW1wbGF0ZTtcblx0bGV0IHsgJCRzbG90cyA9IHt9LCAkJHNjb3BlIH0gPSAkJHByb3BzO1xuXG5cdGZ1bmN0aW9uIGFzY29tcG9uZW50X2NvbXBvbmVudF9iaW5kaW5nKHZhbHVlKSB7XG5cdFx0dGVtcGxhdGUgPSB2YWx1ZTtcblx0XHQkJGludmFsaWRhdGUoMCwgdGVtcGxhdGUpO1xuXHR9XG5cblx0JCRzZWxmLiRzZXQgPSAkJG5ld19wcm9wcyA9PiB7XG5cdFx0JCRpbnZhbGlkYXRlKDEsICQkcHJvcHMgPSBhc3NpZ24oYXNzaWduKHt9LCAkJHByb3BzKSwgZXhjbHVkZV9pbnRlcm5hbF9wcm9wcygkJG5ld19wcm9wcykpKTtcblx0XHRpZiAoXCIkJHNjb3BlXCIgaW4gJCRuZXdfcHJvcHMpICQkaW52YWxpZGF0ZSg0LCAkJHNjb3BlID0gJCRuZXdfcHJvcHMuJCRzY29wZSk7XG5cdH07XG5cblx0JCRwcm9wcyA9IGV4Y2x1ZGVfaW50ZXJuYWxfcHJvcHMoJCRwcm9wcyk7XG5cdHJldHVybiBbdGVtcGxhdGUsICQkcHJvcHMsICQkc2xvdHMsIGFzY29tcG9uZW50X2NvbXBvbmVudF9iaW5kaW5nLCAkJHNjb3BlXTtcbn1cblxuY2xhc3MgVGVtcGxhdGUgZXh0ZW5kcyBTdmVsdGVDb21wb25lbnQge1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHRpbml0KHRoaXMsIG9wdGlvbnMsIGluc3RhbmNlJDIsIGNyZWF0ZV9mcmFnbWVudCQxLCBzYWZlX25vdF9lcXVhbCwge30pO1xuXHR9XG59XG5cbmV4cG9ydCB7IFRlbXBsYXRlIH07XG4iLCJpbXBvcnQgeyB0b3Btb3N0LCBGcmFtZSB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvZnJhbWUnO1xuaW1wb3J0IHsgYWRkQ3NzIH0gZnJvbSAndG5zLWNvcmUtbW9kdWxlcy9hcHBsaWNhdGlvbic7XG5pbXBvcnQgeyBpc0FuZHJvaWQsIGlzSU9TLCBDb250ZW50VmlldywgVmlldywgUGFnZSB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvcGFnZSc7XG5pbXBvcnQgeyBLZXlmcmFtZUFuaW1hdGlvbiB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvYW5pbWF0aW9uL2tleWZyYW1lLWFuaW1hdGlvbic7XG5pbXBvcnQgeyBDc3NBbmltYXRpb25QYXJzZXIgfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL3VpL3N0eWxpbmcvY3NzLWFuaW1hdGlvbi1wYXJzZXInO1xuaW1wb3J0IHsgTGF5b3V0QmFzZSB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvbGF5b3V0cy9sYXlvdXQtYmFzZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlQXJyYXkgfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL2RhdGEvb2JzZXJ2YWJsZS1hcnJheS9vYnNlcnZhYmxlLWFycmF5JztcbmltcG9ydCB7IExpc3RWaWV3IH0gZnJvbSAndG5zLWNvcmUtbW9kdWxlcy91aS9saXN0LXZpZXcnO1xuaW1wb3J0IHsgVGFiVmlldywgVGFiVmlld0l0ZW0gfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL3VpL3RhYi12aWV3JztcbmltcG9ydCB7IFRhYkNvbnRlbnRJdGVtIH0gZnJvbSAndG5zLWNvcmUtbW9kdWxlcy91aS90YWItbmF2aWdhdGlvbi1iYXNlL3RhYi1jb250ZW50LWl0ZW0nO1xuaW1wb3J0IHsgQm90dG9tTmF2aWdhdGlvbiB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvYm90dG9tLW5hdmlnYXRpb24nO1xuaW1wb3J0IHsgVGFicyB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvdGFicyc7XG5pbXBvcnQgeyBBY3Rpb25CYXIgfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL3VpL2FjdGlvbi1iYXInO1xuaW1wb3J0IHsgVGFiU3RyaXAgfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL3VpL3RhYi1uYXZpZ2F0aW9uLWJhc2UvdGFiLXN0cmlwJztcbmltcG9ydCB7IFRhYlN0cmlwSXRlbSB9IGZyb20gJ3Rucy1jb3JlLW1vZHVsZXMvdWkvdGFiLW5hdmlnYXRpb24tYmFzZS90YWItc3RyaXAtaXRlbSc7XG5pbXBvcnQgeyBtZXNzYWdlVHlwZSwgd3JpdGUgfSBmcm9tICd0bnMtY29yZS1tb2R1bGVzL3RyYWNlJztcblxudmFyIExvZ0xldmVsO1xyXG4oZnVuY3Rpb24gKExvZ0xldmVsKSB7XHJcbiAgICBMb2dMZXZlbFtMb2dMZXZlbFtcIkRlYnVnXCJdID0gMF0gPSBcIkRlYnVnXCI7XHJcbiAgICBMb2dMZXZlbFtMb2dMZXZlbFtcIkluZm9cIl0gPSAxXSA9IFwiSW5mb1wiO1xyXG4gICAgTG9nTGV2ZWxbTG9nTGV2ZWxbXCJXYXJuXCJdID0gMl0gPSBcIldhcm5cIjtcclxuICAgIExvZ0xldmVsW0xvZ0xldmVsW1wiRXJyb3JcIl0gPSAzXSA9IFwiRXJyb3JcIjtcclxufSkoTG9nTGV2ZWwgfHwgKExvZ0xldmVsID0ge30pKTtcclxuY29uc3QgbnVsbExvZ2dlciA9ICgpID0+IHsgfTtcclxuY2xhc3MgTG9nZ2VyIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHRoaXMub25Mb2cgPSAoKSA9PiBudWxsTG9nZ2VyO1xyXG4gICAgfVxyXG4gICAgc2V0SGFuZGxlcihsb2dnZXIpIHtcclxuICAgICAgICB0aGlzLm9uTG9nID0gbG9nZ2VyIHx8IG51bGxMb2dnZXI7XHJcbiAgICB9XHJcbiAgICBkZWJ1ZyhtZXNzYWdlKSB7XHJcbiAgICAgICAgdGhpcy5vbkxvZyhtZXNzYWdlLCBMb2dMZXZlbC5EZWJ1Zyk7XHJcbiAgICB9XHJcbiAgICBpbmZvKG1lc3NhZ2UpIHtcclxuICAgICAgICB0aGlzLm9uTG9nKG1lc3NhZ2UsIExvZ0xldmVsLkluZm8pO1xyXG4gICAgfVxyXG4gICAgd2FybihtZXNzYWdlKSB7XHJcbiAgICAgICAgdGhpcy5vbkxvZyhtZXNzYWdlLCBMb2dMZXZlbC5XYXJuKTtcclxuICAgIH1cclxuICAgIGVycm9yKG1lc3NhZ2UpIHtcclxuICAgICAgICB0aGlzLm9uTG9nKG1lc3NhZ2UsIExvZ0xldmVsLkVycm9yKTtcclxuICAgIH1cclxufVxyXG5jb25zdCBsb2dnZXIgPSBuZXcgTG9nZ2VyKCk7XG5cbmNvbnN0IGRhc2hSZWdFeHAgPSAvLS9nO1xyXG5mdW5jdGlvbiBub3JtYWxpemVFbGVtZW50TmFtZShlbGVtZW50TmFtZSkge1xyXG4gICAgcmV0dXJuIGAke2VsZW1lbnROYW1lXHJcbiAgICAgICAgLnJlcGxhY2UoZGFzaFJlZ0V4cCwgJycpXHJcbiAgICAgICAgLnRvTG93ZXJDYXNlKCl9YDtcclxufVxyXG5mdW5jdGlvbiogZWxlbWVudEl0ZXJhdG9yKGVsKSB7XHJcbiAgICB5aWVsZCBlbDtcclxuICAgIGZvciAobGV0IGNoaWxkIG9mIGVsLmNoaWxkTm9kZXMpIHtcclxuICAgICAgICB5aWVsZCogZWxlbWVudEl0ZXJhdG9yKGNoaWxkKTtcclxuICAgIH1cclxufVxyXG5jbGFzcyBWaWV3Tm9kZSB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICB0aGlzLm5vZGVUeXBlID0gbnVsbDtcclxuICAgICAgICB0aGlzLl90YWdOYW1lID0gbnVsbDtcclxuICAgICAgICB0aGlzLnBhcmVudE5vZGUgPSBudWxsO1xyXG4gICAgICAgIHRoaXMuY2hpbGROb2RlcyA9IFtdO1xyXG4gICAgICAgIHRoaXMucHJldlNpYmxpbmcgPSBudWxsO1xyXG4gICAgICAgIHRoaXMubmV4dFNpYmxpbmcgPSBudWxsO1xyXG4gICAgICAgIHRoaXMuX293bmVyRG9jdW1lbnQgPSBudWxsO1xyXG4gICAgICAgIHRoaXMuX2F0dHJpYnV0ZXMgPSB7fTtcclxuICAgIH1cclxuICAgIGhhc0F0dHJpYnV0ZShuYW1lKSB7XHJcbiAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKHRoaXMuX2F0dHJpYnV0ZXMpLmluZGV4T2YobmFtZSkgPiAtMTtcclxuICAgIH1cclxuICAgIHJlbW92ZUF0dHJpYnV0ZShuYW1lKSB7XHJcbiAgICAgICAgZGVsZXRlIHRoaXMuX2F0dHJpYnV0ZXNbbmFtZV07XHJcbiAgICB9XHJcbiAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xyXG4gICAgdG9TdHJpbmcoKSB7XHJcbiAgICAgICAgcmV0dXJuIGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0oJHt0aGlzLnRhZ05hbWV9KWA7XHJcbiAgICB9XHJcbiAgICBzZXQgdGFnTmFtZShuYW1lKSB7XHJcbiAgICAgICAgdGhpcy5fdGFnTmFtZSA9IG5vcm1hbGl6ZUVsZW1lbnROYW1lKG5hbWUpO1xyXG4gICAgfVxyXG4gICAgZ2V0IHRhZ05hbWUoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX3RhZ05hbWU7XHJcbiAgICB9XHJcbiAgICBnZXQgZmlyc3RDaGlsZCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5jaGlsZE5vZGVzLmxlbmd0aCA/IHRoaXMuY2hpbGROb2Rlc1swXSA6IG51bGw7XHJcbiAgICB9XHJcbiAgICBnZXQgbGFzdENoaWxkKCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLmNoaWxkTm9kZXMubGVuZ3RoXHJcbiAgICAgICAgICAgID8gdGhpcy5jaGlsZE5vZGVzW3RoaXMuY2hpbGROb2Rlcy5sZW5ndGggLSAxXVxyXG4gICAgICAgICAgICA6IG51bGw7XHJcbiAgICB9XHJcbiAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xyXG4gICAgZ2V0IG93bmVyRG9jdW1lbnQoKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX293bmVyRG9jdW1lbnQpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX293bmVyRG9jdW1lbnQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGxldCBlbCA9IHRoaXM7XHJcbiAgICAgICAgd2hpbGUgKGVsICE9IG51bGwgJiYgZWwubm9kZVR5cGUgIT09IDkpIHtcclxuICAgICAgICAgICAgZWwgPSBlbC5wYXJlbnROb2RlO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gKHRoaXMuX293bmVyRG9jdW1lbnQgPSBlbCk7XHJcbiAgICB9XHJcbiAgICBnZXRBdHRyaWJ1dGUoa2V5KSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuX2F0dHJpYnV0ZXNba2V5XTtcclxuICAgIH1cclxuICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXHJcbiAgICBzZXRBdHRyaWJ1dGUoa2V5LCB2YWx1ZSkge1xyXG4gICAgICAgIHRoaXMuX2F0dHJpYnV0ZXNba2V5XSA9IHZhbHVlO1xyXG4gICAgfVxyXG4gICAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cclxuICAgIHNldFRleHQodGV4dCkge1xyXG4gICAgICAgIGxvZ2dlci5kZWJ1Zyhgc2V0VGV4dCAke3RoaXN9ICR7dGV4dH1gKTtcclxuICAgICAgICBpZiAodGhpcy5ub2RlVHlwZSA9PT0gMykge1xyXG4gICAgICAgICAgICB0aGlzLnBhcmVudE5vZGUuc2V0VGV4dCh0ZXh0KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0QXR0cmlidXRlKCd0ZXh0JywgdGV4dCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpIHsgfVxyXG4gICAgb25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKSB7IH1cclxuICAgIGluc2VydEJlZm9yZShjaGlsZE5vZGUsIHJlZmVyZW5jZU5vZGUpIHtcclxuICAgICAgICBsb2dnZXIuZGVidWcoYGluc2VydCBiZWZvcmUgJHt0aGlzfSAke2NoaWxkTm9kZX0gJHtyZWZlcmVuY2VOb2RlfWApO1xyXG4gICAgICAgIGlmICghY2hpbGROb2RlKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2FuJ3QgaW5zZXJ0IGNoaWxkLmApO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyBpbiBzb21lIHJhcmUgY2FzZXMgaW5zZXJ0QmVmb3JlIGlzIGNhbGxlZCB3aXRoIGEgbnVsbCByZWZlcmVuY2VOb2RlXHJcbiAgICAgICAgLy8gdGhpcyBtYWtlcyBzdXJlIHRoYXQgaXQgZ2V0J3MgYXBwZW5kZWQgYXMgdGhlIGxhc3QgY2hpbGRcclxuICAgICAgICBpZiAoIXJlZmVyZW5jZU5vZGUpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuYXBwZW5kQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHJlZmVyZW5jZU5vZGUucGFyZW50Tm9kZSAhPT0gdGhpcykge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENhbid0IGluc2VydCBjaGlsZCwgYmVjYXVzZSB0aGUgcmVmZXJlbmNlIG5vZGUgaGFzIGEgZGlmZmVyZW50IHBhcmVudC5gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZS5wYXJlbnROb2RlICYmIGNoaWxkTm9kZS5wYXJlbnROb2RlICE9PSB0aGlzKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2FuJ3QgaW5zZXJ0IGNoaWxkLCBiZWNhdXNlIGl0IGFscmVhZHkgaGFzIGEgZGlmZmVyZW50IHBhcmVudC5gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZS5wYXJlbnROb2RlID09PSB0aGlzKSA7XHJcbiAgICAgICAgbGV0IGluZGV4ID0gdGhpcy5jaGlsZE5vZGVzLmluZGV4T2YocmVmZXJlbmNlTm9kZSk7XHJcbiAgICAgICAgY2hpbGROb2RlLnBhcmVudE5vZGUgPSB0aGlzO1xyXG4gICAgICAgIGNoaWxkTm9kZS5uZXh0U2libGluZyA9IHJlZmVyZW5jZU5vZGU7XHJcbiAgICAgICAgY2hpbGROb2RlLnByZXZTaWJsaW5nID0gdGhpcy5jaGlsZE5vZGVzW2luZGV4IC0gMV07XHJcbiAgICAgICAgcmVmZXJlbmNlTm9kZS5wcmV2U2libGluZyA9IGNoaWxkTm9kZTtcclxuICAgICAgICB0aGlzLmNoaWxkTm9kZXMuc3BsaWNlKGluZGV4LCAwLCBjaGlsZE5vZGUpO1xyXG4gICAgICAgIHRoaXMub25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpO1xyXG4gICAgfVxyXG4gICAgYXBwZW5kQ2hpbGQoY2hpbGROb2RlKSB7XHJcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGBhcHBlbmQgY2hpbGQgJHt0aGlzfSAke2NoaWxkTm9kZX1gKTtcclxuICAgICAgICBpZiAoIWNoaWxkTm9kZSkge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENhbid0IGFwcGVuZCBjaGlsZC5gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZS5wYXJlbnROb2RlICYmIGNoaWxkTm9kZS5wYXJlbnROb2RlICE9PSB0aGlzKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2FuJ3QgYXBwZW5kIGNoaWxkLCBiZWNhdXNlIGl0IGFscmVhZHkgaGFzIGEgZGlmZmVyZW50IHBhcmVudC5gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZS5wYXJlbnROb2RlID09PSB0aGlzKSA7XHJcbiAgICAgICAgY2hpbGROb2RlLnBhcmVudE5vZGUgPSB0aGlzO1xyXG4gICAgICAgIGlmICh0aGlzLmxhc3RDaGlsZCkge1xyXG4gICAgICAgICAgICBjaGlsZE5vZGUucHJldlNpYmxpbmcgPSB0aGlzLmxhc3RDaGlsZDtcclxuICAgICAgICAgICAgdGhpcy5sYXN0Q2hpbGQubmV4dFNpYmxpbmcgPSBjaGlsZE5vZGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuY2hpbGROb2Rlcy5wdXNoKGNoaWxkTm9kZSk7XHJcbiAgICAgICAgdGhpcy5vbkluc2VydGVkQ2hpbGQoY2hpbGROb2RlLCB0aGlzLmNoaWxkTm9kZXMubGVuZ3RoIC0gMSk7XHJcbiAgICB9XHJcbiAgICByZW1vdmVDaGlsZChjaGlsZE5vZGUpIHtcclxuICAgICAgICBsb2dnZXIuZGVidWcoYHJlbW92ZSBjaGlsZCAke3RoaXN9ICR7Y2hpbGROb2RlfWApO1xyXG4gICAgICAgIGlmICghY2hpbGROb2RlKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2FuJ3QgcmVtb3ZlIGNoaWxkLmApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoIWNoaWxkTm9kZS5wYXJlbnROb2RlKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgQ2FuJ3QgcmVtb3ZlIGNoaWxkLCBiZWNhdXNlIGl0IGhhcyBubyBwYXJlbnQuYCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChjaGlsZE5vZGUucGFyZW50Tm9kZSAhPT0gdGhpcykge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYENhbid0IHJlbW92ZSBjaGlsZCwgYmVjYXVzZSBpdCBoYXMgYSBkaWZmZXJlbnQgcGFyZW50LmApO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjaGlsZE5vZGUucGFyZW50Tm9kZSA9IG51bGw7XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZS5wcmV2U2libGluZykge1xyXG4gICAgICAgICAgICBjaGlsZE5vZGUucHJldlNpYmxpbmcubmV4dFNpYmxpbmcgPSBjaGlsZE5vZGUubmV4dFNpYmxpbmc7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChjaGlsZE5vZGUubmV4dFNpYmxpbmcpIHtcclxuICAgICAgICAgICAgY2hpbGROb2RlLm5leHRTaWJsaW5nLnByZXZTaWJsaW5nID0gY2hpbGROb2RlLnByZXZTaWJsaW5nO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyByZXNldCB0aGUgcHJldlNpYmxpbmcgYW5kIG5leHRTaWJsaW5nLiBJZiBub3QsIGEga2VlcC1hbGl2ZWQgY29tcG9uZW50IHdpbGxcclxuICAgICAgICAvLyBzdGlsbCBoYXZlIGEgZmlsbGVkIG5leHRTaWJsaW5nIGF0dHJpYnV0ZSBzbyB2dWUgd2lsbCBub3RcclxuICAgICAgICAvLyBpbnNlcnQgdGhlIG5vZGUgYWdhaW4gdG8gdGhlIHBhcmVudC4gU2VlICMyMjBcclxuICAgICAgICBjaGlsZE5vZGUucHJldlNpYmxpbmcgPSBudWxsO1xyXG4gICAgICAgIGNoaWxkTm9kZS5uZXh0U2libGluZyA9IG51bGw7XHJcbiAgICAgICAgdGhpcy5jaGlsZE5vZGVzID0gdGhpcy5jaGlsZE5vZGVzLmZpbHRlcihub2RlID0+IG5vZGUgIT09IGNoaWxkTm9kZSk7XHJcbiAgICAgICAgdGhpcy5vblJlbW92ZWRDaGlsZChjaGlsZE5vZGUpO1xyXG4gICAgfVxyXG4gICAgZmlyc3RFbGVtZW50KCkge1xyXG4gICAgICAgIGZvciAodmFyIGNoaWxkIG9mIHRoaXMuY2hpbGROb2Rlcykge1xyXG4gICAgICAgICAgICBpZiAoY2hpbGQubm9kZVR5cGUgPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGNoaWxkO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG59XG5cbmNsYXNzIEVsZW1lbnROb2RlIGV4dGVuZHMgVmlld05vZGUge1xyXG4gICAgY29uc3RydWN0b3IodGFnTmFtZSkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy5ub2RlVHlwZSA9IDE7XHJcbiAgICAgICAgdGhpcy50YWdOYW1lID0gdGFnTmFtZTtcclxuICAgIH1cclxuICAgIGdldCBpZCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRBdHRyaWJ1dGUoJ2lkJyk7XHJcbiAgICB9XHJcbiAgICBzZXQgaWQodmFsdWUpIHtcclxuICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZSgnaWQnLCB2YWx1ZSk7XHJcbiAgICB9XHJcbiAgICBnZXQgY2xhc3NMaXN0KCkge1xyXG4gICAgICAgIGlmICghdGhpcy5fY2xhc3NMaXN0KSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGdldENsYXNzZXMgPSAoKSA9PiAodGhpcy5nZXRBdHRyaWJ1dGUoJ2NsYXNzJykgfHwgXCJcIikuc3BsaXQoL1xccysvKS5maWx0ZXIoKGspID0+IGsgIT0gXCJcIik7XHJcbiAgICAgICAgICAgIHRoaXMuX2NsYXNzTGlzdCA9IHtcclxuICAgICAgICAgICAgICAgIGFkZDogKC4uLmNsYXNzTmFtZXMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCBbLi4ubmV3IFNldChnZXRDbGFzc2VzKCkuY29uY2F0KGNsYXNzTmFtZXMpKV0uam9pbihcIiBcIikpO1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHJlbW92ZTogKC4uLmNsYXNzTmFtZXMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZSgnY2xhc3MnLCBnZXRDbGFzc2VzKCkuZmlsdGVyKChpKSA9PiBjbGFzc05hbWVzLmluZGV4T2YoaSkgPT0gLTEpLmpvaW4oXCIgXCIpKTtcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBnZXQgbGVuZ3RoKCkge1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBnZXRDbGFzc2VzKCkubGVuZ3RoO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gdGhpcy5fY2xhc3NMaXN0O1xyXG4gICAgfVxyXG4gICAgYXBwZW5kQ2hpbGQoY2hpbGROb2RlKSB7XHJcbiAgICAgICAgc3VwZXIuYXBwZW5kQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgICAgICBpZiAoY2hpbGROb2RlLm5vZGVUeXBlID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0VGV4dChjaGlsZE5vZGUudGV4dCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChjaGlsZE5vZGUubm9kZVR5cGUgPT09IDcpIHtcclxuICAgICAgICAgICAgY2hpbGROb2RlLnNldE9uTm9kZSh0aGlzKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBpbnNlcnRCZWZvcmUoY2hpbGROb2RlLCByZWZlcmVuY2VOb2RlKSB7XHJcbiAgICAgICAgc3VwZXIuaW5zZXJ0QmVmb3JlKGNoaWxkTm9kZSwgcmVmZXJlbmNlTm9kZSk7XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZS5ub2RlVHlwZSA9PT0gMykge1xyXG4gICAgICAgICAgICB0aGlzLnNldFRleHQoY2hpbGROb2RlLnRleHQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoY2hpbGROb2RlLm5vZGVUeXBlID09PSA3KSB7XHJcbiAgICAgICAgICAgIGNoaWxkTm9kZS5zZXRPbk5vZGUodGhpcyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmVtb3ZlQ2hpbGQoY2hpbGROb2RlKSB7XHJcbiAgICAgICAgc3VwZXIucmVtb3ZlQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgICAgICBpZiAoY2hpbGROb2RlLm5vZGVUeXBlID09PSAzKSB7XHJcbiAgICAgICAgICAgIHRoaXMuc2V0VGV4dCgnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChjaGlsZE5vZGUubm9kZVR5cGUgPT09IDcpIHtcclxuICAgICAgICAgICAgY2hpbGROb2RlLmNsZWFyT25Ob2RlKHRoaXMpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxuXG5jbGFzcyBDb21tZW50Tm9kZSBleHRlbmRzIEVsZW1lbnROb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKHRleHQpIHtcclxuICAgICAgICBzdXBlcignY29tbWVudCcpO1xyXG4gICAgICAgIHRoaXMubm9kZVR5cGUgPSA4O1xyXG4gICAgICAgIHRoaXMudGV4dCA9IHRleHQ7XHJcbiAgICB9XHJcbn1cblxuY2xhc3MgVGV4dE5vZGUgZXh0ZW5kcyBWaWV3Tm9kZSB7XHJcbiAgICBjb25zdHJ1Y3Rvcih0ZXh0KSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICB0aGlzLm5vZGVUeXBlID0gMztcclxuICAgICAgICB0aGlzLnRleHQgPSB0ZXh0O1xyXG4gICAgfVxyXG4gICAgc2V0VGV4dCh0ZXh0KSB7XHJcbiAgICAgICAgdGhpcy50ZXh0ID0gdGV4dDtcclxuICAgICAgICB0aGlzLnBhcmVudE5vZGUuc2V0VGV4dCh0ZXh0KTtcclxuICAgIH1cclxuICAgIHNldCBkYXRhKHRleHQpIHtcclxuICAgICAgICB0aGlzLnNldFRleHQodGV4dCk7XHJcbiAgICB9XHJcbiAgICBnZXQgZGF0YSgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy50ZXh0O1xyXG4gICAgfVxyXG59XG5cbmNsYXNzIFByb3BlcnR5Tm9kZSBleHRlbmRzIEVsZW1lbnROb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKHRhZ05hbWUsIHByb3BlcnR5TmFtZSkge1xyXG4gICAgICAgIHN1cGVyKGAke3RhZ05hbWV9LiR7cHJvcGVydHlOYW1lfWApO1xyXG4gICAgICAgIHRoaXMucHJvcGVydHlOYW1lID0gcHJvcGVydHlOYW1lO1xyXG4gICAgICAgIHRoaXMucHJvcGVydHlUYWdOYW1lID0gbm9ybWFsaXplRWxlbWVudE5hbWUodGFnTmFtZSk7XHJcbiAgICAgICAgdGhpcy5ub2RlVHlwZSA9IDc7IC8vcHJvY2Vzc2luZyBpbnN0cnVjdGlvblxyXG4gICAgfVxyXG4gICAgb25JbnNlcnRlZENoaWxkKCkge1xyXG4gICAgICAgIHRoaXMuc2V0T25Ob2RlKHRoaXMucGFyZW50Tm9kZSk7XHJcbiAgICB9XHJcbiAgICBvblJlbW92ZWRDaGlsZCgpIHtcclxuICAgICAgICB0aGlzLnNldE9uTm9kZSh0aGlzLnBhcmVudE5vZGUpO1xyXG4gICAgfVxyXG4gICAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cclxuICAgIHRvU3RyaW5nKCkge1xyXG4gICAgICAgIHJldHVybiBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9KCR7dGhpcy50YWdOYW1lfSwgJHt0aGlzLnByb3BlcnR5TmFtZX0pYDtcclxuICAgIH1cclxuICAgIHNldE9uTm9kZShwYXJlbnQpIHtcclxuICAgICAgICBpZiAocGFyZW50ICYmIChwYXJlbnQudGFnTmFtZSA9PT0gdGhpcy5wcm9wZXJ0eVRhZ05hbWUpKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGVsID0gdGhpcy5maXJzdEVsZW1lbnQoKTtcclxuICAgICAgICAgICAgcGFyZW50LnNldEF0dHJpYnV0ZSh0aGlzLnByb3BlcnR5TmFtZSwgZWwpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGNsZWFyT25Ob2RlKHBhcmVudCkge1xyXG4gICAgICAgIGlmIChwYXJlbnQgJiYgKHBhcmVudC50YWdOYW1lID09PSB0aGlzLnByb3BlcnR5VGFnTmFtZSkpIHtcclxuICAgICAgICAgICAgcGFyZW50LnNldEF0dHJpYnV0ZSh0aGlzLnByb3BlcnR5TmFtZSwgbnVsbCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XG5cbmNvbnN0IGVsZW1lbnRNYXAgPSB7fTtcclxuZnVuY3Rpb24gcmVnaXN0ZXJFbGVtZW50UmVzb2x2ZXIoZWxlbWVudE5hbWUsIGVudHJ5KSB7XHJcbiAgICBjb25zdCBub3JtYWxpemVkTmFtZSA9IG5vcm1hbGl6ZUVsZW1lbnROYW1lKGVsZW1lbnROYW1lKTtcclxuICAgIGlmIChlbGVtZW50TWFwW25vcm1hbGl6ZWROYW1lXSkge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgRWxlbWVudCBmb3IgJHtub3JtYWxpemVkTmFtZX0gYWxyZWFkeSByZWdpc3RlcmVkLmApO1xyXG4gICAgfVxyXG4gICAgZWxlbWVudE1hcFtub3JtYWxpemVkTmFtZV0gPSBlbnRyeTtcclxufVxyXG5mdW5jdGlvbiByZWdpc3RlckVsZW1lbnQoZWxlbWVudE5hbWUsIHJlc29sdmVyKSB7XHJcbiAgICByZWdpc3RlckVsZW1lbnRSZXNvbHZlcihlbGVtZW50TmFtZSwgeyByZXNvbHZlcjogcmVzb2x2ZXIgfSk7XHJcbn1cclxuZnVuY3Rpb24gY3JlYXRlRWxlbWVudChlbGVtZW50TmFtZSkge1xyXG4gICAgY29uc3Qgbm9ybWFsaXplZE5hbWUgPSBub3JtYWxpemVFbGVtZW50TmFtZShlbGVtZW50TmFtZSk7XHJcbiAgICBjb25zdCBlbGVtZW50RGVmaW5pdGlvbiA9IGVsZW1lbnRNYXBbbm9ybWFsaXplZE5hbWVdO1xyXG4gICAgaWYgKCFlbGVtZW50RGVmaW5pdGlvbikge1xyXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYE5vIGtub3duIGNvbXBvbmVudCBmb3IgZWxlbWVudCAke2VsZW1lbnROYW1lfS5gKTtcclxuICAgIH1cclxuICAgIHJldHVybiBlbGVtZW50RGVmaW5pdGlvbi5yZXNvbHZlcigpO1xyXG59XG5cbmNsYXNzIERvY3VtZW50Tm9kZSBleHRlbmRzIFZpZXdOb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy50YWdOYW1lID0gXCJkb2NOb2RlXCI7XHJcbiAgICAgICAgdGhpcy5ub2RlVHlwZSA9IDk7XHJcbiAgICB9XHJcbiAgICBjcmVhdGVDb21tZW50KHRleHQpIHtcclxuICAgICAgICByZXR1cm4gbmV3IENvbW1lbnROb2RlKHRleHQpO1xyXG4gICAgfVxyXG4gICAgY3JlYXRlUHJvcGVydHlOb2RlKHRhZ05hbWUsIHByb3BlcnR5TmFtZSkge1xyXG4gICAgICAgIHJldHVybiBuZXcgUHJvcGVydHlOb2RlKHRhZ05hbWUsIHByb3BlcnR5TmFtZSk7XHJcbiAgICB9XHJcbiAgICBjcmVhdGVFbGVtZW50KHRhZ05hbWUpIHtcclxuICAgICAgICBpZiAodGFnTmFtZS5pbmRleE9mKFwiLlwiKSA+PSAwKSB7XHJcbiAgICAgICAgICAgIGxldCBiaXRzID0gdGFnTmFtZS5zcGxpdChcIi5cIiwgMik7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmNyZWF0ZVByb3BlcnR5Tm9kZShiaXRzWzBdLCBiaXRzWzFdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIGNyZWF0ZUVsZW1lbnQodGFnTmFtZSk7XHJcbiAgICB9XHJcbiAgICBjcmVhdGVFbGVtZW50TlMobmFtZXNwYWNlLCB0YWdOYW1lKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlRWxlbWVudCh0YWdOYW1lKTtcclxuICAgIH1cclxuICAgIGNyZWF0ZVRleHROb2RlKHRleHQpIHtcclxuICAgICAgICByZXR1cm4gbmV3IFRleHROb2RlKHRleHQpO1xyXG4gICAgfVxyXG4gICAgZ2V0RWxlbWVudEJ5SWQoaWQpIHtcclxuICAgICAgICBmb3IgKGxldCBlbCBvZiBlbGVtZW50SXRlcmF0b3IodGhpcykpIHtcclxuICAgICAgICAgICAgaWYgKGVsLm5vZGVUeXBlID09PSAxICYmIGVsLmlkID09PSBpZClcclxuICAgICAgICAgICAgICAgIHJldHVybiBlbDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBkaXNwYXRjaEV2ZW50KGV2ZW50KSB7XHJcbiAgICAgICAgLy9TdmVsdGUgZGV2IGZpcmVzIHRoZXNlIGZvciB0b29sIHN1cHBvcnRcclxuICAgIH1cclxufVxuXG5jbGFzcyBTdHlsZVNoZWV0IHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHRoaXMuX3J1bGVzID0gW107XHJcbiAgICB9XHJcbiAgICAvLyBUaGUgY3NzIHJ1bGVzIGdlbmVyYXRlZCBieSBzdmVsdGUgaGF2ZSBhIGtleWZyYW1lIGV2ZXJ5IDE2IG1pbGxpc2Vjb25kcyBhbmQgYXJlIHF1aXRlIHNsb3cgdG8gY3JlYXRlIGFuZCBydW5cclxuICAgIC8vIHRoaXMgaXMgaGVyZSB0byBzdXBwb3J0IHRoZSBzaW1wbGUgYW5kIHNob3J0IG9uZXMsIGJ1dCBpZGVhbGx5IHdlIHdvdWxkIHByb21vdGUgb3VyIG93biB0cmFuc2l0aW9ucyBpbiBzdmVsdGUtbmF0aXZlL3RyYW5zaXRpb25zXHJcbiAgICAvLyB3aGljaCB3b3VsZCBkZWxlZ2F0ZSB0byB0aGUgbW9yZSBkaXJlY3QgbmF0aXZlc2NyaXB0IHdheSBvZiB3b3JraW5nLlxyXG4gICAgZGVsZXRlUnVsZShpbmRleCkge1xyXG4gICAgICAgIGxldCByZW1vdmVkID0gdGhpcy5fcnVsZXMuc3BsaWNlKGluZGV4LCAxKTtcclxuICAgICAgICBmb3IgKGxldCByIGluIHJlbW92ZWQpIHtcclxuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGByZW1vdmluZyB0cmFuc2l0aW9uIHJ1bGUgJHtyfWApO1xyXG4gICAgICAgICAgICAvLyBUdXJucyBvdXQgbmF0aXZlc2NyaXB0IGRvZXNuJ3Qgc3VwcG9ydCBcInJlbW92aW5nXCIgY3NzLlxyXG4gICAgICAgICAgICAvLyB0aGlzIGlzIHByZXR0eSBob3JyaWJsZSBidXQgYmV0dGVyIHRoYW4gYSBtZW1vcnkgbGVhay4gXHJcbiAgICAgICAgICAgIC8vIHNpbmNlIHRoaXMgY29kZSBpcyBjYWxsZWQgbWFpbmx5IGZvciBrZXlmcmFtZXMsIGFuZCBrZXlmcmFtZXMgZG9uJ3QgYWRkIG5ldyBzZWxlY3RvcnMgKHRoZXkganVzdCBlbmQgdXAgaW4gX2tleWZyYW1lcylcclxuICAgICAgICAgICAgLy8gd2UgY2FuIGFsbW9zdCByZW1vdmUgdGhlIHJ1bGVzIG91cnNlbHZlcy5cclxuICAgICAgICAgICAgaWYgKHIuc3RhcnRzV2l0aCgnQGtleWZyYW1lcycpKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBuYW1lID0gci5zcGxpdChcIiBcIilbMV07XHJcbiAgICAgICAgICAgICAgICBsZXQgZnJhbWUgPSB0b3Btb3N0KCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoZnJhbWUgJiYgZnJhbWUuX3N0eWxlU2NvcGUpIHtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgc2NvcGUgPSBmcmFtZS5fc3R5bGVTY29wZTtcclxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgc2NvcGUuX2tleWZyYW1lc1tuYW1lXTtcclxuICAgICAgICAgICAgICAgICAgICBzY29wZS5fY3NzID0gc2NvcGUuX2Nzcy5yZXBsYWNlKHIsIFwiXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgaW5zZXJ0UnVsZShydWxlLCBpbmRleCA9IDApIHtcclxuICAgICAgICBsb2dnZXIuZGVidWcoYEFkZGluZyB0cmFuc2l0aW9uIHJ1bGUgJHtydWxlfWApO1xyXG4gICAgICAgIGxldCBmcmFtZSA9IHRvcG1vc3QoKTtcclxuICAgICAgICBmcmFtZS5hZGRDc3MocnVsZSk7XHJcbiAgICAgICAgdGhpcy5fcnVsZXMuc3BsaWNlKGluZGV4LCAwLCBydWxlKTtcclxuICAgIH1cclxuICAgIGdldCBjc3NSdWxlcygpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fcnVsZXM7XHJcbiAgICB9XHJcbn1cclxuY2xhc3MgU3R5bGVFbGVtZW50IGV4dGVuZHMgRWxlbWVudE5vZGUge1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgc3VwZXIoJ3N0eWxlJyk7XHJcbiAgICAgICAgdGhpcy5fc2hlZXQgPSBuZXcgU3R5bGVTaGVldCgpO1xyXG4gICAgfVxyXG4gICAgZ2V0IHNoZWV0KCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9zaGVldDtcclxuICAgIH1cclxufVxuXG5jbGFzcyBIZWFkRWxlbWVudCBleHRlbmRzIEVsZW1lbnROb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCdoZWFkJyk7XHJcbiAgICB9XHJcbiAgICBvbkluc2VydGVkQ2hpbGQoY2hpbGROb2RlLCBhdEluZGV4KSB7XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZSBpbnN0YW5jZW9mIFN0eWxlRWxlbWVudCkge1xyXG4gICAgICAgICAgICBsZXQgY3NzID0gY2hpbGROb2RlLnRleHRDb250ZW50O1xyXG4gICAgICAgICAgICBsZXQgaWQgPSBjaGlsZE5vZGUuaWQ7XHJcbiAgICAgICAgICAgIGxldCBzdHlsZV9oYXNoID0gaWQucmVwbGFjZSgnLXN0eWxlJywgJycpO1xyXG4gICAgICAgICAgICAvL3N0eWxlIHJ1bGVzIGFyZSBvbmUgcGVyIGxpbmUgYXMgbG9uZyBhcyBlYWNoIHNlbGVjdG9yIGluIHRoZSBydWxlIGhhcyB0aGUgc3R5bGUgaGFzaCB3ZSBhcmUgYWxsIHNjb3BlZCBzdHlsZXMgYW5kIGNhbiBwYXNzIHRydWUgdG8gYWRkQ3NzXHJcbiAgICAgICAgICAgIGxldCBhbGxfc2NvcGVkID0gY3NzLnNwbGl0KFwiXFxuXCIpLmV2ZXJ5KHIgPT4gci5zcGxpdChcIixcIikuZXZlcnkoaSA9PiBpLmluZGV4T2Yoc3R5bGVfaGFzaCkgPj0gMCkpO1xyXG4gICAgICAgICAgICBpZiAoY3NzKSB7XHJcbiAgICAgICAgICAgICAgICBhZGRDc3MoY3NzLCBhbGxfc2NvcGVkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxuXG5jbGFzcyBUZW1wbGF0ZUVsZW1lbnQgZXh0ZW5kcyBFbGVtZW50Tm9kZSB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcigndGVtcGxhdGUnKTtcclxuICAgIH1cclxuICAgIHNldCBjb21wb25lbnQodmFsdWUpIHtcclxuICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZSgnY29tcG9uZW50JywgdmFsdWUpO1xyXG4gICAgfVxyXG4gICAgZ2V0IGNvbXBvbmVudCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5nZXRBdHRyaWJ1dGUoJ2NvbXBvbmVudCcpO1xyXG4gICAgfVxyXG59XG5cbi8vIERvbSBlbGVtZW50cyB0aGF0IHN2ZWx0ZSBleHBlY3RzIHRvIGJlIGFibGUgdG8gY3JlYXRlIG9yIHVzZS5cclxuLy8gb3IgY3VzdG9tIGFkZGl0aW9ucyB0byBtYWtlIGxpZmUgZWFzaWVyXHJcbmZ1bmN0aW9uIHJlZ2lzdGVyU3ZlbHRlRWxlbWVudHMoKSB7XHJcbiAgICByZWdpc3RlckVsZW1lbnQoJ2hlYWQnLCAoKSA9PiBuZXcgSGVhZEVsZW1lbnQoKSk7XHJcbiAgICByZWdpc3RlckVsZW1lbnQoJ3N0eWxlJywgKCkgPT4gbmV3IFN0eWxlRWxlbWVudCgpKTtcclxuICAgIHJlZ2lzdGVyRWxlbWVudCgnZnJhZ21lbnQnLCAoKSA9PiBuZXcgRWxlbWVudE5vZGUoJ2ZyYWdtZW50JykpO1xyXG4gICAgcmVnaXN0ZXJFbGVtZW50KCd0ZW1wbGF0ZScsICgpID0+IG5ldyBUZW1wbGF0ZUVsZW1lbnQoKSk7XHJcbn1cblxudmFyIE5hdGl2ZUVsZW1lbnRQcm9wVHlwZTtcclxuKGZ1bmN0aW9uIChOYXRpdmVFbGVtZW50UHJvcFR5cGUpIHtcclxuICAgIE5hdGl2ZUVsZW1lbnRQcm9wVHlwZVtOYXRpdmVFbGVtZW50UHJvcFR5cGVbXCJWYWx1ZVwiXSA9IDBdID0gXCJWYWx1ZVwiO1xyXG4gICAgTmF0aXZlRWxlbWVudFByb3BUeXBlW05hdGl2ZUVsZW1lbnRQcm9wVHlwZVtcIkFycmF5XCJdID0gMV0gPSBcIkFycmF5XCI7XHJcbiAgICBOYXRpdmVFbGVtZW50UHJvcFR5cGVbTmF0aXZlRWxlbWVudFByb3BUeXBlW1wiT2JzZXJ2YWJsZUFycmF5XCJdID0gMl0gPSBcIk9ic2VydmFibGVBcnJheVwiO1xyXG59KShOYXRpdmVFbGVtZW50UHJvcFR5cGUgfHwgKE5hdGl2ZUVsZW1lbnRQcm9wVHlwZSA9IHt9KSk7XHJcbmZ1bmN0aW9uIHNldE9uQXJyYXlQcm9wKHBhcmVudCwgdmFsdWUsIHByb3BOYW1lLCBidWlsZCA9IG51bGwpIHtcclxuICAgIGxldCBjdXJyZW50ID0gcGFyZW50W3Byb3BOYW1lXTtcclxuICAgIGlmICghY3VycmVudCB8fCAhY3VycmVudC5wdXNoKSB7XHJcbiAgICAgICAgcGFyZW50W3Byb3BOYW1lXSA9IGJ1aWxkID8gYnVpbGQodmFsdWUpIDogW3ZhbHVlXTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICAgIGN1cnJlbnQucHVzaCh2YWx1ZSk7XHJcbiAgICB9XHJcbn1cclxuZnVuY3Rpb24gcmVtb3ZlRnJvbUFycmF5UHJvcChwYXJlbnQsIHZhbHVlLCBwcm9wTmFtZSkge1xyXG4gICAgbGV0IGN1cnJlbnQgPSBwYXJlbnRbcHJvcE5hbWVdO1xyXG4gICAgaWYgKCFjdXJyZW50IHx8ICFjdXJyZW50LnNwbGljZSkge1xyXG4gICAgICAgIGxldCBpZHggPSBjdXJyZW50LmluZGV4T2YodmFsdWUpO1xyXG4gICAgICAgIGlmIChpZHggPj0gMClcclxuICAgICAgICAgICAgY3VycmVudC5zcGxpY2UoaWR4LCAxKTtcclxuICAgIH1cclxufVxyXG5jb25zdCBfbm9ybWFsaXplZEtleXMgPSBuZXcgTWFwKCk7XHJcbmZ1bmN0aW9uIGdldE5vcm1hbGl6ZWRLZXlzRm9yT2JqZWN0KG9iaiwga25vd25Qcm9wTmFtZXMpIHtcclxuICAgIGxldCBwcm90byA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihvYmopO1xyXG4gICAgbGV0IG0gPSBfbm9ybWFsaXplZEtleXMuZ2V0KHByb3RvKTtcclxuICAgIGlmIChtKVxyXG4gICAgICAgIHJldHVybiBtO1xyXG4gICAgLy9jYWxjdWxhdGUgb3VyIHByb3AgbmFtZXNcclxuICAgIGxldCBwcm9wcyA9IG5ldyBNYXAoKTtcclxuICAgIF9ub3JtYWxpemVkS2V5cy5zZXQocHJvdG8sIHByb3BzKTtcclxuICAgIC8vaW5jbHVkZSBrbm93biBwcm9wc1xyXG4gICAga25vd25Qcm9wTmFtZXMuZm9yRWFjaChwID0+IHByb3BzLnNldChwLnRvTG93ZXJDYXNlKCksIHApKTtcclxuICAgIC8vaW5mZXIgdGhlIHJlc3QgZnJvbSB0aGUgcGFzc2VkIG9iamVjdCAoaW5jbHVkaW5nIHVwZGF0aW5nIGFueSBpbmNvcnJlY3Qga25vd24gcHJvcCBuYW1lcyBpZiBmb3VuZClcclxuICAgIGZvciAobGV0IHAgaW4gb2JqKSB7XHJcbiAgICAgICAgcHJvcHMuc2V0KHAudG9Mb3dlckNhc2UoKSwgcCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcHJvcHM7XHJcbn1cclxuZnVuY3Rpb24gbm9ybWFsaXplS2V5RnJvbU9iamVjdChvYmosIGtleSkge1xyXG4gICAgbGV0IGxvd2Vya2V5ID0ga2V5LnRvTG93ZXJDYXNlKCk7XHJcbiAgICBmb3IgKGxldCBwIGluIG9iaikge1xyXG4gICAgICAgIGlmIChwLnRvTG93ZXJDYXNlKCkgPT0gbG93ZXJrZXkpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGtleTtcclxufVxyXG4vLyBJbXBsZW1lbnRzIGFuIEVsZW1lbnROb2RlIHRoYXQgd3JhcHMgYSBOYXRpdmVTY3JpcHQgb2JqZWN0LiBJdCB1c2VzIHRoZSBvYmplY3QgYXMgdGhlIHNvdXJjZSBvZiB0cnV0aCBmb3IgaXRzIGF0dHJpYnV0ZXNcclxuY2xhc3MgTmF0aXZlRWxlbWVudE5vZGUgZXh0ZW5kcyBFbGVtZW50Tm9kZSB7XHJcbiAgICBjb25zdHJ1Y3Rvcih0YWdOYW1lLCBlbGVtZW50Q2xhc3MsIHNldHNQYXJlbnRQcm9wID0gbnVsbCwgcHJvcENvbmZpZyA9IHt9KSB7XHJcbiAgICAgICAgc3VwZXIodGFnTmFtZSk7XHJcbiAgICAgICAgdGhpcy5wcm9wQXR0cmlidXRlID0gbnVsbDtcclxuICAgICAgICB0aGlzLnByb3BDb25maWcgPSBwcm9wQ29uZmlnO1xyXG4gICAgICAgIHRoaXMucHJvcEF0dHJpYnV0ZSA9IHNldHNQYXJlbnRQcm9wO1xyXG4gICAgICAgIHRoaXMuX25hdGl2ZUVsZW1lbnQgPSBuZXcgZWxlbWVudENsYXNzKCk7XHJcbiAgICAgICAgdGhpcy5fbm9ybWFsaXplZEtleXMgPSBnZXROb3JtYWxpemVkS2V5c0Zvck9iamVjdCh0aGlzLl9uYXRpdmVFbGVtZW50LCBPYmplY3Qua2V5cyh0aGlzLnByb3BDb25maWcpKTtcclxuICAgICAgICB0aGlzLl9uYXRpdmVFbGVtZW50Ll9fU3ZlbHRlTmF0aXZlRWxlbWVudF9fID0gdGhpcztcclxuICAgICAgICBsb2dnZXIuZGVidWcoYGNyZWF0ZWQgJHt0aGlzfSAke3RoaXMuX25hdGl2ZUVsZW1lbnR9YCk7XHJcbiAgICB9XHJcbiAgICBnZXQgbmF0aXZlRWxlbWVudCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fbmF0aXZlRWxlbWVudDtcclxuICAgIH1cclxuICAgIHNldCBuYXRpdmVFbGVtZW50KGVsKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuX25hdGl2ZUVsZW1lbnQpIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDYW4ndCBvdmVyd3JpdGUgbmF0aXZlIGVsZW1lbnQuYCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuX25hdGl2ZUVsZW1lbnQgPSBlbDtcclxuICAgIH1cclxuICAgIGdldEF0dHJpYnV0ZShmdWxsa2V5KSB7XHJcbiAgICAgICAgbGV0IGdldFRhcmdldCA9IHRoaXMubmF0aXZlRWxlbWVudDtcclxuICAgICAgICBsZXQga2V5cGF0aCA9IGZ1bGxrZXkuc3BsaXQoXCIuXCIpO1xyXG4gICAgICAgIGxldCByZXNvbHZlZEtleXMgPSBbXTtcclxuICAgICAgICB3aGlsZSAoa2V5cGF0aC5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGlmICghZ2V0VGFyZ2V0KVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgICAgIGxldCBrZXkgPSBrZXlwYXRoLnNoaWZ0KCk7XHJcbiAgICAgICAgICAgIGlmIChyZXNvbHZlZEtleXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIGtleSA9IHRoaXMuX25vcm1hbGl6ZWRLZXlzLmdldChrZXkpIHx8IGtleTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGtleSA9IG5vcm1hbGl6ZUtleUZyb21PYmplY3QoZ2V0VGFyZ2V0LCBrZXkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc29sdmVkS2V5cy5wdXNoKGtleSk7XHJcbiAgICAgICAgICAgIGlmIChrZXlwYXRoLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIGdldFRhcmdldCA9IGdldFRhcmdldFtrZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIGdldFRhcmdldFtrZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gICAgb25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpIHtcclxuICAgICAgICBzdXBlci5vbkluc2VydGVkQ2hpbGQoY2hpbGROb2RlLCBpbmRleCk7XHJcbiAgICAgICAgLy8gc3VwcG9ydCBmb3IgdGhlIHByb3A6IHNob3J0aGFuZCBmb3Igc2V0dGluZyBwYXJlbnQgcHJvcGVydHkgdG8gbmF0aXZlIGVsZW1lbnRcclxuICAgICAgICBpZiAoIShjaGlsZE5vZGUgaW5zdGFuY2VvZiBOYXRpdmVFbGVtZW50Tm9kZSkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBsZXQgcHJvcE5hbWUgPSBjaGlsZE5vZGUucHJvcEF0dHJpYnV0ZTtcclxuICAgICAgICBpZiAoIXByb3BOYW1lKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgLy9TcGVjaWFsIGNhc2UgQXJyYXkgYW5kIE9ic2VydmFibGUgQXJyYXkga2V5c1xyXG4gICAgICAgIHByb3BOYW1lID0gdGhpcy5fbm9ybWFsaXplZEtleXMuZ2V0KHByb3BOYW1lKSB8fCBwcm9wTmFtZTtcclxuICAgICAgICBzd2l0Y2ggKHRoaXMucHJvcENvbmZpZ1twcm9wTmFtZV0pIHtcclxuICAgICAgICAgICAgY2FzZSBOYXRpdmVFbGVtZW50UHJvcFR5cGUuQXJyYXk6XHJcbiAgICAgICAgICAgICAgICBzZXRPbkFycmF5UHJvcCh0aGlzLm5hdGl2ZUVsZW1lbnQsIGNoaWxkTm9kZS5uYXRpdmVFbGVtZW50LCBwcm9wTmFtZSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIGNhc2UgTmF0aXZlRWxlbWVudFByb3BUeXBlLk9ic2VydmFibGVBcnJheTpcclxuICAgICAgICAgICAgICAgIHNldE9uQXJyYXlQcm9wKHRoaXMubmF0aXZlRWxlbWVudCwgY2hpbGROb2RlLm5hdGl2ZUVsZW1lbnQsIHByb3BOYW1lLCAodikgPT4gbmV3IE9ic2VydmFibGVBcnJheSh2KSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZShwcm9wTmFtZSwgY2hpbGROb2RlKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBvblJlbW92ZWRDaGlsZChjaGlsZE5vZGUpIHtcclxuICAgICAgICBpZiAoIShjaGlsZE5vZGUgaW5zdGFuY2VvZiBOYXRpdmVFbGVtZW50Tm9kZSkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICBsZXQgcHJvcE5hbWUgPSBjaGlsZE5vZGUucHJvcEF0dHJpYnV0ZTtcclxuICAgICAgICBpZiAoIXByb3BOYW1lKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgLy9TcGVjaWFsIGNhc2UgQXJyYXkgYW5kIE9ic2VydmFibGUgQXJyYXkga2V5c1xyXG4gICAgICAgIHByb3BOYW1lID0gdGhpcy5fbm9ybWFsaXplZEtleXMuZ2V0KHByb3BOYW1lKSB8fCBwcm9wTmFtZTtcclxuICAgICAgICBzd2l0Y2ggKHRoaXMucHJvcENvbmZpZ1twcm9wTmFtZV0pIHtcclxuICAgICAgICAgICAgY2FzZSBOYXRpdmVFbGVtZW50UHJvcFR5cGUuQXJyYXk6XHJcbiAgICAgICAgICAgIGNhc2UgTmF0aXZlRWxlbWVudFByb3BUeXBlLk9ic2VydmFibGVBcnJheTpcclxuICAgICAgICAgICAgICAgIHJlbW92ZUZyb21BcnJheVByb3AodGhpcy5uYXRpdmVFbGVtZW50LCBjaGlsZE5vZGUsIHByb3BOYW1lKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0QXR0cmlidXRlKHByb3BOYW1lLCBudWxsKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc3VwZXIub25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgIH1cclxuICAgIHNldEF0dHJpYnV0ZShmdWxsa2V5LCB2YWx1ZSkge1xyXG4gICAgICAgIGNvbnN0IG52ID0gdGhpcy5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCBzZXRUYXJnZXQgPSBudjtcclxuICAgICAgICAvLyBub3JtYWxpemUga2V5XHJcbiAgICAgICAgaWYgKGlzQW5kcm9pZCAmJiBmdWxsa2V5LnN0YXJ0c1dpdGgoJ2FuZHJvaWQ6JykpIHtcclxuICAgICAgICAgICAgZnVsbGtleSA9IGZ1bGxrZXkuc3Vic3RyKDgpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoaXNJT1MgJiYgZnVsbGtleS5zdGFydHNXaXRoKCdpb3M6JykpIHtcclxuICAgICAgICAgICAgZnVsbGtleSA9IGZ1bGxrZXkuc3Vic3RyKDQpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZnVsbGtleS5zdGFydHNXaXRoKFwicHJvcDpcIikpIHtcclxuICAgICAgICAgICAgdGhpcy5wcm9wQXR0cmlidXRlID0gZnVsbGtleS5zdWJzdHIoNSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy93ZSBtaWdodCBiZSBnZXR0aW5nIGFuIGVsZW1lbnQgZnJvbSBhIHByb3BlcnR5Tm9kZSBlZyBwYWdlLmFjdGlvbkJhciwgdW53cmFwXHJcbiAgICAgICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgTmF0aXZlRWxlbWVudE5vZGUpIHtcclxuICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIH1cclxuICAgICAgICBsZXQga2V5cGF0aCA9IGZ1bGxrZXkuc3BsaXQoXCIuXCIpO1xyXG4gICAgICAgIGxldCByZXNvbHZlZEtleXMgPSBbXTtcclxuICAgICAgICB3aGlsZSAoa2V5cGF0aC5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIGlmICghc2V0VGFyZ2V0KVxyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICBsZXQga2V5ID0ga2V5cGF0aC5zaGlmdCgpO1xyXG4gICAgICAgICAgICAvLyBub3JtYWxpemUgdG8gY29ycmVjdCBjYXNlXHJcbiAgICAgICAgICAgIGlmIChyZXNvbHZlZEtleXMubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIGtleSA9IHRoaXMuX25vcm1hbGl6ZWRLZXlzLmdldChrZXkpIHx8IGtleTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGtleSA9IG5vcm1hbGl6ZUtleUZyb21PYmplY3Qoc2V0VGFyZ2V0LCBrZXkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJlc29sdmVkS2V5cy5wdXNoKGtleSk7XHJcbiAgICAgICAgICAgIGlmIChrZXlwYXRoLmxlbmd0aCA+IDApIHtcclxuICAgICAgICAgICAgICAgIHNldFRhcmdldCA9IHNldFRhcmdldFtrZXldO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYHNldEF0dHIgdmFsdWUgJHt0aGlzfSAke3Jlc29sdmVkS2V5cy5qb2luKFwiLlwiKX0gJHt2YWx1ZX1gKTtcclxuICAgICAgICAgICAgICAgICAgICBzZXRUYXJnZXRba2V5XSA9IHZhbHVlO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgICAgICAvLyBpZ25vcmUgYnV0IGxvZ1xyXG4gICAgICAgICAgICAgICAgICAgIGxvZ2dlci5lcnJvcihgc2V0IGF0dHJpYnV0ZSB0aHJldyBhbiBlcnJvciwgYXR0cjoke2tleX0gb24gJHt0aGlzLl90YWdOYW1lfTogJHtlLm1lc3NhZ2V9YCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuZnVuY3Rpb24gcmVnaXN0ZXJOYXRpdmVDb25maWdFbGVtZW50KGVsZW1lbnROYW1lLCByZXNvbHZlciwgcGFyZW50UHJvcCA9IG51bGwsIHByb3BDb25maWcgPSB7fSkge1xyXG4gICAgcmVnaXN0ZXJFbGVtZW50KGVsZW1lbnROYW1lLCAoKSA9PiBuZXcgTmF0aXZlRWxlbWVudE5vZGUoZWxlbWVudE5hbWUsIHJlc29sdmVyKCksIHBhcmVudFByb3AsIHByb3BDb25maWcpKTtcclxufVxuXG5mdW5jdGlvbiBjYW1lbGl6ZShrZWJhYikge1xyXG4gICAgcmV0dXJuIGtlYmFiLnJlcGxhY2UoL1tcXC1dKyhcXHcpL2csIChtLCBsKSA9PiBsLnRvVXBwZXJDYXNlKCkpO1xyXG59XHJcbmZ1bmN0aW9uIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoZWxlbWVudE5hbWUsIHJlc29sdmVyLCBwYXJlbnRQcm9wID0gbnVsbCwgcHJvcENvbmZpZyA9IHt9KSB7XHJcbiAgICByZWdpc3RlckVsZW1lbnQoZWxlbWVudE5hbWUsICgpID0+IG5ldyBOYXRpdmVWaWV3RWxlbWVudE5vZGUoZWxlbWVudE5hbWUsIHJlc29sdmVyKCksIHBhcmVudFByb3AsIHByb3BDb25maWcpKTtcclxufVxyXG4vLyBBIE5hdGl2ZVZpZXdFbGVtZW50Tm9kZSwgd3JhcHMgYSBuYXRpdmUgVmlldyBhbmQgaGFuZGxlcyBzdHlsZSwgZXZlbnQgZGlzcGF0Y2gsIGFuZCBuYXRpdmUgdmlldyBoaWVyYXJjaHkgbWFuYWdlbWVudC5cclxuY2xhc3MgTmF0aXZlVmlld0VsZW1lbnROb2RlIGV4dGVuZHMgTmF0aXZlRWxlbWVudE5vZGUge1xyXG4gICAgY29uc3RydWN0b3IodGFnTmFtZSwgdmlld0NsYXNzLCBzZXRzUGFyZW50UHJvcCA9IG51bGwsIHByb3BDb25maWcgPSB7fSkge1xyXG4gICAgICAgIHN1cGVyKHRhZ05hbWUsIHZpZXdDbGFzcywgc2V0c1BhcmVudFByb3AsIHByb3BDb25maWcpO1xyXG4gICAgICAgIGxldCBzZXRTdHlsZUF0dHJpYnV0ZSA9ICh2YWx1ZSkgPT4ge1xyXG4gICAgICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZSgnc3R5bGUnLCB2YWx1ZSk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgZ2V0U3R5bGVBdHRyaWJ1dGUgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIHJldHVybiB0aGlzLmdldEF0dHJpYnV0ZSgnc3R5bGUnKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGxldCBnZXRQYXJlbnRQYWdlID0gKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAodGhpcy5uYXRpdmVWaWV3ICYmIHRoaXMubmF0aXZlVmlldy5wYWdlKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5uYXRpdmVWaWV3LnBhZ2UuX19TdmVsdGVOYXRpdmVFbGVtZW50X187XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBsZXQgYW5pbWF0aW9ucyA9IG5ldyBNYXAoKTtcclxuICAgICAgICBsZXQgb2xkQW5pbWF0aW9ucyA9IFtdO1xyXG4gICAgICAgIGNvbnN0IGFkZEFuaW1hdGlvbiA9IChhbmltYXRpb24pID0+IHtcclxuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBBZGRpbmcgYW5pbWF0aW9uICR7YW5pbWF0aW9ufWApO1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMubmF0aXZlVmlldykge1xyXG4gICAgICAgICAgICAgICAgdGhyb3cgRXJyb3IoXCJBdHRlbXB0IHRvIGFwcGx5IGFuaW1hdGlvbiB0byB0YWcgd2l0aG91dCBhIG5hdGl2ZSB2aWV3XCIgKyB0aGlzLnRhZ05hbWUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGxldCBwYWdlID0gZ2V0UGFyZW50UGFnZSgpO1xyXG4gICAgICAgICAgICBpZiAocGFnZSA9PSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBhbmltYXRpb25zLnNldChhbmltYXRpb24sIG51bGwpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vcXVpY2tseSBjYW5jZWwgYW55IG9sZCBvbmVzXHJcbiAgICAgICAgICAgIHdoaWxlIChvbGRBbmltYXRpb25zLmxlbmd0aCkge1xyXG4gICAgICAgICAgICAgICAgbGV0IG9sZEFuaW1hdGlvbiA9IG9sZEFuaW1hdGlvbnMuc2hpZnQoKTtcclxuICAgICAgICAgICAgICAgIGlmIChvbGRBbmltYXRpb24uaXNQbGF5aW5nKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2xkQW5pbWF0aW9uLmNhbmNlbCgpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vUGFyc2Ugb3VyIFwiYW5pbWF0aW9uXCIgc3R5bGUgcHJvcGVydHkgaW50byBhbiBhbmltYXRpb24gaW5mbyBpbnN0YW5jZSAodGhpcyB3b24ndCBpbmNsdWRlIHRoZSBrZXlmcmFtZXMgZnJvbSB0aGUgY3NzKVxyXG4gICAgICAgICAgICBsZXQgYW5pbWF0aW9uSW5mb3MgPSBDc3NBbmltYXRpb25QYXJzZXIua2V5ZnJhbWVBbmltYXRpb25zRnJvbUNTU0RlY2xhcmF0aW9ucyhbeyBwcm9wZXJ0eTogXCJhbmltYXRpb25cIiwgdmFsdWU6IGFuaW1hdGlvbiB9XSk7XHJcbiAgICAgICAgICAgIGlmICghYW5pbWF0aW9uSW5mb3MpIHtcclxuICAgICAgICAgICAgICAgIGFuaW1hdGlvbnMuc2V0KGFuaW1hdGlvbiwgbnVsbCk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGV0IGFuaW1hdGlvbkluZm8gPSBhbmltYXRpb25JbmZvc1swXTtcclxuICAgICAgICAgICAgLy9GZXRjaCBhbiBhbmltYXRpb25JbmZvIGluc3RhbmNlIHRoYXQgaW5jbHVkZXMgdGhlIGtleWZyYW1lcyBmcm9tIHRoZSBjc3MgKHRoaXMgd29uJ3QgaW5jbHVkZSB0aGUgYW5pbWF0aW9uIHByb3BlcnRpZXMgcGFyc2VkIGFib3ZlKVxyXG4gICAgICAgICAgICBsZXQgYW5pbWF0aW9uV2l0aEtleWZyYW1lcyA9IHBhZ2UubmF0aXZlVmlldy5nZXRLZXlmcmFtZUFuaW1hdGlvbldpdGhOYW1lKGFuaW1hdGlvbkluZm8ubmFtZSk7XHJcbiAgICAgICAgICAgIGlmICghYW5pbWF0aW9uV2l0aEtleWZyYW1lcykge1xyXG4gICAgICAgICAgICAgICAgYW5pbWF0aW9ucy5zZXQoYW5pbWF0aW9uLCBudWxsKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBhbmltYXRpb25JbmZvLmtleWZyYW1lcyA9IGFuaW1hdGlvbldpdGhLZXlmcmFtZXMua2V5ZnJhbWVzO1xyXG4gICAgICAgICAgICAvL2NvbWJpbmUgdGhlIGtleWZyYW1lcyBmcm9tIHRoZSBjc3Mgd2l0aCB0aGUgYW5pbWF0aW9uIGZyb20gdGhlIHBhcnNlZCBhdHRyaWJ1dGUgdG8gZ2V0IGEgY29tcGxldGUgYW5pbWF0aW9uSW5mbyBvYmplY3RcclxuICAgICAgICAgICAgbGV0IGFuaW1hdGlvbkluc3RhbmNlID0gS2V5ZnJhbWVBbmltYXRpb24ua2V5ZnJhbWVBbmltYXRpb25Gcm9tSW5mbyhhbmltYXRpb25JbmZvKTtcclxuICAgICAgICAgICAgLy8gc2F2ZSBhbmQgbGF1bmNoIHRoZSBhbmltYXRpb25cclxuICAgICAgICAgICAgYW5pbWF0aW9ucy5zZXQoYW5pbWF0aW9uLCBhbmltYXRpb25JbnN0YW5jZSk7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbkluc3RhbmNlLnBsYXkodGhpcy5uYXRpdmVWaWV3KTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGNvbnN0IHJlbW92ZUFuaW1hdGlvbiA9IChhbmltYXRpb24pID0+IHtcclxuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBSZW1vdmluZyBhbmltYXRpb24gJHthbmltYXRpb259YCk7XHJcbiAgICAgICAgICAgIGlmIChhbmltYXRpb25zLmhhcyhhbmltYXRpb24pKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgYW5pbWF0aW9uSW5zdGFuY2UgPSBhbmltYXRpb25zLmdldChhbmltYXRpb24pO1xyXG4gICAgICAgICAgICAgICAgYW5pbWF0aW9ucy5kZWxldGUoYW5pbWF0aW9uKTtcclxuICAgICAgICAgICAgICAgIGlmIChhbmltYXRpb25JbnN0YW5jZSkge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChhbmltYXRpb25JbnN0YW5jZS5pc1BsYXlpbmcpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy93ZSBkb24ndCB3YW50IHRvIHN0b3AgcmlnaHQgYXdheSBzaW5jZSBzdmVsdGUgcmVtb3ZlcyB0aGUgYW5pbWF0aW9uIGJlZm9yZSBpdCBpcyBmaW5pc2hlZCBkdWUgdG8gb3VyIGxhZyB0aW1lIHN0YXJ0aW5nIHRoZSBhbmltYXRpb24uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9sZEFuaW1hdGlvbnMucHVzaChhbmltYXRpb25JbnN0YW5jZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLnN0eWxlID0ge1xyXG4gICAgICAgICAgICBzZXRQcm9wZXJ0eTogKHByb3BlcnR5TmFtZSwgdmFsdWUsIHByaW9yaXR5KSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnNldFN0eWxlKGNhbWVsaXplKHByb3BlcnR5TmFtZSksIHZhbHVlKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcmVtb3ZlUHJvcGVydHk6IChwcm9wZXJ0eU5hbWUpID0+IHtcclxuICAgICAgICAgICAgICAgIHRoaXMuc2V0U3R5bGUoY2FtZWxpemUocHJvcGVydHlOYW1lKSwgbnVsbCk7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGdldCBhbmltYXRpb24oKSB7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gWy4uLmFuaW1hdGlvbnMua2V5cygpXS5qb2luKFwiLCBcIik7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNldCBhbmltYXRpb24odmFsdWUpIHtcclxuICAgICAgICAgICAgICAgIGxvZ2dlci5kZWJ1Zyhgc2V0dGluZyBhbmltYXRpb24gJHt2YWx1ZX1gKTtcclxuICAgICAgICAgICAgICAgIGxldCBuZXdfYW5pbWF0aW9ucyA9IHZhbHVlLnRyaW0oKSA9PSBcIlwiID8gW10gOiB2YWx1ZS5zcGxpdCgnLCcpLm1hcChhID0+IGEudHJpbSgpKTtcclxuICAgICAgICAgICAgICAgIC8vYWRkIG5ldyBvbmVzXHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBhbmltIG9mIG5ld19hbmltYXRpb25zKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFhbmltYXRpb25zLmhhcyhhbmltKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhZGRBbmltYXRpb24oYW5pbSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy9yZW1vdmUgb2xkIG9uZXNcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGFuaW0gb2YgYW5pbWF0aW9ucy5rZXlzKCkpIHtcclxuICAgICAgICAgICAgICAgICAgICBpZiAobmV3X2FuaW1hdGlvbnMuaW5kZXhPZihhbmltKSA8IDApIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVtb3ZlQW5pbWF0aW9uKGFuaW0pO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgZ2V0IGNzc1RleHQoKSB7XHJcbiAgICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoXCJnb3QgY3NzIHRleHRcIik7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2V0U3R5bGVBdHRyaWJ1dGUoKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2V0IGNzc1RleHQodmFsdWUpIHtcclxuICAgICAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhcInNldCBjc3MgdGV4dFwiKTtcclxuICAgICAgICAgICAgICAgIHNldFN0eWxlQXR0cmlidXRlKHZhbHVlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcbiAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xyXG4gICAgc2V0U3R5bGUocHJvcGVydHksIHZhbHVlKSB7XHJcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGBzZXRTdHlsZSAke3RoaXN9ICR7cHJvcGVydHl9ICR7dmFsdWV9YCk7XHJcbiAgICAgICAgaWYgKCEodmFsdWUgPSB2YWx1ZS50b1N0cmluZygpLnRyaW0oKSkubGVuZ3RoKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKHByb3BlcnR5LmVuZHNXaXRoKCdBbGlnbicpKSB7XHJcbiAgICAgICAgICAgIC8vIE5hdGl2ZVNjcmlwdCB1c2VzIEFsaWdubWVudCBpbnN0ZWFkIG9mIEFsaWduLCB0aGlzIGVuc3VyZXMgdGhhdCB0ZXh0LWFsaWduIHdvcmtzXHJcbiAgICAgICAgICAgIHByb3BlcnR5ICs9ICdtZW50JztcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5uYXRpdmVWaWV3LnN0eWxlW3Byb3BlcnR5XSA9IHZhbHVlO1xyXG4gICAgfVxyXG4gICAgZ2V0IG5hdGl2ZVZpZXcoKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMubmF0aXZlRWxlbWVudDtcclxuICAgIH1cclxuICAgIHNldCBuYXRpdmVWaWV3KHZpZXcpIHtcclxuICAgICAgICB0aGlzLm5hdGl2ZUVsZW1lbnQgPSB2aWV3O1xyXG4gICAgfVxyXG4gICAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cclxuICAgIGFkZEV2ZW50TGlzdGVuZXIoZXZlbnQsIGhhbmRsZXIpIHtcclxuICAgICAgICBsb2dnZXIuZGVidWcoYGFkZCBldmVudCBsaXN0ZW5lciAke3RoaXN9ICR7ZXZlbnR9YCk7XHJcbiAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lm9uKGV2ZW50LCBoYW5kbGVyKTtcclxuICAgIH1cclxuICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXHJcbiAgICByZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCBoYW5kbGVyKSB7XHJcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGByZW1vdmUgZXZlbnQgbGlzdGVuZXIgJHt0aGlzfSAke2V2ZW50fWApO1xyXG4gICAgICAgIHRoaXMubmF0aXZlVmlldy5vZmYoZXZlbnQsIGhhbmRsZXIpO1xyXG4gICAgfVxyXG4gICAgb25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpIHtcclxuICAgICAgICBzdXBlci5vbkluc2VydGVkQ2hpbGQoY2hpbGROb2RlLCBpbmRleCk7XHJcbiAgICAgICAgaWYgKCEoY2hpbGROb2RlIGluc3RhbmNlb2YgTmF0aXZlVmlld0VsZW1lbnROb2RlKSkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vaWYgd2UgYXJlIGEgcHJvcGVydHkgdmFsdWUsIHRoZW4gc2tpcCBhZGRpbmcgdG8gcGFyZW50XHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZS5wcm9wQXR0cmlidXRlKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgY29uc3QgcGFyZW50VmlldyA9IHRoaXMubmF0aXZlVmlldztcclxuICAgICAgICBjb25zdCBjaGlsZFZpZXcgPSBjaGlsZE5vZGUubmF0aXZlVmlldztcclxuICAgICAgICBpZiAoIXBhcmVudFZpZXcgfHwgIWNoaWxkVmlldykge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vdXNlIHRoZSBidWlsZGVyIGxvZ2ljIGlmIHdlIGFyZW4ndCBiZWluZyBkeW5hbWljLCB0byBjYXRjaCBjb25maWcgaXRlbXMgbGlrZSA8YWN0aW9uYmFyPiB0aGF0IGFyZSBub3QgbGlrZWx5IHRvIGJlIHRvZ2dsZWRcclxuICAgICAgICBpZiAoaW5kZXggPCAwICYmIHBhcmVudFZpZXcuX2FkZENoaWxkRnJvbUJ1aWxkZXIpIHtcclxuICAgICAgICAgICAgcGFyZW50Vmlldy5fYWRkQ2hpbGRGcm9tQnVpbGRlcihjaGlsZFZpZXcuY29uc3RydWN0b3IubmFtZSwgY2hpbGRWaWV3KTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAocGFyZW50VmlldyBpbnN0YW5jZW9mIExheW91dEJhc2UpIHtcclxuICAgICAgICAgICAgaWYgKGluZGV4ID49IDApIHtcclxuICAgICAgICAgICAgICAgIC8vb3VyIGRvbSBpbmNsdWRlcyBcInRleHROb2RlXCIgYW5kIFwiY29tbWVudE5vZGVcIiB3aGljaCBkb2VzIG5vdCBhcHBlYXIgaW4gdGhlIG5hdGl2ZXZpZXcncyBjaGlsZHJlbi4gXHJcbiAgICAgICAgICAgICAgICAvL3dlIHJlY2FsY3VsYXRlIHRoZSBpbmRleCByZXF1aXJlZCBmb3IgdGhlIGluc2VydCBvcGVyYXRpb24gYnkgb25seSBpbmNsdWRpbmcgbmF0aXZlIHZpZXcgZWxlbWVudCBub2RlcyBpbiB0aGUgY291bnRcclxuICAgICAgICAgICAgICAgIC8vdGhhdCBhcmVuJ3QgcHJvcGVydHkgc2V0dGVyIG5vZGVzXHJcbiAgICAgICAgICAgICAgICBsZXQgbmF0aXZlSW5kZXggPSB0aGlzLmNoaWxkTm9kZXMuZmlsdGVyKGUgPT4gZSBpbnN0YW5jZW9mIE5hdGl2ZVZpZXdFbGVtZW50Tm9kZSAmJiAhZS5wcm9wQXR0cmlidXRlKS5pbmRleE9mKGNoaWxkTm9kZSk7XHJcbiAgICAgICAgICAgICAgICBwYXJlbnRWaWV3Lmluc2VydENoaWxkKGNoaWxkVmlldywgbmF0aXZlSW5kZXgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgcGFyZW50Vmlldy5hZGRDaGlsZChjaGlsZFZpZXcpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gd2UgYXJlbid0IGEgbGF5b3V0IHZpZXcsIGJ1dCB3ZSB3ZXJlIGdpdmVuIGFuIGluZGV4LCB0cnkgdGhlIF9hZGRDaGlsZEZyb21CdWlsZGVyIGZpcnN0XHJcbiAgICAgICAgaWYgKHBhcmVudFZpZXcuX2FkZENoaWxkRnJvbUJ1aWxkZXIpIHtcclxuICAgICAgICAgICAgcmV0dXJuIHBhcmVudFZpZXcuX2FkZENoaWxkRnJvbUJ1aWxkZXIoY2hpbGRWaWV3LmNvbnN0cnVjdG9yLm5hbWUsIGNoaWxkVmlldyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChwYXJlbnRWaWV3IGluc3RhbmNlb2YgQ29udGVudFZpZXcpIHtcclxuICAgICAgICAgICAgcGFyZW50Vmlldy5jb250ZW50ID0gY2hpbGRWaWV3O1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlBhcmVudCBjYW4ndCBjb250YWluIGNoaWxkcmVuOiBcIiArIHRoaXMgKyBcIiwgXCIgKyBjaGlsZE5vZGUpO1xyXG4gICAgfVxyXG4gICAgb25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKSB7XHJcbiAgICAgICAgc3VwZXIub25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgICAgICBpZiAoIShjaGlsZE5vZGUgaW5zdGFuY2VvZiBOYXRpdmVWaWV3RWxlbWVudE5vZGUpKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy9jaGlsZG5vZGVzIHdpdGggcHJvcEF0dHJpYnV0ZXMgYXJlbid0IGFkZGVkIHRvIG5hdGl2ZSB2aWV3c1xyXG4gICAgICAgIGlmIChjaGlsZE5vZGUucHJvcEF0dHJpYnV0ZSlcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIGlmICghdGhpcy5uYXRpdmVWaWV3IHx8ICFjaGlsZE5vZGUubmF0aXZlVmlldykge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHBhcmVudFZpZXcgPSB0aGlzLm5hdGl2ZVZpZXc7XHJcbiAgICAgICAgY29uc3QgY2hpbGRWaWV3ID0gY2hpbGROb2RlLm5hdGl2ZVZpZXc7XHJcbiAgICAgICAgaWYgKHBhcmVudFZpZXcgaW5zdGFuY2VvZiBMYXlvdXRCYXNlKSB7XHJcbiAgICAgICAgICAgIHBhcmVudFZpZXcucmVtb3ZlQ2hpbGQoY2hpbGRWaWV3KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAocGFyZW50VmlldyBpbnN0YW5jZW9mIENvbnRlbnRWaWV3KSB7XHJcbiAgICAgICAgICAgIGlmIChwYXJlbnRWaWV3LmNvbnRlbnQgPT09IGNoaWxkVmlldykge1xyXG4gICAgICAgICAgICAgICAgcGFyZW50Vmlldy5jb250ZW50ID0gbnVsbDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoY2hpbGROb2RlLm5vZGVUeXBlID09PSA4KSB7XHJcbiAgICAgICAgICAgICAgICBwYXJlbnRWaWV3Ll9yZW1vdmVWaWV3KGNoaWxkVmlldyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSBpZiAocGFyZW50VmlldyBpbnN0YW5jZW9mIFZpZXcpIHtcclxuICAgICAgICAgICAgcGFyZW50Vmlldy5fcmVtb3ZlVmlldyhjaGlsZFZpZXcpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbG9nZ2VyLndhcm4oXCJVbmtub3duIHBhcmVudCB2aWV3IHR5cGU6IFwiICsgcGFyZW50Vmlldyk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgZGlzcGF0Y2hFdmVudChldmVudCkge1xyXG4gICAgICAgIGlmICh0aGlzLm5hdGl2ZVZpZXcpIHtcclxuICAgICAgICAgICAgLy9uYXRpdmVzY3JpcHQgdXNlcyB0aGUgRXZlbnROYW1lIHdoaWxlIGRvbSB1c2VzIFR5cGVcclxuICAgICAgICAgICAgZXZlbnQuZXZlbnROYW1lID0gZXZlbnQudHlwZTtcclxuICAgICAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lm5vdGlmeShldmVudCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XG5cbmNsYXNzIFBhZ2VFbGVtZW50IGV4dGVuZHMgTmF0aXZlVmlld0VsZW1lbnROb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCdwYWdlJywgUGFnZSk7XHJcbiAgICB9XHJcbn1cblxuY2xhc3MgRnJhbWVFbGVtZW50IGV4dGVuZHMgTmF0aXZlVmlld0VsZW1lbnROb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCdmcmFtZScsIEZyYW1lKTtcclxuICAgIH1cclxuICAgIHNldEF0dHJpYnV0ZShrZXksIHZhbHVlKSB7XHJcbiAgICAgICAgaWYgKGtleS50b0xvd2VyQ2FzZSgpID09IFwiZGVmYXVsdHBhZ2VcIikge1xyXG4gICAgICAgICAgICBsb2dnZXIuZGVidWcoYGxvYWRpbmcgcGFnZSAke3ZhbHVlfWApO1xyXG4gICAgICAgICAgICBsZXQgZHVtbXkgPSBjcmVhdGVFbGVtZW50KCdmcmFnbWVudCcpO1xyXG4gICAgICAgICAgICBsZXQgcGFnZSA9IG5ldyB2YWx1ZSh7IHRhcmdldDogZHVtbXksIHByb3BzOiB7fSB9KTtcclxuICAgICAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lm5hdmlnYXRlKHsgY3JlYXRlOiAoKSA9PiBkdW1teS5maXJzdEVsZW1lbnQoKS5uYXRpdmVWaWV3IH0pO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN1cGVyLnNldEF0dHJpYnV0ZShrZXksIHZhbHVlKTtcclxuICAgIH1cclxuICAgIC8vSW4gcmVndWxhciBuYXRpdmUgc2NyaXB0LCBGcmFtZSBlbGVtZW50cyBhcmVuJ3QgbWVhbnQgdG8gaGF2ZSBjaGlsZHJlbiwgd2UgaW5zdGVhZCBhbGxvdyBpdCB0byBoYXZlIG9uZS4uIGEgcGFnZS4uIGFzIGEgY29udmVuaWVuY2VcclxuICAgIC8vIGFuZCBzZXQgdGhlIGluc3RhbmNlIGFzIHRoZSBkZWZhdWx0IHBhZ2UgYnkgbmF2aWdhdGluZyB0byBpdC5cclxuICAgIG9uSW5zZXJ0ZWRDaGlsZChjaGlsZE5vZGUsIGluZGV4KSB7XHJcbiAgICAgICAgLy9vbmx5IGhhbmRsZSBwYWdlIG5vZGVzXHJcbiAgICAgICAgaWYgKCEoY2hpbGROb2RlIGluc3RhbmNlb2YgUGFnZUVsZW1lbnQpKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lm5hdmlnYXRlKHsgY3JlYXRlOiAoKSA9PiBjaGlsZE5vZGUubmF0aXZlVmlldywgY2xlYXJIaXN0b3J5OiB0cnVlIH0pO1xyXG4gICAgfVxyXG59XG5cbmNsYXNzIFN2ZWx0ZUtleWVkVGVtcGxhdGUge1xyXG4gICAgY29uc3RydWN0b3Ioa2V5LCB0ZW1wbGF0ZUVsKSB7XHJcbiAgICAgICAgdGhpcy5fa2V5ID0ga2V5O1xyXG4gICAgICAgIHRoaXMuX3RlbXBsYXRlRWwgPSB0ZW1wbGF0ZUVsO1xyXG4gICAgfVxyXG4gICAgZ2V0IGNvbXBvbmVudCgpIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5fdGVtcGxhdGVFbC5jb21wb25lbnQ7XHJcbiAgICB9XHJcbiAgICBnZXQga2V5KCkge1xyXG4gICAgICAgIHJldHVybiB0aGlzLl9rZXk7XHJcbiAgICB9XHJcbiAgICBjcmVhdGVWaWV3KCkge1xyXG4gICAgICAgIC8vY3JlYXRlIGEgcHJveHkgZWxlbWVudCB0byBldmVudHVhbGx5IGNvbnRhaW4gb3VyIGl0ZW0gKG9uY2Ugd2UgaGF2ZSBvbmUgdG8gcmVuZGVyKVxyXG4gICAgICAgIC8vVE9ETyBpcyBTdGFja0xheW91dCB0aGUgYmVzdCBjaG9pY2UgaGVyZT8gXHJcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGBjcmVhdGluZyB2aWV3IGZvciBrZXkgJHt0aGlzLmtleX1gKTtcclxuICAgICAgICBsZXQgd3JhcHBlciA9IGNyZWF0ZUVsZW1lbnQoJ1N0YWNrTGF5b3V0Jyk7XHJcbiAgICAgICAgd3JhcHBlci5zZXRTdHlsZShcInBhZGRpbmdcIiwgMCk7XHJcbiAgICAgICAgd3JhcHBlci5zZXRTdHlsZShcIm1hcmdpblwiLCAwKTtcclxuICAgICAgICBsZXQgbmF0aXZlRWwgPSB3cmFwcGVyLm5hdGl2ZVZpZXc7XHJcbiAgICAgICAgbmF0aXZlRWwuX19TdmVsdGVDb21wb25lbnRCdWlsZGVyX18gPSAocHJvcHMpID0+IHtcclxuICAgICAgICAgICAgbGV0IGluc3RhbmNlID0gbmV3IHRoaXMuY29tcG9uZW50KHtcclxuICAgICAgICAgICAgICAgIHRhcmdldDogd3JhcHBlcixcclxuICAgICAgICAgICAgICAgIHByb3BzOiBwcm9wc1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgbmF0aXZlRWwuX19TdmVsdGVDb21wb25lbnRfXyA9IGluc3RhbmNlO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgcmV0dXJuIG5hdGl2ZUVsO1xyXG4gICAgfVxyXG59XHJcbmNsYXNzIExpc3RWaWV3RWxlbWVudCBleHRlbmRzIE5hdGl2ZVZpZXdFbGVtZW50Tm9kZSB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcignbGlzdHZpZXcnLCBMaXN0Vmlldyk7XHJcbiAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lm9uKExpc3RWaWV3Lml0ZW1Mb2FkaW5nRXZlbnQsIChhcmdzKSA9PiB7IHRoaXMudXBkYXRlTGlzdEl0ZW0oYXJncyk7IH0pO1xyXG4gICAgfVxyXG4gICAgdXBkYXRlTGlzdEl0ZW0oYXJncykge1xyXG4gICAgICAgIGxldCBpdGVtO1xyXG4gICAgICAgIGxldCBsaXN0VmlldyA9IHRoaXMubmF0aXZlVmlldztcclxuICAgICAgICBsZXQgaXRlbXMgPSBsaXN0Vmlldy5pdGVtcztcclxuICAgICAgICBpZiAoYXJncy5pbmRleCA+PSBpdGVtcy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGBHb3QgcmVxdWVzdCBmb3IgaXRlbSBhdCBpbmRleCB0aGF0IGRpZG4ndCBleGlzdCAke2FyZ3MuaW5kZXh9YCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKGl0ZW1zLmdldEl0ZW0pIHtcclxuICAgICAgICAgICAgaXRlbSA9IGl0ZW1zLmdldEl0ZW0oYXJncy5pbmRleCk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICBpdGVtID0gaXRlbXNbYXJncy5pbmRleF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmICghYXJncy52aWV3IHx8ICFhcmdzLnZpZXcuX19TdmVsdGVDb21wb25lbnRfXykge1xyXG4gICAgICAgICAgICBsZXQgY29tcG9uZW50O1xyXG4gICAgICAgICAgICBpZiAoYXJncy52aWV3ICYmIGFyZ3Mudmlldy5fX1N2ZWx0ZUNvbXBvbmVudEJ1aWxkZXJfXykge1xyXG4gICAgICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBpbnN0YW50aWF0aW5nIGNvbXBvbmVudCBpbiBrZXllZCB2aWV3IGl0ZW0gYXQgJHthcmdzLmluZGV4fWApO1xyXG4gICAgICAgICAgICAgICAgLy9ub3cgd2UgaGF2ZSBhbiBpdGVtLCB3ZSBjYW4gY3JlYXRlIGFuZCBtb3VudCB0aGlzIGNvbXBvbmVudFxyXG4gICAgICAgICAgICAgICAgYXJncy52aWV3Ll9fU3ZlbHRlQ29tcG9uZW50QnVpbGRlcl9fKHsgaXRlbSB9KTtcclxuICAgICAgICAgICAgICAgIGFyZ3Mudmlldy5fX1N2ZWx0ZUNvbXBvbmVudEJ1aWxkZXJfXyA9IG51bGw7IC8vZnJlZSB0aGUgbWVtb3J5XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBjcmVhdGluZyBkZWZhdWx0IHZpZXcgZm9yIGl0ZW0gYXQgJHthcmdzLmluZGV4fWApO1xyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGxpc3RWaWV3Lml0ZW1UZW1wbGF0ZXMgPT0gXCJvYmplY3RcIikge1xyXG4gICAgICAgICAgICAgICAgY29tcG9uZW50ID0gbGlzdFZpZXcuaXRlbVRlbXBsYXRlcy5maWx0ZXIoeCA9PiB4LmtleSA9PSBcImRlZmF1bHRcIikubWFwKHggPT4geC5jb21wb25lbnQpWzBdO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmICghY29tcG9uZW50KSB7XHJcbiAgICAgICAgICAgICAgICBsb2dnZXIuZXJyb3IoYENvdWxkbid0IGRldGVybWluZSBjb21wb25lbnQgdG8gdXNlIGZvciBpdGVtIGF0ICR7YXJncy5pbmRleH1gKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBsZXQgd3JhcHBlciA9IGNyZWF0ZUVsZW1lbnQoJ1Byb3h5Vmlld0NvbnRhaW5lcicpO1xyXG4gICAgICAgICAgICBsZXQgY29tcG9uZW50SW5zdGFuY2UgPSBuZXcgY29tcG9uZW50KHtcclxuICAgICAgICAgICAgICAgIHRhcmdldDogd3JhcHBlcixcclxuICAgICAgICAgICAgICAgIHByb3BzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXRlbVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgbGV0IG5hdGl2ZUVsID0gd3JhcHBlci5uYXRpdmVWaWV3O1xyXG4gICAgICAgICAgICBuYXRpdmVFbC5fX1N2ZWx0ZUNvbXBvbmVudF9fID0gY29tcG9uZW50SW5zdGFuY2U7XHJcbiAgICAgICAgICAgIGFyZ3MudmlldyA9IG5hdGl2ZUVsO1xyXG4gICAgICAgIH1cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgbGV0IGNvbXBvbmVudEluc3RhbmNlID0gYXJncy52aWV3Ll9fU3ZlbHRlQ29tcG9uZW50X187XHJcbiAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgdXBkYXRpbmcgdmlldyBmb3IgJHthcmdzLmluZGV4fSB3aGljaCBpcyBhICR7YXJncy52aWV3fWApO1xyXG4gICAgICAgICAgICBjb21wb25lbnRJbnN0YW5jZS4kc2V0KHsgaXRlbSB9KTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICBvbkluc2VydGVkQ2hpbGQoY2hpbGROb2RlLCBpbmRleCkge1xyXG4gICAgICAgIHN1cGVyLm9uSW5zZXJ0ZWRDaGlsZChjaGlsZE5vZGUsIGluZGV4KTtcclxuICAgICAgICBpZiAoY2hpbGROb2RlIGluc3RhbmNlb2YgVGVtcGxhdGVFbGVtZW50KSB7XHJcbiAgICAgICAgICAgIGxldCBrZXkgPSBjaGlsZE5vZGUuZ2V0QXR0cmlidXRlKCdrZXknKSB8fCBcImRlZmF1bHRcIjtcclxuICAgICAgICAgICAgbG9nZ2VyLmRlYnVnKGBBZGRpbmcgdGVtcGxhdGUgZm9yIGtleSAke2tleX1gKTtcclxuICAgICAgICAgICAgaWYgKCF0aGlzLm5hdGl2ZVZpZXcuaXRlbVRlbXBsYXRlcyB8fCB0eXBlb2YgdGhpcy5uYXRpdmVWaWV3Lml0ZW1UZW1wbGF0ZXMgPT0gXCJzdHJpbmdcIikge1xyXG4gICAgICAgICAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lml0ZW1UZW1wbGF0ZXMgPSBbXTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB0aGlzLm5hdGl2ZVZpZXcuaXRlbVRlbXBsYXRlcy5wdXNoKG5ldyBTdmVsdGVLZXllZFRlbXBsYXRlKGtleSwgY2hpbGROb2RlKSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKSB7XHJcbiAgICAgICAgc3VwZXIub25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgICAgICBpZiAoY2hpbGROb2RlIGluc3RhbmNlb2YgVGVtcGxhdGVFbGVtZW50KSB7XHJcbiAgICAgICAgICAgIGxldCBrZXkgPSBjaGlsZE5vZGUuZ2V0QXR0cmlidXRlKCdrZXknKSB8fCBcImRlZmF1bHRcIjtcclxuICAgICAgICAgICAgaWYgKHRoaXMubmF0aXZlVmlldy5pdGVtVGVtcGxhdGVzICYmIHR5cGVvZiB0aGlzLm5hdGl2ZVZpZXcuaXRlbVRlbXBsYXRlcyAhPSBcInN0cmluZ1wiKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5hdGl2ZVZpZXcuaXRlbVRlbXBsYXRlcyA9IHRoaXMubmF0aXZlVmlldy5pdGVtVGVtcGxhdGVzLmZpbHRlcih0ID0+IHQua2V5ICE9IGtleSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cblxuY2xhc3MgVGFiVmlld0VsZW1lbnQgZXh0ZW5kcyBOYXRpdmVWaWV3RWxlbWVudE5vZGUge1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgc3VwZXIoJ1RhYlZpZXcnLCBUYWJWaWV3KTtcclxuICAgICAgICB0aGlzLm5lZWRzX3VwZGF0ZSA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgZG9VcGRhdGUoKSB7XHJcbiAgICAgICAgbGV0IGl0ZW1zID0gdGhpcy5jaGlsZE5vZGVzLmZpbHRlcih4ID0+IHggaW5zdGFuY2VvZiBOYXRpdmVWaWV3RWxlbWVudE5vZGUgJiYgeC5uYXRpdmVWaWV3IGluc3RhbmNlb2YgVGFiVmlld0l0ZW0pLm1hcCh4ID0+IHgubmF0aXZlVmlldyk7XHJcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGB1cGRhdGluZyB0YWIgaXRlbXMuIG5vdyBoYXMgJHtpdGVtcy5sZW5ndGh9IGl0ZW1zYCk7XHJcbiAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lml0ZW1zID0gaXRlbXM7XHJcbiAgICB9XHJcbiAgICBvbkluc2VydGVkQ2hpbGQoY2hpbGROb2RlLCBpbmRleCkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIC8vV2Ugb25seSB3YW50IHRvIGhhbmRsZSBUYWJWaWV3SXRlbSBhbmQgb25seSBpZiBpdCBpcyB0aGUgbGFzdCBpdGVtIVxyXG4gICAgICAgICAgICBpZiAoIShjaGlsZE5vZGUgaW5zdGFuY2VvZiBOYXRpdmVWaWV3RWxlbWVudE5vZGUgJiYgY2hpbGROb2RlLm5hdGl2ZVZpZXcgaW5zdGFuY2VvZiBUYWJWaWV3SXRlbSkpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gc3VwZXIub25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpO1xyXG4gICAgICAgICAgICB0aGlzLm5lZWRzX3VwZGF0ZSA9IHRydWU7XHJcbiAgICAgICAgICAgIC8vcmVzb2x2ZSBhZnRlciB0aGlzIGV2ZW50IGxvb3AgdG8gY2F0Y2ggYWxsIGFkZGVkIHRhYnZpZXdpdGVtcyBpbiBvbmUgdXBkYXRlLCBhbmQgdG8gaGFuZGxlIHRoZSBmYWN0IHRoYXQgc3ZlbHRlIGFkZHMgdGhlXHJcbiAgICAgICAgICAgIC8vdGFidmlld2l0ZW0gdG8gdGFidmlldyB3aGlsZSBpdCBpcyBzdGlsbCBlbXB0eSB3aGljaCBjYXVzZXMgcHJvYmxlbXMuXHJcbiAgICAgICAgICAgIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMubmVlZHNfdXBkYXRlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5kb1VwZGF0ZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmVlZHNfdXBkYXRlID0gZmFsc2U7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pLmNhdGNoKGUgPT4gY29uc29sZS5lcnJvcihlKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgb25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKSB7XHJcbiAgICAgICAgaWYgKCEoY2hpbGROb2RlIGluc3RhbmNlb2YgTmF0aXZlVmlld0VsZW1lbnROb2RlICYmIGNoaWxkTm9kZS5uYXRpdmVWaWV3IGluc3RhbmNlb2YgVGFiVmlld0l0ZW0pKVxyXG4gICAgICAgICAgICByZXR1cm4gc3VwZXIub25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiUmVtb3ZpbmcgYSBUYWJWaWV3SXRlbSBpcyBub3Qgc3VwcG9ydGVkIGF0bSBzZWU6ICBodHRwczovL2dpdGh1Yi5jb20vTmF0aXZlU2NyaXB0L25hdGl2ZXNjcmlwdC1hbmd1bGFyL2lzc3Vlcy82MjFcIik7XHJcbiAgICB9XHJcbn1cblxuY2xhc3MgQmFzZVRhYk5hdmlnYXRpb25FbGVtZW50IGV4dGVuZHMgTmF0aXZlVmlld0VsZW1lbnROb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKHRhZ05hbWUsIHZpZXdDbGFzcykge1xyXG4gICAgICAgIHN1cGVyKHRhZ05hbWUsIHZpZXdDbGFzcyk7XHJcbiAgICAgICAgdGhpcy5wZW5kaW5nSW5zZXJ0cyA9IFtdO1xyXG4gICAgfVxyXG4gICAgb25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoY2hpbGROb2RlIGluc3RhbmNlb2YgTmF0aXZlVmlld0VsZW1lbnROb2RlICYmIGNoaWxkTm9kZS5uYXRpdmVWaWV3IGluc3RhbmNlb2YgVGFiQ29udGVudEl0ZW0pIHtcclxuICAgICAgICAgICAgICAgIGxvZ2dlci5kZWJ1ZyhgYWRkaW5nIHRhYiBjb250ZW50IHRvIG5hdmApO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5wZW5kaW5nSW5zZXJ0cy5wdXNoKGNoaWxkTm9kZS5uYXRpdmVWaWV3KTtcclxuICAgICAgICAgICAgICAgIC8vd2FpdCBmb3IgbmV4dCB0dXJuIHNvIHRoYXQgYW55IGNvbnRlbnQgZm9yIG91ciB0YWIgaXMgYXR0YWNoZWQgdG8gdGhlIGRvbVxyXG4gICAgICAgICAgICAgICAgUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucGVuZGluZ0luc2VydHMubGVuZ3RoID09IDApXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgICAgICBsZXQgaXRlbXMgPSAodGhpcy5uYXRpdmVWaWV3Lml0ZW1zIHx8IFtdKS5jb25jYXQodGhpcy5wZW5kaW5nSW5zZXJ0cyk7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wZW5kaW5nSW5zZXJ0cyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlVmlldy5pdGVtcyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlVmlldy5pdGVtcyA9IGl0ZW1zO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc3VwZXIub25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpO1xyXG4gICAgfVxyXG4gICAgb25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGNoaWxkTm9kZSBpbnN0YW5jZW9mIE5hdGl2ZVZpZXdFbGVtZW50Tm9kZSAmJiBjaGlsZE5vZGUubmF0aXZlVmlldyBpbnN0YW5jZW9mIFRhYkNvbnRlbnRJdGVtKSB7XHJcbiAgICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYHJlbW92aW5nIGNvbnRlbnQgaXRlbSBmcm9tIG5hdmApO1xyXG4gICAgICAgICAgICAgICAgbGV0IGl0ZW1zID0gKHRoaXMubmF0aXZlVmlldy5pdGVtcyB8fCBbXSkuZmlsdGVyKGkgPT4gaSAhPSBjaGlsZE5vZGUubmF0aXZlVmlldyk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5hdGl2ZVZpZXcuaXRlbXMgPSBbXTtcclxuICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlVmlldy5pdGVtcyA9IGl0ZW1zO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN1cGVyLm9uUmVtb3ZlZENoaWxkKGNoaWxkTm9kZSk7XHJcbiAgICB9XHJcbn1cblxuY2xhc3MgQm90dG9tTmF2aWdhdGlvbkVsZW1lbnQgZXh0ZW5kcyBCYXNlVGFiTmF2aWdhdGlvbkVsZW1lbnQge1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgc3VwZXIoXCJCb3R0b21OYXZpZ2F0aW9uXCIsIEJvdHRvbU5hdmlnYXRpb24pO1xyXG4gICAgfVxyXG59XG5cbmNsYXNzIFRhYnNFbGVtZW50IGV4dGVuZHMgQmFzZVRhYk5hdmlnYXRpb25FbGVtZW50IHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKFwiVGFic1wiLCBUYWJzKTtcclxuICAgIH1cclxufVxuXG5jbGFzcyBBY3Rpb25CYXJFbGVtZW50IGV4dGVuZHMgTmF0aXZlVmlld0VsZW1lbnROb2RlIHtcclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCdBY3Rpb25CYXInLCBBY3Rpb25CYXIpO1xyXG4gICAgfVxyXG4gICAgb25JbnNlcnRlZENoaWxkKGNoaWxkTm9kZSwgaW5kZXgpIHtcclxuICAgICAgICAvL0FjdGlvbkl0ZW1zIGlzbid0IGFuIGFycmF5IG9yIE9ic2VydmFibGVBcnJheSwgaXQgaXMgYSBzcGVjaWFsIEFjdGlvbkl0ZW1zIHR5cGUsIHNvIHdlIGhhbmRsZSBpdCBoZXJlXHJcbiAgICAgICAgaWYgKGNoaWxkTm9kZSBpbnN0YW5jZW9mIE5hdGl2ZUVsZW1lbnROb2RlKSB7XHJcbiAgICAgICAgICAgIGxldCBwcm9wTmFtZSA9IGNoaWxkTm9kZS5wcm9wQXR0cmlidXRlO1xyXG4gICAgICAgICAgICBpZiAocHJvcE5hbWUpIHtcclxuICAgICAgICAgICAgICAgIHByb3BOYW1lID0gdGhpcy5fbm9ybWFsaXplZEtleXMuZ2V0KHByb3BOYW1lKSB8fCBwcm9wTmFtZTtcclxuICAgICAgICAgICAgICAgIGlmIChwcm9wTmFtZS50b0xvd2VyQ2FzZSgpID09IFwiYWN0aW9uaXRlbXNcIikge1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlVmlldy5hY3Rpb25JdGVtcy5hZGRJdGVtKGNoaWxkTm9kZS5uYXRpdmVFbGVtZW50KTtcclxuICAgICAgICAgICAgICAgICAgICByZXR1cm47IC8vc2tpcCByZXN0IG9mIHRoZSBwcm9jZXNzaW5nLlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHN1cGVyLm9uSW5zZXJ0ZWRDaGlsZChjaGlsZE5vZGUsIGluZGV4KTtcclxuICAgIH1cclxuICAgIG9uUmVtb3ZlZENoaWxkKGNoaWxkTm9kZSkge1xyXG4gICAgICAgIGlmIChjaGlsZE5vZGUgaW5zdGFuY2VvZiBOYXRpdmVFbGVtZW50Tm9kZSkge1xyXG4gICAgICAgICAgICBsZXQgcHJvcE5hbWUgPSBjaGlsZE5vZGUucHJvcEF0dHJpYnV0ZTtcclxuICAgICAgICAgICAgaWYgKHByb3BOYW1lKSB7XHJcbiAgICAgICAgICAgICAgICBwcm9wTmFtZSA9IHRoaXMuX25vcm1hbGl6ZWRLZXlzLmdldChwcm9wTmFtZSkgfHwgcHJvcE5hbWU7XHJcbiAgICAgICAgICAgICAgICBpZiAocHJvcE5hbWUudG9Mb3dlckNhc2UoKSA9PSBcImFjdGlvbml0ZW1zXCIpIHtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdGl2ZVZpZXcuYWN0aW9uSXRlbXMucmVtb3ZlSXRlbShjaGlsZE5vZGUubmF0aXZlRWxlbWVudCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuOyAvL3NraXAgcmVzdCBvZiB0aGUgcHJvY2Vzc2luZy5cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBzdXBlci5vblJlbW92ZWRDaGlsZChjaGlsZE5vZGUpO1xyXG4gICAgfVxyXG59XG5cbmNsYXNzIFRhYlN0cmlwRWxlbWVudCBleHRlbmRzIE5hdGl2ZVZpZXdFbGVtZW50Tm9kZSB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcihcIlRhYlN0cmlwXCIsIFRhYlN0cmlwLCBudWxsKTtcclxuICAgIH1cclxuICAgIG9uSW5zZXJ0ZWRDaGlsZChjaGlsZE5vZGUsIGluZGV4KSB7XHJcbiAgICAgICAgLy8gQXMgb2YgdG5zLWNvcmUtbW9kdWxlcyA2LjEuMiBzZXR0aW5nIGEgbmV3IGFycmF5IGhlcmUgZG9lc24ndCBzZXQgdGhlIHBhcmVudCBwcm9wZXJ0eSBvZiBhbnkgbmV3IHRhYnN0cmlwaXRlbXNcclxuICAgICAgICAvLyBhbmQgY2F1c2VzIGEgY3Jhc2guIGEgd29ya2Fyb3VuZCBzdWdnZXN0ZWQgaHR0cHM6Ly9naXRodWIuY29tL05hdGl2ZVNjcmlwdC9OYXRpdmVTY3JpcHQvaXNzdWVzLzc2MDhcclxuICAgICAgICAvLyBpcyB0byBzZXQgaXRlbXMgdG8gW10gYmVmb3JlIHNldHRpbmcgaXQgdG8gdGhlIG5ldyBhcnJheS5cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoY2hpbGROb2RlIGluc3RhbmNlb2YgTmF0aXZlVmlld0VsZW1lbnROb2RlICYmIGNoaWxkTm9kZS5uYXRpdmVWaWV3IGluc3RhbmNlb2YgVGFiU3RyaXBJdGVtKSB7XHJcbiAgICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYGFkZGluZyB0YWIgc3RyaXAgaXRlbSAke2NoaWxkTm9kZS5uYXRpdmVWaWV3LnRpdGxlfWApO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgaXRlbXMgPSB0aGlzLm5hdGl2ZVZpZXcuaXRlbXMgfHwgW107XHJcbiAgICAgICAgICAgICAgICB0aGlzLm5hdGl2ZVZpZXcuaXRlbXMgPSBbXTtcclxuICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlVmlldy5pdGVtcyA9IGl0ZW1zLmNvbmNhdChbY2hpbGROb2RlLm5hdGl2ZVZpZXddKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzdXBlci5vbkluc2VydGVkQ2hpbGQoY2hpbGROb2RlLCBpbmRleCk7XHJcbiAgICB9XHJcbiAgICBvblJlbW92ZWRDaGlsZChjaGlsZE5vZGUpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAoY2hpbGROb2RlIGluc3RhbmNlb2YgTmF0aXZlVmlld0VsZW1lbnROb2RlICYmIGNoaWxkTm9kZS5uYXRpdmVWaWV3IGluc3RhbmNlb2YgVGFiU3RyaXBJdGVtKSB7XHJcbiAgICAgICAgICAgICAgICBsb2dnZXIuZGVidWcoYHJlbW92aW5nIHRhYiBzdHJpcCBpdGVtICR7Y2hpbGROb2RlLm5hdGl2ZVZpZXcudGl0bGV9YCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgaXRlbXMgPSAodGhpcy5uYXRpdmVWaWV3Lml0ZW1zIHx8IFtdKS5maWx0ZXIoaSA9PiBpICE9IGNoaWxkTm9kZS5uYXRpdmVWaWV3KTtcclxuICAgICAgICAgICAgICAgIHRoaXMubmF0aXZlVmlldy5pdGVtcyA9IFtdO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5uYXRpdmVWaWV3Lml0ZW1zID0gaXRlbXM7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihlKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgc3VwZXIub25SZW1vdmVkQ2hpbGQoY2hpbGROb2RlKTtcclxuICAgIH1cclxufVxuXG5mdW5jdGlvbiByZWdpc3Rlck5hdGl2ZUVsZW1lbnRzKCkge1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnQWN0aW9uSXRlbScsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvYWN0aW9uLWJhcicpLkFjdGlvbkl0ZW0sICdhY3Rpb25JdGVtcycpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnTmF2aWdhdGlvbkJ1dHRvbicsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvYWN0aW9uLWJhcicpLk5hdmlnYXRpb25CdXR0b24sICduYXZpZ2F0aW9uQnV0dG9uJyk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdUYWJWaWV3SXRlbScsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvdGFiLXZpZXcnKS5UYWJWaWV3SXRlbSk7XHJcbiAgICAvLyBOUyBjb21wb25lbnRzIHdoaWNoIHVzZXMgdGhlIGF1dG9tYXRpYyByZWdpc3RlckVsZW1lbnQgVnVlIHdyYXBwZXJcclxuICAgIC8vIGFzIHRoZXkgZG8gbm90IG5lZWQgYW55IHNwZWNpYWwgbG9naWNcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ0xhYmVsJywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9sYWJlbCcpLkxhYmVsKTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ0RhdGVQaWNrZXInLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL2RhdGUtcGlja2VyJykuRGF0ZVBpY2tlcik7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdBYnNvbHV0ZUxheW91dCcsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvbGF5b3V0cy9hYnNvbHV0ZS1sYXlvdXQnKS5BYnNvbHV0ZUxheW91dCk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdBY3Rpdml0eUluZGljYXRvcicsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvYWN0aXZpdHktaW5kaWNhdG9yJykuQWN0aXZpdHlJbmRpY2F0b3IpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnQm9yZGVyJywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9ib3JkZXInKS5Cb3JkZXIpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnQnV0dG9uJywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9idXR0b24nKS5CdXR0b24pO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnQ29udGVudFZpZXcnLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL2NvbnRlbnQtdmlldycpLkNvbnRlbnRWaWV3KTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ0RvY2tMYXlvdXQnLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL2xheW91dHMvZG9jay1sYXlvdXQnKS5Eb2NrTGF5b3V0KTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ0dyaWRMYXlvdXQnLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL2xheW91dHMvZ3JpZC1sYXlvdXQnKS5HcmlkTGF5b3V0KTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ0h0bWxWaWV3JywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9odG1sLXZpZXcnKS5IdG1sVmlldyk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdJbWFnZScsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvaW1hZ2UnKS5JbWFnZSk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdMaXN0UGlja2VyJywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9saXN0LXBpY2tlcicpLkxpc3RQaWNrZXIpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnUGxhY2Vob2xkZXInLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL3BsYWNlaG9sZGVyJykuUGxhY2Vob2xkZXIpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnUHJvZ3Jlc3MnLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL3Byb2dyZXNzJykuUHJvZ3Jlc3MpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnUHJveHlWaWV3Q29udGFpbmVyJywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9wcm94eS12aWV3LWNvbnRhaW5lcicpLlByb3h5Vmlld0NvbnRhaW5lcik7XHJcbiAgICAvLyByZWdpc3RlckVsZW1lbnQoXHJcbiAgICAvLyAgICdSZXBlYXRlcicsXHJcbiAgICAvLyAgICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvcmVwZWF0ZXInKS5SZXBlYXRlclxyXG4gICAgLy8gKVxyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnU2Nyb2xsVmlldycsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvc2Nyb2xsLXZpZXcnKS5TY3JvbGxWaWV3KTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ1NlYXJjaEJhcicsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvc2VhcmNoLWJhcicpLlNlYXJjaEJhcik7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdTZWdtZW50ZWRCYXInLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL3NlZ21lbnRlZC1iYXInKS5TZWdtZW50ZWRCYXIsIG51bGwsIHsgXCJpdGVtc1wiOiBOYXRpdmVFbGVtZW50UHJvcFR5cGUuQXJyYXkgfSk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdTZWdtZW50ZWRCYXJJdGVtJywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9zZWdtZW50ZWQtYmFyJykuU2VnbWVudGVkQmFySXRlbSwgXCJpdGVtc1wiKTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ1NsaWRlcicsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvc2xpZGVyJykuU2xpZGVyKTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ1N0YWNrTGF5b3V0JywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9sYXlvdXRzL3N0YWNrLWxheW91dCcpLlN0YWNrTGF5b3V0KTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ0ZsZXhib3hMYXlvdXQnLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL2xheW91dHMvZmxleGJveC1sYXlvdXQnKS5GbGV4Ym94TGF5b3V0KTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ1N3aXRjaCcsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvc3dpdGNoJykuU3dpdGNoKTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ1RleHRGaWVsZCcsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvdGV4dC1maWVsZCcpLlRleHRGaWVsZCk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdUZXh0VmlldycsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvdGV4dC12aWV3JykuVGV4dFZpZXcpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnVGltZVBpY2tlcicsICgpID0+IHJlcXVpcmUoJ3Rucy1jb3JlLW1vZHVsZXMvdWkvdGltZS1waWNrZXInKS5UaW1lUGlja2VyKTtcclxuICAgIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQoJ1dlYlZpZXcnLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL3dlYi12aWV3JykuV2ViVmlldyk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdXcmFwTGF5b3V0JywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy91aS9sYXlvdXRzL3dyYXAtbGF5b3V0JykuV3JhcExheW91dCk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdGb3JtYXR0ZWRTdHJpbmcnLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3RleHQvZm9ybWF0dGVkLXN0cmluZycpLkZvcm1hdHRlZFN0cmluZyk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdTcGFuJywgKCkgPT4gcmVxdWlyZSgndG5zLWNvcmUtbW9kdWxlcy90ZXh0L3NwYW4nKS5TcGFuKTtcclxuICAgIHJlZ2lzdGVyRWxlbWVudCgnQWN0aW9uQmFyJywgKCkgPT4gbmV3IEFjdGlvbkJhckVsZW1lbnQoKSk7XHJcbiAgICByZWdpc3RlckVsZW1lbnQoJ0ZyYW1lJywgKCkgPT4gbmV3IEZyYW1lRWxlbWVudCgpKTtcclxuICAgIHJlZ2lzdGVyRWxlbWVudCgnUGFnZScsICgpID0+IG5ldyBQYWdlRWxlbWVudCgpKTtcclxuICAgIHJlZ2lzdGVyRWxlbWVudCgnTGlzdFZpZXcnLCAoKSA9PiBuZXcgTGlzdFZpZXdFbGVtZW50KCkpO1xyXG4gICAgcmVnaXN0ZXJFbGVtZW50KCdUYWJWaWV3JywgKCkgPT4gbmV3IFRhYlZpZXdFbGVtZW50KCkpO1xyXG4gICAgcmVnaXN0ZXJFbGVtZW50KCdCb3R0b21OYXZpZ2F0aW9uJywgKCkgPT4gbmV3IEJvdHRvbU5hdmlnYXRpb25FbGVtZW50KCkpO1xyXG4gICAgcmVnaXN0ZXJFbGVtZW50KCdUYWJzJywgKCkgPT4gbmV3IFRhYnNFbGVtZW50KCkpO1xyXG4gICAgcmVnaXN0ZXJFbGVtZW50KCdUYWJTdHJpcCcsICgpID0+IG5ldyBUYWJTdHJpcEVsZW1lbnQoKSk7XHJcbiAgICByZWdpc3Rlck5hdGl2ZVZpZXdFbGVtZW50KCdUYWJTdHJpcEl0ZW0nLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL3RhYi1uYXZpZ2F0aW9uLWJhc2UvdGFiLXN0cmlwLWl0ZW0nKS5UYWJTdHJpcEl0ZW0pO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVWaWV3RWxlbWVudCgnVGFiQ29udGVudEl0ZW0nLCAoKSA9PiByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL3VpL3RhYi1uYXZpZ2F0aW9uLWJhc2UvdGFiLWNvbnRlbnQtaXRlbScpLlRhYkNvbnRlbnRJdGVtKTtcclxufVxuXG5jbGFzcyBTdmVsdGVOYXRpdmVEb2N1bWVudCBleHRlbmRzIERvY3VtZW50Tm9kZSB7XHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIHRoaXMuaGVhZCA9IGNyZWF0ZUVsZW1lbnQoJ2hlYWQnKTtcclxuICAgICAgICB0aGlzLmFwcGVuZENoaWxkKHRoaXMuaGVhZCk7XHJcbiAgICAgICAgbG9nZ2VyLmRlYnVnKGBjcmVhdGVkICR7dGhpc31gKTtcclxuICAgIH1cclxuICAgIGNyZWF0ZVRleHROb2RlKHRleHQpIHtcclxuICAgICAgICBjb25zdCBlbCA9IG5ldyBUZXh0Tm9kZSh0ZXh0KTtcclxuICAgICAgICBsb2dnZXIuZGVidWcoYGNyZWF0ZWQgJHtlbH1gKTtcclxuICAgICAgICByZXR1cm4gZWw7XHJcbiAgICB9XHJcbiAgICBjcmVhdGVFbGVtZW50TlMobmFtZXNwYWNlLCB0YWdOYW1lKSB7XHJcbiAgICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlRWxlbWVudCh0YWdOYW1lKTtcclxuICAgIH1cclxuICAgIGNyZWF0ZUV2ZW50KHR5cGUpIHtcclxuICAgICAgICBsZXQgZSA9IHt9O1xyXG4gICAgICAgIGUuaW5pdEN1c3RvbUV2ZW50ID0gKHR5cGUsIGlnbm9yZWQxLCBpZ25vcmVkMiwgZGV0YWlsKSA9PiB7XHJcbiAgICAgICAgICAgIGUudHlwZSA9IHR5cGU7XHJcbiAgICAgICAgICAgIGUuZGV0YWlsID0gZGV0YWlsO1xyXG4gICAgICAgICAgICBlLmV2ZW50TmFtZSA9IHR5cGU7XHJcbiAgICAgICAgfTtcclxuICAgICAgICByZXR1cm4gZTtcclxuICAgIH1cclxufVxuXG4vKiEgKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uIEFsbCByaWdodHMgcmVzZXJ2ZWQuXHJcbkxpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7IHlvdSBtYXkgbm90IHVzZVxyXG50aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS4gWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZVxyXG5MaWNlbnNlIGF0IGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxyXG5cclxuVEhJUyBDT0RFIElTIFBST1ZJREVEIE9OIEFOICpBUyBJUyogQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWVxyXG5LSU5ELCBFSVRIRVIgRVhQUkVTUyBPUiBJTVBMSUVELCBJTkNMVURJTkcgV0lUSE9VVCBMSU1JVEFUSU9OIEFOWSBJTVBMSUVEXHJcbldBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBUSVRMRSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UsXHJcbk1FUkNIQU5UQUJMSVRZIE9SIE5PTi1JTkZSSU5HRU1FTlQuXHJcblxyXG5TZWUgdGhlIEFwYWNoZSBWZXJzaW9uIDIuMCBMaWNlbnNlIGZvciBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnNcclxuYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xyXG5cclxuZnVuY3Rpb24gX19yZXN0KHMsIGUpIHtcclxuICAgIHZhciB0ID0ge307XHJcbiAgICBmb3IgKHZhciBwIGluIHMpIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwocywgcCkgJiYgZS5pbmRleE9mKHApIDwgMClcclxuICAgICAgICB0W3BdID0gc1twXTtcclxuICAgIGlmIChzICE9IG51bGwgJiYgdHlwZW9mIE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMgPT09IFwiZnVuY3Rpb25cIilcclxuICAgICAgICBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGlmIChlLmluZGV4T2YocFtpXSkgPCAwICYmIE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbChzLCBwW2ldKSlcclxuICAgICAgICAgICAgICAgIHRbcFtpXV0gPSBzW3BbaV1dO1xyXG4gICAgICAgIH1cclxuICAgIHJldHVybiB0O1xyXG59XG5cbmZ1bmN0aW9uIHJlc29sdmVGcmFtZShmcmFtZVNwZWMpIHtcclxuICAgIGxldCB0YXJnZXRGcmFtZTtcclxuICAgIGlmICghZnJhbWVTcGVjKVxyXG4gICAgICAgIHRhcmdldEZyYW1lID0gdG9wbW9zdCgpO1xyXG4gICAgaWYgKGZyYW1lU3BlYyBpbnN0YW5jZW9mIEZyYW1lRWxlbWVudClcclxuICAgICAgICB0YXJnZXRGcmFtZSA9IGZyYW1lU3BlYy5uYXRpdmVWaWV3O1xyXG4gICAgaWYgKGZyYW1lU3BlYyBpbnN0YW5jZW9mIEZyYW1lKVxyXG4gICAgICAgIHRhcmdldEZyYW1lID0gZnJhbWVTcGVjO1xyXG4gICAgaWYgKHR5cGVvZiBmcmFtZVNwZWMgPT0gXCJzdHJpbmdcIikge1xyXG4gICAgICAgIHRhcmdldEZyYW1lID0gRnJhbWUuZ2V0RnJhbWVCeUlkKGZyYW1lU3BlYyk7XHJcbiAgICAgICAgaWYgKCF0YXJnZXRGcmFtZSlcclxuICAgICAgICAgICAgbG9nZ2VyLmVycm9yKGBOYXZpZ2F0ZSBjb3VsZCBub3QgZmluZCBmcmFtZSB3aXRoIGlkICR7ZnJhbWVTcGVjfWApO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRhcmdldEZyYW1lO1xyXG59XHJcbmZ1bmN0aW9uIHJlc29sdmVDb21wb25lbnRFbGVtZW50KHBhZ2VTcGVjLCBwcm9wcykge1xyXG4gICAgbGV0IGR1bW15ID0gY3JlYXRlRWxlbWVudCgnZnJhZ21lbnQnKTtcclxuICAgIGxldCBwYWdlSW5zdGFuY2UgPSBuZXcgcGFnZVNwZWMoeyB0YXJnZXQ6IGR1bW15LCBwcm9wczogcHJvcHMgfSk7XHJcbiAgICBsZXQgZWxlbWVudCA9IGR1bW15LmZpcnN0RWxlbWVudCgpO1xyXG4gICAgcmV0dXJuIHsgZWxlbWVudCwgcGFnZUluc3RhbmNlIH07XHJcbn1cclxuZnVuY3Rpb24gbmF2aWdhdGUob3B0aW9ucykge1xyXG4gICAgbGV0IHsgZnJhbWUsIHBhZ2UsIHByb3BzID0ge30gfSA9IG9wdGlvbnMsIG5hdk9wdGlvbnMgPSBfX3Jlc3Qob3B0aW9ucywgW1wiZnJhbWVcIiwgXCJwYWdlXCIsIFwicHJvcHNcIl0pO1xyXG4gICAgbGV0IHRhcmdldEZyYW1lID0gcmVzb2x2ZUZyYW1lKGZyYW1lKTtcclxuICAgIGlmICghdGFyZ2V0RnJhbWUpIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJuYXZpZ2F0ZSByZXF1aXJlcyBmcmFtZSBvcHRpb24gdG8gYmUgYSBuYXRpdmUgRnJhbWUsIGEgRnJhbWVFbGVtZW50LCBhIGZyYW1lIElkLCBvciBudWxsXCIpO1xyXG4gICAgfVxyXG4gICAgaWYgKCFwYWdlKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwibmF2aWdhdGUgcmVxdWlyZXMgcGFnZSB0byBiZSBzZXQgdG8gdGhlIHN2ZWx0ZSBjb21wb25lbnQgY2xhc3MgdGhhdCBpbXBsZW1lbnRzIHRoZSBwYWdlIG9yIHJlZmVyZW5jZSB0byBhIHBhZ2UgZWxlbWVudFwiKTtcclxuICAgIH1cclxuICAgIGxldCB7IGVsZW1lbnQsIHBhZ2VJbnN0YW5jZSB9ID0gcmVzb2x2ZUNvbXBvbmVudEVsZW1lbnQocGFnZSwgcHJvcHMpO1xyXG4gICAgaWYgKCEoZWxlbWVudCBpbnN0YW5jZW9mIFBhZ2VFbGVtZW50KSlcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJuYXZpZ2F0ZSByZXF1aXJlcyBhIHN2ZWx0ZSBjb21wb25lbnQgd2l0aCBhIHBhZ2UgZWxlbWVudCBhdCB0aGUgcm9vdFwiKTtcclxuICAgIGxldCBuYXRpdmVQYWdlID0gZWxlbWVudC5uYXRpdmVWaWV3O1xyXG4gICAgY29uc3QgaGFuZGxlciA9IChhcmdzKSA9PiB7XHJcbiAgICAgICAgaWYgKGFyZ3MuaXNCYWNrTmF2aWdhdGlvbikge1xyXG4gICAgICAgICAgICBuYXRpdmVQYWdlLm9mZignbmF2aWdhdGVkRnJvbScsIGhhbmRsZXIpO1xyXG4gICAgICAgICAgICBwYWdlSW5zdGFuY2UuJGRlc3Ryb3koKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgbmF0aXZlUGFnZS5vbignbmF2aWdhdGVkRnJvbScsIGhhbmRsZXIpO1xyXG4gICAgdGFyZ2V0RnJhbWUubmF2aWdhdGUoT2JqZWN0LmFzc2lnbihPYmplY3QuYXNzaWduKHt9LCBuYXZPcHRpb25zKSwgeyBjcmVhdGU6ICgpID0+IG5hdGl2ZVBhZ2UgfSkpO1xyXG4gICAgcmV0dXJuIHBhZ2VJbnN0YW5jZTtcclxufVxyXG5mdW5jdGlvbiBnb0JhY2sob3B0aW9ucyA9IHt9KSB7XHJcbiAgICBsZXQgdGFyZ2V0RnJhbWUgPSByZXNvbHZlRnJhbWUob3B0aW9ucy5mcmFtZSk7XHJcbiAgICBpZiAoIXRhcmdldEZyYW1lKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiZ29iYWNrIHJlcXVpcmVzIGZyYW1lIG9wdGlvbiB0byBiZSBhIG5hdGl2ZSBGcmFtZSwgYSBGcmFtZUVsZW1lbnQsIGEgZnJhbWUgSWQsIG9yIG51bGxcIik7XHJcbiAgICB9XHJcbiAgICBsZXQgYmFja1N0YWNrRW50cnkgPSBudWxsO1xyXG4gICAgaWYgKG9wdGlvbnMudG8pIHtcclxuICAgICAgICBiYWNrU3RhY2tFbnRyeSA9IHRhcmdldEZyYW1lLmJhY2tTdGFjay5maW5kKGUgPT4gZS5yZXNvbHZlZFBhZ2UgPT09IG9wdGlvbnMudG8ubmF0aXZlVmlldyk7XHJcbiAgICAgICAgaWYgKCFiYWNrU3RhY2tFbnRyeSkge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDb3VsZG4ndCBmaW5kIHRoZSBkZXN0aW5hdGlvbiBwYWdlIGluIHRoZSBmcmFtZXMgYmFja3N0YWNrXCIpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiB0YXJnZXRGcmFtZS5nb0JhY2soYmFja1N0YWNrRW50cnkpO1xyXG59XHJcbmNvbnN0IG1vZGFsU3RhY2sgPSBbXTtcclxuZnVuY3Rpb24gc2hvd01vZGFsKG1vZGFsT3B0aW9ucykge1xyXG4gICAgbGV0IHsgcGFnZSwgcHJvcHMgPSB7fSB9ID0gbW9kYWxPcHRpb25zLCBvcHRpb25zID0gX19yZXN0KG1vZGFsT3B0aW9ucywgW1wicGFnZVwiLCBcInByb3BzXCJdKTtcclxuICAgIC8vR2V0IHRoaXMgYmVmb3JlIGFueSBwb3RlbnRpYWwgbmV3IGZyYW1lcyBhcmUgY3JlYXRlZCBieSBjb21wb25lbnQgYmVsb3dcclxuICAgIGxldCBtb2RhbExhdW5jaGVyID0gdG9wbW9zdCgpLmN1cnJlbnRQYWdlO1xyXG4gICAgbGV0IGNvbXBvbmVudEluc3RhbmNlSW5mbyA9IHJlc29sdmVDb21wb25lbnRFbGVtZW50KHBhZ2UsIHByb3BzKTtcclxuICAgIGxldCBtb2RhbFZpZXcgPSBjb21wb25lbnRJbnN0YW5jZUluZm8uZWxlbWVudC5uYXRpdmVWaWV3O1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBsZXQgcmVzb2x2ZWQgPSBmYWxzZTtcclxuICAgICAgICBjb25zdCBjbG9zZUNhbGxiYWNrID0gKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAocmVzb2x2ZWQpXHJcbiAgICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIHJlc29sdmVkID0gdHJ1ZTtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGNvbXBvbmVudEluc3RhbmNlSW5mby5wYWdlSW5zdGFuY2UuJGRlc3Ryb3koKTsgLy9kb24ndCBsZXQgYW4gZXhjZXB0aW9uIGluIGRlc3Ryb3kga2lsbCB0aGUgcHJvbWlzZSBjYWxsYmFja1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGZpbmFsbHkge1xyXG4gICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN1bHQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfTtcclxuICAgICAgICBtb2RhbFN0YWNrLnB1c2goY29tcG9uZW50SW5zdGFuY2VJbmZvKTtcclxuICAgICAgICBtb2RhbExhdW5jaGVyLnNob3dNb2RhbChtb2RhbFZpZXcsIE9iamVjdC5hc3NpZ24oT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucyksIHsgY29udGV4dDoge30sIGNsb3NlQ2FsbGJhY2sgfSkpO1xyXG4gICAgfSk7XHJcbn1cclxuZnVuY3Rpb24gY2xvc2VNb2RhbChyZXN1bHQpIHtcclxuICAgIGxldCBtb2RhbFBhZ2VJbnN0YW5jZUluZm8gPSBtb2RhbFN0YWNrLnBvcCgpO1xyXG4gICAgbW9kYWxQYWdlSW5zdGFuY2VJbmZvLmVsZW1lbnQubmF0aXZlVmlldy5jbG9zZU1vZGFsKHJlc3VsdCk7XHJcbn1cblxuZnVuY3Rpb24gaW5zdGFsbEdsb2JhbFNoaW1zKCkge1xyXG4gICAgLy9leHBvc2Ugb3VyIGZha2UgZG9tIGFzIGdsb2JhbCBkb2N1bWVudCBmb3Igc3ZlbHRlIGNvbXBvbmVudHNcclxuICAgIGxldCB3aW5kb3cgPSBnbG9iYWw7XHJcbiAgICB3aW5kb3cud2luZG93ID0gZ2xvYmFsO1xyXG4gICAgd2luZG93LmRvY3VtZW50ID0gbmV3IFN2ZWx0ZU5hdGl2ZURvY3VtZW50KCk7XHJcbiAgICBpZiAoIXdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUpIHtcclxuICAgICAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lID0gKGFjdGlvbikgPT4ge1xyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGFjdGlvbih3aW5kb3cucGVyZm9ybWFuY2Uubm93KCkpLCAzMyk7IC8vYWJvdXQgMzAgZnBzXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuICAgIHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlID0gKG5vZGUpID0+IHtcclxuICAgICAgICByZXR1cm4gbm9kZS5uYXRpdmVWaWV3LnN0eWxlO1xyXG4gICAgfTtcclxuICAgIHdpbmRvdy5wZXJmb3JtYW5jZSA9IHtcclxuICAgICAgICBub3coKSB7XHJcbiAgICAgICAgICAgIHJldHVybiBEYXRlLm5vdygpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcbiAgICB3aW5kb3cuQ3VzdG9tRXZlbnQgPSBjbGFzcyB7XHJcbiAgICAgICAgY29uc3RydWN0b3IobmFtZSwgZGV0YWlsID0gbnVsbCkge1xyXG4gICAgICAgICAgICB0aGlzLmV2ZW50TmFtZSA9IG5hbWU7IC8vZXZlbnQgbmFtZSBmb3IgbmF0aXZlc2NyaXB0XHJcbiAgICAgICAgICAgIHRoaXMudHlwZSA9IG5hbWU7IC8vIHR5cGUgZm9yIHN2ZWx0ZVxyXG4gICAgICAgICAgICB0aGlzLmRldGFpbCA9IGRldGFpbDtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIHdpbmRvdy5kb2N1bWVudDtcclxufVxyXG5jb25zdCBEb21UcmFjZUNhdGVnb3J5ID0gJ1N2ZWx0ZU5hdGl2ZURvbSc7XHJcbmZ1bmN0aW9uIGluaXRpYWxpemVMb2dnZXIoKSB7XHJcbiAgICBsb2dnZXIuc2V0SGFuZGxlcigobWVzc2FnZSwgbGV2ZWwpID0+IHtcclxuICAgICAgICBsZXQgdHJhY2VMZXZlbCA9IG1lc3NhZ2VUeXBlLmxvZztcclxuICAgICAgICBzd2l0Y2ggKGxldmVsKSB7XHJcbiAgICAgICAgICAgIGNhc2UgTG9nTGV2ZWwuRGVidWc6XHJcbiAgICAgICAgICAgICAgICB0cmFjZUxldmVsID0gbWVzc2FnZVR5cGUubG9nO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgTG9nTGV2ZWwuSW5mbzpcclxuICAgICAgICAgICAgICAgIHRyYWNlTGV2ZWwgPSBtZXNzYWdlVHlwZS5pbmZvO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgTG9nTGV2ZWwuV2FybjpcclxuICAgICAgICAgICAgICAgIHRyYWNlTGV2ZWwgPSBtZXNzYWdlVHlwZS53YXJuO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICAgIGNhc2UgTG9nTGV2ZWwuRXJyb3I6XHJcbiAgICAgICAgICAgICAgICB0cmFjZUxldmVsID0gbWVzc2FnZVR5cGUuZXJyb3I7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICAgICAgd3JpdGUobWVzc2FnZSwgRG9tVHJhY2VDYXRlZ29yeSwgdHJhY2VMZXZlbCk7XHJcbiAgICB9KTtcclxufVxyXG5mdW5jdGlvbiBpbml0aWFsaXplRG9tKCkge1xyXG4gICAgaW5pdGlhbGl6ZUxvZ2dlcigpO1xyXG4gICAgcmVnaXN0ZXJTdmVsdGVFbGVtZW50cygpO1xyXG4gICAgcmVnaXN0ZXJOYXRpdmVFbGVtZW50cygpO1xyXG4gICAgcmV0dXJuIGluc3RhbGxHbG9iYWxTaGltcygpO1xyXG59XG5cbmV4cG9ydCB7IEFjdGlvbkJhckVsZW1lbnQsIEJvdHRvbU5hdmlnYXRpb25FbGVtZW50LCBEb21UcmFjZUNhdGVnb3J5LCBFbGVtZW50Tm9kZSwgRnJhbWVFbGVtZW50LCBIZWFkRWxlbWVudCwgTGlzdFZpZXdFbGVtZW50LCBMb2dMZXZlbCwgTmF0aXZlRWxlbWVudE5vZGUsIE5hdGl2ZUVsZW1lbnRQcm9wVHlwZSwgTmF0aXZlVmlld0VsZW1lbnROb2RlLCBQYWdlRWxlbWVudCwgU3R5bGVFbGVtZW50LCBTdmVsdGVLZXllZFRlbXBsYXRlLCBTdmVsdGVOYXRpdmVEb2N1bWVudCwgVGFic0VsZW1lbnQsIFRlbXBsYXRlRWxlbWVudCwgVmlld05vZGUsIGNsb3NlTW9kYWwsIGNyZWF0ZUVsZW1lbnQsIGdvQmFjaywgaW5pdGlhbGl6ZURvbSwgbG9nZ2VyLCBuYXZpZ2F0ZSwgcmVnaXN0ZXJFbGVtZW50LCByZWdpc3Rlck5hdGl2ZUNvbmZpZ0VsZW1lbnQsIHJlZ2lzdGVyTmF0aXZlVmlld0VsZW1lbnQsIHNob3dNb2RhbCB9O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuXG52YXIgYXBwbGljYXRpb24gPSByZXF1aXJlKCd0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uJyk7XG52YXIgZG9tID0gcmVxdWlyZSgnLi9kb20nKTtcblxuZnVuY3Rpb24gc3ZlbHRlTmF0aXZlTm9GcmFtZShyb290RWxlbWVudCwgZGF0YSkge1xyXG4gICAgZG9tLmluaXRpYWxpemVEb20oKTtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgbGV0IGVsZW1lbnRJbnN0YW5jZTtcclxuICAgICAgICBjb25zdCBidWlsZEVsZW1lbnQgPSAoKSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBmcmFnID0gZG9tLmNyZWF0ZUVsZW1lbnQoJ2ZyYWdtZW50Jyk7XHJcbiAgICAgICAgICAgIGVsZW1lbnRJbnN0YW5jZSA9IG5ldyByb290RWxlbWVudCh7XHJcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IGZyYWcsXHJcbiAgICAgICAgICAgICAgICBwcm9wczogZGF0YSB8fCB7fVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgcmV0dXJuIGZyYWcuZmlyc3RDaGlsZC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgLy93YWl0IGZvciBsYXVuY2ggYmVmb3JlIHJldHVybmluZ1xyXG4gICAgICAgIGFwcGxpY2F0aW9uLm9uKGFwcGxpY2F0aW9uLmxhdW5jaEV2ZW50LCAoKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQXBwbGljYXRpb24gTGF1bmNoZWRcIik7XHJcbiAgICAgICAgICAgIHJlc29sdmUoZWxlbWVudEluc3RhbmNlKTtcclxuICAgICAgICB9KTtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBhcHBsaWNhdGlvbi5ydW4oeyBjcmVhdGU6IGJ1aWxkRWxlbWVudCB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG59XHJcbmZ1bmN0aW9uIHN2ZWx0ZU5hdGl2ZShzdGFydFBhZ2UsIGRhdGEpIHtcclxuICAgIGRvbS5pbml0aWFsaXplRG9tKCk7XHJcbiAgICBsZXQgcm9vdEZyYW1lO1xyXG4gICAgbGV0IHBhZ2VJbnN0YW5jZTtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgLy93YWl0IGZvciBsYXVuY2hcclxuICAgICAgICBhcHBsaWNhdGlvbi5vbihhcHBsaWNhdGlvbi5sYXVuY2hFdmVudCwgKCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFwcGxpY2F0aW9uIExhdW5jaGVkXCIpO1xyXG4gICAgICAgICAgICByZXNvbHZlKHBhZ2VJbnN0YW5jZSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgYXBwbGljYXRpb24ucnVuKHsgY3JlYXRlOiAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgcm9vdEZyYW1lID0gZG9tLmNyZWF0ZUVsZW1lbnQoJ2ZyYW1lJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcm9vdEZyYW1lLnNldEF0dHJpYnV0ZShcImlkXCIsIFwiYXBwLXJvb3QtZnJhbWVcIik7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFnZUluc3RhbmNlID0gZG9tLm5hdmlnYXRlKHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGFnZTogc3RhcnRQYWdlLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9wczogZGF0YSB8fCB7fSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgZnJhbWU6IHJvb3RGcmFtZVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByb290RnJhbWUubmF0aXZlVmlldztcclxuICAgICAgICAgICAgICAgIH0gfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIHJlamVjdChlKTtcclxuICAgICAgICB9XHJcbiAgICB9KTtcclxufVxyXG4vLyBTdmVsdGUgbG9va3MgdG8gc2VlIGlmIHdpbmRvdyBpcyB1bmRlZmluZWQgaW4gb3JkZXIgdG8gZGV0ZXJtaW5lIGlmIGl0IGlzIHJ1bm5pbmcgb24gdGhlIGNsaWVudCBvciBpbiBTU1IuXHJcbi8vIHdpbmRvdyBpcyB1bmRlZmluZWQgdW50aWwgaW5pdGlhbGl6ZURvbSBpcyBjYWxsZWQuIFdlIHdpbGwgc2V0IGl0IHRvIGEgdGVtcG9yYXJ5IHZhbHVlIGhlcmUgYW5kIG92ZXJ3cml0ZSBpdCBpbiBpbnRpYWxpemVkb20uXHJcbmdsb2JhbC53aW5kb3cgPSB7IGVudjogXCJTdmVsdGUgTmF0aXZlXCIgfTtcblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdEb21UcmFjZUNhdGVnb3J5Jywge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBkb20uRG9tVHJhY2VDYXRlZ29yeTtcbiAgICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnY2xvc2VNb2RhbCcsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gZG9tLmNsb3NlTW9kYWw7XG4gICAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ2dvQmFjaycsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gZG9tLmdvQmFjaztcbiAgICB9XG59KTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnaW5pdGlhbGl6ZURvbScsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gZG9tLmluaXRpYWxpemVEb207XG4gICAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ25hdmlnYXRlJywge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBkb20ubmF2aWdhdGU7XG4gICAgfVxufSk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ3Nob3dNb2RhbCcsIHtcbiAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gZG9tLnNob3dNb2RhbDtcbiAgICB9XG59KTtcbmV4cG9ydHMuc3ZlbHRlTmF0aXZlID0gc3ZlbHRlTmF0aXZlO1xuZXhwb3J0cy5zdmVsdGVOYXRpdmVOb0ZyYW1lID0gc3ZlbHRlTmF0aXZlTm9GcmFtZTtcbiIsImZ1bmN0aW9uIG5vb3AoKSB7IH1cbmNvbnN0IGlkZW50aXR5ID0geCA9PiB4O1xuZnVuY3Rpb24gYXNzaWduKHRhciwgc3JjKSB7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGZvciAoY29uc3QgayBpbiBzcmMpXG4gICAgICAgIHRhcltrXSA9IHNyY1trXTtcbiAgICByZXR1cm4gdGFyO1xufVxuZnVuY3Rpb24gaXNfcHJvbWlzZSh2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHR5cGVvZiB2YWx1ZS50aGVuID09PSAnZnVuY3Rpb24nO1xufVxuZnVuY3Rpb24gYWRkX2xvY2F0aW9uKGVsZW1lbnQsIGZpbGUsIGxpbmUsIGNvbHVtbiwgY2hhcikge1xuICAgIGVsZW1lbnQuX19zdmVsdGVfbWV0YSA9IHtcbiAgICAgICAgbG9jOiB7IGZpbGUsIGxpbmUsIGNvbHVtbiwgY2hhciB9XG4gICAgfTtcbn1cbmZ1bmN0aW9uIHJ1bihmbikge1xuICAgIHJldHVybiBmbigpO1xufVxuZnVuY3Rpb24gYmxhbmtfb2JqZWN0KCkge1xuICAgIHJldHVybiBPYmplY3QuY3JlYXRlKG51bGwpO1xufVxuZnVuY3Rpb24gcnVuX2FsbChmbnMpIHtcbiAgICBmbnMuZm9yRWFjaChydW4pO1xufVxuZnVuY3Rpb24gaXNfZnVuY3Rpb24odGhpbmcpIHtcbiAgICByZXR1cm4gdHlwZW9mIHRoaW5nID09PSAnZnVuY3Rpb24nO1xufVxuZnVuY3Rpb24gc2FmZV9ub3RfZXF1YWwoYSwgYikge1xuICAgIHJldHVybiBhICE9IGEgPyBiID09IGIgOiBhICE9PSBiIHx8ICgoYSAmJiB0eXBlb2YgYSA9PT0gJ29iamVjdCcpIHx8IHR5cGVvZiBhID09PSAnZnVuY3Rpb24nKTtcbn1cbmZ1bmN0aW9uIG5vdF9lcXVhbChhLCBiKSB7XG4gICAgcmV0dXJuIGEgIT0gYSA/IGIgPT0gYiA6IGEgIT09IGI7XG59XG5mdW5jdGlvbiB2YWxpZGF0ZV9zdG9yZShzdG9yZSwgbmFtZSkge1xuICAgIGlmICghc3RvcmUgfHwgdHlwZW9mIHN0b3JlLnN1YnNjcmliZSAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCcke25hbWV9JyBpcyBub3QgYSBzdG9yZSB3aXRoIGEgJ3N1YnNjcmliZScgbWV0aG9kYCk7XG4gICAgfVxufVxuZnVuY3Rpb24gc3Vic2NyaWJlKHN0b3JlLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IHVuc3ViID0gc3RvcmUuc3Vic2NyaWJlKGNhbGxiYWNrKTtcbiAgICByZXR1cm4gdW5zdWIudW5zdWJzY3JpYmUgPyAoKSA9PiB1bnN1Yi51bnN1YnNjcmliZSgpIDogdW5zdWI7XG59XG5mdW5jdGlvbiBnZXRfc3RvcmVfdmFsdWUoc3RvcmUpIHtcbiAgICBsZXQgdmFsdWU7XG4gICAgc3Vic2NyaWJlKHN0b3JlLCBfID0+IHZhbHVlID0gXykoKTtcbiAgICByZXR1cm4gdmFsdWU7XG59XG5mdW5jdGlvbiBjb21wb25lbnRfc3Vic2NyaWJlKGNvbXBvbmVudCwgc3RvcmUsIGNhbGxiYWNrKSB7XG4gICAgY29tcG9uZW50LiQkLm9uX2Rlc3Ryb3kucHVzaChzdWJzY3JpYmUoc3RvcmUsIGNhbGxiYWNrKSk7XG59XG5mdW5jdGlvbiBjcmVhdGVfc2xvdChkZWZpbml0aW9uLCBjdHgsICQkc2NvcGUsIGZuKSB7XG4gICAgaWYgKGRlZmluaXRpb24pIHtcbiAgICAgICAgY29uc3Qgc2xvdF9jdHggPSBnZXRfc2xvdF9jb250ZXh0KGRlZmluaXRpb24sIGN0eCwgJCRzY29wZSwgZm4pO1xuICAgICAgICByZXR1cm4gZGVmaW5pdGlvblswXShzbG90X2N0eCk7XG4gICAgfVxufVxuZnVuY3Rpb24gZ2V0X3Nsb3RfY29udGV4dChkZWZpbml0aW9uLCBjdHgsICQkc2NvcGUsIGZuKSB7XG4gICAgcmV0dXJuIGRlZmluaXRpb25bMV0gJiYgZm5cbiAgICAgICAgPyBhc3NpZ24oJCRzY29wZS5jdHguc2xpY2UoKSwgZGVmaW5pdGlvblsxXShmbihjdHgpKSlcbiAgICAgICAgOiAkJHNjb3BlLmN0eDtcbn1cbmZ1bmN0aW9uIGdldF9zbG90X2NoYW5nZXMoZGVmaW5pdGlvbiwgJCRzY29wZSwgZGlydHksIGZuKSB7XG4gICAgaWYgKGRlZmluaXRpb25bMl0gJiYgZm4pIHtcbiAgICAgICAgY29uc3QgbGV0cyA9IGRlZmluaXRpb25bMl0oZm4oZGlydHkpKTtcbiAgICAgICAgaWYgKCQkc2NvcGUuZGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IG1lcmdlZCA9IFtdO1xuICAgICAgICAgICAgY29uc3QgbGVuID0gTWF0aC5tYXgoJCRzY29wZS5kaXJ0eS5sZW5ndGgsIGxldHMubGVuZ3RoKTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpICs9IDEpIHtcbiAgICAgICAgICAgICAgICBtZXJnZWRbaV0gPSAkJHNjb3BlLmRpcnR5W2ldIHwgbGV0c1tpXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBtZXJnZWQ7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGxldHM7XG4gICAgfVxuICAgIHJldHVybiAkJHNjb3BlLmRpcnR5O1xufVxuZnVuY3Rpb24gZXhjbHVkZV9pbnRlcm5hbF9wcm9wcyhwcm9wcykge1xuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGZvciAoY29uc3QgayBpbiBwcm9wcylcbiAgICAgICAgaWYgKGtbMF0gIT09ICckJylcbiAgICAgICAgICAgIHJlc3VsdFtrXSA9IHByb3BzW2tdO1xuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBvbmNlKGZuKSB7XG4gICAgbGV0IHJhbiA9IGZhbHNlO1xuICAgIHJldHVybiBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgICBpZiAocmFuKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICByYW4gPSB0cnVlO1xuICAgICAgICBmbi5jYWxsKHRoaXMsIC4uLmFyZ3MpO1xuICAgIH07XG59XG5mdW5jdGlvbiBudWxsX3RvX2VtcHR5KHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlID09IG51bGwgPyAnJyA6IHZhbHVlO1xufVxuZnVuY3Rpb24gc2V0X3N0b3JlX3ZhbHVlKHN0b3JlLCByZXQsIHZhbHVlID0gcmV0KSB7XG4gICAgc3RvcmUuc2V0KHZhbHVlKTtcbiAgICByZXR1cm4gcmV0O1xufVxuY29uc3QgaGFzX3Byb3AgPSAob2JqLCBwcm9wKSA9PiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKTtcblxuY29uc3QgaXNfY2xpZW50ID0gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCc7XG5sZXQgbm93ID0gaXNfY2xpZW50XG4gICAgPyAoKSA9PiB3aW5kb3cucGVyZm9ybWFuY2Uubm93KClcbiAgICA6ICgpID0+IERhdGUubm93KCk7XG5sZXQgcmFmID0gaXNfY2xpZW50ID8gY2IgPT4gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGNiKSA6IG5vb3A7XG4vLyB1c2VkIGludGVybmFsbHkgZm9yIHRlc3RpbmdcbmZ1bmN0aW9uIHNldF9ub3coZm4pIHtcbiAgICBub3cgPSBmbjtcbn1cbmZ1bmN0aW9uIHNldF9yYWYoZm4pIHtcbiAgICByYWYgPSBmbjtcbn1cblxuY29uc3QgdGFza3MgPSBuZXcgU2V0KCk7XG5mdW5jdGlvbiBydW5fdGFza3Mobm93KSB7XG4gICAgdGFza3MuZm9yRWFjaCh0YXNrID0+IHtcbiAgICAgICAgaWYgKCF0YXNrLmMobm93KSkge1xuICAgICAgICAgICAgdGFza3MuZGVsZXRlKHRhc2spO1xuICAgICAgICAgICAgdGFzay5mKCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBpZiAodGFza3Muc2l6ZSAhPT0gMClcbiAgICAgICAgcmFmKHJ1bl90YXNrcyk7XG59XG4vKipcbiAqIEZvciB0ZXN0aW5nIHB1cnBvc2VzIG9ubHkhXG4gKi9cbmZ1bmN0aW9uIGNsZWFyX2xvb3BzKCkge1xuICAgIHRhc2tzLmNsZWFyKCk7XG59XG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgdGFzayB0aGF0IHJ1bnMgb24gZWFjaCByYWYgZnJhbWVcbiAqIHVudGlsIGl0IHJldHVybnMgYSBmYWxzeSB2YWx1ZSBvciBpcyBhYm9ydGVkXG4gKi9cbmZ1bmN0aW9uIGxvb3AoY2FsbGJhY2spIHtcbiAgICBsZXQgdGFzaztcbiAgICBpZiAodGFza3Muc2l6ZSA9PT0gMClcbiAgICAgICAgcmFmKHJ1bl90YXNrcyk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcHJvbWlzZTogbmV3IFByb21pc2UoZnVsZmlsbCA9PiB7XG4gICAgICAgICAgICB0YXNrcy5hZGQodGFzayA9IHsgYzogY2FsbGJhY2ssIGY6IGZ1bGZpbGwgfSk7XG4gICAgICAgIH0pLFxuICAgICAgICBhYm9ydCgpIHtcbiAgICAgICAgICAgIHRhc2tzLmRlbGV0ZSh0YXNrKTtcbiAgICAgICAgfVxuICAgIH07XG59XG5cbmZ1bmN0aW9uIGFwcGVuZCh0YXJnZXQsIG5vZGUpIHtcbiAgICB0YXJnZXQuYXBwZW5kQ2hpbGQobm9kZSk7XG59XG5mdW5jdGlvbiBpbnNlcnQodGFyZ2V0LCBub2RlLCBhbmNob3IpIHtcbiAgICB0YXJnZXQuaW5zZXJ0QmVmb3JlKG5vZGUsIGFuY2hvciB8fCBudWxsKTtcbn1cbmZ1bmN0aW9uIGRldGFjaChub2RlKSB7XG4gICAgbm9kZS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKG5vZGUpO1xufVxuZnVuY3Rpb24gZGVzdHJveV9lYWNoKGl0ZXJhdGlvbnMsIGRldGFjaGluZykge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlcmF0aW9ucy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICBpZiAoaXRlcmF0aW9uc1tpXSlcbiAgICAgICAgICAgIGl0ZXJhdGlvbnNbaV0uZChkZXRhY2hpbmcpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGVsZW1lbnQobmFtZSkge1xuICAgIHJldHVybiBkb2N1bWVudC5jcmVhdGVFbGVtZW50KG5hbWUpO1xufVxuZnVuY3Rpb24gZWxlbWVudF9pcyhuYW1lLCBpcykge1xuICAgIHJldHVybiBkb2N1bWVudC5jcmVhdGVFbGVtZW50KG5hbWUsIHsgaXMgfSk7XG59XG5mdW5jdGlvbiBvYmplY3Rfd2l0aG91dF9wcm9wZXJ0aWVzKG9iaiwgZXhjbHVkZSkge1xuICAgIGNvbnN0IHRhcmdldCA9IHt9O1xuICAgIGZvciAoY29uc3QgayBpbiBvYmopIHtcbiAgICAgICAgaWYgKGhhc19wcm9wKG9iaiwgaylcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgICYmIGV4Y2x1ZGUuaW5kZXhPZihrKSA9PT0gLTEpIHtcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgIHRhcmdldFtrXSA9IG9ialtrXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0O1xufVxuZnVuY3Rpb24gc3ZnX2VsZW1lbnQobmFtZSkge1xuICAgIHJldHVybiBkb2N1bWVudC5jcmVhdGVFbGVtZW50TlMoJ2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJywgbmFtZSk7XG59XG5mdW5jdGlvbiB0ZXh0KGRhdGEpIHtcbiAgICByZXR1cm4gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoZGF0YSk7XG59XG5mdW5jdGlvbiBzcGFjZSgpIHtcbiAgICByZXR1cm4gdGV4dCgnICcpO1xufVxuZnVuY3Rpb24gZW1wdHkoKSB7XG4gICAgcmV0dXJuIHRleHQoJycpO1xufVxuZnVuY3Rpb24gbGlzdGVuKG5vZGUsIGV2ZW50LCBoYW5kbGVyLCBvcHRpb25zKSB7XG4gICAgbm9kZS5hZGRFdmVudExpc3RlbmVyKGV2ZW50LCBoYW5kbGVyLCBvcHRpb25zKTtcbiAgICByZXR1cm4gKCkgPT4gbm9kZS5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCBoYW5kbGVyLCBvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIHByZXZlbnRfZGVmYXVsdChmbikge1xuICAgIHJldHVybiBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICByZXR1cm4gZm4uY2FsbCh0aGlzLCBldmVudCk7XG4gICAgfTtcbn1cbmZ1bmN0aW9uIHN0b3BfcHJvcGFnYXRpb24oZm4pIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgIHJldHVybiBmbi5jYWxsKHRoaXMsIGV2ZW50KTtcbiAgICB9O1xufVxuZnVuY3Rpb24gc2VsZihmbikge1xuICAgIHJldHVybiBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0ID09PSB0aGlzKVxuICAgICAgICAgICAgZm4uY2FsbCh0aGlzLCBldmVudCk7XG4gICAgfTtcbn1cbmZ1bmN0aW9uIGF0dHIobm9kZSwgYXR0cmlidXRlLCB2YWx1ZSkge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKVxuICAgICAgICBub2RlLnJlbW92ZUF0dHJpYnV0ZShhdHRyaWJ1dGUpO1xuICAgIGVsc2UgaWYgKG5vZGUuZ2V0QXR0cmlidXRlKGF0dHJpYnV0ZSkgIT09IHZhbHVlKVxuICAgICAgICBub2RlLnNldEF0dHJpYnV0ZShhdHRyaWJ1dGUsIHZhbHVlKTtcbn1cbmZ1bmN0aW9uIHNldF9hdHRyaWJ1dGVzKG5vZGUsIGF0dHJpYnV0ZXMpIHtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgY29uc3QgZGVzY3JpcHRvcnMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhub2RlLl9fcHJvdG9fXyk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gYXR0cmlidXRlcykge1xuICAgICAgICBpZiAoYXR0cmlidXRlc1trZXldID09IG51bGwpIHtcbiAgICAgICAgICAgIG5vZGUucmVtb3ZlQXR0cmlidXRlKGtleSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoa2V5ID09PSAnc3R5bGUnKSB7XG4gICAgICAgICAgICBub2RlLnN0eWxlLmNzc1RleHQgPSBhdHRyaWJ1dGVzW2tleV07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZGVzY3JpcHRvcnNba2V5XSAmJiBkZXNjcmlwdG9yc1trZXldLnNldCkge1xuICAgICAgICAgICAgbm9kZVtrZXldID0gYXR0cmlidXRlc1trZXldO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYXR0cihub2RlLCBrZXksIGF0dHJpYnV0ZXNba2V5XSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5mdW5jdGlvbiBzZXRfc3ZnX2F0dHJpYnV0ZXMobm9kZSwgYXR0cmlidXRlcykge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGF0dHJpYnV0ZXMpIHtcbiAgICAgICAgYXR0cihub2RlLCBrZXksIGF0dHJpYnV0ZXNba2V5XSk7XG4gICAgfVxufVxuZnVuY3Rpb24gc2V0X2N1c3RvbV9lbGVtZW50X2RhdGEobm9kZSwgcHJvcCwgdmFsdWUpIHtcbiAgICBpZiAocHJvcCBpbiBub2RlKSB7XG4gICAgICAgIG5vZGVbcHJvcF0gPSB2YWx1ZTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGF0dHIobm9kZSwgcHJvcCwgdmFsdWUpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHhsaW5rX2F0dHIobm9kZSwgYXR0cmlidXRlLCB2YWx1ZSkge1xuICAgIG5vZGUuc2V0QXR0cmlidXRlTlMoJ2h0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsnLCBhdHRyaWJ1dGUsIHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGdldF9iaW5kaW5nX2dyb3VwX3ZhbHVlKGdyb3VwKSB7XG4gICAgY29uc3QgdmFsdWUgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGdyb3VwLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgIGlmIChncm91cFtpXS5jaGVja2VkKVxuICAgICAgICAgICAgdmFsdWUucHVzaChncm91cFtpXS5fX3ZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gdG9fbnVtYmVyKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlID09PSAnJyA/IHVuZGVmaW5lZCA6ICt2YWx1ZTtcbn1cbmZ1bmN0aW9uIHRpbWVfcmFuZ2VzX3RvX2FycmF5KHJhbmdlcykge1xuICAgIGNvbnN0IGFycmF5ID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCByYW5nZXMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgYXJyYXkucHVzaCh7IHN0YXJ0OiByYW5nZXMuc3RhcnQoaSksIGVuZDogcmFuZ2VzLmVuZChpKSB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGFycmF5O1xufVxuZnVuY3Rpb24gY2hpbGRyZW4oZWxlbWVudCkge1xuICAgIHJldHVybiBBcnJheS5mcm9tKGVsZW1lbnQuY2hpbGROb2Rlcyk7XG59XG5mdW5jdGlvbiBjbGFpbV9lbGVtZW50KG5vZGVzLCBuYW1lLCBhdHRyaWJ1dGVzLCBzdmcpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG5vZGVzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgIGNvbnN0IG5vZGUgPSBub2Rlc1tpXTtcbiAgICAgICAgaWYgKG5vZGUubm9kZU5hbWUgPT09IG5hbWUpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgbm9kZS5hdHRyaWJ1dGVzLmxlbmd0aDsgaiArPSAxKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgYXR0cmlidXRlID0gbm9kZS5hdHRyaWJ1dGVzW2pdO1xuICAgICAgICAgICAgICAgIGlmICghYXR0cmlidXRlc1thdHRyaWJ1dGUubmFtZV0pXG4gICAgICAgICAgICAgICAgICAgIG5vZGUucmVtb3ZlQXR0cmlidXRlKGF0dHJpYnV0ZS5uYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBub2Rlcy5zcGxpY2UoaSwgMSlbMF07IC8vIFRPRE8gc3RyaXAgdW53YW50ZWQgYXR0cmlidXRlc1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzdmcgPyBzdmdfZWxlbWVudChuYW1lKSA6IGVsZW1lbnQobmFtZSk7XG59XG5mdW5jdGlvbiBjbGFpbV90ZXh0KG5vZGVzLCBkYXRhKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBub2Rlcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICBjb25zdCBub2RlID0gbm9kZXNbaV07XG4gICAgICAgIGlmIChub2RlLm5vZGVUeXBlID09PSAzKSB7XG4gICAgICAgICAgICBub2RlLmRhdGEgPSAnJyArIGRhdGE7XG4gICAgICAgICAgICByZXR1cm4gbm9kZXMuc3BsaWNlKGksIDEpWzBdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0ZXh0KGRhdGEpO1xufVxuZnVuY3Rpb24gY2xhaW1fc3BhY2Uobm9kZXMpIHtcbiAgICByZXR1cm4gY2xhaW1fdGV4dChub2RlcywgJyAnKTtcbn1cbmZ1bmN0aW9uIHNldF9kYXRhKHRleHQsIGRhdGEpIHtcbiAgICBkYXRhID0gJycgKyBkYXRhO1xuICAgIGlmICh0ZXh0LmRhdGEgIT09IGRhdGEpXG4gICAgICAgIHRleHQuZGF0YSA9IGRhdGE7XG59XG5mdW5jdGlvbiBzZXRfaW5wdXRfdmFsdWUoaW5wdXQsIHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlICE9IG51bGwgfHwgaW5wdXQudmFsdWUpIHtcbiAgICAgICAgaW5wdXQudmFsdWUgPSB2YWx1ZTtcbiAgICB9XG59XG5mdW5jdGlvbiBzZXRfaW5wdXRfdHlwZShpbnB1dCwgdHlwZSkge1xuICAgIHRyeSB7XG4gICAgICAgIGlucHV0LnR5cGUgPSB0eXBlO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICAvLyBkbyBub3RoaW5nXG4gICAgfVxufVxuZnVuY3Rpb24gc2V0X3N0eWxlKG5vZGUsIGtleSwgdmFsdWUsIGltcG9ydGFudCkge1xuICAgIG5vZGUuc3R5bGUuc2V0UHJvcGVydHkoa2V5LCB2YWx1ZSwgaW1wb3J0YW50ID8gJ2ltcG9ydGFudCcgOiAnJyk7XG59XG5mdW5jdGlvbiBzZWxlY3Rfb3B0aW9uKHNlbGVjdCwgdmFsdWUpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlbGVjdC5vcHRpb25zLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgIGNvbnN0IG9wdGlvbiA9IHNlbGVjdC5vcHRpb25zW2ldO1xuICAgICAgICBpZiAob3B0aW9uLl9fdmFsdWUgPT09IHZhbHVlKSB7XG4gICAgICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSB0cnVlO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgfVxufVxuZnVuY3Rpb24gc2VsZWN0X29wdGlvbnMoc2VsZWN0LCB2YWx1ZSkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VsZWN0Lm9wdGlvbnMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgICAgY29uc3Qgb3B0aW9uID0gc2VsZWN0Lm9wdGlvbnNbaV07XG4gICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IH52YWx1ZS5pbmRleE9mKG9wdGlvbi5fX3ZhbHVlKTtcbiAgICB9XG59XG5mdW5jdGlvbiBzZWxlY3RfdmFsdWUoc2VsZWN0KSB7XG4gICAgY29uc3Qgc2VsZWN0ZWRfb3B0aW9uID0gc2VsZWN0LnF1ZXJ5U2VsZWN0b3IoJzpjaGVja2VkJykgfHwgc2VsZWN0Lm9wdGlvbnNbMF07XG4gICAgcmV0dXJuIHNlbGVjdGVkX29wdGlvbiAmJiBzZWxlY3RlZF9vcHRpb24uX192YWx1ZTtcbn1cbmZ1bmN0aW9uIHNlbGVjdF9tdWx0aXBsZV92YWx1ZShzZWxlY3QpIHtcbiAgICByZXR1cm4gW10ubWFwLmNhbGwoc2VsZWN0LnF1ZXJ5U2VsZWN0b3JBbGwoJzpjaGVja2VkJyksIG9wdGlvbiA9PiBvcHRpb24uX192YWx1ZSk7XG59XG5mdW5jdGlvbiBhZGRfcmVzaXplX2xpc3RlbmVyKGVsZW1lbnQsIGZuKSB7XG4gICAgaWYgKGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCkucG9zaXRpb24gPT09ICdzdGF0aWMnKSB7XG4gICAgICAgIGVsZW1lbnQuc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnO1xuICAgIH1cbiAgICBjb25zdCBvYmplY3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdvYmplY3QnKTtcbiAgICBvYmplY3Quc2V0QXR0cmlidXRlKCdzdHlsZScsICdkaXNwbGF5OiBibG9jazsgcG9zaXRpb246IGFic29sdXRlOyB0b3A6IDA7IGxlZnQ6IDA7IGhlaWdodDogMTAwJTsgd2lkdGg6IDEwMCU7IG92ZXJmbG93OiBoaWRkZW47IHBvaW50ZXItZXZlbnRzOiBub25lOyB6LWluZGV4OiAtMTsnKTtcbiAgICBvYmplY3Quc2V0QXR0cmlidXRlKCdhcmlhLWhpZGRlbicsICd0cnVlJyk7XG4gICAgb2JqZWN0LnR5cGUgPSAndGV4dC9odG1sJztcbiAgICBvYmplY3QudGFiSW5kZXggPSAtMTtcbiAgICBsZXQgd2luO1xuICAgIG9iamVjdC5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIHdpbiA9IG9iamVjdC5jb250ZW50RG9jdW1lbnQuZGVmYXVsdFZpZXc7XG4gICAgICAgIHdpbi5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCBmbik7XG4gICAgfTtcbiAgICBpZiAoL1RyaWRlbnQvLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCkpIHtcbiAgICAgICAgZWxlbWVudC5hcHBlbmRDaGlsZChvYmplY3QpO1xuICAgICAgICBvYmplY3QuZGF0YSA9ICdhYm91dDpibGFuayc7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBvYmplY3QuZGF0YSA9ICdhYm91dDpibGFuayc7XG4gICAgICAgIGVsZW1lbnQuYXBwZW5kQ2hpbGQob2JqZWN0KTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgY2FuY2VsOiAoKSA9PiB7XG4gICAgICAgICAgICB3aW4gJiYgd2luLnJlbW92ZUV2ZW50TGlzdGVuZXIgJiYgd2luLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIGZuKTtcbiAgICAgICAgICAgIGVsZW1lbnQucmVtb3ZlQ2hpbGQob2JqZWN0KTtcbiAgICAgICAgfVxuICAgIH07XG59XG5mdW5jdGlvbiB0b2dnbGVfY2xhc3MoZWxlbWVudCwgbmFtZSwgdG9nZ2xlKSB7XG4gICAgZWxlbWVudC5jbGFzc0xpc3RbdG9nZ2xlID8gJ2FkZCcgOiAncmVtb3ZlJ10obmFtZSk7XG59XG5mdW5jdGlvbiBjdXN0b21fZXZlbnQodHlwZSwgZGV0YWlsKSB7XG4gICAgY29uc3QgZSA9IGRvY3VtZW50LmNyZWF0ZUV2ZW50KCdDdXN0b21FdmVudCcpO1xuICAgIGUuaW5pdEN1c3RvbUV2ZW50KHR5cGUsIGZhbHNlLCBmYWxzZSwgZGV0YWlsKTtcbiAgICByZXR1cm4gZTtcbn1cbmNsYXNzIEh0bWxUYWcge1xuICAgIGNvbnN0cnVjdG9yKGh0bWwsIGFuY2hvciA9IG51bGwpIHtcbiAgICAgICAgdGhpcy5lID0gZWxlbWVudCgnZGl2Jyk7XG4gICAgICAgIHRoaXMuYSA9IGFuY2hvcjtcbiAgICAgICAgdGhpcy51KGh0bWwpO1xuICAgIH1cbiAgICBtKHRhcmdldCwgYW5jaG9yID0gbnVsbCkge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMubi5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgICAgaW5zZXJ0KHRhcmdldCwgdGhpcy5uW2ldLCBhbmNob3IpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMudCA9IHRhcmdldDtcbiAgICB9XG4gICAgdShodG1sKSB7XG4gICAgICAgIHRoaXMuZS5pbm5lckhUTUwgPSBodG1sO1xuICAgICAgICB0aGlzLm4gPSBBcnJheS5mcm9tKHRoaXMuZS5jaGlsZE5vZGVzKTtcbiAgICB9XG4gICAgcChodG1sKSB7XG4gICAgICAgIHRoaXMuZCgpO1xuICAgICAgICB0aGlzLnUoaHRtbCk7XG4gICAgICAgIHRoaXMubSh0aGlzLnQsIHRoaXMuYSk7XG4gICAgfVxuICAgIGQoKSB7XG4gICAgICAgIHRoaXMubi5mb3JFYWNoKGRldGFjaCk7XG4gICAgfVxufVxuXG5sZXQgc3R5bGVzaGVldDtcbmxldCBhY3RpdmUgPSAwO1xubGV0IGN1cnJlbnRfcnVsZXMgPSB7fTtcbi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9kYXJrc2t5YXBwL3N0cmluZy1oYXNoL2Jsb2IvbWFzdGVyL2luZGV4LmpzXG5mdW5jdGlvbiBoYXNoKHN0cikge1xuICAgIGxldCBoYXNoID0gNTM4MTtcbiAgICBsZXQgaSA9IHN0ci5sZW5ndGg7XG4gICAgd2hpbGUgKGktLSlcbiAgICAgICAgaGFzaCA9ICgoaGFzaCA8PCA1KSAtIGhhc2gpIF4gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgcmV0dXJuIGhhc2ggPj4+IDA7XG59XG5mdW5jdGlvbiBjcmVhdGVfcnVsZShub2RlLCBhLCBiLCBkdXJhdGlvbiwgZGVsYXksIGVhc2UsIGZuLCB1aWQgPSAwKSB7XG4gICAgY29uc3Qgc3RlcCA9IDE2LjY2NiAvIGR1cmF0aW9uO1xuICAgIGxldCBrZXlmcmFtZXMgPSAne1xcbic7XG4gICAgZm9yIChsZXQgcCA9IDA7IHAgPD0gMTsgcCArPSBzdGVwKSB7XG4gICAgICAgIGNvbnN0IHQgPSBhICsgKGIgLSBhKSAqIGVhc2UocCk7XG4gICAgICAgIGtleWZyYW1lcyArPSBwICogMTAwICsgYCV7JHtmbih0LCAxIC0gdCl9fVxcbmA7XG4gICAgfVxuICAgIGNvbnN0IHJ1bGUgPSBrZXlmcmFtZXMgKyBgMTAwJSB7JHtmbihiLCAxIC0gYil9fVxcbn1gO1xuICAgIGNvbnN0IG5hbWUgPSBgX19zdmVsdGVfJHtoYXNoKHJ1bGUpfV8ke3VpZH1gO1xuICAgIGlmICghY3VycmVudF9ydWxlc1tuYW1lXSkge1xuICAgICAgICBpZiAoIXN0eWxlc2hlZXQpIHtcbiAgICAgICAgICAgIGNvbnN0IHN0eWxlID0gZWxlbWVudCgnc3R5bGUnKTtcbiAgICAgICAgICAgIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpO1xuICAgICAgICAgICAgc3R5bGVzaGVldCA9IHN0eWxlLnNoZWV0O1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRfcnVsZXNbbmFtZV0gPSB0cnVlO1xuICAgICAgICBzdHlsZXNoZWV0Lmluc2VydFJ1bGUoYEBrZXlmcmFtZXMgJHtuYW1lfSAke3J1bGV9YCwgc3R5bGVzaGVldC5jc3NSdWxlcy5sZW5ndGgpO1xuICAgIH1cbiAgICBjb25zdCBhbmltYXRpb24gPSBub2RlLnN0eWxlLmFuaW1hdGlvbiB8fCAnJztcbiAgICBub2RlLnN0eWxlLmFuaW1hdGlvbiA9IGAke2FuaW1hdGlvbiA/IGAke2FuaW1hdGlvbn0sIGAgOiBgYH0ke25hbWV9ICR7ZHVyYXRpb259bXMgbGluZWFyICR7ZGVsYXl9bXMgMSBib3RoYDtcbiAgICBhY3RpdmUgKz0gMTtcbiAgICByZXR1cm4gbmFtZTtcbn1cbmZ1bmN0aW9uIGRlbGV0ZV9ydWxlKG5vZGUsIG5hbWUpIHtcbiAgICBub2RlLnN0eWxlLmFuaW1hdGlvbiA9IChub2RlLnN0eWxlLmFuaW1hdGlvbiB8fCAnJylcbiAgICAgICAgLnNwbGl0KCcsICcpXG4gICAgICAgIC5maWx0ZXIobmFtZVxuICAgICAgICA/IGFuaW0gPT4gYW5pbS5pbmRleE9mKG5hbWUpIDwgMCAvLyByZW1vdmUgc3BlY2lmaWMgYW5pbWF0aW9uXG4gICAgICAgIDogYW5pbSA9PiBhbmltLmluZGV4T2YoJ19fc3ZlbHRlJykgPT09IC0xIC8vIHJlbW92ZSBhbGwgU3ZlbHRlIGFuaW1hdGlvbnNcbiAgICApXG4gICAgICAgIC5qb2luKCcsICcpO1xuICAgIGlmIChuYW1lICYmICEtLWFjdGl2ZSlcbiAgICAgICAgY2xlYXJfcnVsZXMoKTtcbn1cbmZ1bmN0aW9uIGNsZWFyX3J1bGVzKCkge1xuICAgIHJhZigoKSA9PiB7XG4gICAgICAgIGlmIChhY3RpdmUpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGxldCBpID0gc3R5bGVzaGVldC5jc3NSdWxlcy5sZW5ndGg7XG4gICAgICAgIHdoaWxlIChpLS0pXG4gICAgICAgICAgICBzdHlsZXNoZWV0LmRlbGV0ZVJ1bGUoaSk7XG4gICAgICAgIGN1cnJlbnRfcnVsZXMgPSB7fTtcbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlX2FuaW1hdGlvbihub2RlLCBmcm9tLCBmbiwgcGFyYW1zKSB7XG4gICAgaWYgKCFmcm9tKVxuICAgICAgICByZXR1cm4gbm9vcDtcbiAgICBjb25zdCB0byA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgaWYgKGZyb20ubGVmdCA9PT0gdG8ubGVmdCAmJiBmcm9tLnJpZ2h0ID09PSB0by5yaWdodCAmJiBmcm9tLnRvcCA9PT0gdG8udG9wICYmIGZyb20uYm90dG9tID09PSB0by5ib3R0b20pXG4gICAgICAgIHJldHVybiBub29wO1xuICAgIGNvbnN0IHsgZGVsYXkgPSAwLCBkdXJhdGlvbiA9IDMwMCwgZWFzaW5nID0gaWRlbnRpdHksIFxuICAgIC8vIEB0cy1pZ25vcmUgdG9kbzogc2hvdWxkIHRoaXMgYmUgc2VwYXJhdGVkIGZyb20gZGVzdHJ1Y3R1cmluZz8gT3Igc3RhcnQvZW5kIGFkZGVkIHRvIHB1YmxpYyBhcGkgYW5kIGRvY3VtZW50YXRpb24/XG4gICAgc3RhcnQ6IHN0YXJ0X3RpbWUgPSBub3coKSArIGRlbGF5LCBcbiAgICAvLyBAdHMtaWdub3JlIHRvZG86XG4gICAgZW5kID0gc3RhcnRfdGltZSArIGR1cmF0aW9uLCB0aWNrID0gbm9vcCwgY3NzIH0gPSBmbihub2RlLCB7IGZyb20sIHRvIH0sIHBhcmFtcyk7XG4gICAgbGV0IHJ1bm5pbmcgPSB0cnVlO1xuICAgIGxldCBzdGFydGVkID0gZmFsc2U7XG4gICAgbGV0IG5hbWU7XG4gICAgZnVuY3Rpb24gc3RhcnQoKSB7XG4gICAgICAgIGlmIChjc3MpIHtcbiAgICAgICAgICAgIG5hbWUgPSBjcmVhdGVfcnVsZShub2RlLCAwLCAxLCBkdXJhdGlvbiwgZGVsYXksIGVhc2luZywgY3NzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRlbGF5KSB7XG4gICAgICAgICAgICBzdGFydGVkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBzdG9wKCkge1xuICAgICAgICBpZiAoY3NzKVxuICAgICAgICAgICAgZGVsZXRlX3J1bGUobm9kZSwgbmFtZSk7XG4gICAgICAgIHJ1bm5pbmcgPSBmYWxzZTtcbiAgICB9XG4gICAgbG9vcChub3cgPT4ge1xuICAgICAgICBpZiAoIXN0YXJ0ZWQgJiYgbm93ID49IHN0YXJ0X3RpbWUpIHtcbiAgICAgICAgICAgIHN0YXJ0ZWQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdGFydGVkICYmIG5vdyA+PSBlbmQpIHtcbiAgICAgICAgICAgIHRpY2soMSwgMCk7XG4gICAgICAgICAgICBzdG9wKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFydW5uaW5nKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHN0YXJ0ZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHAgPSBub3cgLSBzdGFydF90aW1lO1xuICAgICAgICAgICAgY29uc3QgdCA9IDAgKyAxICogZWFzaW5nKHAgLyBkdXJhdGlvbik7XG4gICAgICAgICAgICB0aWNrKHQsIDEgLSB0KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9KTtcbiAgICBzdGFydCgpO1xuICAgIHRpY2soMCwgMSk7XG4gICAgcmV0dXJuIHN0b3A7XG59XG5mdW5jdGlvbiBmaXhfcG9zaXRpb24obm9kZSkge1xuICAgIGNvbnN0IHN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZShub2RlKTtcbiAgICBpZiAoc3R5bGUucG9zaXRpb24gIT09ICdhYnNvbHV0ZScgJiYgc3R5bGUucG9zaXRpb24gIT09ICdmaXhlZCcpIHtcbiAgICAgICAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0IH0gPSBzdHlsZTtcbiAgICAgICAgY29uc3QgYSA9IG5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIG5vZGUuc3R5bGUucG9zaXRpb24gPSAnYWJzb2x1dGUnO1xuICAgICAgICBub2RlLnN0eWxlLndpZHRoID0gd2lkdGg7XG4gICAgICAgIG5vZGUuc3R5bGUuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgICAgICBhZGRfdHJhbnNmb3JtKG5vZGUsIGEpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGFkZF90cmFuc2Zvcm0obm9kZSwgYSkge1xuICAgIGNvbnN0IGIgPSBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGlmIChhLmxlZnQgIT09IGIubGVmdCB8fCBhLnRvcCAhPT0gYi50b3ApIHtcbiAgICAgICAgY29uc3Qgc3R5bGUgPSBnZXRDb21wdXRlZFN0eWxlKG5vZGUpO1xuICAgICAgICBjb25zdCB0cmFuc2Zvcm0gPSBzdHlsZS50cmFuc2Zvcm0gPT09ICdub25lJyA/ICcnIDogc3R5bGUudHJhbnNmb3JtO1xuICAgICAgICBub2RlLnN0eWxlLnRyYW5zZm9ybSA9IGAke3RyYW5zZm9ybX0gdHJhbnNsYXRlKCR7YS5sZWZ0IC0gYi5sZWZ0fXB4LCAke2EudG9wIC0gYi50b3B9cHgpYDtcbiAgICB9XG59XG5cbmxldCBjdXJyZW50X2NvbXBvbmVudDtcbmZ1bmN0aW9uIHNldF9jdXJyZW50X2NvbXBvbmVudChjb21wb25lbnQpIHtcbiAgICBjdXJyZW50X2NvbXBvbmVudCA9IGNvbXBvbmVudDtcbn1cbmZ1bmN0aW9uIGdldF9jdXJyZW50X2NvbXBvbmVudCgpIHtcbiAgICBpZiAoIWN1cnJlbnRfY29tcG9uZW50KVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZ1bmN0aW9uIGNhbGxlZCBvdXRzaWRlIGNvbXBvbmVudCBpbml0aWFsaXphdGlvbmApO1xuICAgIHJldHVybiBjdXJyZW50X2NvbXBvbmVudDtcbn1cbmZ1bmN0aW9uIGJlZm9yZVVwZGF0ZShmbikge1xuICAgIGdldF9jdXJyZW50X2NvbXBvbmVudCgpLiQkLmJlZm9yZV91cGRhdGUucHVzaChmbik7XG59XG5mdW5jdGlvbiBvbk1vdW50KGZuKSB7XG4gICAgZ2V0X2N1cnJlbnRfY29tcG9uZW50KCkuJCQub25fbW91bnQucHVzaChmbik7XG59XG5mdW5jdGlvbiBhZnRlclVwZGF0ZShmbikge1xuICAgIGdldF9jdXJyZW50X2NvbXBvbmVudCgpLiQkLmFmdGVyX3VwZGF0ZS5wdXNoKGZuKTtcbn1cbmZ1bmN0aW9uIG9uRGVzdHJveShmbikge1xuICAgIGdldF9jdXJyZW50X2NvbXBvbmVudCgpLiQkLm9uX2Rlc3Ryb3kucHVzaChmbik7XG59XG5mdW5jdGlvbiBjcmVhdGVFdmVudERpc3BhdGNoZXIoKSB7XG4gICAgY29uc3QgY29tcG9uZW50ID0gZ2V0X2N1cnJlbnRfY29tcG9uZW50KCk7XG4gICAgcmV0dXJuICh0eXBlLCBkZXRhaWwpID0+IHtcbiAgICAgICAgY29uc3QgY2FsbGJhY2tzID0gY29tcG9uZW50LiQkLmNhbGxiYWNrc1t0eXBlXTtcbiAgICAgICAgaWYgKGNhbGxiYWNrcykge1xuICAgICAgICAgICAgLy8gVE9ETyBhcmUgdGhlcmUgc2l0dWF0aW9ucyB3aGVyZSBldmVudHMgY291bGQgYmUgZGlzcGF0Y2hlZFxuICAgICAgICAgICAgLy8gaW4gYSBzZXJ2ZXIgKG5vbi1ET00pIGVudmlyb25tZW50P1xuICAgICAgICAgICAgY29uc3QgZXZlbnQgPSBjdXN0b21fZXZlbnQodHlwZSwgZGV0YWlsKTtcbiAgICAgICAgICAgIGNhbGxiYWNrcy5zbGljZSgpLmZvckVhY2goZm4gPT4ge1xuICAgICAgICAgICAgICAgIGZuLmNhbGwoY29tcG9uZW50LCBldmVudCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH07XG59XG5mdW5jdGlvbiBzZXRDb250ZXh0KGtleSwgY29udGV4dCkge1xuICAgIGdldF9jdXJyZW50X2NvbXBvbmVudCgpLiQkLmNvbnRleHQuc2V0KGtleSwgY29udGV4dCk7XG59XG5mdW5jdGlvbiBnZXRDb250ZXh0KGtleSkge1xuICAgIHJldHVybiBnZXRfY3VycmVudF9jb21wb25lbnQoKS4kJC5jb250ZXh0LmdldChrZXkpO1xufVxuLy8gVE9ETyBmaWd1cmUgb3V0IGlmIHdlIHN0aWxsIHdhbnQgdG8gc3VwcG9ydFxuLy8gc2hvcnRoYW5kIGV2ZW50cywgb3IgaWYgd2Ugd2FudCB0byBpbXBsZW1lbnRcbi8vIGEgcmVhbCBidWJibGluZyBtZWNoYW5pc21cbmZ1bmN0aW9uIGJ1YmJsZShjb21wb25lbnQsIGV2ZW50KSB7XG4gICAgY29uc3QgY2FsbGJhY2tzID0gY29tcG9uZW50LiQkLmNhbGxiYWNrc1tldmVudC50eXBlXTtcbiAgICBpZiAoY2FsbGJhY2tzKSB7XG4gICAgICAgIGNhbGxiYWNrcy5zbGljZSgpLmZvckVhY2goZm4gPT4gZm4oZXZlbnQpKTtcbiAgICB9XG59XG5cbmNvbnN0IGRpcnR5X2NvbXBvbmVudHMgPSBbXTtcbmNvbnN0IGludHJvcyA9IHsgZW5hYmxlZDogZmFsc2UgfTtcbmNvbnN0IGJpbmRpbmdfY2FsbGJhY2tzID0gW107XG5jb25zdCByZW5kZXJfY2FsbGJhY2tzID0gW107XG5jb25zdCBmbHVzaF9jYWxsYmFja3MgPSBbXTtcbmNvbnN0IHJlc29sdmVkX3Byb21pc2UgPSBQcm9taXNlLnJlc29sdmUoKTtcbmxldCB1cGRhdGVfc2NoZWR1bGVkID0gZmFsc2U7XG5mdW5jdGlvbiBzY2hlZHVsZV91cGRhdGUoKSB7XG4gICAgaWYgKCF1cGRhdGVfc2NoZWR1bGVkKSB7XG4gICAgICAgIHVwZGF0ZV9zY2hlZHVsZWQgPSB0cnVlO1xuICAgICAgICByZXNvbHZlZF9wcm9taXNlLnRoZW4oZmx1c2gpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHRpY2soKSB7XG4gICAgc2NoZWR1bGVfdXBkYXRlKCk7XG4gICAgcmV0dXJuIHJlc29sdmVkX3Byb21pc2U7XG59XG5mdW5jdGlvbiBhZGRfcmVuZGVyX2NhbGxiYWNrKGZuKSB7XG4gICAgcmVuZGVyX2NhbGxiYWNrcy5wdXNoKGZuKTtcbn1cbmZ1bmN0aW9uIGFkZF9mbHVzaF9jYWxsYmFjayhmbikge1xuICAgIGZsdXNoX2NhbGxiYWNrcy5wdXNoKGZuKTtcbn1cbmZ1bmN0aW9uIGZsdXNoKCkge1xuICAgIGNvbnN0IHNlZW5fY2FsbGJhY2tzID0gbmV3IFNldCgpO1xuICAgIGRvIHtcbiAgICAgICAgLy8gZmlyc3QsIGNhbGwgYmVmb3JlVXBkYXRlIGZ1bmN0aW9uc1xuICAgICAgICAvLyBhbmQgdXBkYXRlIGNvbXBvbmVudHNcbiAgICAgICAgd2hpbGUgKGRpcnR5X2NvbXBvbmVudHMubGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zdCBjb21wb25lbnQgPSBkaXJ0eV9jb21wb25lbnRzLnNoaWZ0KCk7XG4gICAgICAgICAgICBzZXRfY3VycmVudF9jb21wb25lbnQoY29tcG9uZW50KTtcbiAgICAgICAgICAgIHVwZGF0ZShjb21wb25lbnQuJCQpO1xuICAgICAgICB9XG4gICAgICAgIHdoaWxlIChiaW5kaW5nX2NhbGxiYWNrcy5sZW5ndGgpXG4gICAgICAgICAgICBiaW5kaW5nX2NhbGxiYWNrcy5wb3AoKSgpO1xuICAgICAgICAvLyB0aGVuLCBvbmNlIGNvbXBvbmVudHMgYXJlIHVwZGF0ZWQsIGNhbGxcbiAgICAgICAgLy8gYWZ0ZXJVcGRhdGUgZnVuY3Rpb25zLiBUaGlzIG1heSBjYXVzZVxuICAgICAgICAvLyBzdWJzZXF1ZW50IHVwZGF0ZXMuLi5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZW5kZXJfY2FsbGJhY2tzLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgICAgICBjb25zdCBjYWxsYmFjayA9IHJlbmRlcl9jYWxsYmFja3NbaV07XG4gICAgICAgICAgICBpZiAoIXNlZW5fY2FsbGJhY2tzLmhhcyhjYWxsYmFjaykpIHtcbiAgICAgICAgICAgICAgICBjYWxsYmFjaygpO1xuICAgICAgICAgICAgICAgIC8vIC4uLnNvIGd1YXJkIGFnYWluc3QgaW5maW5pdGUgbG9vcHNcbiAgICAgICAgICAgICAgICBzZWVuX2NhbGxiYWNrcy5hZGQoY2FsbGJhY2spO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlbmRlcl9jYWxsYmFja3MubGVuZ3RoID0gMDtcbiAgICB9IHdoaWxlIChkaXJ0eV9jb21wb25lbnRzLmxlbmd0aCk7XG4gICAgd2hpbGUgKGZsdXNoX2NhbGxiYWNrcy5sZW5ndGgpIHtcbiAgICAgICAgZmx1c2hfY2FsbGJhY2tzLnBvcCgpKCk7XG4gICAgfVxuICAgIHVwZGF0ZV9zY2hlZHVsZWQgPSBmYWxzZTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZSgkJCkge1xuICAgIGlmICgkJC5mcmFnbWVudCAhPT0gbnVsbCkge1xuICAgICAgICAkJC51cGRhdGUoKTtcbiAgICAgICAgcnVuX2FsbCgkJC5iZWZvcmVfdXBkYXRlKTtcbiAgICAgICAgJCQuZnJhZ21lbnQgJiYgJCQuZnJhZ21lbnQucCgkJC5jdHgsICQkLmRpcnR5KTtcbiAgICAgICAgJCQuZGlydHkgPSBbLTFdO1xuICAgICAgICAkJC5hZnRlcl91cGRhdGUuZm9yRWFjaChhZGRfcmVuZGVyX2NhbGxiYWNrKTtcbiAgICB9XG59XG5cbmxldCBwcm9taXNlO1xuZnVuY3Rpb24gd2FpdCgpIHtcbiAgICBpZiAoIXByb21pc2UpIHtcbiAgICAgICAgcHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICBwcm9taXNlLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgcHJvbWlzZSA9IG51bGw7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gcHJvbWlzZTtcbn1cbmZ1bmN0aW9uIGRpc3BhdGNoKG5vZGUsIGRpcmVjdGlvbiwga2luZCkge1xuICAgIG5vZGUuZGlzcGF0Y2hFdmVudChjdXN0b21fZXZlbnQoYCR7ZGlyZWN0aW9uID8gJ2ludHJvJyA6ICdvdXRybyd9JHtraW5kfWApKTtcbn1cbmNvbnN0IG91dHJvaW5nID0gbmV3IFNldCgpO1xubGV0IG91dHJvcztcbmZ1bmN0aW9uIGdyb3VwX291dHJvcygpIHtcbiAgICBvdXRyb3MgPSB7XG4gICAgICAgIHI6IDAsXG4gICAgICAgIGM6IFtdLFxuICAgICAgICBwOiBvdXRyb3MgLy8gcGFyZW50IGdyb3VwXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGNoZWNrX291dHJvcygpIHtcbiAgICBpZiAoIW91dHJvcy5yKSB7XG4gICAgICAgIHJ1bl9hbGwob3V0cm9zLmMpO1xuICAgIH1cbiAgICBvdXRyb3MgPSBvdXRyb3MucDtcbn1cbmZ1bmN0aW9uIHRyYW5zaXRpb25faW4oYmxvY2ssIGxvY2FsKSB7XG4gICAgaWYgKGJsb2NrICYmIGJsb2NrLmkpIHtcbiAgICAgICAgb3V0cm9pbmcuZGVsZXRlKGJsb2NrKTtcbiAgICAgICAgYmxvY2suaShsb2NhbCk7XG4gICAgfVxufVxuZnVuY3Rpb24gdHJhbnNpdGlvbl9vdXQoYmxvY2ssIGxvY2FsLCBkZXRhY2gsIGNhbGxiYWNrKSB7XG4gICAgaWYgKGJsb2NrICYmIGJsb2NrLm8pIHtcbiAgICAgICAgaWYgKG91dHJvaW5nLmhhcyhibG9jaykpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIG91dHJvaW5nLmFkZChibG9jayk7XG4gICAgICAgIG91dHJvcy5jLnB1c2goKCkgPT4ge1xuICAgICAgICAgICAgb3V0cm9pbmcuZGVsZXRlKGJsb2NrKTtcbiAgICAgICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgICAgICAgIGlmIChkZXRhY2gpXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrLmQoMSk7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2soKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGJsb2NrLm8obG9jYWwpO1xuICAgIH1cbn1cbmNvbnN0IG51bGxfdHJhbnNpdGlvbiA9IHsgZHVyYXRpb246IDAgfTtcbmZ1bmN0aW9uIGNyZWF0ZV9pbl90cmFuc2l0aW9uKG5vZGUsIGZuLCBwYXJhbXMpIHtcbiAgICBsZXQgY29uZmlnID0gZm4obm9kZSwgcGFyYW1zKTtcbiAgICBsZXQgcnVubmluZyA9IGZhbHNlO1xuICAgIGxldCBhbmltYXRpb25fbmFtZTtcbiAgICBsZXQgdGFzaztcbiAgICBsZXQgdWlkID0gMDtcbiAgICBmdW5jdGlvbiBjbGVhbnVwKCkge1xuICAgICAgICBpZiAoYW5pbWF0aW9uX25hbWUpXG4gICAgICAgICAgICBkZWxldGVfcnVsZShub2RlLCBhbmltYXRpb25fbmFtZSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdvKCkge1xuICAgICAgICBjb25zdCB7IGRlbGF5ID0gMCwgZHVyYXRpb24gPSAzMDAsIGVhc2luZyA9IGlkZW50aXR5LCB0aWNrID0gbm9vcCwgY3NzIH0gPSBjb25maWcgfHwgbnVsbF90cmFuc2l0aW9uO1xuICAgICAgICBpZiAoY3NzKVxuICAgICAgICAgICAgYW5pbWF0aW9uX25hbWUgPSBjcmVhdGVfcnVsZShub2RlLCAwLCAxLCBkdXJhdGlvbiwgZGVsYXksIGVhc2luZywgY3NzLCB1aWQrKyk7XG4gICAgICAgIHRpY2soMCwgMSk7XG4gICAgICAgIGNvbnN0IHN0YXJ0X3RpbWUgPSBub3coKSArIGRlbGF5O1xuICAgICAgICBjb25zdCBlbmRfdGltZSA9IHN0YXJ0X3RpbWUgKyBkdXJhdGlvbjtcbiAgICAgICAgaWYgKHRhc2spXG4gICAgICAgICAgICB0YXNrLmFib3J0KCk7XG4gICAgICAgIHJ1bm5pbmcgPSB0cnVlO1xuICAgICAgICBhZGRfcmVuZGVyX2NhbGxiYWNrKCgpID0+IGRpc3BhdGNoKG5vZGUsIHRydWUsICdzdGFydCcpKTtcbiAgICAgICAgdGFzayA9IGxvb3Aobm93ID0+IHtcbiAgICAgICAgICAgIGlmIChydW5uaW5nKSB7XG4gICAgICAgICAgICAgICAgaWYgKG5vdyA+PSBlbmRfdGltZSkge1xuICAgICAgICAgICAgICAgICAgICB0aWNrKDEsIDApO1xuICAgICAgICAgICAgICAgICAgICBkaXNwYXRjaChub2RlLCB0cnVlLCAnZW5kJyk7XG4gICAgICAgICAgICAgICAgICAgIGNsZWFudXAoKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJ1bm5pbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG5vdyA+PSBzdGFydF90aW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHQgPSBlYXNpbmcoKG5vdyAtIHN0YXJ0X3RpbWUpIC8gZHVyYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICB0aWNrKHQsIDEgLSB0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcnVubmluZztcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGxldCBzdGFydGVkID0gZmFsc2U7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgc3RhcnQoKSB7XG4gICAgICAgICAgICBpZiAoc3RhcnRlZClcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICBkZWxldGVfcnVsZShub2RlKTtcbiAgICAgICAgICAgIGlmIChpc19mdW5jdGlvbihjb25maWcpKSB7XG4gICAgICAgICAgICAgICAgY29uZmlnID0gY29uZmlnKCk7XG4gICAgICAgICAgICAgICAgd2FpdCgpLnRoZW4oZ28pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZ28oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgaW52YWxpZGF0ZSgpIHtcbiAgICAgICAgICAgIHN0YXJ0ZWQgPSBmYWxzZTtcbiAgICAgICAgfSxcbiAgICAgICAgZW5kKCkge1xuICAgICAgICAgICAgaWYgKHJ1bm5pbmcpIHtcbiAgICAgICAgICAgICAgICBjbGVhbnVwKCk7XG4gICAgICAgICAgICAgICAgcnVubmluZyA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZV9vdXRfdHJhbnNpdGlvbihub2RlLCBmbiwgcGFyYW1zKSB7XG4gICAgbGV0IGNvbmZpZyA9IGZuKG5vZGUsIHBhcmFtcyk7XG4gICAgbGV0IHJ1bm5pbmcgPSB0cnVlO1xuICAgIGxldCBhbmltYXRpb25fbmFtZTtcbiAgICBjb25zdCBncm91cCA9IG91dHJvcztcbiAgICBncm91cC5yICs9IDE7XG4gICAgZnVuY3Rpb24gZ28oKSB7XG4gICAgICAgIGNvbnN0IHsgZGVsYXkgPSAwLCBkdXJhdGlvbiA9IDMwMCwgZWFzaW5nID0gaWRlbnRpdHksIHRpY2sgPSBub29wLCBjc3MgfSA9IGNvbmZpZyB8fCBudWxsX3RyYW5zaXRpb247XG4gICAgICAgIGlmIChjc3MpXG4gICAgICAgICAgICBhbmltYXRpb25fbmFtZSA9IGNyZWF0ZV9ydWxlKG5vZGUsIDEsIDAsIGR1cmF0aW9uLCBkZWxheSwgZWFzaW5nLCBjc3MpO1xuICAgICAgICBjb25zdCBzdGFydF90aW1lID0gbm93KCkgKyBkZWxheTtcbiAgICAgICAgY29uc3QgZW5kX3RpbWUgPSBzdGFydF90aW1lICsgZHVyYXRpb247XG4gICAgICAgIGFkZF9yZW5kZXJfY2FsbGJhY2soKCkgPT4gZGlzcGF0Y2gobm9kZSwgZmFsc2UsICdzdGFydCcpKTtcbiAgICAgICAgbG9vcChub3cgPT4ge1xuICAgICAgICAgICAgaWYgKHJ1bm5pbmcpIHtcbiAgICAgICAgICAgICAgICBpZiAobm93ID49IGVuZF90aW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIHRpY2soMCwgMSk7XG4gICAgICAgICAgICAgICAgICAgIGRpc3BhdGNoKG5vZGUsIGZhbHNlLCAnZW5kJyk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghLS1ncm91cC5yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIHdpbGwgcmVzdWx0IGluIGBlbmQoKWAgYmVpbmcgY2FsbGVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gc28gd2UgZG9uJ3QgbmVlZCB0byBjbGVhbiB1cCBoZXJlXG4gICAgICAgICAgICAgICAgICAgICAgICBydW5fYWxsKGdyb3VwLmMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG5vdyA+PSBzdGFydF90aW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHQgPSBlYXNpbmcoKG5vdyAtIHN0YXJ0X3RpbWUpIC8gZHVyYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICB0aWNrKDEgLSB0LCB0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcnVubmluZztcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChpc19mdW5jdGlvbihjb25maWcpKSB7XG4gICAgICAgIHdhaXQoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICAgIGNvbmZpZyA9IGNvbmZpZygpO1xuICAgICAgICAgICAgZ28oKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBnbygpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBlbmQocmVzZXQpIHtcbiAgICAgICAgICAgIGlmIChyZXNldCAmJiBjb25maWcudGljaykge1xuICAgICAgICAgICAgICAgIGNvbmZpZy50aWNrKDEsIDApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJ1bm5pbmcpIHtcbiAgICAgICAgICAgICAgICBpZiAoYW5pbWF0aW9uX25hbWUpXG4gICAgICAgICAgICAgICAgICAgIGRlbGV0ZV9ydWxlKG5vZGUsIGFuaW1hdGlvbl9uYW1lKTtcbiAgICAgICAgICAgICAgICBydW5uaW5nID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xufVxuZnVuY3Rpb24gY3JlYXRlX2JpZGlyZWN0aW9uYWxfdHJhbnNpdGlvbihub2RlLCBmbiwgcGFyYW1zLCBpbnRybykge1xuICAgIGxldCBjb25maWcgPSBmbihub2RlLCBwYXJhbXMpO1xuICAgIGxldCB0ID0gaW50cm8gPyAwIDogMTtcbiAgICBsZXQgcnVubmluZ19wcm9ncmFtID0gbnVsbDtcbiAgICBsZXQgcGVuZGluZ19wcm9ncmFtID0gbnVsbDtcbiAgICBsZXQgYW5pbWF0aW9uX25hbWUgPSBudWxsO1xuICAgIGZ1bmN0aW9uIGNsZWFyX2FuaW1hdGlvbigpIHtcbiAgICAgICAgaWYgKGFuaW1hdGlvbl9uYW1lKVxuICAgICAgICAgICAgZGVsZXRlX3J1bGUobm9kZSwgYW5pbWF0aW9uX25hbWUpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpbml0KHByb2dyYW0sIGR1cmF0aW9uKSB7XG4gICAgICAgIGNvbnN0IGQgPSBwcm9ncmFtLmIgLSB0O1xuICAgICAgICBkdXJhdGlvbiAqPSBNYXRoLmFicyhkKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGE6IHQsXG4gICAgICAgICAgICBiOiBwcm9ncmFtLmIsXG4gICAgICAgICAgICBkLFxuICAgICAgICAgICAgZHVyYXRpb24sXG4gICAgICAgICAgICBzdGFydDogcHJvZ3JhbS5zdGFydCxcbiAgICAgICAgICAgIGVuZDogcHJvZ3JhbS5zdGFydCArIGR1cmF0aW9uLFxuICAgICAgICAgICAgZ3JvdXA6IHByb2dyYW0uZ3JvdXBcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ28oYikge1xuICAgICAgICBjb25zdCB7IGRlbGF5ID0gMCwgZHVyYXRpb24gPSAzMDAsIGVhc2luZyA9IGlkZW50aXR5LCB0aWNrID0gbm9vcCwgY3NzIH0gPSBjb25maWcgfHwgbnVsbF90cmFuc2l0aW9uO1xuICAgICAgICBjb25zdCBwcm9ncmFtID0ge1xuICAgICAgICAgICAgc3RhcnQ6IG5vdygpICsgZGVsYXksXG4gICAgICAgICAgICBiXG4gICAgICAgIH07XG4gICAgICAgIGlmICghYikge1xuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZSB0b2RvOiBpbXByb3ZlIHR5cGluZ3NcbiAgICAgICAgICAgIHByb2dyYW0uZ3JvdXAgPSBvdXRyb3M7XG4gICAgICAgICAgICBvdXRyb3MuciArPSAxO1xuICAgICAgICB9XG4gICAgICAgIGlmIChydW5uaW5nX3Byb2dyYW0pIHtcbiAgICAgICAgICAgIHBlbmRpbmdfcHJvZ3JhbSA9IHByb2dyYW07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBpZiB0aGlzIGlzIGFuIGludHJvLCBhbmQgdGhlcmUncyBhIGRlbGF5LCB3ZSBuZWVkIHRvIGRvXG4gICAgICAgICAgICAvLyBhbiBpbml0aWFsIHRpY2sgYW5kL29yIGFwcGx5IENTUyBhbmltYXRpb24gaW1tZWRpYXRlbHlcbiAgICAgICAgICAgIGlmIChjc3MpIHtcbiAgICAgICAgICAgICAgICBjbGVhcl9hbmltYXRpb24oKTtcbiAgICAgICAgICAgICAgICBhbmltYXRpb25fbmFtZSA9IGNyZWF0ZV9ydWxlKG5vZGUsIHQsIGIsIGR1cmF0aW9uLCBkZWxheSwgZWFzaW5nLCBjc3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGIpXG4gICAgICAgICAgICAgICAgdGljaygwLCAxKTtcbiAgICAgICAgICAgIHJ1bm5pbmdfcHJvZ3JhbSA9IGluaXQocHJvZ3JhbSwgZHVyYXRpb24pO1xuICAgICAgICAgICAgYWRkX3JlbmRlcl9jYWxsYmFjaygoKSA9PiBkaXNwYXRjaChub2RlLCBiLCAnc3RhcnQnKSk7XG4gICAgICAgICAgICBsb29wKG5vdyA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHBlbmRpbmdfcHJvZ3JhbSAmJiBub3cgPiBwZW5kaW5nX3Byb2dyYW0uc3RhcnQpIHtcbiAgICAgICAgICAgICAgICAgICAgcnVubmluZ19wcm9ncmFtID0gaW5pdChwZW5kaW5nX3Byb2dyYW0sIGR1cmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgcGVuZGluZ19wcm9ncmFtID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgZGlzcGF0Y2gobm9kZSwgcnVubmluZ19wcm9ncmFtLmIsICdzdGFydCcpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY3NzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGVhcl9hbmltYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFuaW1hdGlvbl9uYW1lID0gY3JlYXRlX3J1bGUobm9kZSwgdCwgcnVubmluZ19wcm9ncmFtLmIsIHJ1bm5pbmdfcHJvZ3JhbS5kdXJhdGlvbiwgMCwgZWFzaW5nLCBjb25maWcuY3NzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocnVubmluZ19wcm9ncmFtKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChub3cgPj0gcnVubmluZ19wcm9ncmFtLmVuZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGljayh0ID0gcnVubmluZ19wcm9ncmFtLmIsIDEgLSB0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BhdGNoKG5vZGUsIHJ1bm5pbmdfcHJvZ3JhbS5iLCAnZW5kJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXBlbmRpbmdfcHJvZ3JhbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHdlJ3JlIGRvbmVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAocnVubmluZ19wcm9ncmFtLmIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaW50cm8g4oCUIHdlIGNhbiB0aWR5IHVwIGltbWVkaWF0ZWx5XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsZWFyX2FuaW1hdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gb3V0cm8g4oCUIG5lZWRzIHRvIGJlIGNvb3JkaW5hdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghLS1ydW5uaW5nX3Byb2dyYW0uZ3JvdXAucilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJ1bl9hbGwocnVubmluZ19wcm9ncmFtLmdyb3VwLmMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJ1bm5pbmdfcHJvZ3JhbSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAobm93ID49IHJ1bm5pbmdfcHJvZ3JhbS5zdGFydCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgcCA9IG5vdyAtIHJ1bm5pbmdfcHJvZ3JhbS5zdGFydDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHQgPSBydW5uaW5nX3Byb2dyYW0uYSArIHJ1bm5pbmdfcHJvZ3JhbS5kICogZWFzaW5nKHAgLyBydW5uaW5nX3Byb2dyYW0uZHVyYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGljayh0LCAxIC0gdCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuICEhKHJ1bm5pbmdfcHJvZ3JhbSB8fCBwZW5kaW5nX3Byb2dyYW0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcnVuKGIpIHtcbiAgICAgICAgICAgIGlmIChpc19mdW5jdGlvbihjb25maWcpKSB7XG4gICAgICAgICAgICAgICAgd2FpdCgpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpZyA9IGNvbmZpZygpO1xuICAgICAgICAgICAgICAgICAgICBnbyhiKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGdvKGIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBlbmQoKSB7XG4gICAgICAgICAgICBjbGVhcl9hbmltYXRpb24oKTtcbiAgICAgICAgICAgIHJ1bm5pbmdfcHJvZ3JhbSA9IHBlbmRpbmdfcHJvZ3JhbSA9IG51bGw7XG4gICAgICAgIH1cbiAgICB9O1xufVxuXG5mdW5jdGlvbiBoYW5kbGVfcHJvbWlzZShwcm9taXNlLCBpbmZvKSB7XG4gICAgY29uc3QgdG9rZW4gPSBpbmZvLnRva2VuID0ge307XG4gICAgZnVuY3Rpb24gdXBkYXRlKHR5cGUsIGluZGV4LCBrZXksIHZhbHVlKSB7XG4gICAgICAgIGlmIChpbmZvLnRva2VuICE9PSB0b2tlbilcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgaW5mby5yZXNvbHZlZCA9IHZhbHVlO1xuICAgICAgICBsZXQgY2hpbGRfY3R4ID0gaW5mby5jdHg7XG4gICAgICAgIGlmIChrZXkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgY2hpbGRfY3R4ID0gY2hpbGRfY3R4LnNsaWNlKCk7XG4gICAgICAgICAgICBjaGlsZF9jdHhba2V5XSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGJsb2NrID0gdHlwZSAmJiAoaW5mby5jdXJyZW50ID0gdHlwZSkoY2hpbGRfY3R4KTtcbiAgICAgICAgbGV0IG5lZWRzX2ZsdXNoID0gZmFsc2U7XG4gICAgICAgIGlmIChpbmZvLmJsb2NrKSB7XG4gICAgICAgICAgICBpZiAoaW5mby5ibG9ja3MpIHtcbiAgICAgICAgICAgICAgICBpbmZvLmJsb2Nrcy5mb3JFYWNoKChibG9jaywgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAoaSAhPT0gaW5kZXggJiYgYmxvY2spIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwX291dHJvcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbl9vdXQoYmxvY2ssIDEsIDEsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmJsb2Nrc1tpXSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrX291dHJvcygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpbmZvLmJsb2NrLmQoMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBibG9jay5jKCk7XG4gICAgICAgICAgICB0cmFuc2l0aW9uX2luKGJsb2NrLCAxKTtcbiAgICAgICAgICAgIGJsb2NrLm0oaW5mby5tb3VudCgpLCBpbmZvLmFuY2hvcik7XG4gICAgICAgICAgICBuZWVkc19mbHVzaCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgaW5mby5ibG9jayA9IGJsb2NrO1xuICAgICAgICBpZiAoaW5mby5ibG9ja3MpXG4gICAgICAgICAgICBpbmZvLmJsb2Nrc1tpbmRleF0gPSBibG9jaztcbiAgICAgICAgaWYgKG5lZWRzX2ZsdXNoKSB7XG4gICAgICAgICAgICBmbHVzaCgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChpc19wcm9taXNlKHByb21pc2UpKSB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRfY29tcG9uZW50ID0gZ2V0X2N1cnJlbnRfY29tcG9uZW50KCk7XG4gICAgICAgIHByb21pc2UudGhlbih2YWx1ZSA9PiB7XG4gICAgICAgICAgICBzZXRfY3VycmVudF9jb21wb25lbnQoY3VycmVudF9jb21wb25lbnQpO1xuICAgICAgICAgICAgdXBkYXRlKGluZm8udGhlbiwgMSwgaW5mby52YWx1ZSwgdmFsdWUpO1xuICAgICAgICAgICAgc2V0X2N1cnJlbnRfY29tcG9uZW50KG51bGwpO1xuICAgICAgICB9LCBlcnJvciA9PiB7XG4gICAgICAgICAgICBzZXRfY3VycmVudF9jb21wb25lbnQoY3VycmVudF9jb21wb25lbnQpO1xuICAgICAgICAgICAgdXBkYXRlKGluZm8uY2F0Y2gsIDIsIGluZm8uZXJyb3IsIGVycm9yKTtcbiAgICAgICAgICAgIHNldF9jdXJyZW50X2NvbXBvbmVudChudWxsKTtcbiAgICAgICAgfSk7XG4gICAgICAgIC8vIGlmIHdlIHByZXZpb3VzbHkgaGFkIGEgdGhlbi9jYXRjaCBibG9jaywgZGVzdHJveSBpdFxuICAgICAgICBpZiAoaW5mby5jdXJyZW50ICE9PSBpbmZvLnBlbmRpbmcpIHtcbiAgICAgICAgICAgIHVwZGF0ZShpbmZvLnBlbmRpbmcsIDApO1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGlmIChpbmZvLmN1cnJlbnQgIT09IGluZm8udGhlbikge1xuICAgICAgICAgICAgdXBkYXRlKGluZm8udGhlbiwgMSwgaW5mby52YWx1ZSwgcHJvbWlzZSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBpbmZvLnJlc29sdmVkID0gcHJvbWlzZTtcbiAgICB9XG59XG5cbmNvbnN0IGdsb2JhbHMgPSAodHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgPyB3aW5kb3cgOiBnbG9iYWwpO1xuXG5mdW5jdGlvbiBkZXN0cm95X2Jsb2NrKGJsb2NrLCBsb29rdXApIHtcbiAgICBibG9jay5kKDEpO1xuICAgIGxvb2t1cC5kZWxldGUoYmxvY2sua2V5KTtcbn1cbmZ1bmN0aW9uIG91dHJvX2FuZF9kZXN0cm95X2Jsb2NrKGJsb2NrLCBsb29rdXApIHtcbiAgICB0cmFuc2l0aW9uX291dChibG9jaywgMSwgMSwgKCkgPT4ge1xuICAgICAgICBsb29rdXAuZGVsZXRlKGJsb2NrLmtleSk7XG4gICAgfSk7XG59XG5mdW5jdGlvbiBmaXhfYW5kX2Rlc3Ryb3lfYmxvY2soYmxvY2ssIGxvb2t1cCkge1xuICAgIGJsb2NrLmYoKTtcbiAgICBkZXN0cm95X2Jsb2NrKGJsb2NrLCBsb29rdXApO1xufVxuZnVuY3Rpb24gZml4X2FuZF9vdXRyb19hbmRfZGVzdHJveV9ibG9jayhibG9jaywgbG9va3VwKSB7XG4gICAgYmxvY2suZigpO1xuICAgIG91dHJvX2FuZF9kZXN0cm95X2Jsb2NrKGJsb2NrLCBsb29rdXApO1xufVxuZnVuY3Rpb24gdXBkYXRlX2tleWVkX2VhY2gob2xkX2Jsb2NrcywgZGlydHksIGdldF9rZXksIGR5bmFtaWMsIGN0eCwgbGlzdCwgbG9va3VwLCBub2RlLCBkZXN0cm95LCBjcmVhdGVfZWFjaF9ibG9jaywgbmV4dCwgZ2V0X2NvbnRleHQpIHtcbiAgICBsZXQgbyA9IG9sZF9ibG9ja3MubGVuZ3RoO1xuICAgIGxldCBuID0gbGlzdC5sZW5ndGg7XG4gICAgbGV0IGkgPSBvO1xuICAgIGNvbnN0IG9sZF9pbmRleGVzID0ge307XG4gICAgd2hpbGUgKGktLSlcbiAgICAgICAgb2xkX2luZGV4ZXNbb2xkX2Jsb2Nrc1tpXS5rZXldID0gaTtcbiAgICBjb25zdCBuZXdfYmxvY2tzID0gW107XG4gICAgY29uc3QgbmV3X2xvb2t1cCA9IG5ldyBNYXAoKTtcbiAgICBjb25zdCBkZWx0YXMgPSBuZXcgTWFwKCk7XG4gICAgaSA9IG47XG4gICAgd2hpbGUgKGktLSkge1xuICAgICAgICBjb25zdCBjaGlsZF9jdHggPSBnZXRfY29udGV4dChjdHgsIGxpc3QsIGkpO1xuICAgICAgICBjb25zdCBrZXkgPSBnZXRfa2V5KGNoaWxkX2N0eCk7XG4gICAgICAgIGxldCBibG9jayA9IGxvb2t1cC5nZXQoa2V5KTtcbiAgICAgICAgaWYgKCFibG9jaykge1xuICAgICAgICAgICAgYmxvY2sgPSBjcmVhdGVfZWFjaF9ibG9jayhrZXksIGNoaWxkX2N0eCk7XG4gICAgICAgICAgICBibG9jay5jKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZHluYW1pYykge1xuICAgICAgICAgICAgYmxvY2sucChjaGlsZF9jdHgsIGRpcnR5KTtcbiAgICAgICAgfVxuICAgICAgICBuZXdfbG9va3VwLnNldChrZXksIG5ld19ibG9ja3NbaV0gPSBibG9jayk7XG4gICAgICAgIGlmIChrZXkgaW4gb2xkX2luZGV4ZXMpXG4gICAgICAgICAgICBkZWx0YXMuc2V0KGtleSwgTWF0aC5hYnMoaSAtIG9sZF9pbmRleGVzW2tleV0pKTtcbiAgICB9XG4gICAgY29uc3Qgd2lsbF9tb3ZlID0gbmV3IFNldCgpO1xuICAgIGNvbnN0IGRpZF9tb3ZlID0gbmV3IFNldCgpO1xuICAgIGZ1bmN0aW9uIGluc2VydChibG9jaykge1xuICAgICAgICB0cmFuc2l0aW9uX2luKGJsb2NrLCAxKTtcbiAgICAgICAgYmxvY2subShub2RlLCBuZXh0KTtcbiAgICAgICAgbG9va3VwLnNldChibG9jay5rZXksIGJsb2NrKTtcbiAgICAgICAgbmV4dCA9IGJsb2NrLmZpcnN0O1xuICAgICAgICBuLS07XG4gICAgfVxuICAgIHdoaWxlIChvICYmIG4pIHtcbiAgICAgICAgY29uc3QgbmV3X2Jsb2NrID0gbmV3X2Jsb2Nrc1tuIC0gMV07XG4gICAgICAgIGNvbnN0IG9sZF9ibG9jayA9IG9sZF9ibG9ja3NbbyAtIDFdO1xuICAgICAgICBjb25zdCBuZXdfa2V5ID0gbmV3X2Jsb2NrLmtleTtcbiAgICAgICAgY29uc3Qgb2xkX2tleSA9IG9sZF9ibG9jay5rZXk7XG4gICAgICAgIGlmIChuZXdfYmxvY2sgPT09IG9sZF9ibG9jaykge1xuICAgICAgICAgICAgLy8gZG8gbm90aGluZ1xuICAgICAgICAgICAgbmV4dCA9IG5ld19ibG9jay5maXJzdDtcbiAgICAgICAgICAgIG8tLTtcbiAgICAgICAgICAgIG4tLTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICghbmV3X2xvb2t1cC5oYXMob2xkX2tleSkpIHtcbiAgICAgICAgICAgIC8vIHJlbW92ZSBvbGQgYmxvY2tcbiAgICAgICAgICAgIGRlc3Ryb3kob2xkX2Jsb2NrLCBsb29rdXApO1xuICAgICAgICAgICAgby0tO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKCFsb29rdXAuaGFzKG5ld19rZXkpIHx8IHdpbGxfbW92ZS5oYXMobmV3X2tleSkpIHtcbiAgICAgICAgICAgIGluc2VydChuZXdfYmxvY2spO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGRpZF9tb3ZlLmhhcyhvbGRfa2V5KSkge1xuICAgICAgICAgICAgby0tO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGRlbHRhcy5nZXQobmV3X2tleSkgPiBkZWx0YXMuZ2V0KG9sZF9rZXkpKSB7XG4gICAgICAgICAgICBkaWRfbW92ZS5hZGQobmV3X2tleSk7XG4gICAgICAgICAgICBpbnNlcnQobmV3X2Jsb2NrKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHdpbGxfbW92ZS5hZGQob2xkX2tleSk7XG4gICAgICAgICAgICBvLS07XG4gICAgICAgIH1cbiAgICB9XG4gICAgd2hpbGUgKG8tLSkge1xuICAgICAgICBjb25zdCBvbGRfYmxvY2sgPSBvbGRfYmxvY2tzW29dO1xuICAgICAgICBpZiAoIW5ld19sb29rdXAuaGFzKG9sZF9ibG9jay5rZXkpKVxuICAgICAgICAgICAgZGVzdHJveShvbGRfYmxvY2ssIGxvb2t1cCk7XG4gICAgfVxuICAgIHdoaWxlIChuKVxuICAgICAgICBpbnNlcnQobmV3X2Jsb2Nrc1tuIC0gMV0pO1xuICAgIHJldHVybiBuZXdfYmxvY2tzO1xufVxuZnVuY3Rpb24gbWVhc3VyZShibG9ja3MpIHtcbiAgICBjb25zdCByZWN0cyA9IHt9O1xuICAgIGxldCBpID0gYmxvY2tzLmxlbmd0aDtcbiAgICB3aGlsZSAoaS0tKVxuICAgICAgICByZWN0c1tibG9ja3NbaV0ua2V5XSA9IGJsb2Nrc1tpXS5ub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHJldHVybiByZWN0cztcbn1cblxuZnVuY3Rpb24gZ2V0X3NwcmVhZF91cGRhdGUobGV2ZWxzLCB1cGRhdGVzKSB7XG4gICAgY29uc3QgdXBkYXRlID0ge307XG4gICAgY29uc3QgdG9fbnVsbF9vdXQgPSB7fTtcbiAgICBjb25zdCBhY2NvdW50ZWRfZm9yID0geyAkJHNjb3BlOiAxIH07XG4gICAgbGV0IGkgPSBsZXZlbHMubGVuZ3RoO1xuICAgIHdoaWxlIChpLS0pIHtcbiAgICAgICAgY29uc3QgbyA9IGxldmVsc1tpXTtcbiAgICAgICAgY29uc3QgbiA9IHVwZGF0ZXNbaV07XG4gICAgICAgIGlmIChuKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBvKSB7XG4gICAgICAgICAgICAgICAgaWYgKCEoa2V5IGluIG4pKVxuICAgICAgICAgICAgICAgICAgICB0b19udWxsX291dFtrZXldID0gMTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIG4pIHtcbiAgICAgICAgICAgICAgICBpZiAoIWFjY291bnRlZF9mb3Jba2V5XSkge1xuICAgICAgICAgICAgICAgICAgICB1cGRhdGVba2V5XSA9IG5ba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgYWNjb3VudGVkX2ZvcltrZXldID0gMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZXZlbHNbaV0gPSBuO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gbykge1xuICAgICAgICAgICAgICAgIGFjY291bnRlZF9mb3Jba2V5XSA9IDE7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgaW4gdG9fbnVsbF9vdXQpIHtcbiAgICAgICAgaWYgKCEoa2V5IGluIHVwZGF0ZSkpXG4gICAgICAgICAgICB1cGRhdGVba2V5XSA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIHVwZGF0ZTtcbn1cbmZ1bmN0aW9uIGdldF9zcHJlYWRfb2JqZWN0KHNwcmVhZF9wcm9wcykge1xuICAgIHJldHVybiB0eXBlb2Ygc3ByZWFkX3Byb3BzID09PSAnb2JqZWN0JyAmJiBzcHJlYWRfcHJvcHMgIT09IG51bGwgPyBzcHJlYWRfcHJvcHMgOiB7fTtcbn1cblxuLy8gc291cmNlOiBodHRwczovL2h0bWwuc3BlYy53aGF0d2cub3JnL211bHRpcGFnZS9pbmRpY2VzLmh0bWxcbmNvbnN0IGJvb2xlYW5fYXR0cmlidXRlcyA9IG5ldyBTZXQoW1xuICAgICdhbGxvd2Z1bGxzY3JlZW4nLFxuICAgICdhbGxvd3BheW1lbnRyZXF1ZXN0JyxcbiAgICAnYXN5bmMnLFxuICAgICdhdXRvZm9jdXMnLFxuICAgICdhdXRvcGxheScsXG4gICAgJ2NoZWNrZWQnLFxuICAgICdjb250cm9scycsXG4gICAgJ2RlZmF1bHQnLFxuICAgICdkZWZlcicsXG4gICAgJ2Rpc2FibGVkJyxcbiAgICAnZm9ybW5vdmFsaWRhdGUnLFxuICAgICdoaWRkZW4nLFxuICAgICdpc21hcCcsXG4gICAgJ2xvb3AnLFxuICAgICdtdWx0aXBsZScsXG4gICAgJ211dGVkJyxcbiAgICAnbm9tb2R1bGUnLFxuICAgICdub3ZhbGlkYXRlJyxcbiAgICAnb3BlbicsXG4gICAgJ3BsYXlzaW5saW5lJyxcbiAgICAncmVhZG9ubHknLFxuICAgICdyZXF1aXJlZCcsXG4gICAgJ3JldmVyc2VkJyxcbiAgICAnc2VsZWN0ZWQnXG5dKTtcblxuY29uc3QgaW52YWxpZF9hdHRyaWJ1dGVfbmFtZV9jaGFyYWN0ZXIgPSAvW1xccydcIj4vPVxcdXtGREQwfS1cXHV7RkRFRn1cXHV7RkZGRX1cXHV7RkZGRn1cXHV7MUZGRkV9XFx1ezFGRkZGfVxcdXsyRkZGRX1cXHV7MkZGRkZ9XFx1ezNGRkZFfVxcdXszRkZGRn1cXHV7NEZGRkV9XFx1ezRGRkZGfVxcdXs1RkZGRX1cXHV7NUZGRkZ9XFx1ezZGRkZFfVxcdXs2RkZGRn1cXHV7N0ZGRkV9XFx1ezdGRkZGfVxcdXs4RkZGRX1cXHV7OEZGRkZ9XFx1ezlGRkZFfVxcdXs5RkZGRn1cXHV7QUZGRkV9XFx1e0FGRkZGfVxcdXtCRkZGRX1cXHV7QkZGRkZ9XFx1e0NGRkZFfVxcdXtDRkZGRn1cXHV7REZGRkV9XFx1e0RGRkZGfVxcdXtFRkZGRX1cXHV7RUZGRkZ9XFx1e0ZGRkZFfVxcdXtGRkZGRn1cXHV7MTBGRkZFfVxcdXsxMEZGRkZ9XS91O1xuLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2Uvc3ludGF4Lmh0bWwjYXR0cmlidXRlcy0yXG4vLyBodHRwczovL2luZnJhLnNwZWMud2hhdHdnLm9yZy8jbm9uY2hhcmFjdGVyXG5mdW5jdGlvbiBzcHJlYWQoYXJncywgY2xhc3Nlc190b19hZGQpIHtcbiAgICBjb25zdCBhdHRyaWJ1dGVzID0gT2JqZWN0LmFzc2lnbih7fSwgLi4uYXJncyk7XG4gICAgaWYgKGNsYXNzZXNfdG9fYWRkKSB7XG4gICAgICAgIGlmIChhdHRyaWJ1dGVzLmNsYXNzID09IG51bGwpIHtcbiAgICAgICAgICAgIGF0dHJpYnV0ZXMuY2xhc3MgPSBjbGFzc2VzX3RvX2FkZDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGF0dHJpYnV0ZXMuY2xhc3MgKz0gJyAnICsgY2xhc3Nlc190b19hZGQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgbGV0IHN0ciA9ICcnO1xuICAgIE9iamVjdC5rZXlzKGF0dHJpYnV0ZXMpLmZvckVhY2gobmFtZSA9PiB7XG4gICAgICAgIGlmIChpbnZhbGlkX2F0dHJpYnV0ZV9uYW1lX2NoYXJhY3Rlci50ZXN0KG5hbWUpKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGF0dHJpYnV0ZXNbbmFtZV07XG4gICAgICAgIGlmICh2YWx1ZSA9PT0gdHJ1ZSlcbiAgICAgICAgICAgIHN0ciArPSBcIiBcIiArIG5hbWU7XG4gICAgICAgIGVsc2UgaWYgKGJvb2xlYW5fYXR0cmlidXRlcy5oYXMobmFtZS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgICAgICAgaWYgKHZhbHVlKVxuICAgICAgICAgICAgICAgIHN0ciArPSBcIiBcIiArIG5hbWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodmFsdWUgIT0gbnVsbCkge1xuICAgICAgICAgICAgc3RyICs9IFwiIFwiICsgbmFtZSArIFwiPVwiICsgSlNPTi5zdHJpbmdpZnkoU3RyaW5nKHZhbHVlKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC9cIi9nLCAnJiMzNDsnKVxuICAgICAgICAgICAgICAgIC5yZXBsYWNlKC8nL2csICcmIzM5OycpKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBzdHI7XG59XG5jb25zdCBlc2NhcGVkID0ge1xuICAgICdcIic6ICcmcXVvdDsnLFxuICAgIFwiJ1wiOiAnJiMzOTsnLFxuICAgICcmJzogJyZhbXA7JyxcbiAgICAnPCc6ICcmbHQ7JyxcbiAgICAnPic6ICcmZ3Q7J1xufTtcbmZ1bmN0aW9uIGVzY2FwZShodG1sKSB7XG4gICAgcmV0dXJuIFN0cmluZyhodG1sKS5yZXBsYWNlKC9bXCInJjw+XS9nLCBtYXRjaCA9PiBlc2NhcGVkW21hdGNoXSk7XG59XG5mdW5jdGlvbiBlYWNoKGl0ZW1zLCBmbikge1xuICAgIGxldCBzdHIgPSAnJztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZW1zLmxlbmd0aDsgaSArPSAxKSB7XG4gICAgICAgIHN0ciArPSBmbihpdGVtc1tpXSwgaSk7XG4gICAgfVxuICAgIHJldHVybiBzdHI7XG59XG5jb25zdCBtaXNzaW5nX2NvbXBvbmVudCA9IHtcbiAgICAkJHJlbmRlcjogKCkgPT4gJydcbn07XG5mdW5jdGlvbiB2YWxpZGF0ZV9jb21wb25lbnQoY29tcG9uZW50LCBuYW1lKSB7XG4gICAgaWYgKCFjb21wb25lbnQgfHwgIWNvbXBvbmVudC4kJHJlbmRlcikge1xuICAgICAgICBpZiAobmFtZSA9PT0gJ3N2ZWx0ZTpjb21wb25lbnQnKVxuICAgICAgICAgICAgbmFtZSArPSAnIHRoaXM9ey4uLn0nO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYDwke25hbWV9PiBpcyBub3QgYSB2YWxpZCBTU1IgY29tcG9uZW50LiBZb3UgbWF5IG5lZWQgdG8gcmV2aWV3IHlvdXIgYnVpbGQgY29uZmlnIHRvIGVuc3VyZSB0aGF0IGRlcGVuZGVuY2llcyBhcmUgY29tcGlsZWQsIHJhdGhlciB0aGFuIGltcG9ydGVkIGFzIHByZS1jb21waWxlZCBtb2R1bGVzYCk7XG4gICAgfVxuICAgIHJldHVybiBjb21wb25lbnQ7XG59XG5mdW5jdGlvbiBkZWJ1ZyhmaWxlLCBsaW5lLCBjb2x1bW4sIHZhbHVlcykge1xuICAgIGNvbnNvbGUubG9nKGB7QGRlYnVnfSAke2ZpbGUgPyBmaWxlICsgJyAnIDogJyd9KCR7bGluZX06JHtjb2x1bW59KWApOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLWNvbnNvbGVcbiAgICBjb25zb2xlLmxvZyh2YWx1ZXMpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLWNvbnNvbGVcbiAgICByZXR1cm4gJyc7XG59XG5sZXQgb25fZGVzdHJveTtcbmZ1bmN0aW9uIGNyZWF0ZV9zc3JfY29tcG9uZW50KGZuKSB7XG4gICAgZnVuY3Rpb24gJCRyZW5kZXIocmVzdWx0LCBwcm9wcywgYmluZGluZ3MsIHNsb3RzKSB7XG4gICAgICAgIGNvbnN0IHBhcmVudF9jb21wb25lbnQgPSBjdXJyZW50X2NvbXBvbmVudDtcbiAgICAgICAgY29uc3QgJCQgPSB7XG4gICAgICAgICAgICBvbl9kZXN0cm95LFxuICAgICAgICAgICAgY29udGV4dDogbmV3IE1hcChwYXJlbnRfY29tcG9uZW50ID8gcGFyZW50X2NvbXBvbmVudC4kJC5jb250ZXh0IDogW10pLFxuICAgICAgICAgICAgLy8gdGhlc2Ugd2lsbCBiZSBpbW1lZGlhdGVseSBkaXNjYXJkZWRcbiAgICAgICAgICAgIG9uX21vdW50OiBbXSxcbiAgICAgICAgICAgIGJlZm9yZV91cGRhdGU6IFtdLFxuICAgICAgICAgICAgYWZ0ZXJfdXBkYXRlOiBbXSxcbiAgICAgICAgICAgIGNhbGxiYWNrczogYmxhbmtfb2JqZWN0KClcbiAgICAgICAgfTtcbiAgICAgICAgc2V0X2N1cnJlbnRfY29tcG9uZW50KHsgJCQgfSk7XG4gICAgICAgIGNvbnN0IGh0bWwgPSBmbihyZXN1bHQsIHByb3BzLCBiaW5kaW5ncywgc2xvdHMpO1xuICAgICAgICBzZXRfY3VycmVudF9jb21wb25lbnQocGFyZW50X2NvbXBvbmVudCk7XG4gICAgICAgIHJldHVybiBodG1sO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICByZW5kZXI6IChwcm9wcyA9IHt9LCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgICAgIG9uX2Rlc3Ryb3kgPSBbXTtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHsgaGVhZDogJycsIGNzczogbmV3IFNldCgpIH07XG4gICAgICAgICAgICBjb25zdCBodG1sID0gJCRyZW5kZXIocmVzdWx0LCBwcm9wcywge30sIG9wdGlvbnMpO1xuICAgICAgICAgICAgcnVuX2FsbChvbl9kZXN0cm95KTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgaHRtbCxcbiAgICAgICAgICAgICAgICBjc3M6IHtcbiAgICAgICAgICAgICAgICAgICAgY29kZTogQXJyYXkuZnJvbShyZXN1bHQuY3NzKS5tYXAoY3NzID0+IGNzcy5jb2RlKS5qb2luKCdcXG4nKSxcbiAgICAgICAgICAgICAgICAgICAgbWFwOiBudWxsIC8vIFRPRE9cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIGhlYWQ6IHJlc3VsdC5oZWFkXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgICAgICAkJHJlbmRlclxuICAgIH07XG59XG5mdW5jdGlvbiBhZGRfYXR0cmlidXRlKG5hbWUsIHZhbHVlLCBib29sZWFuKSB7XG4gICAgaWYgKHZhbHVlID09IG51bGwgfHwgKGJvb2xlYW4gJiYgIXZhbHVlKSlcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIHJldHVybiBgICR7bmFtZX0ke3ZhbHVlID09PSB0cnVlID8gJycgOiBgPSR7dHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IEpTT04uc3RyaW5naWZ5KGVzY2FwZSh2YWx1ZSkpIDogYFwiJHt2YWx1ZX1cImB9YH1gO1xufVxuZnVuY3Rpb24gYWRkX2NsYXNzZXMoY2xhc3Nlcykge1xuICAgIHJldHVybiBjbGFzc2VzID8gYCBjbGFzcz1cIiR7Y2xhc3Nlc31cImAgOiBgYDtcbn1cblxuZnVuY3Rpb24gYmluZChjb21wb25lbnQsIG5hbWUsIGNhbGxiYWNrKSB7XG4gICAgY29uc3QgaW5kZXggPSBjb21wb25lbnQuJCQucHJvcHNbbmFtZV07XG4gICAgaWYgKGluZGV4ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgY29tcG9uZW50LiQkLmJvdW5kW2luZGV4XSA9IGNhbGxiYWNrO1xuICAgICAgICBjYWxsYmFjayhjb21wb25lbnQuJCQuY3R4W2luZGV4XSk7XG4gICAgfVxufVxuZnVuY3Rpb24gY3JlYXRlX2NvbXBvbmVudChibG9jaykge1xuICAgIGJsb2NrICYmIGJsb2NrLmMoKTtcbn1cbmZ1bmN0aW9uIGNsYWltX2NvbXBvbmVudChibG9jaywgcGFyZW50X25vZGVzKSB7XG4gICAgYmxvY2sgJiYgYmxvY2subChwYXJlbnRfbm9kZXMpO1xufVxuZnVuY3Rpb24gbW91bnRfY29tcG9uZW50KGNvbXBvbmVudCwgdGFyZ2V0LCBhbmNob3IpIHtcbiAgICBjb25zdCB7IGZyYWdtZW50LCBvbl9tb3VudCwgb25fZGVzdHJveSwgYWZ0ZXJfdXBkYXRlIH0gPSBjb21wb25lbnQuJCQ7XG4gICAgZnJhZ21lbnQgJiYgZnJhZ21lbnQubSh0YXJnZXQsIGFuY2hvcik7XG4gICAgLy8gb25Nb3VudCBoYXBwZW5zIGJlZm9yZSB0aGUgaW5pdGlhbCBhZnRlclVwZGF0ZVxuICAgIGFkZF9yZW5kZXJfY2FsbGJhY2soKCkgPT4ge1xuICAgICAgICBjb25zdCBuZXdfb25fZGVzdHJveSA9IG9uX21vdW50Lm1hcChydW4pLmZpbHRlcihpc19mdW5jdGlvbik7XG4gICAgICAgIGlmIChvbl9kZXN0cm95KSB7XG4gICAgICAgICAgICBvbl9kZXN0cm95LnB1c2goLi4ubmV3X29uX2Rlc3Ryb3kpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgLy8gRWRnZSBjYXNlIC0gY29tcG9uZW50IHdhcyBkZXN0cm95ZWQgaW1tZWRpYXRlbHksXG4gICAgICAgICAgICAvLyBtb3N0IGxpa2VseSBhcyBhIHJlc3VsdCBvZiBhIGJpbmRpbmcgaW5pdGlhbGlzaW5nXG4gICAgICAgICAgICBydW5fYWxsKG5ld19vbl9kZXN0cm95KTtcbiAgICAgICAgfVxuICAgICAgICBjb21wb25lbnQuJCQub25fbW91bnQgPSBbXTtcbiAgICB9KTtcbiAgICBhZnRlcl91cGRhdGUuZm9yRWFjaChhZGRfcmVuZGVyX2NhbGxiYWNrKTtcbn1cbmZ1bmN0aW9uIGRlc3Ryb3lfY29tcG9uZW50KGNvbXBvbmVudCwgZGV0YWNoaW5nKSB7XG4gICAgY29uc3QgJCQgPSBjb21wb25lbnQuJCQ7XG4gICAgaWYgKCQkLmZyYWdtZW50ICE9PSBudWxsKSB7XG4gICAgICAgIHJ1bl9hbGwoJCQub25fZGVzdHJveSk7XG4gICAgICAgICQkLmZyYWdtZW50ICYmICQkLmZyYWdtZW50LmQoZGV0YWNoaW5nKTtcbiAgICAgICAgLy8gVE9ETyBudWxsIG91dCBvdGhlciByZWZzLCBpbmNsdWRpbmcgY29tcG9uZW50LiQkIChidXQgbmVlZCB0b1xuICAgICAgICAvLyBwcmVzZXJ2ZSBmaW5hbCBzdGF0ZT8pXG4gICAgICAgICQkLm9uX2Rlc3Ryb3kgPSAkJC5mcmFnbWVudCA9IG51bGw7XG4gICAgICAgICQkLmN0eCA9IFtdO1xuICAgIH1cbn1cbmZ1bmN0aW9uIG1ha2VfZGlydHkoY29tcG9uZW50LCBpKSB7XG4gICAgaWYgKGNvbXBvbmVudC4kJC5kaXJ0eVswXSA9PT0gLTEpIHtcbiAgICAgICAgZGlydHlfY29tcG9uZW50cy5wdXNoKGNvbXBvbmVudCk7XG4gICAgICAgIHNjaGVkdWxlX3VwZGF0ZSgpO1xuICAgICAgICBjb21wb25lbnQuJCQuZGlydHkuZmlsbCgwKTtcbiAgICB9XG4gICAgY29tcG9uZW50LiQkLmRpcnR5WyhpIC8gMzEpIHwgMF0gfD0gKDEgPDwgKGkgJSAzMSkpO1xufVxuZnVuY3Rpb24gaW5pdChjb21wb25lbnQsIG9wdGlvbnMsIGluc3RhbmNlLCBjcmVhdGVfZnJhZ21lbnQsIG5vdF9lcXVhbCwgcHJvcHMsIGRpcnR5ID0gWy0xXSkge1xuICAgIGNvbnN0IHBhcmVudF9jb21wb25lbnQgPSBjdXJyZW50X2NvbXBvbmVudDtcbiAgICBzZXRfY3VycmVudF9jb21wb25lbnQoY29tcG9uZW50KTtcbiAgICBjb25zdCBwcm9wX3ZhbHVlcyA9IG9wdGlvbnMucHJvcHMgfHwge307XG4gICAgY29uc3QgJCQgPSBjb21wb25lbnQuJCQgPSB7XG4gICAgICAgIGZyYWdtZW50OiBudWxsLFxuICAgICAgICBjdHg6IG51bGwsXG4gICAgICAgIC8vIHN0YXRlXG4gICAgICAgIHByb3BzLFxuICAgICAgICB1cGRhdGU6IG5vb3AsXG4gICAgICAgIG5vdF9lcXVhbCxcbiAgICAgICAgYm91bmQ6IGJsYW5rX29iamVjdCgpLFxuICAgICAgICAvLyBsaWZlY3ljbGVcbiAgICAgICAgb25fbW91bnQ6IFtdLFxuICAgICAgICBvbl9kZXN0cm95OiBbXSxcbiAgICAgICAgYmVmb3JlX3VwZGF0ZTogW10sXG4gICAgICAgIGFmdGVyX3VwZGF0ZTogW10sXG4gICAgICAgIGNvbnRleHQ6IG5ldyBNYXAocGFyZW50X2NvbXBvbmVudCA/IHBhcmVudF9jb21wb25lbnQuJCQuY29udGV4dCA6IFtdKSxcbiAgICAgICAgLy8gZXZlcnl0aGluZyBlbHNlXG4gICAgICAgIGNhbGxiYWNrczogYmxhbmtfb2JqZWN0KCksXG4gICAgICAgIGRpcnR5XG4gICAgfTtcbiAgICBsZXQgcmVhZHkgPSBmYWxzZTtcbiAgICAkJC5jdHggPSBpbnN0YW5jZVxuICAgICAgICA/IGluc3RhbmNlKGNvbXBvbmVudCwgcHJvcF92YWx1ZXMsIChpLCByZXQsIHZhbHVlID0gcmV0KSA9PiB7XG4gICAgICAgICAgICBpZiAoJCQuY3R4ICYmIG5vdF9lcXVhbCgkJC5jdHhbaV0sICQkLmN0eFtpXSA9IHZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGlmICgkJC5ib3VuZFtpXSlcbiAgICAgICAgICAgICAgICAgICAgJCQuYm91bmRbaV0odmFsdWUpO1xuICAgICAgICAgICAgICAgIGlmIChyZWFkeSlcbiAgICAgICAgICAgICAgICAgICAgbWFrZV9kaXJ0eShjb21wb25lbnQsIGkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgICAgfSlcbiAgICAgICAgOiBbXTtcbiAgICAkJC51cGRhdGUoKTtcbiAgICByZWFkeSA9IHRydWU7XG4gICAgcnVuX2FsbCgkJC5iZWZvcmVfdXBkYXRlKTtcbiAgICAvLyBgZmFsc2VgIGFzIGEgc3BlY2lhbCBjYXNlIG9mIG5vIERPTSBjb21wb25lbnRcbiAgICAkJC5mcmFnbWVudCA9IGNyZWF0ZV9mcmFnbWVudCA/IGNyZWF0ZV9mcmFnbWVudCgkJC5jdHgpIDogZmFsc2U7XG4gICAgaWYgKG9wdGlvbnMudGFyZ2V0KSB7XG4gICAgICAgIGlmIChvcHRpb25zLmh5ZHJhdGUpIHtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tbm9uLW51bGwtYXNzZXJ0aW9uXG4gICAgICAgICAgICAkJC5mcmFnbWVudCAmJiAkJC5mcmFnbWVudC5sKGNoaWxkcmVuKG9wdGlvbnMudGFyZ2V0KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLW5vbi1udWxsLWFzc2VydGlvblxuICAgICAgICAgICAgJCQuZnJhZ21lbnQgJiYgJCQuZnJhZ21lbnQuYygpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRpb25zLmludHJvKVxuICAgICAgICAgICAgdHJhbnNpdGlvbl9pbihjb21wb25lbnQuJCQuZnJhZ21lbnQpO1xuICAgICAgICBtb3VudF9jb21wb25lbnQoY29tcG9uZW50LCBvcHRpb25zLnRhcmdldCwgb3B0aW9ucy5hbmNob3IpO1xuICAgICAgICBmbHVzaCgpO1xuICAgIH1cbiAgICBzZXRfY3VycmVudF9jb21wb25lbnQocGFyZW50X2NvbXBvbmVudCk7XG59XG5sZXQgU3ZlbHRlRWxlbWVudDtcbmlmICh0eXBlb2YgSFRNTEVsZW1lbnQgPT09ICdmdW5jdGlvbicpIHtcbiAgICBTdmVsdGVFbGVtZW50ID0gY2xhc3MgZXh0ZW5kcyBIVE1MRWxlbWVudCB7XG4gICAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAgICAgc3VwZXIoKTtcbiAgICAgICAgICAgIHRoaXMuYXR0YWNoU2hhZG93KHsgbW9kZTogJ29wZW4nIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbm5lY3RlZENhbGxiYWNrKCkge1xuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZSB0b2RvOiBpbXByb3ZlIHR5cGluZ3NcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIHRoaXMuJCQuc2xvdHRlZCkge1xuICAgICAgICAgICAgICAgIC8vIEB0cy1pZ25vcmUgdG9kbzogaW1wcm92ZSB0eXBpbmdzXG4gICAgICAgICAgICAgICAgdGhpcy5hcHBlbmRDaGlsZCh0aGlzLiQkLnNsb3R0ZWRba2V5XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgYXR0cmlidXRlQ2hhbmdlZENhbGxiYWNrKGF0dHIsIF9vbGRWYWx1ZSwgbmV3VmFsdWUpIHtcbiAgICAgICAgICAgIHRoaXNbYXR0cl0gPSBuZXdWYWx1ZTtcbiAgICAgICAgfVxuICAgICAgICAkZGVzdHJveSgpIHtcbiAgICAgICAgICAgIGRlc3Ryb3lfY29tcG9uZW50KHRoaXMsIDEpO1xuICAgICAgICAgICAgdGhpcy4kZGVzdHJveSA9IG5vb3A7XG4gICAgICAgIH1cbiAgICAgICAgJG9uKHR5cGUsIGNhbGxiYWNrKSB7XG4gICAgICAgICAgICAvLyBUT0RPIHNob3VsZCB0aGlzIGRlbGVnYXRlIHRvIGFkZEV2ZW50TGlzdGVuZXI/XG4gICAgICAgICAgICBjb25zdCBjYWxsYmFja3MgPSAodGhpcy4kJC5jYWxsYmFja3NbdHlwZV0gfHwgKHRoaXMuJCQuY2FsbGJhY2tzW3R5cGVdID0gW10pKTtcbiAgICAgICAgICAgIGNhbGxiYWNrcy5wdXNoKGNhbGxiYWNrKTtcbiAgICAgICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5kZXggPSBjYWxsYmFja3MuaW5kZXhPZihjYWxsYmFjayk7XG4gICAgICAgICAgICAgICAgaWYgKGluZGV4ICE9PSAtMSlcbiAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2tzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgICRzZXQoKSB7XG4gICAgICAgICAgICAvLyBvdmVycmlkZGVuIGJ5IGluc3RhbmNlLCBpZiBpdCBoYXMgcHJvcHNcbiAgICAgICAgfVxuICAgIH07XG59XG5jbGFzcyBTdmVsdGVDb21wb25lbnQge1xuICAgICRkZXN0cm95KCkge1xuICAgICAgICBkZXN0cm95X2NvbXBvbmVudCh0aGlzLCAxKTtcbiAgICAgICAgdGhpcy4kZGVzdHJveSA9IG5vb3A7XG4gICAgfVxuICAgICRvbih0eXBlLCBjYWxsYmFjaykge1xuICAgICAgICBjb25zdCBjYWxsYmFja3MgPSAodGhpcy4kJC5jYWxsYmFja3NbdHlwZV0gfHwgKHRoaXMuJCQuY2FsbGJhY2tzW3R5cGVdID0gW10pKTtcbiAgICAgICAgY2FsbGJhY2tzLnB1c2goY2FsbGJhY2spO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBjYWxsYmFja3MuaW5kZXhPZihjYWxsYmFjayk7XG4gICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKVxuICAgICAgICAgICAgICAgIGNhbGxiYWNrcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICAkc2V0KCkge1xuICAgICAgICAvLyBvdmVycmlkZGVuIGJ5IGluc3RhbmNlLCBpZiBpdCBoYXMgcHJvcHNcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGRpc3BhdGNoX2Rldih0eXBlLCBkZXRhaWwpIHtcbiAgICBkb2N1bWVudC5kaXNwYXRjaEV2ZW50KGN1c3RvbV9ldmVudCh0eXBlLCBkZXRhaWwpKTtcbn1cbmZ1bmN0aW9uIGFwcGVuZF9kZXYodGFyZ2V0LCBub2RlKSB7XG4gICAgZGlzcGF0Y2hfZGV2KFwiU3ZlbHRlRE9NSW5zZXJ0XCIsIHsgdGFyZ2V0LCBub2RlIH0pO1xuICAgIGFwcGVuZCh0YXJnZXQsIG5vZGUpO1xufVxuZnVuY3Rpb24gaW5zZXJ0X2Rldih0YXJnZXQsIG5vZGUsIGFuY2hvcikge1xuICAgIGRpc3BhdGNoX2RldihcIlN2ZWx0ZURPTUluc2VydFwiLCB7IHRhcmdldCwgbm9kZSwgYW5jaG9yIH0pO1xuICAgIGluc2VydCh0YXJnZXQsIG5vZGUsIGFuY2hvcik7XG59XG5mdW5jdGlvbiBkZXRhY2hfZGV2KG5vZGUpIHtcbiAgICBkaXNwYXRjaF9kZXYoXCJTdmVsdGVET01SZW1vdmVcIiwgeyBub2RlIH0pO1xuICAgIGRldGFjaChub2RlKTtcbn1cbmZ1bmN0aW9uIGRldGFjaF9iZXR3ZWVuX2RldihiZWZvcmUsIGFmdGVyKSB7XG4gICAgd2hpbGUgKGJlZm9yZS5uZXh0U2libGluZyAmJiBiZWZvcmUubmV4dFNpYmxpbmcgIT09IGFmdGVyKSB7XG4gICAgICAgIGRldGFjaF9kZXYoYmVmb3JlLm5leHRTaWJsaW5nKTtcbiAgICB9XG59XG5mdW5jdGlvbiBkZXRhY2hfYmVmb3JlX2RldihhZnRlcikge1xuICAgIHdoaWxlIChhZnRlci5wcmV2aW91c1NpYmxpbmcpIHtcbiAgICAgICAgZGV0YWNoX2RldihhZnRlci5wcmV2aW91c1NpYmxpbmcpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGRldGFjaF9hZnRlcl9kZXYoYmVmb3JlKSB7XG4gICAgd2hpbGUgKGJlZm9yZS5uZXh0U2libGluZykge1xuICAgICAgICBkZXRhY2hfZGV2KGJlZm9yZS5uZXh0U2libGluZyk7XG4gICAgfVxufVxuZnVuY3Rpb24gbGlzdGVuX2Rldihub2RlLCBldmVudCwgaGFuZGxlciwgb3B0aW9ucywgaGFzX3ByZXZlbnRfZGVmYXVsdCwgaGFzX3N0b3BfcHJvcGFnYXRpb24pIHtcbiAgICBjb25zdCBtb2RpZmllcnMgPSBvcHRpb25zID09PSB0cnVlID8gW1wiY2FwdHVyZVwiXSA6IG9wdGlvbnMgPyBBcnJheS5mcm9tKE9iamVjdC5rZXlzKG9wdGlvbnMpKSA6IFtdO1xuICAgIGlmIChoYXNfcHJldmVudF9kZWZhdWx0KVxuICAgICAgICBtb2RpZmllcnMucHVzaCgncHJldmVudERlZmF1bHQnKTtcbiAgICBpZiAoaGFzX3N0b3BfcHJvcGFnYXRpb24pXG4gICAgICAgIG1vZGlmaWVycy5wdXNoKCdzdG9wUHJvcGFnYXRpb24nKTtcbiAgICBkaXNwYXRjaF9kZXYoXCJTdmVsdGVET01BZGRFdmVudExpc3RlbmVyXCIsIHsgbm9kZSwgZXZlbnQsIGhhbmRsZXIsIG1vZGlmaWVycyB9KTtcbiAgICBjb25zdCBkaXNwb3NlID0gbGlzdGVuKG5vZGUsIGV2ZW50LCBoYW5kbGVyLCBvcHRpb25zKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBkaXNwYXRjaF9kZXYoXCJTdmVsdGVET01SZW1vdmVFdmVudExpc3RlbmVyXCIsIHsgbm9kZSwgZXZlbnQsIGhhbmRsZXIsIG1vZGlmaWVycyB9KTtcbiAgICAgICAgZGlzcG9zZSgpO1xuICAgIH07XG59XG5mdW5jdGlvbiBhdHRyX2Rldihub2RlLCBhdHRyaWJ1dGUsIHZhbHVlKSB7XG4gICAgYXR0cihub2RlLCBhdHRyaWJ1dGUsIHZhbHVlKTtcbiAgICBpZiAodmFsdWUgPT0gbnVsbClcbiAgICAgICAgZGlzcGF0Y2hfZGV2KFwiU3ZlbHRlRE9NUmVtb3ZlQXR0cmlidXRlXCIsIHsgbm9kZSwgYXR0cmlidXRlIH0pO1xuICAgIGVsc2VcbiAgICAgICAgZGlzcGF0Y2hfZGV2KFwiU3ZlbHRlRE9NU2V0QXR0cmlidXRlXCIsIHsgbm9kZSwgYXR0cmlidXRlLCB2YWx1ZSB9KTtcbn1cbmZ1bmN0aW9uIHByb3BfZGV2KG5vZGUsIHByb3BlcnR5LCB2YWx1ZSkge1xuICAgIG5vZGVbcHJvcGVydHldID0gdmFsdWU7XG4gICAgZGlzcGF0Y2hfZGV2KFwiU3ZlbHRlRE9NU2V0UHJvcGVydHlcIiwgeyBub2RlLCBwcm9wZXJ0eSwgdmFsdWUgfSk7XG59XG5mdW5jdGlvbiBkYXRhc2V0X2Rldihub2RlLCBwcm9wZXJ0eSwgdmFsdWUpIHtcbiAgICBub2RlLmRhdGFzZXRbcHJvcGVydHldID0gdmFsdWU7XG4gICAgZGlzcGF0Y2hfZGV2KFwiU3ZlbHRlRE9NU2V0RGF0YXNldFwiLCB7IG5vZGUsIHByb3BlcnR5LCB2YWx1ZSB9KTtcbn1cbmZ1bmN0aW9uIHNldF9kYXRhX2Rldih0ZXh0LCBkYXRhKSB7XG4gICAgZGF0YSA9ICcnICsgZGF0YTtcbiAgICBpZiAodGV4dC5kYXRhID09PSBkYXRhKVxuICAgICAgICByZXR1cm47XG4gICAgZGlzcGF0Y2hfZGV2KFwiU3ZlbHRlRE9NU2V0RGF0YVwiLCB7IG5vZGU6IHRleHQsIGRhdGEgfSk7XG4gICAgdGV4dC5kYXRhID0gZGF0YTtcbn1cbmNsYXNzIFN2ZWx0ZUNvbXBvbmVudERldiBleHRlbmRzIFN2ZWx0ZUNvbXBvbmVudCB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgICAgICBpZiAoIW9wdGlvbnMgfHwgKCFvcHRpb25zLnRhcmdldCAmJiAhb3B0aW9ucy4kJGlubGluZSkpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgJ3RhcmdldCcgaXMgYSByZXF1aXJlZCBvcHRpb25gKTtcbiAgICAgICAgfVxuICAgICAgICBzdXBlcigpO1xuICAgIH1cbiAgICAkZGVzdHJveSgpIHtcbiAgICAgICAgc3VwZXIuJGRlc3Ryb3koKTtcbiAgICAgICAgdGhpcy4kZGVzdHJveSA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUud2FybihgQ29tcG9uZW50IHdhcyBhbHJlYWR5IGRlc3Ryb3llZGApOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLWNvbnNvbGVcbiAgICAgICAgfTtcbiAgICB9XG59XG5mdW5jdGlvbiBsb29wX2d1YXJkKHRpbWVvdXQpIHtcbiAgICBjb25zdCBzdGFydCA9IERhdGUubm93KCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgaWYgKERhdGUubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgSW5maW5pdGUgbG9vcCBkZXRlY3RlZGApO1xuICAgICAgICB9XG4gICAgfTtcbn1cblxuZXhwb3J0IHsgSHRtbFRhZywgU3ZlbHRlQ29tcG9uZW50LCBTdmVsdGVDb21wb25lbnREZXYsIFN2ZWx0ZUVsZW1lbnQsIGFkZF9hdHRyaWJ1dGUsIGFkZF9jbGFzc2VzLCBhZGRfZmx1c2hfY2FsbGJhY2ssIGFkZF9sb2NhdGlvbiwgYWRkX3JlbmRlcl9jYWxsYmFjaywgYWRkX3Jlc2l6ZV9saXN0ZW5lciwgYWRkX3RyYW5zZm9ybSwgYWZ0ZXJVcGRhdGUsIGFwcGVuZCwgYXBwZW5kX2RldiwgYXNzaWduLCBhdHRyLCBhdHRyX2RldiwgYmVmb3JlVXBkYXRlLCBiaW5kLCBiaW5kaW5nX2NhbGxiYWNrcywgYmxhbmtfb2JqZWN0LCBidWJibGUsIGNoZWNrX291dHJvcywgY2hpbGRyZW4sIGNsYWltX2NvbXBvbmVudCwgY2xhaW1fZWxlbWVudCwgY2xhaW1fc3BhY2UsIGNsYWltX3RleHQsIGNsZWFyX2xvb3BzLCBjb21wb25lbnRfc3Vic2NyaWJlLCBjcmVhdGVFdmVudERpc3BhdGNoZXIsIGNyZWF0ZV9hbmltYXRpb24sIGNyZWF0ZV9iaWRpcmVjdGlvbmFsX3RyYW5zaXRpb24sIGNyZWF0ZV9jb21wb25lbnQsIGNyZWF0ZV9pbl90cmFuc2l0aW9uLCBjcmVhdGVfb3V0X3RyYW5zaXRpb24sIGNyZWF0ZV9zbG90LCBjcmVhdGVfc3NyX2NvbXBvbmVudCwgY3VycmVudF9jb21wb25lbnQsIGN1c3RvbV9ldmVudCwgZGF0YXNldF9kZXYsIGRlYnVnLCBkZXN0cm95X2Jsb2NrLCBkZXN0cm95X2NvbXBvbmVudCwgZGVzdHJveV9lYWNoLCBkZXRhY2gsIGRldGFjaF9hZnRlcl9kZXYsIGRldGFjaF9iZWZvcmVfZGV2LCBkZXRhY2hfYmV0d2Vlbl9kZXYsIGRldGFjaF9kZXYsIGRpcnR5X2NvbXBvbmVudHMsIGRpc3BhdGNoX2RldiwgZWFjaCwgZWxlbWVudCwgZWxlbWVudF9pcywgZW1wdHksIGVzY2FwZSwgZXNjYXBlZCwgZXhjbHVkZV9pbnRlcm5hbF9wcm9wcywgZml4X2FuZF9kZXN0cm95X2Jsb2NrLCBmaXhfYW5kX291dHJvX2FuZF9kZXN0cm95X2Jsb2NrLCBmaXhfcG9zaXRpb24sIGZsdXNoLCBnZXRDb250ZXh0LCBnZXRfYmluZGluZ19ncm91cF92YWx1ZSwgZ2V0X2N1cnJlbnRfY29tcG9uZW50LCBnZXRfc2xvdF9jaGFuZ2VzLCBnZXRfc2xvdF9jb250ZXh0LCBnZXRfc3ByZWFkX29iamVjdCwgZ2V0X3NwcmVhZF91cGRhdGUsIGdldF9zdG9yZV92YWx1ZSwgZ2xvYmFscywgZ3JvdXBfb3V0cm9zLCBoYW5kbGVfcHJvbWlzZSwgaGFzX3Byb3AsIGlkZW50aXR5LCBpbml0LCBpbnNlcnQsIGluc2VydF9kZXYsIGludHJvcywgaW52YWxpZF9hdHRyaWJ1dGVfbmFtZV9jaGFyYWN0ZXIsIGlzX2NsaWVudCwgaXNfZnVuY3Rpb24sIGlzX3Byb21pc2UsIGxpc3RlbiwgbGlzdGVuX2RldiwgbG9vcCwgbG9vcF9ndWFyZCwgbWVhc3VyZSwgbWlzc2luZ19jb21wb25lbnQsIG1vdW50X2NvbXBvbmVudCwgbm9vcCwgbm90X2VxdWFsLCBub3csIG51bGxfdG9fZW1wdHksIG9iamVjdF93aXRob3V0X3Byb3BlcnRpZXMsIG9uRGVzdHJveSwgb25Nb3VudCwgb25jZSwgb3V0cm9fYW5kX2Rlc3Ryb3lfYmxvY2ssIHByZXZlbnRfZGVmYXVsdCwgcHJvcF9kZXYsIHJhZiwgcnVuLCBydW5fYWxsLCBzYWZlX25vdF9lcXVhbCwgc2NoZWR1bGVfdXBkYXRlLCBzZWxlY3RfbXVsdGlwbGVfdmFsdWUsIHNlbGVjdF9vcHRpb24sIHNlbGVjdF9vcHRpb25zLCBzZWxlY3RfdmFsdWUsIHNlbGYsIHNldENvbnRleHQsIHNldF9hdHRyaWJ1dGVzLCBzZXRfY3VycmVudF9jb21wb25lbnQsIHNldF9jdXN0b21fZWxlbWVudF9kYXRhLCBzZXRfZGF0YSwgc2V0X2RhdGFfZGV2LCBzZXRfaW5wdXRfdHlwZSwgc2V0X2lucHV0X3ZhbHVlLCBzZXRfbm93LCBzZXRfcmFmLCBzZXRfc3RvcmVfdmFsdWUsIHNldF9zdHlsZSwgc2V0X3N2Z19hdHRyaWJ1dGVzLCBzcGFjZSwgc3ByZWFkLCBzdG9wX3Byb3BhZ2F0aW9uLCBzdWJzY3JpYmUsIHN2Z19lbGVtZW50LCB0ZXh0LCB0aWNrLCB0aW1lX3Jhbmdlc190b19hcnJheSwgdG9fbnVtYmVyLCB0b2dnbGVfY2xhc3MsIHRyYW5zaXRpb25faW4sIHRyYW5zaXRpb25fb3V0LCB1cGRhdGVfa2V5ZWRfZWFjaCwgdmFsaWRhdGVfY29tcG9uZW50LCB2YWxpZGF0ZV9zdG9yZSwgeGxpbmtfYXR0ciB9O1xuIiwidmFyIGc7XG5cbi8vIFRoaXMgd29ya3MgaW4gbm9uLXN0cmljdCBtb2RlXG5nID0gKGZ1bmN0aW9uKCkge1xuXHRyZXR1cm4gdGhpcztcbn0pKCk7XG5cbnRyeSB7XG5cdC8vIFRoaXMgd29ya3MgaWYgZXZhbCBpcyBhbGxvd2VkIChzZWUgQ1NQKVxuXHRnID0gZyB8fCBuZXcgRnVuY3Rpb24oXCJyZXR1cm4gdGhpc1wiKSgpO1xufSBjYXRjaCAoZSkge1xuXHQvLyBUaGlzIHdvcmtzIGlmIHRoZSB3aW5kb3cgcmVmZXJlbmNlIGlzIGF2YWlsYWJsZVxuXHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJvYmplY3RcIikgZyA9IHdpbmRvdztcbn1cblxuLy8gZyBjYW4gc3RpbGwgYmUgdW5kZWZpbmVkLCBidXQgbm90aGluZyB0byBkbyBhYm91dCBpdC4uLlxuLy8gV2UgcmV0dXJuIHVuZGVmaW5lZCwgaW5zdGVhZCBvZiBub3RoaW5nIGhlcmUsIHNvIGl0J3Ncbi8vIGVhc2llciB0byBoYW5kbGUgdGhpcyBjYXNlLiBpZighZ2xvYmFsKSB7IC4uLn1cblxubW9kdWxlLmV4cG9ydHMgPSBnO1xuIiwibW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbihvcmlnaW5hbE1vZHVsZSkge1xuXHRpZiAoIW9yaWdpbmFsTW9kdWxlLndlYnBhY2tQb2x5ZmlsbCkge1xuXHRcdHZhciBtb2R1bGUgPSBPYmplY3QuY3JlYXRlKG9yaWdpbmFsTW9kdWxlKTtcblx0XHQvLyBtb2R1bGUucGFyZW50ID0gdW5kZWZpbmVkIGJ5IGRlZmF1bHRcblx0XHRpZiAoIW1vZHVsZS5jaGlsZHJlbikgbW9kdWxlLmNoaWxkcmVuID0gW107XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG1vZHVsZSwgXCJsb2FkZWRcIiwge1xuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdGdldDogZnVuY3Rpb24oKSB7XG5cdFx0XHRcdHJldHVybiBtb2R1bGUubDtcblx0XHRcdH1cblx0XHR9KTtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobW9kdWxlLCBcImlkXCIsIHtcblx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRnZXQ6IGZ1bmN0aW9uKCkge1xuXHRcdFx0XHRyZXR1cm4gbW9kdWxlLmk7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG1vZHVsZSwgXCJleHBvcnRzXCIsIHtcblx0XHRcdGVudW1lcmFibGU6IHRydWVcblx0XHR9KTtcblx0XHRtb2R1bGUud2VicGFja1BvbHlmaWxsID0gMTtcblx0fVxuXHRyZXR1cm4gbW9kdWxlO1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=