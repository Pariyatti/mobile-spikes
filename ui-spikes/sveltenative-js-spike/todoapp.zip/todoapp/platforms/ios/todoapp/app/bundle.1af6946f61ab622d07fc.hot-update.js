webpackHotUpdate("bundle",{

/***/ "./app.css":
/***/ (function(module, exports) {

throw new Error("Module build failed (from ../node_modules/nativescript-dev-webpack/css2json-loader.js):\nError: undefined:21:1: property missing ':'\n    at error (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/@nativescript/core/css/lib/parse/index.js:62:15)\n    at declaration (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/@nativescript/core/css/lib/parse/index.js:223:33)\n    at declarations (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/@nativescript/core/css/lib/parse/index.js:252:19)\n    at rule (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/@nativescript/core/css/lib/parse/index.js:560:21)\n    at rules (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/@nativescript/core/css/lib/parse/index.js:117:70)\n    at stylesheet (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/@nativescript/core/css/lib/parse/index.js:81:21)\n    at Object.module.exports [as parse] (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/@nativescript/core/css/lib/parse/index.js:564:20)\n    at Object.loader (/Users/stevehanlon/coding/javascript/SVELTE_NATIVE/todoapp/node_modules/nativescript-dev-webpack/css2json-loader.js:12:23)");

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJidW5kbGUuMWFmNjk0NmY2MWFiNjIyZDA3ZmMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIifQ==