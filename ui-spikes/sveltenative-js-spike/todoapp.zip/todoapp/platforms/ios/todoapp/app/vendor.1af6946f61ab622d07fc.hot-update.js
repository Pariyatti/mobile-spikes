webpackHotUpdate("vendor",{

/***/ "../node_modules/nativescript-theme-core/css/core.css":
false

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ2ZW5kb3IuMWFmNjk0NmY2MWFiNjIyZDA3ZmMuaG90LXVwZGF0ZS5qcyIsInNvdXJjZVJvb3QiOiIifQ==